﻿using System;
namespace DANSE_v4
{
    unsafe partial class cUserTransport : cTransport
    {
        /////////////////////////////////////////////
        // Do not modify anything above this line. //
        /////////////////////////////////////////////
        //
        // This file can be used to enter code for a 
        // user-defined transport layer.  Dummy versions
        // for the required functions are provided:

        [Serializable] struct TransportHeader
        {
            // The only necessary things are the destination and source
            // port numbers.
            internal byte destinationPort;
            internal byte sourcePort;
        }

        void PacketArrivesFromNetworkLayer(cPacket packet, int sourceNode)
        {
            // Get a pointer to the TransportHeader and cast to the structure type:
            TransportHeader* thisHeader = (TransportHeader*)RemoveHeader(packet);

            // Then send the packet up to the application layer:
            SendPacketToApplicationLayer(packet, sourceNode, 
                thisHeader->destinationPort, thisHeader->sourcePort);
        }

        void PacketArrivesFromApplicationLayer(cPacket packet, int destinationNode, 
            int destinationPort, int sourcePort)
        {
            // Generate a new TransportHeader:
            TransportHeader MyHeader;
            MyHeader.destinationPort = (byte)destinationPort;
            MyHeader.sourcePort = (byte)sourcePort;
            // Add the header to the packet, 
            AddHeader(packet, (byte*)&MyHeader, sizeof(TransportHeader));
            // Send the packet down to the network layer:
            SendPacketToNetworkLayer(packet, destinationNode);
        }

        void Callback(int A, cPacket packet = null)
        {
            // No callbacks ever requested, so nothing to do.
        }

        void Initialise(double A, double B, double C, double D)
        {
            // Nothing to initialise.
        }

        void Shutdown()
        {
            // No dynamically assigned memory to free up.
        }

        /////////////////////////////////////////////
        // Do not modify anything below this line. //
        /////////////////////////////////////////////
    }
}
