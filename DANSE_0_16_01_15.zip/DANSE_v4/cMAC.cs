﻿using System;
namespace DANSE_v4
{
    unsafe partial class cUserMAC : cMAC
    {
        /////////////////////////////////////////////
        // Do not modify anything above this line. //
        /////////////////////////////////////////////
        //
        // This file can be used to enter code for a 
        // user-defined transport layer.  Dummy versions
        // for the required functions are provided:

        [Serializable]
        struct MACHeader
        {
            // Just contains the destination (next-hop) 
            // and source (current node) addresses:
            internal byte destinationNode;
            internal byte sourceNode;
        }

        [Serializable]
        struct ExplorerHeader
        {
            // Just contains the next-hop:
            internal byte nextHop;
        }

        // A couple of variables that have to be remembered
        // between calls to different functions:
        Boolean bWakeUpNextTime = true;  // True if this node has to wake up next time
        Boolean bExplorerCycle = true;   // True for an explorer cycle, false for data
        Boolean bMyTurnNextTime = false; // True if this node can send data in the next cycle
        Boolean bExplorerReceived = false;  // Records if an explorer received already

        void PacketArrivesFromPhysicalLayer(cPacket packet, double rxPower)
        {
            // I'll need to know who I am:
            int ME = GetMyNumber();

            // Is this an explorer header?
            if (packet.GetPacketSize() < 2)
            {
                bExplorerReceived = true;
                ExplorerHeader* explore = (ExplorerHeader*)RemoveHeader(packet);
                int exploreNextHop = explore->nextHop;
                if (exploreNextHop == ME || exploreNextHop == BROADCAST) bWakeUpNextTime = true;
                else bWakeUpNextTime = false;
            }
            else
            {
                // Get the header from the packet:
                MACHeader* header = (MACHeader*)RemoveHeader(packet);
                // Find out where it came from and where it was going:
                int sourceNode = header->sourceNode;
                int destinationNode = header->destinationNode;
                // If I'm supposed to receive it, send it up to the logical-link layer:
                if (destinationNode == ME || destinationNode == BROADCAST)
                {
                    // Pass straight up to the logical-link layer:
                    SendPacketToLogicalLinkLayer(packet, sourceNode);
                }
            }

            // Might as well go to sleep now, since nothing more is going to
            // happen in this wake-up cycle (only one packet is sent
            // per cycle):
            GoToSleep();
        }

        void PacketArrivesFromLogicalLinkLayer(cPacket packet, int nextHop)
        {
            // Generate a MAC-layer header for this packet:
            MACHeader newHeader;
            newHeader.destinationNode = (byte)nextHop;
            newHeader.sourceNode = (byte)GetMyNumber();
            // Add this header to the packet:
            AddHeader(packet, (byte*)&newHeader, sizeof(MACHeader));

            // Put packet in the queue for sending later:
            PutPacketInQueue(packet);
        }

        double SLEEP_TIME = 1.0;
        double WAKE_TIME = 1.0;
        double MAX_RANDOM_WAIT = 0.1;

        const int LENGTHEN_CYCLE = 4; // Makes code more readable

        void Callback(int A, cPacket packet)
        {
            switch (A)
            {
                case 0: //Wake up now (if I'm supposed to):
                    if (bWakeUpNextTime == true) WakeUp();
                    RequestRelativeCallback(WAKE_TIME, 1);

                    // Reset the "WakeUpNextTime" flag:
                    bWakeUpNextTime = true;

                    // There are two types of cycle now: explorer and data.
                    // I need to know what sort of cycle this is:
                    bExplorerCycle = !bExplorerCycle;

                    // If it's an explorer cycle, then I need to contend for
                    // the opportunity to send an explorer:
                    if (bExplorerCycle == true)
                    {
                        bExplorerReceived = false; // Reset flag 
                        if (GetQueueLength() > 0)
                        {
                            double Wait_Time = rand() / (double)RAND_MAX * MAX_RANDOM_WAIT;
                            RequestRelativeCallback(Wait_Time, 2);
                        }
                    }

                        // if it isn't an explorer cycle, then if it's my turn to transmit
                        // (i.e. I won the last contention round), then I can transmit
                        // a data packet.  No need to wait a random time, since I am no
                        // longer in competition with anyone else.
                    else
                    {
                        if (bMyTurnNextTime == true)
                        {
                            cPacket toSend = GetPacketInQueue(0);
                            RemovePacketFromQueue(0);
                            SendPacketToPhysicalLayer(toSend, 3.27e-5);
                        }
                        bMyTurnNextTime = false; // Reset the flag
                    }
                    break;

                case 2: // Transmit now if channel is clear and no-one's sent an
                    // explorer already (note this second condition now required
                    // since explorer can be much shorter than the random wait
                    // interval.
                    if (IsChannelQuiet() == true && bExplorerReceived == false)
                    {
                        // I need to find out where the packet in the queue is
                        // going to:
                        cPacket nextToGo = GetPacketInQueue(0);
                        MACHeader* nextToGoMAC = (MACHeader *)ViewHeader(nextToGo);
                        int nextHop = nextToGoMAC->destinationNode;

                        // Then send an explorer packet with this data:
                        cPacket explore = MakePacket(null, 0);
                        SetPacketTag(explore, "Explore to " + nextHop);
                        ExplorerHeader exploreHead;
                        exploreHead.nextHop = (byte)nextHop;
                        AddHeader(explore, (byte*)&exploreHead, 1);
                        SendPacketToPhysicalLayer(explore, 7.29e-3);

                        // And note it will be my turn to transmit next cycle:
                        bMyTurnNextTime = true;
                    }
                    break;
                case 1: // Go to sleep now
                    RequestRelativeCallback(SLEEP_TIME, 0);
                    GoToSleep();
                    break;
                case LENGTHEN_CYCLE: // Lengthen the cycles
                    SLEEP_TIME = 1.0;
                    WAKE_TIME = 1.0;
                    MAX_RANDOM_WAIT = 0.1;
                    break;
                default:
                    break;
            }
        }

        void Initialise(double A, double B, double C, double D, double E, double F, double G)
        {
            // Register the first wake-up cycle start
            RequestRelativeCallback(WAKE_TIME, 1);

            // The first cycle has top be an explorer cycle, and everyone has to wake up,
            // but it's no-one's turn to send data, and no-ones had an explorer yet:
            bExplorerCycle = true;
            bWakeUpNextTime = true;
            bMyTurnNextTime = false;
            bExplorerReceived = false;

            // There's another problem: if using Bellman-Ford, you'll need a lot of 
            // transmissions from each node to be reasonably sure the tables have built
            // up in time for the data to start after 100 seconds.  That suggests a
            // cycle time of maximum 100 / (12 * 12) / 2  / 2 = 0.16 seconds.
            // However, that's too fast a cycle time for the data, since data packets will
            // take longer than that to be sent.  Only solution is to change the cycle time
            // after the routeing tables have been built up:
            SLEEP_TIME = 0.05;
            WAKE_TIME = 0.2;
            MAX_RANDOM_WAIT = 0.01;
            RequestAbsoluteCallback(99.9, LENGTHEN_CYCLE);
        }

        void Shutdown()
        {
            // No dynamically assigned memory to free up.
        }

        int packetsSentSoFar = 0;  // Keep a count of packets sent
        override internal string AskQuery(string s)
        {
            return "MAC layer of node " + GetMyNumber().ToString() + " has sent " + packetsSentSoFar + " packets.";
        }

        /////////////////////////////////////////////
        // Do not modify anything below this line. //
        /////////////////////////////////////////////
    }
}
