﻿using System;
using System.Windows;

namespace DANSE_v4
{
    /// <summary>
    /// Interaction logic for Window1.xaml.  Most of the routines for 
    /// interacting with the user controls are in the file cMainWindowStuff.cs,
    /// this is just a header file stored here to get things started.
    /// 
    /// Don't change anything in this file.
    /// </summary>

    public partial class MainWindow : Window
    {
        // This installed so I can call UI functions from a background thread:
        public static MainWindow myMain;

        public MainWindow()
        {
            myMain = this;
            Globals.SettingUp = true;
            InitializeComponent();
            Globals.MainWindow = this;
            Globals.MainCanvas = this.canvasMain;
            Globals.OutputCanvas = this.canvasOutput;
            Globals.NodeCanvas = this.Canvas2D;
            InitReScaling();
            SetCanvasToRightSize(Canvas2D, canvasMain);
            Globals.LineRouteDashes.Add(2);
            Globals.LineRouteDashes.Add(2);

            // Set-up the controls on the "Setup Simulation" panel and elsewhere:
            SetUpControlsOnSimulationPanel();
            SetUpShadowControls();
            SetUpLogWhichNodesCombo();
            SetUpPHYActivityGraph();

            // Set-up the timer, load defaults, then reset the simulation (note
            // this has to be done in this order, otherwise the simulator is
            // not properly reset).
            SetUpTimer();
            Globals.SettingUp = false;
            cXMLStuff.XMLLoadDefaultConfiguration();
            ResetSimulation();
            Boolean BatchMode = cXMLStuff.XMLRunAnyCommandLineFiles();
            if (BatchMode) { this.Hide(); this.Close(); }
        }

    }
}

