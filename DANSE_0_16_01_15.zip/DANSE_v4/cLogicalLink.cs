﻿using System;
namespace DANSE_v4
{
    unsafe partial class cUserLLC : cLogicalLink
    {
        /////////////////////////////////////////////
        // Do not modify anything above this line. //
        /////////////////////////////////////////////
        //
        // This file can be used to enter code for a 
        // user-defined logical-link layer.  Dummy versions
        // for the required functions are provided:

        [Serializable] struct LogicalLinkHeader
        {
            // By default, I won't add a logical-link header.
        }

        void PacketArrivesFromMACLayer(cPacket packet, int lastHop)
        {
            LogicalLinkHeader ThisHeader = (LogicalLinkHeader) packet.RemoveHeader();
            SendPacketToNetworkLayer(packet, lastHop);
        }

        void PacketArrivesFromNetworkLayer(cPacket packet, int nextHop)
        {
            SendPacketToMACLayer(packet, nextHop);
        }

        void Callback(int A, cPacket packet = null)
        {
            // No callbacks ever requested, so nothing to do.
        }

        void Initialise(double A, double B, double C, double D)
        {
            // Nothing to initialise.
        }

        void Shutdown()
        {
            // No dynamically assigned memory to free up.
        }

        /////////////////////////////////////////////
        // Do not modify anything below this line. //
        /////////////////////////////////////////////
    }
}
