﻿using System;
namespace DANSE_v4
{
    unsafe partial class cUserNetwork : cNetwork
    {
        /////////////////////////////////////////////
        // Do not modify anything above this line. //
        /////////////////////////////////////////////
        //
        // This file can be used to enter code for a 
        // user-defined network layer.  Dummy versions
        // for the required functions are provided.

        [Serializable]
        struct NetworkHeader
        {
            internal byte sourceNode;
            internal byte destinationNode;
        }

        void PacketArrivesFromLogicalLinkLayer(cPacket packet, int receivedFrom)
        {
            // Get a pointer to the NetworkHeader and cast to the structure type:
            NetworkHeader* thisHeader = (NetworkHeader*)ViewHeader(packet);

            // If the packet is addressed to me, get the source node and send
            // the packet up to the transport layer:
            if (thisHeader->destinationNode == GetMyNumber())
            {
                int sourceNode = thisHeader->sourceNode;
                RemoveHeader(packet);
                SendPacketToTransportLayer(packet, sourceNode);
            }
            else
            {
                // Set crosslayer flag to false:
                SetCrossLayer(packet, false);
                // send to the logical link layer:
                SendPacketToLogicalLinkLayer(packet, GetNextHop(thisHeader->destinationNode));
            }
        }


        void PacketArrivesFromTransportLayer(cPacket packet, int destination)
        {
            if (destination == GetMyNumber())
            {
                // If packet is addressed to me, send it right back up to the transport layer:
                SendPacketToTransportLayer(packet, GetMyNumber());
            }
            else
            {
                // Otherwise it must be for someone else, so generate a new NetworkHeader,
                NetworkHeader MyHeader;
                MyHeader.destinationNode = (byte)destination;
                MyHeader.sourceNode = (byte)GetMyNumber();
                // Add the header to the packet,
                AddHeader(packet, (byte*)&MyHeader, sizeof(NetworkHeader));
                // Add crosslayer information saying that this is a new packet
                SetCrossLayer(packet, true);
                // Set the next hop to the final destination, and send the packet
                // down to the logical-link layer:
                int nextHop = destination;
                SendPacketToLogicalLinkLayer(packet, GetNextHop(destination));

            }
        }

        void Callback(int A, cPacket packet = null)
        {
            // Things to do when a callback occurs.
        }

        int GetNextHop(int destination)
        {
            int thisNode = GetMyNumber();
            // an interger value used for assigning direction
            int direction = destination - thisNode;

            // Setting which route packets are to take
            if (((direction > -6) && (direction < 0)) || (direction > 6))
            {
                // Clockwise route
                return (thisNode == 0) ? 11 : thisNode - 1;
            }
            // AntiClockwise route             
            return thisNode == 11 ? 0 : thisNode + 1;

        }

        void Initialise(double A, double B, double C, double D, double E, double F, double G)
        {
            // Things to do at the start of the simulation, 
            // before any packets have been sent: set up the 
            // routeing tables (using Bellman-Ford).

        }
        void Shutdown()
        {
        }

        /////////////////////////////////////////////
        // Do not modify anything below this line. //
        /////////////////////////////////////////////
    }
}


