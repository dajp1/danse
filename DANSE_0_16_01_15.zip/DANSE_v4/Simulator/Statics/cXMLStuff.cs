﻿using System;
using System.Text;
using System.Xml;
using System.IO;
using System.Windows;
using System.Threading;
using System.ComponentModel;
using Microsoft.Win32;  // For the file dialogs

namespace DANSE_v4
{
    internal static class cXMLStuff
    {
        // This class contains the loading and saving routines so that entire
        // configurations of the simulator can be loaded from .xml files, and
        // multiple runs done in a batch format for later processing.

        static private string XML_CurrentDirectory = @"C:\";
        static private string XML_DefaultConfiguration = "DANSE_default.xml";

        internal static void XMLSaveConfiguration() //
        {
            // First, prompt user for a filename to save the configuration into:
            try
            {
                SaveFileDialog NewSFD = new SaveFileDialog();
                NewSFD.Title = "Select Filename";
                NewSFD.InitialDirectory = XML_CurrentDirectory;
                NewSFD.Filter = "All files (*.*)|*.*|XML files (*.xml)|*.xml|Text files (*.txt)|*.txt";
                NewSFD.FilterIndex = 2;
                NewSFD.RestoreDirectory = true;
                Nullable<bool> result = NewSFD.ShowDialog();
                if (result == true)
                {
                    // Store the current directory
                    XML_CurrentDirectory = System.IO.Path.GetDirectoryName(NewSFD.FileName);
                    // Save the configuration file code in here (overwrites file with same name)
                    XmlTextWriter ConfigWriter = new XmlTextWriter(NewSFD.FileName, Encoding.UTF8);
                    ConfigWriter.Formatting = Formatting.Indented;
                    ConfigWriter.WriteStartDocument();
                    ConfigWriter.WriteWhitespace("\n");
                    ConfigWriter.WriteStartElement("Configuration");
                    ConfigWriter.WriteWhitespace("\n");
                    // OK, now go through and write all the configuration stuff

                    // The system parameters:
                    StartXMLElement(ConfigWriter, "System");
                    WriteXMLElement(ConfigWriter, Globals._NumberOfNodesName, Globals.NumberOfNodes.ToString());
                    WriteXMLElement(ConfigWriter, Globals._HowToPlaceNodesName, Globals.HowToPlaceNodes.ToString());
                    WriteXMLElement(ConfigWriter, Globals._SimulationLengthName, Globals.SimulationLength.ToString());
                    WriteXMLElement(ConfigWriter, Globals._PrerollLengthName, Globals.PrerollLength.ToString());
                    WriteXMLElement(ConfigWriter, Globals._PostrollLengthName, Globals.PostrollLength.ToString());
                    WriteXMLElement(ConfigWriter, Globals._SwitchingOnName, Globals.SwitchingOn.ToString());
                    WriteXMLElement(ConfigWriter, Globals._ClockSyncName, Globals.ClockSync.ToString());
                    WriteXMLElement(ConfigWriter, Globals._ClockAccuracyName, (Globals.ClockAccuracy * 1e6).ToString());
                    WriteXMLElement(ConfigWriter, Globals._EnergyLeftModeName, Globals.EnergyMode.ToString());
                    EndXMLElement(ConfigWriter);

                    // The movement parameters:
                    StartXMLElement(ConfigWriter, "Movement");
                    WriteXMLElement(ConfigWriter, Globals._MoveTypeName, Globals.MoveMode.ToString());
                    WriteXMLElement(ConfigWriter, Globals._MovementSpeedName, Globals.MovementSpeed.ToString());
                    WriteXMLElement(ConfigWriter, Globals._MovementSpeedSpreadName, Globals.MovementSpeedSpread.ToString());
                    EndXMLElement(ConfigWriter);

                    // The application parameters:
                    StartXMLElement(ConfigWriter, "Application");
                    WriteXMLElement(ConfigWriter, Globals._TrafficDistributionName, Globals.TrafficDistribution.ToString());
                    WriteXMLElement(ConfigWriter, Globals._TrafficGenerateRateName, Globals.TrafficGenerateRate.ToString());
                    WriteXMLElement(ConfigWriter, Globals._PacketDistributionName, Globals.PacketDistribution.ToString());
                    WriteXMLElement(ConfigWriter, Globals._MeanPacketSizeName, Globals.MeanPacketSize.ToString());
                    WriteXMLElement(ConfigWriter, Globals._PacketPriorityName, Globals.PacketPriority.ToString());
                    WriteXMLElement(ConfigWriter, Globals._WhereToSendPacketsName, Globals.WhereToSendPackets.ToString());
                    EndXMLElement(ConfigWriter);

                    // Note: for the user-controllable protocols, always do the style first, since when 
                    // loading a style the other parameters are reset to default values.

                    // The transport parameters:
                    StartXMLElement(ConfigWriter, "Transport");
                    WriteXMLElement(ConfigWriter, Globals._TransportStyleName, Globals.TransportStyle.ToString());
                    WriteXMLElement(ConfigWriter, Globals._TransportTimeOutName, Globals.TransportTimeOut.ToString());
                    WriteXMLElement(ConfigWriter, Globals._TransportRetriesName, Globals.TransportRetries.ToString());
                    WriteXMLElement(ConfigWriter, Globals._TransportParameterOneName, Globals.TransportParameterOne.ToString());
                    WriteXMLElement(ConfigWriter, Globals._TransportParameterTwoName, Globals.TransportParameterTwo.ToString());
                    WriteXMLElement(ConfigWriter, Globals._TransportParameterThreeName, Globals.TransportParameterThree.ToString());
                    WriteXMLElement(ConfigWriter, Globals._TransportParameterFourName, Globals.TransportParameterFour.ToString());
                    EndXMLElement(ConfigWriter);

                    // The network parameters:
                    StartXMLElement(ConfigWriter, "Network");
                    WriteXMLElement(ConfigWriter, Globals._NetworkStyleName, Globals.NetworkStyle.ToString());
                    WriteXMLElement(ConfigWriter, Globals._NetworkHopCountName, Globals.HopCount.ToString());
                    WriteXMLElement(ConfigWriter, Globals._NetworkParameterOneName, Globals.NetworkParameterOne.ToString());
                    WriteXMLElement(ConfigWriter, Globals._NetworkParameterTwoName, Globals.NetworkParameterTwo.ToString());
                    WriteXMLElement(ConfigWriter, Globals._NetworkParameterThreeName, Globals.NetworkParameterThree.ToString());
                    WriteXMLElement(ConfigWriter, Globals._NetworkParameterFourName, Globals.NetworkParameterFour.ToString());
                    WriteXMLElement(ConfigWriter, Globals._NetworkParameterFiveName, Globals.NetworkParameterFive.ToString());
                    WriteXMLElement(ConfigWriter, Globals._NetworkParameterSixName, Globals.NetworkParameterSix.ToString());
                    WriteXMLElement(ConfigWriter, Globals._NetworkParameterSevenName, Globals.NetworkParameterSeven.ToString());
                    EndXMLElement(ConfigWriter);

                    // The logical link parameters:
                    StartXMLElement(ConfigWriter, "Logical_Link");
                    WriteXMLElement(ConfigWriter, Globals._LogicalLinkStyleName, Globals.LogicalLinkStyle.ToString());
                    WriteXMLElement(ConfigWriter, Globals._LogicalLinkTimeOutName, Globals.LogicalLinkTimeOut.ToString());
                    WriteXMLElement(ConfigWriter, Globals._LogicalLinkRetriesName, Globals.LogicalLinkRetries.ToString());
                    WriteXMLElement(ConfigWriter, Globals._LogicalLinkParameterOneName, Globals.LogicalLinkParameterOne.ToString());
                    WriteXMLElement(ConfigWriter, Globals._LogicalLinkParameterTwoName, Globals.LogicalLinkParameterTwo.ToString());
                    WriteXMLElement(ConfigWriter, Globals._LogicalLinkParameterThreeName, Globals.LogicalLinkParameterThree.ToString());
                    WriteXMLElement(ConfigWriter, Globals._LogicalLinkParameterFourName, Globals.LogicalLinkParameterFour.ToString());
                    EndXMLElement(ConfigWriter);

                    // The multiple access parameters:
                    StartXMLElement(ConfigWriter, "Multiple_Access");
                    WriteXMLElement(ConfigWriter, Globals._MACStyleName, Globals.MACStyle.ToString());
                    WriteXMLElement(ConfigWriter, Globals._MACInitialBackoffName, Globals.MACInitialBackoff.ToString());
                    WriteXMLElement(ConfigWriter, Globals._MACParameterOneName, Globals.MACParameterOne.ToString());
                    WriteXMLElement(ConfigWriter, Globals._MACParameterTwoName, Globals.MACParameterTwo.ToString());
                    WriteXMLElement(ConfigWriter, Globals._MACParameterThreeName, Globals.MACParameterThree.ToString());
                    WriteXMLElement(ConfigWriter, Globals._MACParameterFourName, Globals.MACParameterFour.ToString());
                    WriteXMLElement(ConfigWriter, Globals._MACParameterFiveName, Globals.MACParameterFive.ToString());
                    WriteXMLElement(ConfigWriter, Globals._MACParameterSixName, Globals.MACParameterSix.ToString());
                    WriteXMLElement(ConfigWriter, Globals._MACParameterSevenName, Globals.MACParameterSeven.ToString());
                    EndXMLElement(ConfigWriter);

                    // The physical parameters:
                    StartXMLElement(ConfigWriter, "Physical");
                    WriteXMLElement(ConfigWriter, Globals._PhysicalStyleName, Globals.PhysicalStyle.ToString());
                    WriteXMLElement(ConfigWriter, Globals._DefaultTxPowerName, Globals.DefaultTxPowerdBm.ToString());
                    WriteXMLElement(ConfigWriter, Globals._DefaultBitRateName, Globals.DefaultBitRate.ToString());
                    WriteXMLElement(ConfigWriter, Globals._DetectSINRName, Globals.DetectSINRdB.ToString());
                    WriteXMLElement(ConfigWriter, Globals._PhysicalHeaderSizeName, Globals.PhysicalHeaderSize.ToString());
                    WriteXMLElement(ConfigWriter, Globals._ChannelStyleName, Globals.ChannelStyle.ToString());
                    EndXMLElement(ConfigWriter);

                    // The few physical layer parameters not in the UI:
                    StartXMLElement(ConfigWriter, "Channel");
                    WriteXMLElement(ConfigWriter, "Path_Loss_Constant", Globals.PathLossConstant.ToString());
                    WriteXMLElement(ConfigWriter, "Path_Loss_Exponent", Globals.PathLossExponent.ToString());
                    WriteXMLElement(ConfigWriter, "Noise_Level", (10.0 * Math.Log10(Globals.NoiseFloor) + 30).ToString());
                    EndXMLElement(ConfigWriter);

                    // The energy model parameters:
                    StartXMLElement(ConfigWriter, "Energy");
                    WriteXMLElement(ConfigWriter, "Initial_Energy", Globals.InitialEnergy.ToString());
                    WriteXMLElement(ConfigWriter, "Power_When_Asleep", Globals.PowerWhenRxAsleep.ToString());
                    WriteXMLElement(ConfigWriter, "Power_When_Rx_Off", Globals.PowerWhenRxOff.ToString());
                    WriteXMLElement(ConfigWriter, "Power_When_Listening", Globals.PowerWhenRxListening.ToString());
                    WriteXMLElement(ConfigWriter, "Power_When_Receiving", Globals.PowerWhenRxReceiving.ToString());
                    WriteXMLElement(ConfigWriter, "Power_When_Tx_Off", Globals.PowerWhenTxOff.ToString());
                    WriteXMLElement(ConfigWriter, "Power_When_Transmitting_Offset", Globals.PowerWhenTransmittingOffset.ToString());
                    WriteXMLElement(ConfigWriter, "Power_When_Transmitting_Multiplier", Globals.PowerWhenTransmittingMultiplier.ToString());
                    EndXMLElement(ConfigWriter);

                    // Save configuration also saves any packets in the pre-programmed packet store:
                    for (int loop = 0; loop < Globals.myPacketsToGo.Count; loop++)
                    {
                        StartXMLElement(ConfigWriter, "Packet");
                        WriteXMLElement(ConfigWriter, "Destination", Globals.myPacketsToGo[loop].GetFinalDestination().ToString());
                        WriteXMLElement(ConfigWriter, "Source", Globals.myPacketsToGo[loop].GetOriginalSource().ToString());
                        WriteXMLElement(ConfigWriter, "Priority", Globals.myPacketsToGo[loop].GetPriority().ToString());
                        WriteXMLElement(ConfigWriter, "Length", Globals.myPacketsToGo[loop].GetLength().ToString());
                        WriteXMLElement(ConfigWriter, "Time", Globals.myPacketsToGo[loop].GetStartTime().ToString());
                        EndXMLElement(ConfigWriter);
                    }

                    // OK, that's it, tidy things up:
                    ConfigWriter.WriteEndDocument();
                    ConfigWriter.Close();
                }
            }
            catch (Exception problem)
            {
                string Description = problem.ToString();
                MessageBox.Show(Description + "\nSorry, attempted configuration file write failed.", "Annoying Error");
            }
        }

        internal static void XMLSaveNodes()
        {
              // First, prompt user for a filename to save the configuration into:
            try
            {
                SaveFileDialog NewSFD = new SaveFileDialog();
                NewSFD.Title = "Select Filename";
                NewSFD.InitialDirectory = XML_CurrentDirectory;
                NewSFD.Filter = "All files (*.*)|*.*|XML files (*.xml)|*.xml|Text files (*.txt)|*.txt";
                NewSFD.FilterIndex = 2;
                NewSFD.RestoreDirectory = true;
                Nullable<bool> result = NewSFD.ShowDialog();
                if (result == true)
                {
                    // Store the current directory
                    XML_CurrentDirectory = System.IO.Path.GetDirectoryName(NewSFD.FileName);
                    // Save the configuration file code in here (overwrites file with same name)
                    XmlTextWriter NodeWriter = new XmlTextWriter(NewSFD.FileName, Encoding.UTF8);
                    NodeWriter.Formatting = Formatting.Indented;
                    NodeWriter.WriteStartDocument();
                    NodeWriter.WriteWhitespace("\n");
                    NodeWriter.WriteStartElement("NodesLocations");
                    NodeWriter.WriteWhitespace("\n");
                    // The Node Locations:            
                    foreach (cNode node in Globals.myNodes)
                    {
                        StartXMLElement(NodeWriter, "Node");
                        WriteXMLElement(NodeWriter,"X",node.GetPosition().X.ToString());
                        WriteXMLElement(NodeWriter,"Y",node.GetPosition().Y.ToString());
                        EndXMLElement(NodeWriter);
                    }
                      // OK, that's it, tidy things up:
                    NodeWriter.WriteEndDocument();
                    NodeWriter.Close();
                }
            }
            catch (Exception problem)
            {
                string Description = problem.ToString();
                MessageBox.Show(Description + "\nSorry, attempted configuration file write failed.", "Annoying Error");
            }
        }


        internal static void XMLSavePackets()
        {
            // First, prompt user for a filename to save the configuration into:
            try
            {
                SaveFileDialog NewSFD = new SaveFileDialog();
                NewSFD.Title = "Select Filename";
                NewSFD.InitialDirectory = XML_CurrentDirectory;
                NewSFD.Filter = "All files (*.*)|*.*|XML files (*.xml)|*.xml|Text files (*.txt)|*.txt";
                NewSFD.FilterIndex = 2;
                NewSFD.RestoreDirectory = true;
                Nullable<bool> result = NewSFD.ShowDialog();
                if (result == true)
                {
                    // Store the current directory
                    XML_CurrentDirectory = System.IO.Path.GetDirectoryName(NewSFD.FileName);
                    // Save the configuration file code in here (overwrites file with same name)
                    // First, set up the output document:
                    XmlTextWriter ConfigWriter = new XmlTextWriter(NewSFD.FileName, null);
                    ConfigWriter.Formatting = Formatting.Indented;
                    ConfigWriter.WriteStartDocument();
                    ConfigWriter.WriteWhitespace("\n");
                    ConfigWriter.WriteStartElement("Configuration");
                    ConfigWriter.WriteWhitespace("\n");

                    // OK, now go through and write all the packets stuff:
                    // For each packet this means, for example:
                    //   <Destination>0</Destination>
                    //   <Source>1</Source>
                    //   <Priority>0</Priority>
                    //   <Length>100</Length>
                    //   <Time>1e8</Time>
                    for (int loop = 0; loop < Globals.myPackets.Count; loop++)
                    {
                        StartXMLElement(ConfigWriter, "Packet");
                        WriteXMLElement(ConfigWriter, "Destination", Globals.myPackets[loop].GetFinalDestination().ToString());
                        WriteXMLElement(ConfigWriter, "Source", Globals.myPackets[loop].GetOriginalSource().ToString());
                        WriteXMLElement(ConfigWriter, "Priority", Globals.myPackets[loop].GetPriority().ToString());
                        WriteXMLElement(ConfigWriter, "Length", Globals.myPackets[loop].GetLength().ToString());
                        WriteXMLElement(ConfigWriter, "Time", Globals.myPackets[loop].GetStartTime().ToString());
                        EndXMLElement(ConfigWriter);
                    }

                    // OK, that's it, tidy things up:
                    ConfigWriter.WriteEndDocument();
                    ConfigWriter.Close();
                }
            }
            catch (Exception problem)
            {
                string Description = problem.ToString();
                MessageBox.Show(Description + "\nSorry, attempted packet file write failed.", "Annoying Error");
            }
        }

        static private void StartXMLElement(XmlTextWriter ConfigWriter, string Parameter)
        {
            ConfigWriter.WriteWhitespace("  ");
            ConfigWriter.WriteStartElement(Parameter);
            ConfigWriter.WriteWhitespace("\n");
        }
        static private void EndXMLElement(XmlTextWriter ConfigWriter)
        {
            ConfigWriter.WriteWhitespace("  ");
            ConfigWriter.WriteEndElement();
            ConfigWriter.WriteWhitespace("\n");
        }
        static private void WriteXMLElement(XmlTextWriter ConfigWriter, string Parameter, string Value)
        {
            ConfigWriter.WriteWhitespace("    ");
            ConfigWriter.WriteStartElement(Parameter);
            ConfigWriter.WriteString(Value);
            ConfigWriter.WriteEndElement();
            ConfigWriter.WriteWhitespace("\n");
        }

        internal static void XMLLoadDefaultConfiguration()
        {
            // When the simulator is first started, it has a look in the current
            // directory for a file called XML_DefaultConfiguration and if it finds
            // one, it loads it into the configuration.
            if (File.Exists(XML_DefaultConfiguration))
            {
                XMLParseConfigurationFile(XML_DefaultConfiguration, false, false, false);
            }
        }

        internal static void XMLLoadConfiguration(Boolean RunBatch, Boolean packetsOnly, Boolean nodesOnly)
        {
            // First, prompt user for a filename to load the configuration from:
            try
            {
                OpenFileDialog NewOFD = new OpenFileDialog();
                NewOFD.Title = "Select Filename";
                NewOFD.InitialDirectory = XML_CurrentDirectory;
                NewOFD.Filter = "All files (*.*)|*.*|XML files (*.xml)|*.xml|Text files (*.txt)|*.txt";
                NewOFD.FilterIndex = 2;
                NewOFD.RestoreDirectory = true;
                Nullable<bool> result = NewOFD.ShowDialog();
                if (result == true)
                {
                    // Save the current directory:
                    XML_CurrentDirectory = System.IO.Path.GetDirectoryName(NewOFD.FileName);
                    // Load a configuration from this file if possible:
                    XMLParseConfigurationFile(NewOFD.FileName, RunBatch, packetsOnly, nodesOnly);
                }
            }
            catch (Exception problem)
            {
                string Description = problem.ToString();
                MessageBox.Show(Description + "\nSorry, attempted configuration file read failed.", "Annoying Error");
            }
            // Then reset the simulator:
            ((MainWindow)Globals.MainWindow).ResetSimulation();
        }

        internal static Boolean XMLRunAnyCommandLineFiles()
        {
            // If there are any command line arguments (could specify a batch file),
            // then attempt to load and run this batch file:
            Boolean RunningInBatchMode = false;
            foreach (string arg in Environment.GetCommandLineArgs())
            {
                // Load any configuration files from the command line, and run if required:
                if (arg.Contains(".xml"))
                {
                    // First, set the output directory to wherever the simulator is
                    // being run from.  This is necessary, since otherwise it
                    // defaults to C:\, and windows 7 doesn't allow access there.
                    XML_CurrentDirectory = System.AppDomain.CurrentDomain.BaseDirectory;

                    RunningInBatchMode = true;
                    cXMLStuff.XMLParseConfigurationFile(arg, true, false, false);
                }
            }
            // If return is true (so at least one batch file was specified on the command-line), 
            // the simulator exits immediately and doesn't enter interactive mode.
            return RunningInBatchMode;
        }

        internal static void XMLParseConfigurationFile(string FileName, 
                                    Boolean RunBatch, Boolean packetsOnly, Boolean nodesOnly)
        {
            try
            {
                // Load a configuration from this file if possible:
                XmlTextReader ConfigReader = new XmlTextReader(FileName);
                
                // There's a slight problem that needs fixing: if the number of nodes
                // is read in as a non-square value while the placement is set to 
                // square (for example), the number of nodes will be adjusted even
                // if placement is later changed to random.  Updating the number
                // of nodes should be the last thing done, so I need to remember
                // what the new value is, and do this at the end.
                // (It is done during the run as well, so that RunBatch mode
                // runs as expected when the number of nodes being changed is the
                // dependent variable.)
                int UpdatedNumberOfNodes = 0;

                // Delete any packets in the PacketsToGo list and nodesOnly list
                // if I'm not about to load them in...
                if (nodesOnly == false) Globals.myPacketsToGo.Clear();
                if (packetsOnly == false) Globals.myPreloadedNodes.Clear();
                // then for storing details about packets before writing them out:
                int DestinationNode = 0, SourceNode = 0, PacketLength = 0, Priority = 0;
                // and for storing details about nodes before writing them out:
                double nodeX = 0.0, nodeY = 0.0, nodeEnergy = Globals.InitialEnergy;
                double nodeSpeed = Globals.MovementSpeed;
                double TimeToGo = 0;

                // Read through the file:
                string LastElementName = "";
                while (ConfigReader.Read())
                {
                    XmlNodeType NodeType = ConfigReader.NodeType;
                    if (NodeType == XmlNodeType.Whitespace) continue;
                    if (NodeType == XmlNodeType.Element) LastElementName = ConfigReader.Name;
                    if (NodeType == XmlNodeType.EndElement && ConfigReader.Name == "Packet")
                    {
                        // End of details about a packet.  Add it to MyPacketsToGo:
                        Globals.RawPacketToGoData NewPacketData = new Globals.RawPacketToGoData();
                        NewPacketData.SetOriginalSource(SourceNode);
                        NewPacketData.SetFinalDestination(DestinationNode);
                        NewPacketData.SetPriority(Priority);
                        NewPacketData.SetLength(PacketLength);
                        NewPacketData.SetStartTime((long)TimeToGo);
                        Globals.myPacketsToGo.Add(NewPacketData);
                    }
                    if (NodeType == XmlNodeType.EndElement && ConfigReader.Name == "Node")
                    {
                        // End of details about a node.  Add it to MyPreloadedNodes:
                        Globals.preloadNode NewNode = new Globals.preloadNode();
                        NewNode.X = nodeX;
                        NewNode.Y = nodeY;
                        NewNode.InitialEnergy = nodeEnergy;
                        NewNode.InitialSpeed = nodeSpeed;
                        Globals.myPreloadedNodes.Add(NewNode);
                    }
                    // This might be part of a packet or node being parsed:
                    if (NodeType == XmlNodeType.Text)
                    {
                        if (LastElementName == "Destination") int.TryParse(ConfigReader.Value, out DestinationNode);
                        else if (LastElementName == "Source") int.TryParse(ConfigReader.Value, out SourceNode);
                        else if (LastElementName == "Length") int.TryParse(ConfigReader.Value, out PacketLength);
                        else if (LastElementName == "Priority") int.TryParse(ConfigReader.Value, out Priority);
                        else if (LastElementName == "Time") double.TryParse(ConfigReader.Value, out TimeToGo);
                        else if (LastElementName == "X") double.TryParse(ConfigReader.Value, out nodeX);
                        else if (LastElementName == "Y") double.TryParse(ConfigReader.Value, out nodeY);
                        else if (LastElementName == "InitialEnergy") double.TryParse(ConfigReader.Value, out nodeEnergy);
                        else if (LastElementName == "InitialSpeed") double.TryParse(ConfigReader.Value, out nodeSpeed);
                            // Then this final one does almost everything else:
                        else if (packetsOnly == false) UpdateValue(LastElementName, ConfigReader.Value, ref RunBatch);
                    }
                    if (LastElementName == Globals._NumberOfNodesName && NodeType == XmlNodeType.Text)
                    {
                        int.TryParse(ConfigReader.Value, out UpdatedNumberOfNodes);
                    }
                }
                ConfigReader.Close();

                // I might have been running batch files, in which case I should set
                // the batch status back to default at this point:
                Globals.BatchStatus = Globals.BatchRunStatus.Default;
                
                // Then the number of nodes should be the last thing, in case the 
                // arrangement of nodes has changed and forced a change in the 
                // number of nodes earlier on.
                if (UpdatedNumberOfNodes > 0 && packetsOnly == false)
                    Globals.stsNumberOfNodes.SetSliderValue(UpdatedNumberOfNodes, true);
            }
            catch (Exception problem)
            {
                string Description = problem.ToString();
                if (RunBatch == false)
                    MessageBox.Show(Description + "\nSorry, attempted read of configuration file failed.", "Annoying Error");
                else
                    MessageBox.Show(Description + "\nSorry, attempted batch file run failed.", "Annoying Error");
            }
        }

        private static void UpdateValue(string ElementName, string Value, ref Boolean RunBatch)
        {
            // There are a lot of things this might be; I'll try them all.
            // First, the system parameters box:
            if (ElementName == Globals._NumberOfNodesName)
                Globals.stsNumberOfNodes.SetSliderValue(Value, true);
            else if (ElementName == Globals._HowToPlaceNodesName)
                Globals.ctsHowToPlaceNodes.SetValue<Globals.eNodePlacement>(Value, ref Globals.HowToPlaceNodes);
            else if (ElementName == Globals._SimulationLengthName)
                Globals.stsSimulationLength.SetSliderValue(Value, true);
            else if (ElementName == Globals._PrerollLengthName)
                Globals.stsPrerollLength.SetSliderValue(Value, true);
            else if (ElementName == Globals._PostrollLengthName)
                Globals.stsPostrollLength.SetSliderValue(Value, true);
            else if (ElementName == Globals._SwitchingOnName)
                Globals.ctsSwitchingOn.SetValue<Globals.SwitchingOnType>(Value, ref Globals.SwitchingOn);
            else if (ElementName == Globals._ClockSyncName)
                Globals.ctsClockSync.SetValue<Globals.ClockSyncType>(Value, ref Globals.ClockSync);
            else if (ElementName == Globals._ClockAccuracyName)
                Globals.stsClockAccuracy.SetSliderValue(Value, true);
            else if (ElementName == Globals._EnergyLeftModeName)
                Globals.ctsEnergyMode.SetValue<Globals.EnergyType>(Value, ref Globals.EnergyMode);

            // Then the movement box:
            else if (ElementName == Globals._MoveTypeName)
                Globals.ctsMoveType.SetValue<Globals.MovementType>(Value, ref Globals.MoveMode);
            else if (ElementName == Globals._MovementSpeedName)
                Globals.stsMeanSpeed.SetSliderValue(Value, true);
            else if (ElementName == Globals._MovementSpeedSpreadName)
                Globals.stsSpreadSpeed.SetSliderValue(Value, true);

            // Then the application box:
            else if (ElementName == Globals._TrafficDistributionName)
                Globals.ctsTrafficDistribution.SetValue<Globals.TrafficType>(Value, ref Globals.TrafficDistribution);
            else if (ElementName == Globals._TrafficGenerateRateName)
                Globals.stsTrafficGenerateRate.SetSliderValue(Value, true);
            else if (ElementName == Globals._PacketDistributionName)
                Globals.ctsTrafficSizeType.SetValue<Globals.TrafficSizeType>(Value, ref Globals.PacketDistribution);
            else if (ElementName == Globals._MeanPacketSizeName)
                Globals.stsMeanPacketSize.SetSliderValue(Value, true);
            else if (ElementName == Globals._PacketPriorityName)
                Globals.stsPacketPriority.SetSliderValue(Value, true);
            else if (ElementName == Globals._WhereToSendPacketsName)
                Globals.ctsWhereToSendPackets.SetValue<Globals.eNodeTarget>(Value, ref Globals.WhereToSendPackets);

            // Then the transport box:
            else if (ElementName == Globals._TransportStyleName)
                Globals.ctsTransportStyle.SetValue<Globals.TransportType>(Value, ref Globals.TransportStyle);
            else if (ElementName == Globals._TransportTimeOutName)
                Globals.stsTransportTimeOut.SetSliderValue(Value, true);
            else if (ElementName == Globals._TransportRetriesName)
                Globals.stsTransportAttempts.SetSliderValue(Value, true);
            else if (ElementName == Globals._TransportParameterOneName)
                Globals.stsTransportParameterOne.SetSliderValue(Value, true);
            else if (ElementName == Globals._TransportParameterTwoName)
                Globals.stsTransportParameterTwo.SetSliderValue(Value, true);
            else if (ElementName == Globals._TransportParameterThreeName)
                Globals.stsTransportParameterThree.SetSliderValue(Value, true);
            else if (ElementName == Globals._TransportParameterFourName)
                Globals.stsTransportParameterFour.SetSliderValue(Value, true);

            // Then the network box:
            else if (ElementName == Globals._NetworkStyleName)
                Globals.ctsNetworkStyle.SetValue<Globals.NetworkType>(Value, ref Globals.NetworkStyle);
            else if (ElementName == Globals._NetworkHopCountName)
                Globals.stsNetworkHopCount.SetSliderValue(Value, true);
            else if (ElementName == Globals._NetworkParameterOneName)
                Globals.stsNetworkParameterOne.SetSliderValue(Value, true);
            else if (ElementName == Globals._NetworkParameterTwoName)
                Globals.stsNetworkParameterTwo.SetSliderValue(Value, true);
            else if (ElementName == Globals._NetworkParameterThreeName)
                Globals.stsNetworkParameterThree.SetSliderValue(Value, true);
            else if (ElementName == Globals._NetworkParameterFourName)
                Globals.stsNetworkParameterFour.SetSliderValue(Value, true);
            else if (ElementName == Globals._NetworkParameterFiveName)
                Globals.stsNetworkParameterFive.SetSliderValue(Value, true);
            else if (ElementName == Globals._NetworkParameterSixName)
                Globals.stsNetworkParameterSix.SetSliderValue(Value, true);
            else if (ElementName == Globals._NetworkParameterSevenName)
                Globals.stsNetworkParameterSeven.SetSliderValue(Value, true);

            // Then the LogicalLink box:
            else if (ElementName == Globals._LogicalLinkStyleName)
                Globals.ctsLogicalLinkType.SetValue<Globals.LogicalLinkType>(Value, ref Globals.LogicalLinkStyle);
            else if (ElementName == Globals._LogicalLinkTimeOutName)
                Globals.stsLogicalLinkTimeOut.SetSliderValue(Value, true);
            else if (ElementName == Globals._LogicalLinkRetriesName)
                Globals.stsLogicalLinkAttempts.SetSliderValue(Value, true);
            else if (ElementName == Globals._LogicalLinkParameterOneName)
                Globals.stsLogicalLinkParameterOne.SetSliderValue(Value, true);
            else if (ElementName == Globals._LogicalLinkParameterTwoName)
                Globals.stsLogicalLinkParameterTwo.SetSliderValue(Value, true);
            else if (ElementName == Globals._LogicalLinkParameterThreeName)
                Globals.stsLogicalLinkParameterThree.SetSliderValue(Value, true);
            else if (ElementName == Globals._LogicalLinkParameterFourName)
                Globals.stsLogicalLinkParameterFour.SetSliderValue(Value, true);

            // Then the multiple access box:
            else if (ElementName == Globals._MACStyleName)
                Globals.ctsMACStyle.SetValue<Globals.MultipleAccessType>(Value, ref Globals.MACStyle);
            else if (ElementName == Globals._MACInitialBackoffName)
                Globals.stsMACInitialBackoff.SetSliderValue(Value, true);
            else if (ElementName == Globals._MACParameterOneName)
                Globals.stsMACParameterOne.SetSliderValue(Value, true);
            else if (ElementName == Globals._MACParameterTwoName)
                Globals.stsMACParameterTwo.SetSliderValue(Value, true);
            else if (ElementName == Globals._MACParameterThreeName)
                Globals.stsMACParameterThree.SetSliderValue(Value, true);
            else if (ElementName == Globals._MACParameterFourName)
                Globals.stsMACParameterFour.SetSliderValue(Value, true);
            else if (ElementName == Globals._MACParameterFiveName)
                Globals.stsMACParameterFive.SetSliderValue(Value, true);
            else if (ElementName == Globals._MACParameterSixName)
                Globals.stsMACParameterSix.SetSliderValue(Value, true);
            else if (ElementName == Globals._MACParameterSevenName)
                Globals.stsMACParameterSeven.SetSliderValue(Value, true);

            // Then the physical layer access box:
            else if (ElementName == Globals._PhysicalStyleName)
                Globals.ctsPhysicalType.SetValue<Globals.PhysicalType>(Value, ref Globals.PhysicalStyle);
            else if (ElementName == Globals._DefaultTxPowerName)
                Globals.stsDefaultTxPower.SetSliderValue(Value, true);
            else if (ElementName == Globals._DetectSINRName)
                Globals.stsDetectSINR.SetSliderValue(Value, true);
            else if (ElementName == Globals._DefaultBitRateName)
                Globals.stsDefaultBitRate.SetSliderValue(Value, true);
            else if (ElementName == Globals._PhysicalHeaderSizeName)
                Globals.stsPhysicalHeaderSize.SetSliderValue(Value, true);
            else if (ElementName == Globals._ChannelStyleName)
                Globals.ctsChannelType.SetValue<Globals.ChannelType>(Value, ref Globals.ChannelStyle);

            // Then there are some lesser-known ones that aren't available for
            // users to control directly from the user interface, and if they
            // are going to be changed, have to be done from a configuration 
            // file.  Note there is no range checking on these, so user beware.
            else if (ElementName == "Path_Loss_Constant")
                Globals.PathLossConstant = double.Parse(Value);
            else if (ElementName == "Path_Loss_Exponent")
                Globals.PathLossExponent = double.Parse(Value);
            else if (ElementName == "Noise_Level")
                Globals.NoiseFloor = Math.Pow(10, double.Parse(Value) / 10) / 1000;
            else if (ElementName == "Random_Seed")
            {
                Int32 randomSeed = Int32.Parse(Value);
                Globals.rands = new Random(randomSeed);
            }
            else if (ElementName == "Initial_Energy")
                Globals.InitialEnergy = double.Parse(Value);
            else if (ElementName == "Power_When_Asleep")
                Globals.PowerWhenRxAsleep = double.Parse(Value);
            else if (ElementName == "Power_When_Rx_Off")
                Globals.PowerWhenRxOff = double.Parse(Value);
            else if (ElementName == "Power_When_Listening")
                Globals.PowerWhenRxListening = double.Parse(Value);
            else if (ElementName == "Power_When_Receiving")
                Globals.PowerWhenRxReceiving = double.Parse(Value);
            else if (ElementName == "Power_When_Tx_Off")
                Globals.PowerWhenTxOff = double.Parse(Value);
            else if (ElementName == "Power_When_Transmitting_Offset")
                Globals.PowerWhenTransmittingOffset = double.Parse(Value);
            else if (ElementName == "Power_When_Transmitting_Multiplier")
                Globals.PowerWhenTransmittingMultiplier = double.Parse(Value);

            // Finally the instructions to run batch files:
            else if (RunBatch == true && ElementName == "Run")
            {
                // First reset the simulation and set-up to run:
                ((MainWindow)Globals.MainWindow).ResetSimulation();
                Globals.SimStatus = Globals.status.Reset;
                ((MainWindow)Globals.MainWindow).StartNewLogFile();
                ((MainWindow)Globals.MainWindow).SimulateFullSpeed();
                int thing = Globals.theQueue.EventCount();

                // Set the Globals variables required for the threads 
                // to communicate, set animate off (other threads 
                // can't interact with the main GUI):
                Globals.BatchFileName = Value;
                Globals.BatchStatus = Globals.BatchRunStatus.Running;
                Globals.theTimer.IsEnabled = false;
                Boolean wasAnimate = Globals.Animate;
                Globals.Animate = false;

                // Now set up a GUI window as a separate thread, so this
                // main thread can go to sleep while this other GUI thread
                // provides a means to cancel the batch file:
                DANSE.Simulator.Statics.BatchWin GUIWin = null;
                Thread batchGUI = new Thread(() =>
                {
                    DANSE.Simulator.Statics.BatchWin w = new DANSE.Simulator.Statics.BatchWin();
                    w.WindowStartupLocation = WindowStartupLocation.CenterScreen;
                    w.ShowDialog();
                    // I don't entirely understand the next two lines; they're from
                    // an example on the forums, which seems to think they are 
                    // required.  However, DANSE seems to work fine without them,
                    // (in fact if you add the second one it seems to leave a process
                    // hanging when the main window is shut down, so I'll comment
                    // it out for now.)
                    // 1) Make sure dispatcher is removed when window closes:
                    w.Closed += (sender2, e2) => w.Dispatcher.InvokeShutdown();
                    // 2) Need this, so the new window gets its own dispatcher,
                    // which it will need for its timer:
                    // System.Windows.Threading.Dispatcher.Run();
                    // This is so I can close the window later:
                    GUIWin = w;
                });
                // All UI threads have to be single-threaded applications:
                batchGUI.SetApartmentState(ApartmentState.STA);
                batchGUI.Start();

                // The batch simulations run in a different thread as a background 
                // worker; this thread just sets up the batch GUI window to monitor 
                // progress.  First, set up the background worker:
                BackgroundWorker batcher = new BackgroundWorker();
                batcher.DoWork += delegate(object s, DoWorkEventArgs f)
                {
                    int TotalEvents = 0;
                    while (Globals.theQueue.EventCount() > 0)
                    {
                        for (int loop = 0; loop < 100; loop++)
                        {
                            Globals.theQueue.DoNextEvent();
                            TotalEvents++;
                        }
                        // Every so often, check the batch status - the GUI
                        // might have updated it.
                        if (Globals.BatchStatus != Globals.BatchRunStatus.Running) break;
                    }
                    // OK, all done now...
                    if (Globals.BatchStatus == Globals.BatchRunStatus.Running)
                        Globals.BatchStatus = Globals.BatchRunStatus.Finished;
                };
                // Kick off the background thread:
                batcher.RunWorkerAsync();

                // This thread will just sit around and wait for everything to 
                // finish (then it will carry on with the next batch file)
                int howlong = 0;
                while (Globals.BatchStatus == Globals.BatchRunStatus.Running)
                {
                    System.Threading.Thread.Sleep(100);
                    howlong += 100;
                }

                // OK, must have finished (or been cancelled).  It would be nice
                // to shut down the GUI window, but this seems to be difficult
                // to do from a different thread... I might just have to wait for
                // them to shut themselves down.
                System.Threading.Thread.Sleep(300);

                if (Globals.BatchStatus == Globals.BatchRunStatus.CancelAll)
                {
                    // Cancel all further batch files in this xml file:
                    RunBatch = false;
                }

                // Store the results in the requested files:
                string PacketFileName = XML_CurrentDirectory + "\\" + Value + "_packets.txt";
                FileStream newFileStream1 = new FileStream(PacketFileName, FileMode.Create);
                using (StreamWriter OutputFile = new StreamWriter(newFileStream1))
                {
                    StringBuilder Raw = new StringBuilder();
                    foreach (Globals.RawPacketData data in Globals.myPackets)
                        Raw.AppendLine(data.ToString());
                    OutputFile.Write(Raw);
                }
                newFileStream1.Close();

                string NodesFileName = XML_CurrentDirectory + "\\" + Value + "_nodes.txt";
                FileStream newFileStream2 = new FileStream(NodesFileName, FileMode.Create);
                using (StreamWriter OutputFile = new StreamWriter(newFileStream2))
                {
                    StringBuilder Raw = new StringBuilder();
                    foreach (cNode node in Globals.myNodes)
                        Raw.AppendLine(node.GetStatusString());
                    OutputFile.Write(Raw);
                }
                newFileStream2.Close();

                // Then make sure the simulation has ended properly and put things
                // back as before:
                Globals.Animate = wasAnimate;
                Globals.BatchStatus = Globals.BatchRunStatus.Finished;
                ((MainWindow)Globals.MainWindow).EndSimulation();
                ((MainWindow)Globals.MainWindow).ResetSimulation();

                // At this point I could also update the console, which I haven't been
                // able to write to during the batch file run in a different thread.
                // (However at present this doesn't do anything, since Globals.
                // ConsoleText is cleared in the ResetSimulation() routine.)
                ((MainWindow)Globals.MainWindow).txtConsole.Text = Globals.ConsoleText.ToString();
            }
            else if (RunBatch == false && ElementName == "Run")
            {
                // Might have cancelled a batch file with a "CancelAll"
            }

            // And if all else fails:
            else
            {
                MessageBox.Show("Cannot recognise element type " + ElementName + " in xml file.",
                    "Format error");
            }
        }
    }
}