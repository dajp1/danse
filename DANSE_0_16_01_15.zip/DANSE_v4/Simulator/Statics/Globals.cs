﻿using System;
using System.Collections.Generic;
using System.Windows.Threading;
using System.Windows;
using System.Windows.Shapes;
using System.Windows.Media;
using System.IO;
using System.Text;
using System.Windows.Controls;

namespace DANSE_v4
{
    internal static partial class Globals
    {
        // First some constants used around the place in addressing:
        internal const int NOWHERE = -2;    // Used internally only
        internal const int BROADCAST = 255; // Because you can't store -1 in a byte
        internal const int CONTROLVOFFSETSTART = 6;
        internal const int CONTROLVOFFSETDELTA = 28;
        internal const double INFINITY = 1e20;
        internal const int STATUSTEXTLENGTH = 100;

        // A few global things required in various places:
        static internal Window MainWindow;
        static internal Random rands = new Random();      // For simulator
        static internal Random userRands = new Random();  // For user protocols
        static internal Point GridCentre = new Point();
        static internal Size GridSize = new Size();
        static internal double GridScale = 1.0;

        static internal List<cNode> myNodes = new List<cNode>();
        static internal int SelectedNode = NOWHERE;
        static internal cEventQueue myQueue = new cEventQueue();
        internal const int MaximumNumberOfEvents = (int)1e6;
        static internal Canvas MainCanvas;
        static internal Canvas OutputCanvas;
        static internal Canvas NodeCanvas;

        // What state is in the simulator in?
        static internal Boolean SettingUp = true;
        internal enum status { Initial, Stepping, Running, Stopped, Resetting, Reset, Terminating };
        static internal status SimStatus;
        static internal Boolean Animate = true;
        internal enum TimeMode { Real, Fast, NonReal };
        static internal TimeMode TimingMode = TimeMode.NonReal;
        static internal Boolean ShowRoutes = false;
        static internal Boolean ShowParents = false;
        static internal Boolean ShowNumbers = false;
        static internal List<Line> RouteLines = new List<Line>();
        internal const int MaximumHopsToPlot = 20;
        internal enum BatchRunStatus { Default, Running, CancelThis, CancelAll, Finished } ;
        static internal BatchRunStatus BatchStatus = BatchRunStatus.Default;
        static internal int NumberOfBatchFiles;
        static internal int CurrentBatchFileNumber;
        static internal string BatchFileName;

        // The maximum user header and packet sizes:
        static internal int MaxHeaderSize = 1024;
        static internal int MaxPacketSize = 8192;

        // I need an event queue:
        static internal cEventQueue theQueue = new cEventQueue();

        #region Region: Placing the Nodes
        // Some constants for placing the nodes:
        internal const double MinimumNodeSeparation = 0.1;
        internal const double DefaultNodeSeparation = 0.2;
        internal const double MaximumNodeSeparation = 0.3;
        internal const double FirstNodeMaxOffset = 0.3;
        static internal int[][] SquareGrids = 
        {
            new int[] {1},
            new int[] {2, 2},
            new int[] {1, 3, 1},
            new int[] {3, 3, 3},
            new int[] {2, 4, 4, 2},
            new int[] {1, 3, 5, 3, 1},
            new int[] {4, 4, 4, 4},
            new int[] {3, 5, 5, 5, 3},
            new int[] {2, 4, 6, 6, 4, 2},
            new int[] {5, 5, 5, 5, 5},
            new int[] {4, 6, 6, 6, 6, 4},
            new int[] {6, 6, 6, 6, 6, 6},
            new int[] {3, 5, 7, 7, 7, 5, 3},
            new int[] {5, 7, 7, 7, 7, 7, 5},
            new int[] {7, 7, 7, 7, 7, 7, 7},
            new int[] {4, 6, 8, 8, 8, 8, 6, 4},
            new int[] {6, 8, 8, 8, 8, 8, 8, 6},
            new int[] {8, 8, 8, 8, 8, 8, 8, 8},
            new int[] {5, 7, 9, 9, 9, 9, 9, 7, 5},
            new int[] {7, 9, 9, 9, 9, 9, 9, 9, 7},
            new int[] {9, 9, 9, 9, 9, 9, 9, 9, 9},
            new int[] {6, 8, 10, 10, 10, 10, 10, 10, 8, 6},
            new int[] {8, 10, 10, 10, 10, 10, 10, 10, 10, 8},
            new int[] {10, 10, 10, 10, 10, 10, 10, 10, 10, 10}
        };
        static internal int[][] HexGrids = 
        {
            new int[] {1},
            new int[] {1, 2},
            new int[] {2, 3, 2},
            new int[] {3, 4, 5, 4, 3},
            new int[] {4, 5, 6, 7, 6, 5, 4},
            new int[] {5, 6, 7, 8, 9, 8, 7, 6, 5},
            new int[] {6, 7, 8, 9, 10, 11, 10, 9, 8, 7, 6}
        };
        // If I have nodes loaded in from the configuration file:
        internal struct preloadNode
        {
            internal double X;
            internal double Y;
            internal double InitialEnergy;
            internal double InitialSpeed;
        }
        internal static List<preloadNode> myPreloadedNodes = new List<preloadNode>();
        #endregion

        #region Region: Messages, Logfiles and Logging
        // There's an output log file for keeping track of everything:
        internal const int MaxMessageSize = 1024;
        static internal Boolean LogEventsOn = false;
        static internal Boolean LogFileOn = false;
        static internal FileStream LogFileStream = null;
        static internal StreamWriter LogStreamWriter = null;
        static internal string LogFileName = "delete.me";
        static internal StringBuilder LogFileCurrentContents = new StringBuilder();
        static internal long LogFileEntryCount = 0; // Stores how many entries in the log file

        static internal StringBuilder NewLogEvent = new StringBuilder(4096); // Builds the current log file entry
        static internal StringBuilder ConsoleText = new StringBuilder(1048576); // Builds the text in the console
        static internal long LogEventCount = 0; // Stores how many log events occur
        static internal Boolean LogApplication = false;
        static internal Boolean LogTransport = false;
        static internal Boolean LogNetwork = false;
        static internal Boolean LogLogicalLink = false;
        static internal Boolean LogMultipleAccess = false;
        static internal Boolean LogPhysical = false;
        static internal Boolean LogMovement = false;
        static internal Boolean LogSystem = false;
        static internal long WhenPacketsLastViewed = -1;
        static internal long WhenConsoleLastViewed = -1;
        static internal long WhenLogFileLastViewed = -1;

        internal enum eWhatToLog { All, Zero, ZeroAndOne, PacketZero, PacketZeroAndOne, PacketNonZero }
        static internal eWhatToLog WhatToLog = eWhatToLog.All;
        #endregion

        #region Region: Keeping The Time
        // Keeping the time:
        static internal DispatcherTimer theTimer;
        internal const int TimeStep = 100; // Time step for timer in milliseconds;
        static internal int EventsPerInterrupt = 100; // How fast can I go on this machine?
        static internal long SimTime = 0;   // The simulation time in nanoseconds;
        static internal long RealTime = 0;  // The real time in nanoseconds since start of simulation;
        internal const long MinimumEventTime = 1000; // Minimum time (in ns) for an event at a node
        internal const long OneJiffy = 5; // To make sure packets don't arrive before leaving

        // Can also end the simulation prematurely:
        static internal Boolean ShowMessageBox(string thing, string caption)
        {
            MessageBoxResult Reply = MessageBox.Show(thing + "\n\nContinue the simulation?",
                caption, MessageBoxButton.YesNo);
            if (Reply == MessageBoxResult.No)
            {
                // User has selected to terminate.  Stop the simulation.
                ((MainWindow)Globals.MainWindow).EndSimulation();
                return false;
            }
            return true;
        }
        #endregion

        internal const double _UserParameterDefault = 0.0;
        internal const double _UserParameterMinimum = 0.0;
        internal const double _UserParameterMaximum = 10.0;

        #region Region: System Control Box
        /////////////////////////////
        // The "System" control box
        /////////////////////////////
        internal const string _NumberOfNodesName = "Number_of_nodes";
        internal const int _NumberOfNodesDefault = 10;
        internal const int _NumberOfNodesMinimum = 1;
        internal const int _NumberOfNodesMaximum = 100;
        static internal int NumberOfNodes = _NumberOfNodesDefault;
        static internal GUIBits.SliderTagStruct stsNumberOfNodes = null;

        internal const string _HowToPlaceNodesName = "Node_placement_style";
        internal enum eNodePlacement { Random, Circle, Ring, Square, Hexagonal, Linear, Cross, Preloaded }
        internal const eNodePlacement _HowToPlaceNodesDefault = eNodePlacement.Random;
        static internal eNodePlacement HowToPlaceNodes = _HowToPlaceNodesDefault;
        static internal GUIBits.ComboBoxTagStruct ctsHowToPlaceNodes = null;

        internal const string _SimulationLengthName = "Length_of_simulation";
        internal const long _SimulationLengthDefault = 1000;
        internal const long _SimulationLengthMinimum = 10;
        internal const long _SimulationLengthMaximum = 1000000;
        static internal long SimulationLength = _SimulationLengthDefault;
        static internal GUIBits.SliderTagStruct stsSimulationLength = null;

        internal const string _PrerollLengthName = "Preroll_time_before_packets";
        internal const long _PrerollLengthDefault = 1;
        internal const long _PrerollLengthMinimum = 1;
        internal const long _PrerollLengthMaximum = 10000;
        static internal long PrerollLength = _PrerollLengthDefault;
        static internal GUIBits.SliderTagStruct stsPrerollLength = null;

        internal const string _PostrollLengthName = "Postroll_time_after_packets";
        internal const long _PostrollLengthDefault = 1;
        internal const long _PostrollLengthMinimum = 1;
        internal const long _PostrollLengthMaximum = 10000;
        static internal long PostrollLength = _PostrollLengthDefault;
        static internal GUIBits.SliderTagStruct stsPostrollLength = null;

        internal const string _SwitchingOnName = "Switching_on_mode";
        internal enum SwitchingOnType { Instant, Sequence, Random }
        internal const SwitchingOnType _SwitchingOnDefault = SwitchingOnType.Instant;
        static internal SwitchingOnType SwitchingOn = _SwitchingOnDefault;
        static internal GUIBits.ComboBoxTagStruct ctsSwitchingOn = null;

        internal const string _ClockSyncName = "Clock_synchronisation_mode";
        internal enum ClockSyncType { Global, Individual }
        internal const ClockSyncType _ClockSyncDefault = ClockSyncType.Global;
        static internal ClockSyncType ClockSync = _ClockSyncDefault;
        static internal GUIBits.ComboBoxTagStruct ctsClockSync = null;

        internal const string _ClockAccuracyName = "Clock_accuracy_ppm";
        internal const double _ClockAccuracyDefault = 100.0;
        internal const double _ClockAccuracyMinimum = 1.0;
        internal const double _ClockAccuracyMaximum = 10000.0;
        static internal double ClockAccuracy = _ClockAccuracyDefault;
        static internal GUIBits.SliderTagStruct stsClockAccuracy = null;
        #endregion

        #region Region: Movement Control Box
        ///////////////////////////////
        // The "Movement" control box
        ///////////////////////////////
        // The simulator needs one instance of the cMovement class:
        static internal cMovement MoveClass = new cMovement();
        internal const long MoveInterval = (long)500e6; // 0.5 seconds in nanoseconds

        internal const string _MoveTypeName = "Movement_type";
        internal enum MovementType { None, Linear, Targetted }
        internal const MovementType _MoveModeDefault = MovementType.None;
        static internal MovementType MoveMode = _MoveModeDefault;
        static internal GUIBits.ComboBoxTagStruct ctsMoveType = null;

        internal const string _MovementSpeedName = "Mean_node_speed";
        internal const double _MovementSpeedMinimum = 0.01;
        internal const double _MovementSpeedMaximum = 10.0;
        internal const double _MovementSpeedDefault = 0.1;
        static internal double MovementSpeed = _MovementSpeedDefault;
        static internal GUIBits.SliderTagStruct stsMeanSpeed = null;

        internal const string _MovementSpeedSpreadName = "Spread_in_node_speeds";
        internal const double _MovementSpeedSpreadMinimum = 0.0;
        internal const double _MovementSpeedSpreadMaximum = 1.0;
        internal const double _MovementSpeedSpreadDefault = 0.0;
        static internal double MovementSpeedSpread = _MovementSpeedSpreadDefault;
        static internal GUIBits.SliderTagStruct stsSpreadSpeed = null;
        // This next calculation divides by 200 since I want MovementSpeedNew() to
        // return a speed in meters per second.  (The movement routine is called 
        // twice a second, and the scaling factor of the display is 100.)
        static internal double MovementSpeedNew() { return (MovementSpeed * (1.0 + MovementSpeedSpread * 2.0 * (rands.NextDouble() - 0.5)) / 200.0); }
        #endregion

        #region Region: Application Control Box
        /////////////////////////////////
        // The "Application" control box
        /////////////////////////////////

        // Types and globals for the application classes:
        internal const string _TrafficDistributionName = "Interpacket_time_distribution";
        internal enum TrafficType { Exponential, Regular, Sequence, Uniform }
        internal const TrafficType _TrafficDistributionDefault = TrafficType.Exponential;
        static internal TrafficType TrafficDistribution = _TrafficDistributionDefault;
        static internal GUIBits.ComboBoxTagStruct ctsTrafficDistribution = null;

        internal const string _TrafficGenerateRateName = "Mean_packet_generation_rate";
        internal const double _TrafficGenerateRateMinimum = 0.0;
        internal const double _TrafficGenerateRateMaximum = 3.0;
        internal const double _TrafficGenerateRateDefault = 0.1;
        static internal double TrafficGenerateRate = _TrafficGenerateRateDefault;
        static internal GUIBits.SliderTagStruct stsTrafficGenerateRate = null;

        internal const string _PacketDistributionName = "Packet_size_distribution";
        internal enum TrafficSizeType { Regular, Uniform, Exponential }
        internal const TrafficSizeType _PacketDistributionDefault = TrafficSizeType.Regular;
        static internal TrafficSizeType PacketDistribution = _PacketDistributionDefault;
        static internal GUIBits.ComboBoxTagStruct ctsTrafficSizeType = null;

        internal const string _MeanPacketSizeName = "Mean_packet_size";
        internal const int _MeanPacketSizeMinimum = 1;
        internal const int _MeanPacketSizeMaximum = 1000;
        internal const int _MeanPacketSizeDefault = 100;
        static internal int MeanPacketSize = _MeanPacketSizeDefault; // This is in bytes
        static internal GUIBits.SliderTagStruct stsMeanPacketSize = null;

        internal const string _PacketPriorityName = "Packet_priority";
        internal const int _PacketPriorityMinimum = 0;
        internal const int _PacketPriorityMaximum = 7;
        internal const int _PacketPriorityDefault = 0;
        static internal int PacketPriority = _PacketPriorityDefault; // This is in bytes
        static internal GUIBits.SliderTagStruct stsPacketPriority = null;

        internal const string _WhereToSendPacketsName = "Packet_destination";
        internal enum eNodeTarget { Random, Centre, Zero, Random_Other }
        internal const eNodeTarget _TargetDefault = eNodeTarget.Random;
        static internal eNodeTarget WhereToSendPackets = _TargetDefault;
        static internal int CentreNode;
        static internal GUIBits.ComboBoxTagStruct ctsWhereToSendPackets = null;
        #endregion

        #region Region: Transport Control Box
        ////////////////////////////////
        // The "Transport" control box
        ////////////////////////////////
        internal const string _TransportStyleName = "Transport_protocol";
        internal enum TransportType { Best_Effort, Reliable, User }
        internal const TransportType _TransportTypeDefault = TransportType.Best_Effort;
        static internal TransportType TransportStyle = _TransportTypeDefault;
        static internal GUIBits.ComboBoxTagStruct ctsTransportStyle = null;

        internal const string _TransportTimeOutName = "Transport_maximum_timeout";
        internal const double _TransportTimeOutMinimum = 1;
        internal const double _TransportTimeOutMaximum = 100;
        internal const double _TransportTimeOutDefault = 10;
        static internal double TransportTimeOut = _TransportTimeOutDefault;
        static internal GUIBits.SliderTagStruct stsTransportTimeOut = null;

        internal const string _TransportRetriesName = "Transport_maximum_attempts";
        internal const int _TransportRetriesMinimum = 1;
        internal const int _TransportRetriesMaximum = 10;
        internal const int _TransportRetriesDefault = 3;
        static internal int TransportRetries = _TransportRetriesDefault;
        static internal GUIBits.SliderTagStruct stsTransportAttempts = null;

        internal const string _TransportParameterOneName = "Transport_parameter_A";
        internal const string _TransportParameterTwoName = "Transport_parameter_B";
        internal const string _TransportParameterThreeName = "Transport_parameter_C";
        internal const string _TransportParameterFourName = "Transport_parameter_D";
        static internal double TransportParameterOne = _UserParameterDefault;
        static internal GUIBits.SliderTagStruct stsTransportParameterOne = null;
        static internal double TransportParameterTwo = _UserParameterDefault;
        static internal GUIBits.SliderTagStruct stsTransportParameterTwo = null;
        static internal double TransportParameterThree = _UserParameterDefault;
        static internal GUIBits.SliderTagStruct stsTransportParameterThree = null;
        static internal double TransportParameterFour = _UserParameterDefault;
        static internal GUIBits.SliderTagStruct stsTransportParameterFour = null;
        #endregion

        #region Region: Network Control Box
        ////////////////////////////////
        // The "Network" control box
        ////////////////////////////////
        internal const string _NetworkStyleName = "Network_protocol";
        internal enum NetworkType { Direct, Flooding, Bellman_Ford, On_Demand, User }
        internal const NetworkType _NetworkTypeDefault = NetworkType.Direct;
        static internal NetworkType NetworkStyle = _NetworkTypeDefault;
        static internal GUIBits.ComboBoxTagStruct ctsNetworkStyle = null;

        internal const string _NetworkHopCountName = "Maximum_hop_count";
        internal const int _NetworkHopCountMinimum = 1;
        internal const int _NetworkHopCountMaximum = 10;
        internal const int _NetworkHopCountDefault = 20;
        static internal int HopCount = _NetworkHopCountDefault;
        static internal GUIBits.SliderTagStruct stsNetworkHopCount = null;

        internal const string _NetworkParameterOneName = "Network_parameter_A";
        internal const string _NetworkParameterTwoName = "Network_parameter_B";
        internal const string _NetworkParameterThreeName = "Network_parameter_C";
        internal const string _NetworkParameterFourName = "Network_parameter_D";
        internal const string _NetworkParameterFiveName = "Network_parameter_E";
        internal const string _NetworkParameterSixName = "Network_parameter_F";
        internal const string _NetworkParameterSevenName = "Network_parameter_G";
        static internal double NetworkParameterOne = _UserParameterDefault;
        static internal GUIBits.SliderTagStruct stsNetworkParameterOne = null;
        static internal double NetworkParameterTwo = _UserParameterDefault;
        static internal GUIBits.SliderTagStruct stsNetworkParameterTwo = null;
        static internal double NetworkParameterThree = _UserParameterDefault;
        static internal GUIBits.SliderTagStruct stsNetworkParameterThree = null;
        static internal double NetworkParameterFour = _UserParameterDefault;
        static internal GUIBits.SliderTagStruct stsNetworkParameterFour = null;
        static internal double NetworkParameterFive = _UserParameterDefault;
        static internal GUIBits.SliderTagStruct stsNetworkParameterFive = null;
        static internal double NetworkParameterSix = _UserParameterDefault;
        static internal GUIBits.SliderTagStruct stsNetworkParameterSix = null;
        static internal double NetworkParameterSeven = _UserParameterDefault;
        static internal GUIBits.SliderTagStruct stsNetworkParameterSeven = null;
        #endregion

        #region Region: Logical-Link Control Box
        ////////////////////////////////
        // The "Logical-Link" control box
        ////////////////////////////////
        internal const string _LogicalLinkStyleName = "Logical-link_protocol";
        internal enum LogicalLinkType { Best_Effort, Reliable, User }
        internal const LogicalLinkType _LogicalLinkTypeDefault = LogicalLinkType.Best_Effort;
        static internal LogicalLinkType LogicalLinkStyle = _LogicalLinkTypeDefault;
        static internal GUIBits.ComboBoxTagStruct ctsLogicalLinkType = null;

        internal const string _LogicalLinkTimeOutName = "Logical-link_maximum_time-out";
        internal const double _LogicalLinkTimeOutMinimum = 1;
        internal const double _LogicalLinkTimeOutMaximum = 100;
        internal const double _LogicalLinkTimeOutDefault = 5;
        static internal double LogicalLinkTimeOut = _LogicalLinkTimeOutDefault;
        static internal GUIBits.SliderTagStruct stsLogicalLinkTimeOut = null;

        internal const string _LogicalLinkRetriesName = "Logical-link_maximum_attempts";
        internal const int _LogicalLinkRetriesMinimum = 1;
        internal const int _LogicalLinkRetriesMaximum = 20;
        internal const int _LogicalLinkRetriesDefault = 2;
        static internal int LogicalLinkRetries = _LogicalLinkRetriesDefault;
        static internal GUIBits.SliderTagStruct stsLogicalLinkAttempts = null;

        internal const string _LogicalLinkParameterOneName = "Logical-link_parameter_A";
        internal const string _LogicalLinkParameterTwoName = "Logical-link_parameter_B";
        internal const string _LogicalLinkParameterThreeName = "Logical-link_parameter_C";
        internal const string _LogicalLinkParameterFourName = "Logical-link_parameter_D";
        static internal double LogicalLinkParameterOne = _UserParameterDefault;
        static internal GUIBits.SliderTagStruct stsLogicalLinkParameterOne = null;
        static internal double LogicalLinkParameterTwo = _UserParameterDefault;
        static internal GUIBits.SliderTagStruct stsLogicalLinkParameterTwo = null;
        static internal double LogicalLinkParameterThree = _UserParameterDefault;
        static internal GUIBits.SliderTagStruct stsLogicalLinkParameterThree = null;
        static internal double LogicalLinkParameterFour = _UserParameterDefault;
        static internal GUIBits.SliderTagStruct stsLogicalLinkParameterFour = null;
        #endregion

        #region Region: Multiple Access Control Box
        //////////////////////////////////////
        // The "Multiple Access" control box
        //////////////////////////////////////
        internal const string _MACStyleName = "Multiple_access_protocol";
        internal enum MultipleAccessType { ALOHA, CSMA, Polling, User }
        internal const MultipleAccessType _MACDefault = MultipleAccessType.ALOHA;
        static internal MultipleAccessType MACStyle;
        static internal GUIBits.ComboBoxTagStruct ctsMACStyle = null;

        internal const string _MACInitialBackoffName = "MAC_initial_backoff";
        internal const double _MACInitialBackoffMinimum = 0.01;
        internal const double _MACInitialBackoffMaximum = 2.0;
        internal const double _MACInitialBackoffDefault = 0.2;
        static internal double MACInitialBackoff = _MACInitialBackoffDefault;
        static internal GUIBits.SliderTagStruct stsMACInitialBackoff = null;

        internal const string _MACParameterOneName = "Multiple-access_parameter_A";
        internal const string _MACParameterTwoName = "Multiple-access_parameter_B";
        internal const string _MACParameterThreeName = "Multiple-access_parameter_C";
        internal const string _MACParameterFourName = "Multiple-access_parameter_D";
        internal const string _MACParameterFiveName = "Multiple-access_parameter_E";
        internal const string _MACParameterSixName = "Multiple-access_parameter_F";
        internal const string _MACParameterSevenName = "Multiple-access_parameter_G";
        static internal double MACParameterOne = _UserParameterDefault;
        static internal GUIBits.SliderTagStruct stsMACParameterOne = null;
        static internal double MACParameterTwo = _UserParameterDefault;
        static internal GUIBits.SliderTagStruct stsMACParameterTwo = null;
        static internal double MACParameterThree = _UserParameterDefault;
        static internal GUIBits.SliderTagStruct stsMACParameterThree = null;
        static internal double MACParameterFour = _UserParameterDefault;
        static internal GUIBits.SliderTagStruct stsMACParameterFour = null;
        static internal double MACParameterFive = _UserParameterDefault;
        static internal GUIBits.SliderTagStruct stsMACParameterFive = null;
        static internal double MACParameterSix = _UserParameterDefault;
        static internal GUIBits.SliderTagStruct stsMACParameterSix = null;
        static internal double MACParameterSeven = _UserParameterDefault;
        static internal GUIBits.SliderTagStruct stsMACParameterSeven = null;

        internal const int _MACNumberOfChannels = 4;
        #endregion

        #region Region: Physical Control Box and SINRs
        ///////////////////////////////
        // The "Physical" control box
        ///////////////////////////////
        internal const string _PhysicalStyleName = "Pre-emption_mode";
        internal enum PhysicalType { Default, Preemptive }
        internal const PhysicalType _PhysicalDefault = PhysicalType.Default;
        static internal PhysicalType PhysicalStyle = _PhysicalDefault;
        static internal GUIBits.ComboBoxTagStruct ctsPhysicalType = null;

        internal const string _DefaultTxPowerName = "Default_transmit_power";
        internal const double _DefaultTxPowerDefault = -10.0;
        internal const double _DefaultTxPowerMaximum = 10.0;
        internal const double _DefaultTxPowerMinimum = -30.0;
        static internal double DefaultTxPowerdBm = _DefaultTxPowerDefault; // in dBm
        static internal GUIBits.SliderTagStruct stsDefaultTxPower = null;

        internal const string _DefaultBitRateName = "Default_bit_rate";
        internal const double _DefaultBitRateDefault = 1000.0;
        internal const double _DefaultBitRateMaximum = 250000.0;
        internal const double _DefaultBitRateMinimum = 500.0;
        static internal double DefaultBitRate = _DefaultBitRateDefault;
        static internal GUIBits.SliderTagStruct stsDefaultBitRate = null;

        internal const string _PhysicalHeaderSizeName = "Physical_header_size";
        internal const double _PhysicalHeaderSizeDefault = 0.0;
        internal const double _PhysicalHeaderSizeMaximum = 16.0;
        internal const double _PhysicalHeaderSizeMinimum = 0.0;
        static internal double PhysicalHeaderSize = _PhysicalHeaderSizeDefault;
        static internal GUIBits.SliderTagStruct stsPhysicalHeaderSize = null;

        internal const string _DetectSINRName = "SINR_for_Detection";
        internal const double _DetectSINRDefault = 0.0;
        internal const double _DetectSINRMaximum = 10.0;
        internal const double _DetectSINRMinimum = 0.0;
        static internal double DetectSINRdB = _DetectSINRDefault;
        static internal GUIBits.SliderTagStruct stsDetectSINR = null;

        internal const string _ChannelStyleName = "Channel_model";
        internal enum ChannelType { Default, Cliff_Edge }
        internal const ChannelType _ChannelDefault = ChannelType.Default;
        static internal ChannelType ChannelStyle = _ChannelDefault;
        static internal GUIBits.ComboBoxTagStruct ctsChannelType = null;

        // Some routines to relate bit-rates to the SINR requirements:
        // Routine for anyone to use to check if a current bit rate is legal.
        private struct legalBitRateStuff { 
            int BitRate; double SINR; 
            internal legalBitRateStuff(int rate, double SINR) { this.BitRate = rate; this.SINR = SINR; }
            internal int GetBitRate() { return BitRate; }
            internal double GetSINR() { return SINR; }
        }
        // Note: this is the master list of legal bit-rates, and the SINRs they need:
        static private List<legalBitRateStuff> legalBitRates = new List<legalBitRateStuff>() 
        {
            // Add new legal bit rates and SINR requirements in here.
            // Note: they must be in ascending order of bit-rate.
                new legalBitRateStuff(500, 2.5),
                new legalBitRateStuff(1000, 10),
                new legalBitRateStuff(2000, 40),
                new legalBitRateStuff(4000, 160),
                new legalBitRateStuff(250000, 40) // Zigbee mode only
        };
        static internal Boolean CheckBitRate(double bitRate)
        {
            Boolean isValid = false;
            foreach (legalBitRateStuff x in legalBitRates)
                if (x.GetBitRate() == bitRate) isValid = true;
            return isValid;
        }
        static internal double GetSINRForBitRate(int bitRate)
        {
            Boolean isValid = false;
            double requiredSINR = 1e20;
            foreach (legalBitRateStuff x in legalBitRates)
                if (x.GetBitRate() == bitRate) 
                {
                    isValid = true;
                    requiredSINR = x.GetSINR();
                }
            if (isValid == false || (Globals.ZigbeeMode == false && bitRate == 250000)) 
            {
                // Bit-rate set to unknown value:
                string error = "Attempt to find SINR for bit rate " + bitRate.ToString()
                    + " which is not an acceptable value."
                    + "\nSINR value of 1e20 will be used, this is probably wrong.";
                if (bitRate == 250000 && Globals.ZigbeeMode == false)
                    error += "\nHave you forgotten to enable ZigBee mode?";
                Globals.ShowMessageBox(error, "Serious Error");
                requiredSINR = 1e20;
            }          
            return requiredSINR;
        }
        static internal int GetNearestLegalBitRate(double bitRate)
        {
            // If only one element in the list, just return this:
            if (legalBitRates.Count == 1) return legalBitRates[0].GetBitRate();
            // Otherwise search through and compare with mid-points:
            for (int loop = 0; loop < legalBitRates.Count - 1; loop++)
            {
                int lowBitRate = legalBitRates[loop].GetBitRate();
                int highBitRate = legalBitRates[loop + 1].GetBitRate();
                double midBitRate = (lowBitRate + highBitRate) / 2.0;
                if (bitRate < midBitRate) return lowBitRate;
            }
            // If bigger than all mid-points, set to the maximum:
            return legalBitRates[legalBitRates.Count - 1].GetBitRate();
        }
        #endregion

        #region Region: Statistics and Packet Data
        // Keep track of some overall statistics:
        static internal int TotalPacketsSent = 0;
        static internal int TotalPacketsReceived = 0;
        static internal int TotalPacketsReceivedAtWrongNode = 0;
        static internal int TotalPacketsReceivedAtWrongPort = 0;
        static internal int TotalFramesSent = 0;
        static internal int TotalFramesReceived = 0;
        static internal long TotalDelay;
        static internal long MinDelay;
        static internal long MaxDelay;
        static internal void ClearStatistics()
        {
            TotalPacketsSent = 0;
            TotalPacketsReceived = 0;
            TotalPacketsReceivedAtWrongNode = 0;
            TotalPacketsReceivedAtWrongPort = 0;
            TotalFramesSent = 0;
            TotalFramesReceived = 0;
            TotalDelay = 0;
            MinDelay = 1000000000000000;
            MaxDelay = 0;
        }
        // Maximum number of packets that can be in queues, and events in the queue per node:
        internal const int DefaultMaxPacketsInQueues = 1000;
        static internal int MaxPacketsInQueues = DefaultMaxPacketsInQueues;
        internal const int DefaultMaxEventsPerNode = 30;
        static internal int MaxEventsPerNode = DefaultMaxEventsPerNode;

        // The raw details for each packet are also stored for further analysis:
        internal class RawPacketData
        {
            int OriginalSource = NOWHERE;
            int FinalDestination = NOWHERE;
            int PacketNumber = -1;
            int Priority = 0;
            int Length = 0;
            long StartTime = -1;
            long EndTime = -1;
            int NumberOfHops = 0;

            internal void SetOriginalSource(int x) { OriginalSource = x; }
            internal int GetOriginalSource() { return OriginalSource; }
            internal void SetFinalDestination(int x) { FinalDestination = x; }
            internal int GetFinalDestination() { return FinalDestination; }
            internal void SetPacketNumber(int x) { PacketNumber = x; }
            internal int GetPacketNumber() { return PacketNumber; }
            internal void SetPriority(int x) { Priority = x; }
            internal int GetPriority() { return Priority; }
            internal void SetLength(int x) { Length = x; }
            internal int GetLength() { return Length; }
            internal void SetStartTime(long x) { StartTime = x; }
            internal long GetStartTime() { return StartTime; }
            internal void SetEndTime(long x) { EndTime = x; }
            internal long GetEndTime() { return EndTime; }
            internal void SetNumberOfHops(int x) { NumberOfHops = x; }
            internal int GetNumberOfHops() { return NumberOfHops; }

            public override string ToString()
            {
                string Thing = new string(' ', 128);
                Thing = PacketNumber.ToString() + "\t"
                    + Priority.ToString() + "\t"
                    + Length.ToString() + "\t"
                    + OriginalSource.ToString() + "\t"
                    + FinalDestination.ToString() + "\t"
                    + NumberOfHops.ToString() + "\t"
                    + StartTime.ToString() + "\t"
                    + EndTime.ToString();
                return Thing;
            }
        }
        static internal List<RawPacketData> myPackets = new List<RawPacketData>();
        
        // And packets can be read in from configuration files:
        internal class RawPacketToGoData
        {
            int OriginalSource = NOWHERE;
            int FinalDestination = NOWHERE;
            int Priority = 0;
            int Length = 0;
            long StartTime = -1;

            internal void SetOriginalSource(int x) { OriginalSource = x; }
            internal int GetOriginalSource() { return OriginalSource; }
            internal void SetFinalDestination(int x) { FinalDestination = x; }
            internal int GetFinalDestination() { return FinalDestination; }
            internal void SetPriority(int x) { Priority = x; }
            internal int GetPriority() { return Priority; }
            internal void SetLength(int x) { Length = x; }
            internal int GetLength() { return Length; }
            internal void SetStartTime(long x) { StartTime = x; }
            internal long GetStartTime() { return StartTime; }

            internal cPacket MakePacket()
            {
                // If the specified source does not exist, it defaults to node zero:
                if (OriginalSource >= Globals.NumberOfNodes) OriginalSource = 0;
                // The first packet out is number one, not number zero:
                cPacket newPacket = new cPacket(Length, OriginalSource, Globals.TotalPacketsSent + 1);

                // Set up the metainformation for this packet:
                newPacket.MetaInformation().SetOriginalSource(OriginalSource);
                newPacket.MetaInformation().SetFinalDestination(FinalDestination);
                newPacket.MetaInformation().SetWhenGenerated(StartTime);
                newPacket.MetaInformation().SetSystemNumber(Globals.TotalPacketsSent + 1);
                newPacket.MetaInformation().SetTag((Globals.TotalPacketsSent + 1).ToString());
                // The port numbers are also chosen at random, and are between zero and 255.
                newPacket.MetaInformation().SetSourcePort(Globals.rands.Next(255));
                newPacket.MetaInformation().SetDestinationPort(Globals.rands.Next(255));
                return newPacket;
            }
        }
        static internal List<RawPacketToGoData> myPacketsToGo = new List<RawPacketToGoData>();

        // I need to be able to sort these so I can make sure they are in
        // chronological order before the simulation run starts, so I 
        // need a comparer and a sort function:
        static private int ComparePacketsToGo(RawPacketToGoData one, RawPacketToGoData two)
        {
            if (one.GetStartTime() == two.GetStartTime()) return 0;
            else if (one.GetStartTime() > two.GetStartTime()) return 1;
            else return -1;
        }
        static internal void SortPacketsToGo() 
        {
            Globals.myPacketsToGo.Sort(ComparePacketsToGo); 
        }

        // Initialising the whole thing at the start of a simulation:
        static private int nextPacketToGoIndex = 0;
        static internal void InitialisePacketsToGo()
        {
            nextPacketToGoIndex = 0;
            SortPacketsToGo();
            if (myPacketsToGo.Count > 0)
            {
                // Add a callback event to the queue to call when the first 
                // packet is due:
                Globals.theQueue.AddEvent(new cEvent(null, null, 
                    myPacketsToGo[0].GetStartTime(), EventType.System_InsertStoredPacket));
            }
        }
        static internal cPacket GetNextPacketToSend()
        {
            // First check to see if there are any packets left to be sent:
            if (myPacketsToGo.Count <= nextPacketToGoIndex) return null;
            // Then make the packet...
            cPacket newPacket = myPacketsToGo[nextPacketToGoIndex].MakePacket();
            // ... and increment the pointer ready for the next one
            nextPacketToGoIndex++;
            // A bit of safety-checking:
            int destination = newPacket.MetaInformation().GetFinalDestination();
            int source = newPacket.MetaInformation().GetOriginalSource();
            long timeToGo = newPacket.MetaInformation().GetWhenGenerated();
            if (destination > Globals.NumberOfNodes)
            {
                MessageBoxResult Reply = MessageBox.Show("Error: Packet loaded to be sent to node " 
                    + destination + ".\nbut there are only " + Globals.NumberOfNodes + " nodes.\n"
                    + "Packet will be sent to node zero.\nAbort rest of packet load?", 
                    "Configuration Error", MessageBoxButton.YesNo);
                newPacket.MetaInformation().SetFinalDestination(0);
                if (Reply == MessageBoxResult.Yes)
                {
                    // User has selected to terminate packet loading.
                    nextPacketToGoIndex = myPacketsToGo.Count;
                }
            }
            if (source > Globals.NumberOfNodes)
            {
                MessageBoxResult Reply = MessageBox.Show("Error: Packet loaded to be sent from node "
                    + source + "\nbut there are only " + Globals.NumberOfNodes + " nodes\n"
                    + "Packet will be sent from node zero.\nAbort rest of packet load?",
                    "Configuration Error", MessageBoxButton.YesNo);
                newPacket.MetaInformation().SetOriginalSource(0);
                if (Reply == MessageBoxResult.Yes)
                {
                    // User has selected to terminate packet loading.
                    nextPacketToGoIndex = myPacketsToGo.Count;
                }
            }
            if (timeToGo < Globals.SimTime || timeToGo > Globals.SimulationLength*1e9)
            {
                MessageBoxResult Reply = MessageBox.Show("Error: Packet loaded to be sent at time "
                    + timeToGo + ".\nbut simulation is length " + Globals.SimulationLength + " ns\n"
                    + "Packet will not be sent.\nAbort rest of packet load?",
                    "Configuration Error.", MessageBoxButton.YesNo);
                newPacket.MetaInformation().SetWhenGenerated(Globals.SimulationLength + 1);
                if (Reply == MessageBoxResult.Yes)
                {
                    // User has selected to terminate packet loading.
                    nextPacketToGoIndex = myPacketsToGo.Count;
                }
            }
            return newPacket;
        }
        static internal void AddNextPacketToGoEventToQueue()
        {
            // First check to see if there are any packets left to be sent:
            if (myPacketsToGo.Count <= nextPacketToGoIndex) return;

            // Add a callback event to the queue to call when the first 
            // packet is due:
            Globals.theQueue.AddEvent(new cEvent(null, null,
                myPacketsToGo[nextPacketToGoIndex].GetStartTime(), 
                EventType.System_InsertStoredPacket));
        }
        #endregion

        #region Region: Tx and Rx State and History
        // Types and globals for the nodes themselves:
        internal enum ReceiverState { Asleep, Off, Listening, Detecting, Receiving, Colliding }
        internal enum TransmitterState { Off, Transmitting }
        // Activities are stored with the time in global time:
        internal struct TxActivity
        {
            internal TransmitterState state; internal long time; internal string packetTag; internal double txPower;
            internal TxActivity(TransmitterState A) { state = A; time = Globals.SimTime; packetTag = ""; txPower = 0; } 
        }
        internal struct RxActivity
        {
            internal ReceiverState state; internal long time; internal string packetTag; internal double excessSINR;
            internal Boolean success;
            internal RxActivity(ReceiverState A) { state = A; time = Globals.SimTime; packetTag = ""; excessSINR = 0; success = true; } 
        }
        internal struct ReceiveSINRHistoryItem
        {
            internal long time;
            internal double SINR;
            internal ReceiveSINRHistoryItem(double newSINR)
            {
                this.SINR = newSINR;
                this.time = Globals.SimTime;
            }
        }
        #endregion

        #region Region: The Energy Constants
        // The energy globals settings:
        internal const long UpdateEnergyInterval = (long)250e6; // 0.25 seconds in nanoseconds
        static internal double InitialEnergy = 1000.0;
        static internal double PowerWhenRxAsleep = 24.0e-6;
        static internal double PowerWhenRxOff = 6.0e-3;
        static internal double PowerWhenRxListening = 24.0e-3;
        static internal double PowerWhenRxReceiving = 48.0e-3;
        static internal double PowerWhenTxOff = 0.0;
        static internal double PowerWhenTransmittingOffset = 0.03;
        static internal double PowerWhenTransmittingMultiplier = 10.0;

        internal const string _EnergyLeftModeName = "Energy_mode";
        internal enum EnergyType { Countdown, Addup, Down_Not_Zero };
        internal const EnergyType _EnergyModeDefault = EnergyType.Countdown;
        static internal EnergyType EnergyMode = _EnergyModeDefault;
        static internal GUIBits.ComboBoxTagStruct ctsEnergyMode = null;

        // Note: this is in addition to the current transmit power
        #endregion

        #region Region: The Channel and Noise Constants
        // Types and globals for the physical classes:
        // (note all powers and SINR are not in dB, dBW, dBm, etc).
        internal static Boolean ZigbeeMode = false;
        // These are constants at the moment, while I find a better channel model:
        internal const double _DefaultNoiseFloor = 1e-8;  // in Watts (= -50 dBm)
        private const double _DefaultPathLossExponent = 4.0;    // Gamma in the path loss equation, Loss = k * d^gamma
        private const double _DefaultPathLossConstant = 0.001;  // k in the path loss equation, Loss = k * d^gamma
        static internal double NoiseFloor = _DefaultNoiseFloor; // in Watts
        static internal double PathLossExponent = _DefaultPathLossExponent;
        static internal double PathLossConstant = _DefaultPathLossConstant;
        static internal double GetPathLossFromDistance(double x) { return PathLossConstant * Math.Pow(x, PathLossExponent); }
        static internal double GetPathLossFromSquareDistance(double x) { return PathLossConstant * Math.Pow(x, PathLossExponent / 2.0); }
        static internal double GetReceiveRangeFromTransmitPower(double x, double SINR) 
        {
            return Math.Pow(x / (PathLossConstant * NoiseFloor * SINR),
                    1.0 / PathLossExponent);
        }
        static internal double GetDetectRangeFromTransmitPower(double x)
        {
            return Math.Pow(x / (PathLossConstant * NoiseFloor * Math.Pow(10.0, DetectSINRdB / 10.0)),
                    1.0 / PathLossExponent);
        }
        static internal double[,] PathLosses;   // Array that will hold the path losses

        static internal double GetRequiredSINR(cPacket packet)  // Look up required SINR for a packet:
        {
            double bitRate = packet.MetaInformation().GetBitRate();
            return GetSINRForBitRate((int)bitRate);
        }
        #endregion

        #region Region: Colours and levels for the display
        // Some constants for the display
        static internal SolidColorBrush RangeDefaultBrush = new SolidColorBrush(Colors.Green);
        static internal SolidColorBrush NodeDefaultBrush = new SolidColorBrush(Colors.Purple);
        static internal SolidColorBrush NodeListeningBrush = new SolidColorBrush(Colors.Purple);
        static internal SolidColorBrush NodeDetectingBrush = new SolidColorBrush(Colors.Blue);
        static internal SolidColorBrush NodeReceivingBrush = new SolidColorBrush(Colors.LightGreen);
        static internal SolidColorBrush NodeTransmittingBrush = new SolidColorBrush(Colors.DarkGreen);
        static internal SolidColorBrush NodeAsleepBrush = new SolidColorBrush(Colors.Gray);
        static internal SolidColorBrush NodeCollisionBrush = new SolidColorBrush(Colors.Red);
        static internal SolidColorBrush NodeHighlightBrush = new SolidColorBrush(Colors.Orange);
        static internal SolidColorBrush NodeAsSourceBrush = new SolidColorBrush(Colors.Yellow);
        static internal SolidColorBrush NodeAsDestinationBrush = new SolidColorBrush(Colors.Goldenrod);
        static internal SolidColorBrush NodeSelectedBrush = new SolidColorBrush(Colors.Red);
        static internal SolidColorBrush NodeInvisibleBrush = new SolidColorBrush(Colors.Transparent);
        static internal SolidColorBrush NodePolyLinePathBrush = new SolidColorBrush(Colors.Black);
        static internal SolidColorBrush NodeLineMACParentBrush = new SolidColorBrush(Colors.DarkCyan);
        static internal SolidColorBrush NodeLineLLCParentBrush = new SolidColorBrush(Colors.DarkKhaki);
        static internal SolidColorBrush TextGrayBrush = new SolidColorBrush(Colors.Gray);
        static internal SolidColorBrush TextBlackBrush = new SolidColorBrush(Colors.Black);
        static internal SolidColorBrush TextHighlightBrush = new SolidColorBrush(Colors.DarkSlateGray);
        static internal SolidColorBrush LineRouteToBrush = new SolidColorBrush(Colors.DarkBlue);
        static internal SolidColorBrush LineRouteFromBrush = new SolidColorBrush(Colors.Plum);
        static internal SolidColorBrush LineRouteLoopBrush = new SolidColorBrush(Colors.Red);
        static internal DoubleCollection LineRouteDashes = new DoubleCollection();

        // Drawing Z-levels for the elements in the main UI screen:
        internal const int Z_Background = 0;
        internal const int Z_DetectRange = 1;
        internal const int Z_ReceiveRange = 2;
        internal const int Z_LLCParents = 3;
        internal const int Z_MACParents = 4;
        internal const int Z_RoutesTo = 5;
        internal const int Z_RoutesAway = 6;
        internal const int Z_PacketRoute = 7;
        internal const int Z_NodeEllipse = 8;

        // Pixel size for the shadowing curves bitmap:
        internal const int shadowPixelSize = 2;

        // The status rectangles on the main screen:
        static internal List<Rectangle> PacketRects = new List<Rectangle>();
        static internal List<Rectangle> PowerRects = new List<Rectangle>();
        static internal List<Rectangle> TotalPowerRects = new List<Rectangle>();
        static internal double PacketsTarget = 0;
        static internal SolidColorBrush PowerLevelOK = new SolidColorBrush(Colors.Green);
        static internal SolidColorBrush PowerLevelBackground = new SolidColorBrush(Color.FromArgb(64, 128, 128, 128));
        static internal SolidColorBrush PowerLevelWeak = new SolidColorBrush(Colors.DarkGoldenrod);
        static internal SolidColorBrush PowerLevelCritical = new SolidColorBrush(Colors.Red);
        static internal SolidColorBrush PacketLevelBrush = new SolidColorBrush(Colors.Green);
        static internal SolidColorBrush PacketLevelLine = new SolidColorBrush(Colors.Red);

        // The physical layer activity tab:
        static internal SolidColorBrush ReceiverActivityBrush = new SolidColorBrush(Colors.Blue);
        static internal SolidColorBrush TransmitterActivityBrush = new SolidColorBrush(Colors.Red);
        internal const double PHYActivityStrokeThickness = 2.0;
        static internal SolidColorBrush PHYActivityCursorBrush = new SolidColorBrush(Colors.DarkGray);
        static internal SolidColorBrush PHYActivityWhite = new SolidColorBrush(Colors.White);
        #endregion
    }
}
