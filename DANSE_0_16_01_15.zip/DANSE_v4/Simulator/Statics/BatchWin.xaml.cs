﻿using System;
using System.ComponentModel;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Threading;
using DANSE_v4;

namespace DANSE.Simulator.Statics
{
    /// <summary>
    /// Interaction logic for BatchWin.xaml
    /// </summary>

    public partial class BatchWin : Window
    {
        DispatcherTimer guiTimer;
        public delegate void BatchWinDelegate();

        private void SetUpTimer()
        {
            guiTimer = new DispatcherTimer();
            guiTimer.Interval = System.TimeSpan.FromMilliseconds(100);
            guiTimer.Tick += new EventHandler(guiTimer_Tick);
            guiTimer.IsEnabled = true;
        }

        void guiTimer_Tick(object sender, EventArgs e)
        {
            updateGUI();
            if (Globals.BatchStatus != Globals.BatchRunStatus.Running)
            {
                guiTimer.IsEnabled = false;
                this.Close();
            }
        }

        public BatchWin()
        {
            InitializeComponent();
            btnCancel.Click += new RoutedEventHandler(btnCancel_Click);
            btnCancelAll.Click += new RoutedEventHandler(btnCancelAll_Click);
            lblBatch.Content = "";
            SetUpTimer();
        }

        internal void updateGUI()
        {
            if (this.IsActive == false) return;  // Intercept attempt to update when closed
            progBar.Value = Globals.SimTime / (1e9 * Globals.SimulationLength);
            lblBatch.Content = "Running batch file: " + Globals.BatchFileName + "\nNumber " + Globals.CurrentBatchFileNumber + " of " + Globals.NumberOfBatchFiles + " batch files";
            this.Visibility = System.Windows.Visibility.Visible;
        }
        
        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            shutMeDown(Globals.BatchRunStatus.CancelThis);
        }
        private void btnCancelAll_Click(object sender, RoutedEventArgs e)
        {
            shutMeDown(Globals.BatchRunStatus.CancelAll);
        }
        internal void shutMeDown(Globals.BatchRunStatus e = Globals.BatchRunStatus.Finished) 
        {
            Globals.BatchStatus = e;
            guiTimer.IsEnabled = false;
            this.Close(); 
        }
    }
}
