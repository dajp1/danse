﻿using System;
using System.ComponentModel;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Threading;
using DANSE_v4;

namespace DANSE.Simulator.Statics
{
    /// <summary>
    /// Interaction logic for BatchThreadWin.xaml
    /// </summary>
    public partial class BatchThreadWin : Window
    {
        public BatchThreadWin()
        {
            InitializeComponent();
            btnCancel.Click += new RoutedEventHandler(btnCancel_Click);
            btnCancelAll.Click += new RoutedEventHandler(btnCancelAll_Click);
            lblBatch.Content = "";
        }
        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            shutMeDown(Globals.BatchRunStatus.CancelThis);
        }
        private void btnCancelAll_Click(object sender, RoutedEventArgs e)
        {
            shutMeDown(Globals.BatchRunStatus.CancelAll);
        }
        internal void shutMeDown(Globals.BatchRunStatus e = Globals.BatchRunStatus.Finished) 
        {
            Globals.BatchStatus = e;
        }
        internal void updateGUI()
        {
            if (this.IsActive == false) return;  // Intercept attempt to update when closed
            progBar.Value = Globals.SimTime / (1e9 * Globals.SimulationLength);
            // There's a weird thing about labels: they suppress the first underscore, so
            // if there is an underscore in the batch file name, it gets deleted.  So:
            string batchFileName = Globals.BatchFileName.Replace("_", "__");
            lblBatch.Content = "Running batch file: " + batchFileName;
            lblBatchXofX.Content = "Batch file number " + Globals.CurrentBatchFileNumber + " of " + Globals.NumberOfBatchFiles + " batch files";
            lblBatchTime.Content = Math.Round((Globals.SimTime / 1e9), 0).ToString() + " of " + Globals.SimulationLength.ToString() + " seconds elapsed";
            this.Visibility = System.Windows.Visibility.Visible;
        }
    }
}
