﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Runtime.InteropServices;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Windows.Controls.Primitives;
using System.Windows.Automation.Peers;

namespace DANSE_v4
{
    internal static class GUIBits
    {
        private const double DEFAULTHEIGHT = 26;
        private const double DEFAULTLABELWIDTH = 240;
        private const double DEFAULTCONTROLLABELWIDTH = 96;
        private const double DEFAULTCONTROLVALUEWIDTH = 60;
        private const double DEFAULTCOMBOBOXWIDTH = 110;
        private const double DEFAULTCOMBOBOXOFFSET = 100;
        private const double DEFAULTSLIDERWIDTH = 80;
        private const double DEFAULTSLIDERLABELWIDTH = 52;
        private const double DEFAULTSLIDEROFFSET = 142; // was 132
        private const double DEFAULTCHECKBOXOFFSET = 142;
        private const double DEFAULTCHECKBOXVERTICALOFFSET = 5;
        private const double DEFAULTSLIDERVALUEOFFSET = 90;

        // To help the placing of new controls on the Setup tab, there are some default
        // routines here to initialise several common control types:
        #region Region: Comboboxes and Labels
        static internal Label SetupNewLabel(List<UIElement> controls, double fromtop, string name)
        {
            Label lbl = new Label();
            lbl.VerticalAlignment = VerticalAlignment.Top;
            lbl.HorizontalAlignment = HorizontalAlignment.Left;
            lbl.VerticalContentAlignment = VerticalAlignment.Center;
            lbl.HorizontalContentAlignment = HorizontalAlignment.Left;
            Canvas.SetLeft(lbl, 0);
            Canvas.SetTop(lbl, fromtop);
            lbl.Height = DEFAULTHEIGHT;
            lbl.Width = DEFAULTLABELWIDTH;  // Default width
            lbl.Content = name;
            controls.Add(lbl);
            return lbl;
        }

        static internal ComboBoxTagStruct SetupNewComboBox<T>(List<UIElement> controls, double fromtop, string fullname, string name)
        {
            ComboBoxTagStruct tag = new ComboBoxTagStruct();

            // First the label that tells the user what this is for:
            Label lbl = new Label();
            lbl.VerticalAlignment = VerticalAlignment.Top;
            lbl.HorizontalAlignment = HorizontalAlignment.Left;
            lbl.VerticalContentAlignment = VerticalAlignment.Center;
            lbl.HorizontalContentAlignment = HorizontalAlignment.Right;
            Canvas.SetLeft(lbl, 0);
            Canvas.SetTop(lbl, fromtop);
            lbl.Height = DEFAULTHEIGHT;
            lbl.Width = DEFAULTCONTROLLABELWIDTH;
            lbl.Content = name;
            controls.Add(lbl);

            // Then the combo box itself:
            ComboBox box = new ComboBox();
            box.VerticalAlignment = VerticalAlignment.Top;
            box.HorizontalAlignment = HorizontalAlignment.Left;
            Canvas.SetLeft(box, DEFAULTCOMBOBOXOFFSET);
            Canvas.SetTop(box, fromtop);
            box.Height = DEFAULTHEIGHT - 2.0;
            box.Width = DEFAULTCOMBOBOXWIDTH;  // Default width
            box.Items.Clear();
            controls.Add(box);

            // Take the items for the combo box from the enumerated variables:
            foreach (string i in Enum.GetNames(typeof(T)))
            {
                string j = i.Replace('_', ' ');
                box.Items.Add(j);
            }
            box.Text = box.Items[0].ToString();

            // And set up the tag
            tag.theComboBox = box;
            tag.theLabel = lbl;
            tag.theName = name;
            tag.NameForMessages = fullname;
            tag.enumType = typeof(T);
            box.Tag = tag;

            return tag;
        }
        internal class ComboBoxTagStruct
        {
            internal string NameForMessages;
            internal ComboBox theComboBox;
            internal Label theLabel;
            internal string theName;
            internal Type enumType;

            internal void SetValue(string NewValue)
            {
                // This is an attempt to get the SetValue function to
                // not only set the value of the comboBox, but also
                // of the Global variable associated with this comboBox.
                // For this to work, the comboBox will need to know which
                // Global variable this is.
                //
                // On second thoughts... is this necessary?  Changing the
                // value in the comboBox should fire the value changed
                // event, which should update this value automatically;
                // and this event handler was defined when the comboBox
                // was first defined?
                //
                // I can't remember now why I need the other version 
                // of this function (see below).  Surely the combobox
                // could already know the enum type of the variable it
                // controls, and could look it up?  I could then just
                // return the new value and the calling routine could
                // set the Global variable; that way it can operate in
                // a delegate call to another thread?  This is an attempt
                // to get that idea to work.

                // First check that the value exists, and if not display an
                // error message and set the string NewValue equal to the 
                // default (first) value of the enum.
                // Note spaces should be converted to underscores first,
                // as this allows spaces in the combobox items when they are
                // automatically derived from enumerators.
                string Value = null;
                string NewValueUnderscored = NewValue.Replace(' ', '_');
                foreach (string item in Enum.GetNames(enumType))
                {
                    if (item == NewValueUnderscored) Value = NewValueUnderscored;
                }
                if (Value == null)
                {
                    MessageBox.Show(NameForMessages + " cannot be " + NewValue
                        + ".\nSetting to default value.", "Value Problem");
                    Value = Enum.GetNames(enumType)[0];
                }

                theComboBox.Text = Value.Replace('_', ' ');
            }

            internal void SetValue<T>(string NewValue, ref T variable)
            {
                // First check that the value exists, and if not display an
                // error message and set the string NewValue equal to the 
                // default (first) value of the enum.
                // Note spaces should be converted to underscores first,
                // as this allows spaces in the combobox items when they are
                // automatically derived from enumerators.
                string Value = null;
                string NewValueUnderscored = NewValue.Replace(' ', '_');
                // foreach (string item in Enum.GetNames(typeof(T)))
                foreach (string item in Enum.GetNames(enumType))
                {
                    if (item == NewValueUnderscored) Value = NewValueUnderscored;
                }
                if (Value == null)
                {
                    MessageBox.Show(NameForMessages + " cannot be " + NewValue
                        + ".\nSetting to default value.", "Value Problem");
                    // Value = Enum.GetNames(typeof(T))[0];
                    Value = Enum.GetNames(enumType)[0];
                }

                // variable = (T)Enum.Parse(typeof(T), Value);
                variable = (T)Enum.Parse(enumType, Value);
                theComboBox.Text = Value.Replace('_',' ');
            }
            internal string GetValue<T>()
            {
                return theComboBox.Text.Replace(' ','_');
            }
        }
        #endregion

        #region Region: Sliders
        // There are lots of versions of the sliders: integer, linear, log, loginteger 
        // and squarerootinteger, as well as a special log slider that can be zero, 
        // and a special case of linear integer from 0 to 1 which is shown as a checkbox.
        internal enum SliderType
        {
            linear, integer, integer125,
            log, loginteger, loginteger125, logwithzero, logwithzero125,
            squareroot, squarerootinteger,
            checkbox
        }
        private static Boolean isThisLogarithmic(SliderType x)
        {
            return (x == SliderType.log
                    || x == SliderType.loginteger
                    || x == SliderType.loginteger125
                    || x == SliderType.logwithzero
                    || x == SliderType.logwithzero125);
        }
        private static Boolean isThisLogWithZero(SliderType x)
        {
            return (x == SliderType.logwithzero
                    || x == SliderType.logwithzero125);
        }
        private static Boolean isThis125(SliderType x)
        {
            return (x == SliderType.integer125
                    || x == SliderType.loginteger125
                    || x == SliderType.logwithzero125);
        }
        private static Boolean isThisInteger(SliderType x)
        {
            return (x == SliderType.checkbox
                || x == SliderType.integer
                || x == SliderType.integer125
                || x == SliderType.loginteger
                || x == SliderType.loginteger125
                || x == SliderType.logwithzero125
                || x == SliderType.squarerootinteger);
        }
        private static Boolean isThisSquareRoot(SliderType x)
        {
            return (x == SliderType.squareroot 
                || x == SliderType.squarerootinteger);
        }
        private static Boolean isThisCheckbox(SliderType x)
        {
            return (x == SliderType.checkbox);
        }
        internal class SliderTagStruct
        {
            private string NameForMessages;
            internal Slider theSlider;
            internal TextBox theTextBox;
            internal CheckBox theCheckBox;
            internal Label theLabel;
            internal Label NameOnSetup;
            private Double Default;
            private Double Minimum;
            private Double Maximum;
            private SliderType type;
            internal Boolean CheckBoxMode;

            internal SliderTagStruct(
                double DefaultValue, double MinValue, double MaxValue,
                string fullname, Label nameLabel,
                Slider slide, Label sliderLabel, TextBox sliderTextBox,
                CheckBox sliderCheckBox, SliderType sType
                )
            {
                this.Default = DefaultValue;
                this.Minimum = MinValue;
                this.Maximum = MaxValue;
                this.NameForMessages = fullname;
                this.NameOnSetup = nameLabel;
                this.theSlider = slide;
                this.theLabel = sliderLabel;
                this.theTextBox = sliderTextBox;
                this.theCheckBox = sliderCheckBox;
                this.type = sType;
            }

            // Then a few methods:
            // CheckValue takes any possible value, adjusts it to the nearest
            //   possible, and (potentially) shows warnings for any adjustment.
            // GetActualValue returns the actual value that the slider means,
            //   not the value of the slider itself (e.g. for log slider).
            // GetSliderValue returns the real value of the slider.
            // ConvertToSliderValue returns what the slider should be set to
            //   to represent the given input value.  Anyone wanting to 
            //   change the global variable can then set the slider to that
            //   value.
            // SetSliderValue sets the slider to a given value.
            // SetLabel sets the contents of the label and textbox.
            // SetToDefault sets to the default value.
            // Enable enables or disables the slider.

            internal double CheckValue(double NewValue, Boolean warnings)
            {
                // First check that the values are sensible:
                if (NewValue == 0 && isThisLogWithZero(this.type))
                {
                    // This is OK - even though below minimum set value
                    // in this case (the minimum is the lowest value in
                    // the log span, it doesn't include the special
                    // zero value here).
                }
                else if (NewValue < Minimum)
                {
                    if (warnings) MessageBox.Show("Value for " + NameForMessages.ToString() 
                        + " is too low.\nSetting to " + Minimum.ToString(),
                        "Value Problem");
                    NewValue = Minimum;
                }
                else if (NewValue > Maximum)
                {
                    if (warnings) MessageBox.Show("Value for " + NameForMessages.ToString()
                        + " is too high.\nSetting to " + Maximum.ToString(),
                        "Value Problem");
                    NewValue = Maximum;
                }
                if (isThisInteger(this.type) == true && NewValue != Math.Round(NewValue))
                {
                    if (warnings) MessageBox.Show("Value for " + NameForMessages.ToString()
                        + " must be an integer.\nSetting to " + Math.Round(NewValue).ToString(),
                        "Value Problem");
                    NewValue = Default;
                }
                if (NewValue != Math.Round(NewValue, 6))
                {
                    if (warnings) MessageBox.Show("Value for " + NameForMessages.ToString()
                        + " can only be specified to six decimal places.  Setting to " 
                        + Math.Round(NewValue, 6).ToString(), "Value Problem");
                    NewValue = Default;
                }
                if (isThis125(this.type) && NewValue != Nearest125(NewValue))
                {
                    if (warnings) MessageBox.Show("Value for " + NameForMessages.ToString()
                        + " must be 1, 2, 5, 10, 20, 50 etc.\nSetting to " + Nearest125(NewValue).ToString(),
                        "Value Problem");
                    NewValue = Nearest125(NewValue);
                }
                return NewValue;
            }

            internal double GetSliderValue()
            {
                return theSlider.Value;
            }
            internal Boolean IsThisACheckBox()
            {
                return isThisCheckbox(this.type);
            }

            internal double GetActualValue()
            {
                // Note: logarithmic, logbutcanbezero and squareroot
                // are mutually exclusive.
                double Value = theSlider.Value;
                if (isThisLogarithmic(this.type) == true && isThisLogWithZero(this.type) == false) 
                    Value = Math.Pow(10, Value);
                else if (isThisLogWithZero(this.type))
                {
                    if (theSlider.Value == theSlider.Minimum) Value = 0.0;
                    else Value = Math.Pow(10, Value);
                }
                else if (isThisSquareRoot(this.type) == true) Value = Value * Value;

                if (isThisInteger(this.type)) Value = Math.Round(Value);
                if (isThis125(this.type)) Value = Nearest125(Value);
                return Value;
            }

            internal double ConvertToSliderValue(double Actual)
            {
                double SliderValue = CheckValue(Actual, false);
                if (isThisLogarithmic(this.type) && Actual > 0)
                    SliderValue = Math.Log10(SliderValue);
                else if (isThisLogWithZero(this.type) && Actual == 0)
                    SliderValue = theSlider.Minimum;
                else if (isThisSquareRoot(this.type)) 
                    SliderValue = Math.Sqrt(SliderValue);
                return SliderValue;
            }

            internal void SetSliderValue(string NewValue, Boolean warnings)
            {
                double temp;
                Boolean IsThisANumber = double.TryParse(NewValue, out temp);
                if (IsThisANumber == false)
                {
                    temp = this.Default;
                    MessageBox.Show("Attempt to set " + this.NameForMessages + " failed.\n" 
                        + NewValue + " is not a number", 
                        "Value Problem");
                }
                SetSliderValue(temp, warnings);
                if (IsThisACheckBox() == true)
                    this.theCheckBox.IsChecked = temp == 0 ? false : true;
            }
            internal void SetSliderValue(double NewValue, Boolean warnings)
            {
                double WantedValue = CheckValue(NewValue, warnings);
                double SliderValue = ConvertToSliderValue(WantedValue);
                theSlider.Value = SliderValue;
            }

            internal void SetLabel()
            {
                double ActualValue = this.GetActualValue();
                double AbsActualValue = Math.Abs(this.GetActualValue());

                if (isThisLogarithmic(this.type) && !isThisInteger(this.type) && AbsActualValue < 1)
                {
                    theLabel.Content = ActualValue.ToString("0.000");
                    theTextBox.Text = ActualValue.ToString("0.000");
                }
                else if (isThisLogarithmic(this.type) && !isThisInteger(this.type) && AbsActualValue < 10)
                {
                    theLabel.Content = ActualValue.ToString("0.00");
                    theTextBox.Text = ActualValue.ToString("0.00");
                }
                else if (isThisLogarithmic(this.type) && !isThisInteger(this.type) && AbsActualValue < 100)
                {
                    theLabel.Content = ActualValue.ToString("0.0");
                    theTextBox.Text = ActualValue.ToString("0.0");
                }
                else if (isThisLogarithmic(this.type))
                {
                    theLabel.Content = ActualValue.ToString("0");
                    theTextBox.Text = ActualValue.ToString("0");
                }
                  // XXX: Note: the following used to depend on this.Maximum
                  // rather than ActualValue.  This change was made to allow
                  // finer control of timeouts in reliable layers.
                else if (AbsActualValue <= 1 && !isThisInteger(this.type))
                {
                    theLabel.Content = ActualValue.ToString("0.000");
                    theTextBox.Text = ActualValue.ToString("0.000");
                }
                else if (AbsActualValue <= 10 && !isThisInteger(this.type))
                {
                    theLabel.Content = ActualValue.ToString("0.00");
                    theTextBox.Text = ActualValue.ToString("0.00");
                }
                else if (AbsActualValue <= 100 && !isThisInteger(this.type))
                {
                    theLabel.Content = ActualValue.ToString("0.0");
                    theTextBox.Text = ActualValue.ToString("0.0");
                }
                else
                {
                    theLabel.Content = ActualValue.ToString("0");
                    theTextBox.Text = ActualValue.ToString("0");
                }
                // Also, turn the textbox off:
                theTextBox.Visibility = Visibility.Hidden;
                theLabel.Visibility = IsThisACheckBox() ? Visibility.Hidden : Visibility.Visible;
            }

            internal void SetToDefault()
            {
                SetLabel();
                // If the slider was already at the default, then the value changed event
                // won't automatically fire.  If there are some side-effects of firing it,
                // then it's best to raise the value changed event anyway.
                SetSliderValue(this.Minimum, false);
                SetSliderValue(this.Maximum, false);
                SetSliderValue(this.Default, false);
                // I can't find a better way to do it than that yet.
            }
            internal void SetNewRange(double newMinimum, double newMaximum, 
                double newDefault, SliderType sType)
            {
                this.theSlider.Maximum = newMaximum;
                this.Minimum = newMinimum;
                this.Maximum = newMaximum;
                this.Default = newDefault;
                this.type = sType;

                if (newDefault < newMinimum)
                {
                    MessageBox.Show("Default set to less than minimum?", "Strange error");
                    newDefault = newMinimum;
                }
                if (newDefault > newMaximum)
                {
                    MessageBox.Show("Default set to greater than minimum?", "Strange error");
                    newDefault = newMaximum;
                }

                if (isThisSquareRoot(sType) == true)
                {
                    this.theSlider.Minimum = Math.Sqrt(newMinimum);
                    this.theSlider.Maximum = Math.Sqrt(newMaximum);
                }
                else if (isThisLogarithmic(sType))
                {
                    this.theSlider.Minimum = Math.Log10(newMinimum);
                    this.theSlider.Maximum = Math.Log10(newMaximum);
                }
                else
                {
                    this.theSlider.Minimum = newMinimum;
                    this.theSlider.Maximum = newMaximum;
                }

                // If this is the special case, then turn the slider off, and the 
                // checkbox on (or vice versa):
                if (isThisCheckbox(this.type))
                {
                    this.theSlider.Visibility = Visibility.Hidden;
                    this.theCheckBox.Visibility = Visibility.Visible;
                    this.CheckBoxMode = true;
                }
                else
                {
                    this.theSlider.Visibility = Visibility.Visible;
                    this.theCheckBox.Visibility = Visibility.Hidden;
                    this.CheckBoxMode = false;
                }

                // Then set the slider to the default value:
                SetToDefault();
                // and the default value of checkboxes:
                if (isThisCheckbox(this.type)) 
                    this.theCheckBox.IsChecked = newDefault == 0.0 ? false : true;
            }
            internal void Enable(Boolean OK)
            {
                // Unused (disabled) controls are now set invisible:
                if (OK) SetControlOpacity(1.0);
                else if (OK == false) SetControlOpacity(0.01);

                if (this.IsThisACheckBox())
                {
                    this.theSlider.IsEnabled = !OK;
                    this.theCheckBox.IsEnabled = OK;
                }
                else
                {
                    this.theSlider.IsEnabled = OK;
                    this.theCheckBox.IsEnabled = !OK;
                }

                this.theLabel.IsEnabled = OK;
                this.theTextBox.IsEnabled = OK;
                this.NameOnSetup.IsEnabled = OK;
            }
            internal void SetControlOpacity(double opacity)
            {
                // For some reason (yet to be discovered), setting the
                // unused options to Visibility.Hidden doesn't make them
                // invisible, but setting them to an Opacity of 0.01 does.
                if (this.IsThisACheckBox() == true) this.theCheckBox.Opacity = opacity;
                else this.theSlider.Opacity = opacity;
                this.theLabel.Opacity = opacity;
                this.NameOnSetup.Opacity = opacity;
            }
        }

        static internal SliderTagStruct SetupNewLinearSlider(List<UIElement> controls, double fromtop, string fullname, string name, double DefaultValue, double MinValue, double MaxValue)
        {
            return SetupNewGenericSlider(controls, fromtop, fullname, name, DefaultValue, MinValue, MaxValue, SliderType.linear);
        }
        static internal SliderTagStruct SetupNewIntegerSlider(List<UIElement> controls, double fromtop, string fullname, string name, double DefaultValue, double MinValue, double MaxValue)
        {
            return SetupNewGenericSlider(controls, fromtop, fullname, name, DefaultValue, MinValue, MaxValue, SliderType.integer);
        }
        static internal SliderTagStruct SetupNewLogSlider(List<UIElement> controls, double fromtop, string fullname, string name, double DefaultValue, double MinValue, double MaxValue)
        {
            return SetupNewGenericSlider(controls, fromtop, fullname, name, DefaultValue, MinValue, MaxValue, SliderType.log);
        }
        static internal SliderTagStruct SetupNewLogIntegerSlider(List<UIElement> controls, double fromtop, string fullname, string name, double DefaultValue, double MinValue, double MaxValue)
        {
            return SetupNewGenericSlider(controls, fromtop, fullname, name, DefaultValue, MinValue, MaxValue, SliderType.loginteger);
        }
        static internal SliderTagStruct SetupNewSquareRootIntegerSlider(List<UIElement> controls, double fromtop, string fullname, string name, double DefaultValue, double MinValue, double MaxValue)
        {
            return SetupNewGenericSlider(controls, fromtop, fullname, name, DefaultValue, MinValue, MaxValue, SliderType.squarerootinteger);
        }
        static internal SliderTagStruct SetupNewLog125Slider(List<UIElement> controls, double fromtop, string fullname, string name, double DefaultValue, double MinValue, double MaxValue)
        {
            return SetupNewGenericSlider(controls, fromtop, fullname, name, DefaultValue, MinValue, MaxValue, SliderType.loginteger125);
        }
        static internal SliderTagStruct SetupNewLog0125Slider(List<UIElement> controls, double fromtop, string fullname, string name, double DefaultValue, double MinValue, double MaxValue)
        {
            return SetupNewGenericSlider(controls, fromtop, fullname, name, DefaultValue, MinValue, MaxValue, SliderType.logwithzero125);
        }

        static internal SliderTagStruct SetupNewGenericSlider(List<UIElement> controls, double fromtop, 
            string fullname, string name, double DefaultValue, double MinValue, double MaxValue,
            SliderType sType)
        {
            // First the label that tells the user what it's for:
            Label nameLabel = new Label();
            nameLabel.VerticalAlignment = VerticalAlignment.Top;
            nameLabel.HorizontalAlignment = HorizontalAlignment.Left;
            nameLabel.VerticalContentAlignment = VerticalAlignment.Center;
            nameLabel.HorizontalContentAlignment = HorizontalAlignment.Right;
            Canvas.SetLeft(nameLabel, 0);
            Canvas.SetTop(nameLabel, fromtop);
            nameLabel.Width = DEFAULTCONTROLLABELWIDTH;
            nameLabel.Height = DEFAULTHEIGHT;
            nameLabel.Content = name;
            controls.Add(nameLabel);

            // Then the slider itself:
            Slider slide = new Slider();
            slide.VerticalAlignment = VerticalAlignment.Top;
            slide.HorizontalAlignment = HorizontalAlignment.Left;
            Canvas.SetLeft(slide, DEFAULTSLIDEROFFSET);
            Canvas.SetTop(slide, fromtop);
            slide.Height = DEFAULTHEIGHT - 2.0;
            slide.Width = DEFAULTSLIDERWIDTH;
            if (isThisSquareRoot(sType))
            {
                slide.Minimum = Math.Sqrt(MinValue);
                slide.Maximum = Math.Sqrt(MaxValue);
                slide.Value = Math.Sqrt(DefaultValue);
            }
            else if (isThisLogarithmic(sType))
            {
                slide.Minimum = Math.Log10(MinValue);
                slide.Maximum = Math.Log10(MaxValue);
                slide.Value = Math.Log10(DefaultValue);
            }
            else
            {
                slide.Minimum = MinValue;
                slide.Maximum = MaxValue;
                slide.Value = DefaultValue;
            }
            controls.Add(slide);

            // Then the checkbox, in case it is required:
            CheckBox sliderCheckBox = new CheckBox();
            sliderCheckBox.VerticalAlignment = VerticalAlignment.Top;
            sliderCheckBox.HorizontalAlignment = HorizontalAlignment.Left;
            Canvas.SetLeft(sliderCheckBox, DEFAULTCHECKBOXOFFSET);
            Canvas.SetTop(sliderCheckBox, fromtop + DEFAULTCHECKBOXVERTICALOFFSET);
            sliderCheckBox.Height = DEFAULTHEIGHT - 2.0;
            sliderCheckBox.Width = DEFAULTSLIDERWIDTH;
            sliderCheckBox.Content = " Disabled";
            sliderCheckBox.Visibility = Visibility.Hidden;
            controls.Add(sliderCheckBox);

            if (isThisCheckbox(sType))
            {
                // Special case: this is the checkbox, not the slider
                sliderCheckBox.Visibility = Visibility.Visible;
                slide.Visibility = Visibility.Hidden;
            }

            // Then the label that gives its value:
            Label sliderLabel = new Label();
            sliderLabel.VerticalAlignment = VerticalAlignment.Top;
            sliderLabel.HorizontalAlignment = HorizontalAlignment.Left;
            sliderLabel.VerticalContentAlignment = VerticalAlignment.Center;
            sliderLabel.HorizontalContentAlignment = HorizontalAlignment.Center;
            Canvas.SetLeft(sliderLabel, DEFAULTSLIDERVALUEOFFSET);
            Canvas.SetTop(sliderLabel, fromtop);
            sliderLabel.Width = DEFAULTSLIDERLABELWIDTH;
            sliderLabel.Height = DEFAULTHEIGHT - 2.0;
            sliderLabel.Visibility = isThisCheckbox(sType) ? Visibility.Hidden : Visibility.Visible;
            controls.Add(sliderLabel);

            // And the textbox that allows typing:
            TextBox sliderTextBox = new TextBox();
            sliderTextBox.VerticalAlignment = VerticalAlignment.Top;
            sliderTextBox.HorizontalAlignment = HorizontalAlignment.Left;
            sliderTextBox.VerticalContentAlignment = VerticalAlignment.Center;
            sliderTextBox.HorizontalContentAlignment = HorizontalAlignment.Center;
            Canvas.SetLeft(sliderTextBox, Canvas.GetLeft(sliderLabel));
            Canvas.SetTop(sliderTextBox, Canvas.GetTop(sliderLabel));
            sliderTextBox.Width = sliderLabel.Width;
            sliderTextBox.Height = sliderLabel.Height;
            sliderTextBox.Visibility = Visibility.Hidden;
            controls.Add(sliderTextBox);

            // All their tags points to each other so they can find each other:
            GUIBits.SliderTagStruct TagStruct = new GUIBits.SliderTagStruct(
                DefaultValue, MinValue, MaxValue,
                fullname, nameLabel,
                slide, sliderLabel, sliderTextBox, sliderCheckBox, sType);

            sliderLabel.Tag = TagStruct;
            sliderTextBox.Tag = TagStruct;
            sliderCheckBox.Tag = TagStruct;
            slide.Tag = TagStruct;
            nameLabel.Tag = TagStruct;

            // Now the event handlers for all this:
            sliderCheckBox.Checked += new RoutedEventHandler(sliderCheckBox_Checked);
            sliderCheckBox.Unchecked += new RoutedEventHandler(sliderCheckBox_Unchecked);
            sliderLabel.MouseDoubleClick += new System.Windows.Input.MouseButtonEventHandler(sliderLabel_MouseDoubleClick);
            sliderTextBox.KeyDown += new System.Windows.Input.KeyEventHandler(sliderTextBox_KeyDown);
            sliderTextBox.LostFocus += new RoutedEventHandler(sliderTextBox_LostFocus);
            slide.ValueChanged += new RoutedPropertyChangedEventHandler<double>(slide_ValueChanged);
            slide.MouseDoubleClick += new System.Windows.Input.MouseButtonEventHandler(slide_MouseDoubleClick);
            slide_ValueChanged(slide, null);
            return TagStruct;
        }

        static void sliderCheckBox_Unchecked(object sender, RoutedEventArgs e)
        {
            // Find the slider, and set its value to zero:
            CheckBox x = (CheckBox)sender;
            Slider slide = (Slider)((GUIBits.SliderTagStruct)(x.Tag)).theSlider;
            slide.Value = 0.0;
            x.Content = " Disabled";
            sliderCheckBox_UpdateGUI();
        }

        static void sliderCheckBox_Checked(object sender, RoutedEventArgs e)
        {
            // Find the slider, and set its value to one:
            CheckBox x = (CheckBox)sender;
            Slider slide = (Slider)((GUIBits.SliderTagStruct)(x.Tag)).theSlider;
            slide.Value = 1.0;
            x.Content = " Enabled";
            sliderCheckBox_UpdateGUI();
        }

        static void sliderCheckBox_UpdateGUI()
        {
            // This is such a hack... but I haven't found a better way yet
            if ((string)Globals.ctsMACStyle.theComboBox.Text == "CSMA")
                ((MainWindow)Globals.MainWindow).MACSetupCSMAControlsEnable();
        }

        static void sliderTextBox_LostFocus(object sender, RoutedEventArgs e)
        {
            // Then just update with the new value in the textbox:
            sliderTextBox_Update(sender);
        }
        static void sliderTextBox_KeyDown(object sender, System.Windows.Input.KeyEventArgs e)
        {
            // If the user did not press the enter key, then ignore:
            if (e.Key != System.Windows.Input.Key.Enter) return;
            // Then just update with the new value in the textbox:
            sliderTextBox_Update(sender);
        }
        static void sliderTextBox_Update(object sender)
        {
            // The value in the textbox has just changed, so update the position of the slider
            // (after checking the new value is sensible).
            TextBox thistextbox = (TextBox)sender;
            SliderTagStruct thisTag = (SliderTagStruct)thistextbox.Tag;
            Slider thisslider = thisTag.theSlider;
            double NewSliderValue;
            double.TryParse(thistextbox.Text, out NewSliderValue);

            // Check and adjust the new value for sensibleness:
            NewSliderValue = thisTag.CheckValue(NewSliderValue, false);
            thisslider.Value = thisTag.ConvertToSliderValue(NewSliderValue);

            // Then turn off the textbox, and turn the label back on:
            Label thislabel = ((SliderTagStruct)thistextbox.Tag).theLabel;
            thislabel.Visibility = thisTag.IsThisACheckBox() ? Visibility.Hidden : Visibility.Visible;
            thistextbox.Visibility = Visibility.Hidden;
        }

        static void slide_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            // The value of the slider has just changed, so change the value in the label:
            Slider thisslider = (Slider)sender;
            SliderTagStruct thisTag = (SliderTagStruct)thisslider.Tag;
            thisTag.SetLabel();
        }

        static void sliderLabel_MouseDoubleClick(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            // Double-clicking the slider label turns it into a textbox ready for data entry,
            // provided this is not a special checkbox mode case:            
            Label thislabel = (Label)sender;
            if (((SliderTagStruct)thislabel.Tag).CheckBoxMode == true) return;
            TextBox thistextbox = ((SliderTagStruct)thislabel.Tag).theTextBox;
            thistextbox.Text = thislabel.Content.ToString();
            thistextbox.Visibility = Visibility.Visible;
            thislabel.Visibility = Visibility.Hidden;
            // Set focus to this element so that any other active textbox will
            // lose focus, which in turn prompts that new value to be parsed:
            thistextbox.Focus();
        }

        static void slide_MouseDoubleClick(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            SliderTagStruct thing = (SliderTagStruct)((Slider)sender).Tag;
            thing.SetToDefault();
        }
        #endregion

        #region Region: Assistance routines
        // A few routines to help with various things.  Firstly, one which takes
        // in any input double, and returns the nearest 1, 2 or 5 thing.
        static internal double Nearest125(double thing)
        {
            double intpart = Math.Floor(Math.Log10(thing));
            double fracpart = Math.Log10(thing) % 1.0;
            double multiplyby = 1.0;
            if (fracpart > 0.54407) multiplyby = 5.0;
            else if (fracpart > 0.17609) multiplyby = 2.0;
            return Math.Pow(10, intpart) * multiplyby;
        }
        #endregion

        #region Region: Lines between nodes
        // A routine to draw lines between nodes when required.
        static private List<Line> LinesForDisplay = new List<Line>();
        static internal void DrawDisplayLine(int node1, int node2, Brush LineStyle, Boolean dash, double opacity, int zLevel)
        {
            Line newLine = new Line();
            newLine.Stroke = LineStyle;
            newLine.StrokeThickness = 2;

            newLine.X1 = Globals.GridCentre.X + Globals.myNodes[node1].GetPosition().X * Globals.GridSize.Width / 2.0;
            newLine.Y1 = Globals.GridCentre.Y - Globals.myNodes[node1].GetPosition().Y * Globals.GridSize.Height / 2.0;
            newLine.X2 = Globals.GridCentre.X + Globals.myNodes[node2].GetPosition().X * Globals.GridSize.Width / 2.0;
            newLine.Y2 = Globals.GridCentre.Y - Globals.myNodes[node2].GetPosition().Y * Globals.GridSize.Height / 2.0;

            if (dash == true) newLine.StrokeDashArray = Globals.LineRouteDashes;
            newLine.Opacity = opacity;

            ((MainWindow)Globals.MainWindow).Canvas2D.Children.Add(newLine);
            Canvas.SetZIndex(newLine, zLevel);
            LinesForDisplay.Add(newLine);
        }
        static internal void ClearDisplayLines()
        {
            foreach (Line thing in LinesForDisplay)
                ((MainWindow)Globals.MainWindow).Canvas2D.Children.Remove(thing);
            LinesForDisplay.Clear();
        }
        #endregion

        #region Region: Scrollbar helper methods
        // Code to help with setting and placing the scrollbar thumbs.
        // Adapted from Dan Lamping's code found at
        // http://www.wpfmentor.com/2008/12/how-to-set-thumb-position-and-length-of.html

        static internal class ScrollBarThumbStuff
        {
            static internal double GetThumbCentre(ScrollBar bar)
            {
                double thumbLength = GetThumbLength(bar);
                double trackLength = bar.Maximum - bar.Minimum;
                double thumbCentre = thumbLength / 2 + bar.Minimum + (bar.Value - bar.Minimum) *
                    (trackLength - thumbLength) / trackLength;
                return thumbCentre;
            }

            static internal void SetThumbCentre(ScrollBar bar, double thumbCentre)
            {
                double thumbLength = GetThumbLength(bar);
                double trackLength = bar.Maximum - bar.Minimum;

                if (thumbCentre >= bar.Maximum - thumbLength / 2)
                {
                    bar.Value = bar.Maximum;
                }
                else if (thumbCentre <= bar.Minimum + thumbLength / 2)
                {
                    bar.Value = bar.Minimum;
                }
                else if (thumbLength >= trackLength)
                {
                    bar.Value = bar.Minimum;
                }
                else
                {
                    bar.Value = bar.Minimum + trackLength *
                        ((thumbCentre - bar.Minimum - thumbLength / 2)
                        / (trackLength - thumbLength));
                }
            }

            static internal double GetThumbLength(ScrollBar bar)
            {
                double trackLength = bar.Maximum - bar.Minimum;
                return trackLength * bar.ViewportSize /
                    (trackLength + bar.ViewportSize);
            }

            static internal void SetThumbLength(ScrollBar bar, double thumbLength)
            {
                double trackLength = bar.Maximum - bar.Minimum;

                if (thumbLength < 0)
                {
                    bar.ViewportSize = 0;
                }
                else if (thumbLength < trackLength)
                {
                    bar.ViewportSize = trackLength * thumbLength / (trackLength - thumbLength);
                }
                else
                {
                    bar.ViewportSize = double.MaxValue;
                }
            }
        }

        #endregion
    }
}
