using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Runtime.InteropServices;
using System.Text;

namespace DANSE_v4
{
    #region Region: The protocol base class with virtual methods

    // This is the base class that the Transport, Network, LogicalLink and MAC protocol
    // layers derive from.  It provides a few parameters and methods that are common to 
    // all protocol layers, some help with writing comments, and a packet store that 
    // any protocol layer can use.

    internal class cProtocol
    {
        // All protocols know which node they belong to:
        protected cNode node;

        // All protocols have up to seven user-defined parameters:
        internal double ParameterOne;
        internal double ParameterTwo;
        internal double ParameterThree;
        internal double ParameterFour;
        internal double ParameterFive;
        internal double ParameterSix;
        internal double ParameterSeven;

        // Some defined integers for the user routines to use: 
        protected const int NOWHERE = Globals.NOWHERE;
        protected const int BROADCAST = Globals.BROADCAST;
        protected const double INFINITY = Globals.INFINITY;
        protected const int CHANNELS = Globals._MACNumberOfChannels;

        // Getting and setting active channels:
        protected Boolean SetTransmitChannel(int newChannel)
            { return node.SetTransmitChannel(newChannel); }
        protected Boolean SetReceiveChannel(int newChannel)
            { return node.SetReceiveChannel(newChannel); }
        protected int GetTransmitChannel()
            { return node.GetTransmitChannel(); }
        protected int GetReceiveChannel()
            { return node.GetReceiveChannel(); }
        protected Boolean AmIReceiving()
            { return node.GetReceiveState() == Globals.ReceiverState.Receiving; }
        protected Boolean AmITransmitting()
            { return node.GetTransmitState() == Globals.TransmitterState.Transmitting; }

        // Finding out about the node:
        protected int GetMyNumber() { return node.GetNumber(); }
        protected double GetMyXCoordinate() { return 100 * node.GetPosition().X; }
        protected double GetMyYCoordinate() { return 100 * node.GetPosition().Y; }
        protected double GetMyEnergyLeft() { return node.GetEnergyLeft(); }
        protected double GetMyTime() { return (double)node.GetTime() / 1e9; }
        protected void SetMyTime(double newTime) 
        {
            if (Globals.ClockSync == Globals.ClockSyncType.Global)
            {
                // Attempt to set clock in global clock mode.  That's illegal, 
                // in this mode all nodes have the same clock, they can't set
                // it to something different themselves.
                Globals.ShowMessageBox("Attempt to set individual clock in global clocks mode.\nYou can't do this.", "Illegal request.");
            }
            else
            {
                if (newTime >= -10000 && newTime <= 10000)
                {
                    node.SetTime((long)Math.Round(newTime * 1.0e9));
                }
                else
                {
                    Globals.ShowMessageBox("Attempt to set individual clock to " + newTime.ToString() + " secs.\nThis is an illegal value.", "Illegal request.");
                }
            }
        }

        // There's an exception to the "no cross-layer information" rule, all
        // layers are allowed to see the received power of a received packet:
        protected double GetRxPower(cPacket packet)
        { return packet.MetaInformation().GetReceivedPower(); }

        // All the protocols share a printfToLog method for writing to the log file
        protected void printfToLog(string format, params Object[] parameters)
        {
            string thing = myPrintf.sprintf(format, parameters);
            OutToLog(thing);
        }
        protected void OutToLog(string message)
        {
            if (Globals.LogEventsOn == true) Globals.NewLogEvent.AppendLine(message);
        }
        // and a messagebox for more urgent / critical messages:
        protected void printfToMessageBox(string format, params Object[] parameters)
        {
            string thing = myPrintf.sprintf(format, parameters);
            Globals.ShowMessageBox(thing, "User Message");
        }
        // and they can write to the console on the front screen using the
        // printf function:
        protected void printf(string thing, params object[] Parameters)
        {
            string newbit = myPrintf.sprintf(thing, Parameters) + '\n';
            Globals.ConsoleText.Append(newbit);

            // You can only update the console in normal running mode.
            // (In batch mode the running thread can't update the UI.)
            if (Globals.BatchStatus == Globals.BatchRunStatus.Default)
            {
                ((MainWindow)Globals.MainWindow).txtConsole.Text = Globals.ConsoleText.ToString();
            }
        }
        // And they might call these functions with C-style strings.  In these
        // cases, I'll enforce a maximum message size Globals.MaxMessageSize:
        unsafe protected void printfToLog(char* format, params Object[] parameters)
        { printfToLog(CharArrayToString(format), parameters); }
        unsafe protected void printfToMessageBox(char* format, params Object[] parameters)
        { printfToMessageBox(CharArrayToString(format), parameters); }
        unsafe protected void printf(char* thing, params Object[] parameters)
        { printf(CharArrayToString(thing), parameters); }
        unsafe private string CharArrayToString(char* whatever)
        {
            StringBuilder thing = new StringBuilder(Globals.MaxMessageSize);
            int next = 0;
            while (next < Globals.MaxMessageSize && whatever[next] != '\0')
                thing.Append(whatever[next++]);
            return thing.ToString();
        }

        // User protocols can generate random numbers, again
        // this is written to mimic C:
        protected const int RAND_MAX = 65535;
        protected void srand(double seed)
        {
            // Start again, let the old one be eaten up by the garbage collector:
            Globals.userRands = new Random((int)seed);
        }
        protected int rand()
        {
            return Globals.userRands.Next(RAND_MAX);
        }

        // A bodge to allow users to use something that looks and works a bit 
        // like malloc() and free(), so I can sell this to them as 'C'.
        protected unsafe void *malloc(int size)
        {
            // The ToPointer() method on an IntPtr returns a void*
            return Marshal.AllocHGlobal(size).ToPointer();
        }
        protected unsafe void free(void* whatever)
        {
            // I'm not 100% sure this next line is right, can
            // you cast a void* to a IntPtr?  The compiler seems
            // to think you can.
            //
            // Also, note this is put inside a try-catch block to
            // prevent problems due to multiple attempts to free
            // the same memory.  This can happen if, for example,
            // in batch file the EndSimulation() function is
            // called twice (once in the simulation thread, and
            // once when cleaning up).
            try
            {
                Marshal.FreeHGlobal((IntPtr)whatever);
            } catch {}
        }

        // Users may also want to use the standard C maths functions.  
        // I'll bodge these too:
        protected double sin(double input) { return Math.Sin(input); }
        protected double cos(double input) { return Math.Cos(input); }
        protected double tan(double input) { return Math.Tan(input); }
        protected double log(double input) { return Math.Log(input); }
        protected double log10(double input) { return Math.Log10(input); }
        protected double exp(double input) { return Math.Exp(input); }
        protected double abs(double input) { return Math.Abs(input); }
        protected double min(double A, double B) { return Math.Min(A, B); }
        protected double max(double A, double B) { return Math.Max(A, B); }
        protected double pow(double A, double B) { return Math.Pow(A, B); }
        protected double acos(double input) { return Math.Acos(input); }
        protected double asin(double input) { return Math.Asin(input); }
        protected double atan(double input) { return Math.Atan(input); }
        protected double atan2(double A, double B) { return Math.Atan2(A, B); }
        protected double sqrt(double input) { return Math.Sqrt(input); }
        protected double floor(double input) { return Math.Floor(input); }
        protected double ceil(double input) { return Math.Ceiling(input); }
        protected double round(double input) { return Math.Round(input); }

        // Setting and getting the cross-layer information (a double can
        // be associated with a packet by any layer, and read by any other
        // layer).  The tag is used for identifying packets in the GUI.
        protected Object GetCrossLayer (cPacket packet)
        {
            return packet.MetaInformation().GetCrossLayer();
        }
        protected void SetCrossLayer(cPacket packet, Object value)
        {
            packet.MetaInformation().SetCrossLayer(value);
        }
        // Users can also set and get packet priority, and set a tag
        // that is used for identifying packets on the display
        protected void SetPacketTag(cPacket packet, string tag)
        {
            packet.MetaInformation().SetTag(tag);
        }
        protected void SetPacketPriority(cPacket packet, int priority)
        {
            packet.MetaInformation().SetPriority(priority);
        }
        protected int GetPacketPriority(cPacket packet)
        {
            return packet.MetaInformation().GetPriority();
        }

        // Adding and removing headers.  These are unsafe routines for use by the 
        // students.  In the built-in protocols, it's better not to use these
        // functions, instead use the AddHeader, ViewHeader and RemoveHeader
        // methods in the cPacket class.

        // All user headers and packets are stored internally as managed byte arrays.
        // However, the interfaces to the user routines use pointers, so I have to convert.
        // This is done by having an area of dynamically assigned unsafe memory:
        // when a header is passed back to the user routines it is copied into
        // here first.  (C# doesn't allow pointers to be declared to managed
        // objects, since the garbage collector sometimes moves them around.)
        unsafe byte* dummyHeaderStorage = (byte*)Marshal.AllocHGlobal(Globals.MaxHeaderSize);
        unsafe byte* dummyPacketStorage = (byte*)Marshal.AllocHGlobal(Globals.MaxPacketSize + 4*Globals.MaxHeaderSize);
        // There's another dummy storage that's used by some other routines as well,
        // including the routeing layer for the routes stored in the routeing table
        protected const int DummyStorageSize = 1024;
        unsafe protected byte* dummyStorage = (byte*)Marshal.AllocHGlobal(DummyStorageSize);

        // This means I need to ensure there's a destructor that frees up this memory
        // whenever the protocol layer is destroyed:
        ~cProtocol() 
        { 
            unsafe 
            { 
                Marshal.FreeHGlobal((IntPtr)dummyHeaderStorage);
                Marshal.FreeHGlobal((IntPtr)dummyPacketStorage);
                Marshal.FreeHGlobal((IntPtr)dummyStorage);
            } 
        }

        // Then I can allow the users to add and remove header by passing pointers,
        // just like C:
        unsafe protected void AddHeader(cPacket packet, byte* header, int headersize)
        {
            // First check I can cope with headers of this size (this isn't a problem
            // with sending headers, but it is when receiving them).
            if (headersize > Globals.MaxHeaderSize)
            {
                Globals.ShowMessageBox("Sorry, can't cope with headers of size " + headersize.ToString()
                    + ".  The maximum size is " + Globals.MaxHeaderSize.ToString() + ".",
                    "Serious Error");
                headersize = Globals.MaxHeaderSize;
            }
            // Then convert to a byte array, then add this to the packet:
            byte[] newHeader = new byte[headersize];
            for (int loop = 0; loop < headersize; loop++) newHeader[loop] = header[loop];
            packet.AddHeader(newHeader, headersize);
        }
        unsafe protected byte* RemoveHeader(cPacket packet)
        {
            return ViewOrRemoveHeader(packet, true);
        }
        unsafe protected byte* ViewHeader(cPacket packet)
        {
            return ViewOrRemoveHeader(packet, false);
        }
        unsafe private byte* ViewOrRemoveHeader(cPacket packet, Boolean remove)
        {
            // If there is no header to remove, give an error:
            if (packet.HowManyHeaders() == 0)
            {
                Globals.ShowMessageBox("Attempt to remove header from packet with no headers.", "Header Problem");
                return dummyHeaderStorage;
            }
            // If the header is not a byte array, the user is trying to read in
            // a system header - this means they've got something wrong...
            if (packet.GetHeaderType() != typeof(byte[]))
            {
                Globals.ShowMessageBox("Attempt by user routine to remove internal header from a \ndifferent layer or header in an unexpected format.", "Header Problem");
                return dummyHeaderStorage;
            }
            // Then I need to extract the information from the header 
            // into a managed byte array:
            byte[] Outermost;
            if (remove) Outermost = (byte[])packet.RemoveHeader();
            else Outermost = (byte[])packet.ViewHeader();

            // Now copy the header into the dummyStorage memory and return:
            for (int loop = 0; loop < Outermost.GetLength(0); loop++)
                dummyHeaderStorage[loop] = Outermost[loop];
            return dummyHeaderStorage;
        }

        // Users may want to make packets: this is a routine that lets them do it:
        unsafe protected cPacket MakePacket(byte* content, int size)
        {
            // First check that the packet isn't too long:
            if (size > Globals.MaxPacketSize)
            {
                Globals.ShowMessageBox("Sorry, can't cope with packets bigger than "
                    + Globals.MaxPacketSize + " bytes.\nPacket has been truncated",
                    "Warning");
                size = Globals.MaxPacketSize;
            }
            // The packet constructor takes a managed byte array, so the first
            // thing is to build one from the unmanaged pointer arriving:
            byte[] NewContent = new byte[size];
            for (int loop = 0; loop < size; loop++) NewContent[loop] = content[loop];
            // Then generate the new packet, and return it:
            cPacket newPacket = new cPacket(size, node.GetNumber(), NewContent, 0);
            return newPacket;
        }
        // There's also a function to copy packets for C-programmers:
        protected cPacket CopyPacket(cPacket Original) 
        {
            cPacket copy = cPacket.DeepCopy(Original);
            if (copy == null)
                printfToMessageBox("Memory error: strongly advise stop.");
            return copy;
        }

        // Since they can make packets, they need to be able to view them as well:
        protected int GetPacketSize(cPacket packet) { return packet.GetPacketSize(); } 
        unsafe protected byte* GetPacketContents(cPacket packet)
        {
            // If there are any headers left, return an error.
            if (packet.HowManyHeaders() > 0)
            {
                Globals.ShowMessageBox("Attempt to access a packet's contents when there is a header left.", "Header Problem");
                return dummyPacketStorage;
            }
            // Otherwise, check the contents are a managed byte array
            if (packet.ViewContents() is byte[])
            {
                // if so, copy the packet data,
                byte[] Contents = (byte[])packet.ViewContents();
                if (Contents != null)
                {
                    for (int loop = 0; loop < Contents.GetLength(0); loop++)
                        dummyPacketStorage[loop] = Contents[loop];
                }
            }
            // otherwise, throw an error:
            else
            {
                Globals.ShowMessageBox("Attempt to access a packet's contents which were not created by a user protocol.", 
                    "Can't understand packet contents");
            }
            return dummyPacketStorage;
        }

        // For packet buffers, there's a general PacketStoreElement and a packet list,
        // and some methods to add and remove packets from the list, as well as 
        // working out whether a packet (or a copy of a packet) is in the list.
        protected class cPacketStoreElement
        {
            cPacket StoredPacket;   // The packet to be stored
            int PacketSystemNumber; // To tell packets apart easily
            long WhenStored;        // The time when the packet was stored
            Object metaData;        // Meta-data stored with the packet

            protected internal cPacketStoreElement(cNode thisnode, cPacket packet, Object whatever = null)
            {
                this.StoredPacket = packet;
                this.PacketSystemNumber = packet.MetaInformation().GetSystemNumber();
                this.WhenStored = thisnode.GetTime();
                this.metaData = whatever;
            }
            protected internal cPacket GetPacket() { return StoredPacket; }
            protected internal Object GetMetadata() { return metaData; }
            protected internal void SetMetadata(Object x) { metaData = x; }
            protected internal long GetWhenStored() { return WhenStored; }
        }
        protected List<cPacketStoreElement> PacketStore = new List<cPacketStoreElement>(); // For storing packets in reliable mode.

        // This needs to be internal to allow main window to interrogate
        // it for the infobox to find out how many packets waiting:
        internal int GetQueueLength() { return PacketStore.Count; }

        // Can put packets in queue with either some, or no metadata:
        protected void PutPacketInQueue(cPacket Packet, Object whatever = null)
        {
            PacketStore.Add(new cPacketStoreElement(node, Packet, whatever));
        }
        protected int FindPacketInQueue(cPacket Packet)
        {
            int Index = PacketStore.FindIndex(o => 
                o.GetPacket().MetaInformation().GetSystemNumber() == Packet.MetaInformation().GetSystemNumber());
            return Index;
        }
        protected Object GetMetadataInQueue(int Index)
        {
            if (Index < 0 || Index >= PacketStore.Count) return null;
            return PacketStore[Index].GetMetadata();
        }
        protected void ReplaceMetadataInQueue(int Index, Object whatever)
        {
            if (Index < 0 || Index >= PacketStore.Count) return;
            PacketStore[Index].SetMetadata(whatever);
        }
        protected cPacket GetPacketInQueue(int Index)
        {
            if (Index < 0 || Index >= PacketStore.Count) return null;
            return PacketStore[Index].GetPacket();
        }
        protected void ClearQueue()
        {
            PacketStore.Clear();
        }
        protected cPacket RemovePacketFromQueue(int Index)
        {
            if (Index < 0 || Index >= PacketStore.Count) return null;
            cPacket OneToGet = PacketStore[Index].GetPacket();
            PacketStore.RemoveAt(Index);
            return OneToGet;
        }
        protected int GetIndexOfOldestPacket()
        {
            long LastStored = (long)1e18;
            int Oldest = -1;
            for (int loop = 0; loop < PacketStore.Count; loop++)
            {
                if (PacketStore[loop].GetWhenStored() < LastStored)
                {
                    LastStored = PacketStore[loop].GetWhenStored();
                    Oldest = loop;
                }
            }
            return Oldest;
        }
        protected cPacket GetOldestPacket()
        {
            long LastStored = (long)1e18;
            cPacket Oldest = null;
            for (int loop = 0; loop < PacketStore.Count; loop++)
            {
                if (PacketStore[loop].GetWhenStored() < LastStored)
                {
                    LastStored = PacketStore[loop].GetWhenStored();
                    Oldest = PacketStore[loop].GetPacket();
                }
            }
            return Oldest;
        }

        // Functions for setting and getting parameters during a simulation run
        // This is the default, which lists packets in the queue, and is called
        // unless it is overridden by a function further down the inheritance.
        internal virtual string AskQuery(string s)
        {
            StringBuilder store = new StringBuilder(256);
            if (this.PacketStore.Count > 0)
            {
                store.Append("Packets in transmit queue:\n");
                foreach (cPacketStoreElement ele in this.PacketStore)
                {
                    store.Append("  ");
                    store.Append(ele.GetPacket().ToString());
                    store.Append("\n");
                }
            }
            else
            {
                store.Append("Packet store is empty");
            }
            return store.ToString();
        }

        // All functions can also pause the simulator by calling the Pause
        // function, which effectively just clicks the Pause button.  Note
        // that this cannot be done in a batch file, since it requires
        // access the the GUI.
        internal void Pause()
        {
            if (Globals.BatchStatus != Globals.BatchRunStatus.Running)
                ((MainWindow)Globals.MainWindow).btnRun_Click(null, null);
        }
    }
    #endregion

    #region Region: The partial MainWindow class for the transport layer controls
    public partial class MainWindow : Window
    {
        internal List<UIElement> GetTransportControls()
        {
            List<UIElement> controls = new List<UIElement>();
            int VOffset = Globals.CONTROLVOFFSETSTART;
            int VOffsetDifference = Globals.CONTROLVOFFSETDELTA;

            // A label and ComboBox for the transport style:
            Globals.ctsTransportStyle = GUIBits.SetupNewComboBox<Globals.TransportType>(controls, VOffset, "transport prototol", "Protocol");
            Globals.ctsTransportStyle.theComboBox.SelectionChanged += new SelectionChangedEventHandler(TransportTypeCombo_SelectionChanged);
            VOffset += VOffsetDifference;

            // Then a slider for the (initial) timeout interval:
            Globals.stsTransportTimeOut = GUIBits.SetupNewLinearSlider(controls, VOffset, "transport timeout timer", "Init Timeout", 
                Globals._TransportTimeOutDefault, Globals._TransportTimeOutMinimum, Globals._TransportTimeOutMaximum);
            Globals.stsTransportTimeOut.theSlider.ValueChanged += new RoutedPropertyChangedEventHandler<double>(TransportTimeOutSlider_ValueChanged);
            TransportTimeOutSlider_ValueChanged(Globals.stsTransportTimeOut.theSlider, null);
            VOffset += VOffsetDifference;

            // Then a slider for the maximum number of re-transmission attempts:
            Globals.stsTransportAttempts = GUIBits.SetupNewIntegerSlider(controls, VOffset, "transport maximum attempts", "Retries",
                Globals._TransportRetriesDefault, Globals._TransportRetriesMinimum, Globals._TransportRetriesMaximum);
            Globals.stsTransportAttempts.theSlider.ValueChanged += new RoutedPropertyChangedEventHandler<double>(TransportAttemptsSlider_ValueChanged);
            TransportAttemptsSlider_ValueChanged(Globals.stsTransportAttempts.theSlider, null);
            VOffset += VOffsetDifference;

            // Then the two transport layer parameters:
            Globals.stsTransportParameterOne = GUIBits.SetupNewLinearSlider(controls, VOffset, "transport parameter A", "Parameter A",
                Globals._UserParameterDefault, Globals._UserParameterMinimum, Globals._UserParameterMaximum);
            Globals.stsTransportParameterOne.theSlider.ValueChanged += new RoutedPropertyChangedEventHandler<double>(TransportParameterOne_ValueChanged);
            TransportParameterOne_ValueChanged(Globals.stsTransportParameterOne.theSlider, null);
            VOffset += VOffsetDifference;

            Globals.stsTransportParameterTwo = GUIBits.SetupNewLinearSlider(controls, VOffset, "transport parameter B", "Parameter B",
                Globals._UserParameterDefault, Globals._UserParameterMinimum, Globals._UserParameterMaximum);
            Globals.stsTransportParameterTwo.theSlider.ValueChanged += new RoutedPropertyChangedEventHandler<double>(TransportParameterTwo_ValueChanged);
            TransportParameterTwo_ValueChanged(Globals.stsTransportParameterTwo.theSlider, null);
            VOffset += VOffsetDifference;

            Globals.stsTransportParameterThree = GUIBits.SetupNewLinearSlider(controls, VOffset, "transport parameter C", "Parameter C",
                Globals._UserParameterDefault, Globals._UserParameterMinimum, Globals._UserParameterMaximum);
            Globals.stsTransportParameterThree.theSlider.ValueChanged += new RoutedPropertyChangedEventHandler<double>(TransportParameterThree_ValueChanged);
            TransportParameterThree_ValueChanged(Globals.stsTransportParameterThree.theSlider, null);
            VOffset += VOffsetDifference;

            Globals.stsTransportParameterFour = GUIBits.SetupNewLinearSlider(controls, VOffset, "transport parameter C", "Parameter C",
                Globals._UserParameterDefault, Globals._UserParameterMinimum, Globals._UserParameterMaximum);
            Globals.stsTransportParameterFour.theSlider.ValueChanged += new RoutedPropertyChangedEventHandler<double>(TransportParameterFour_ValueChanged);
            TransportParameterFour_ValueChanged(Globals.stsTransportParameterFour.theSlider, null);
            VOffset += VOffsetDifference;

            // Then send back the list
            return controls;
        }

        void TransportAttemptsSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            Globals.TransportRetries = (int)Math.Floor(((GUIBits.SliderTagStruct)(((Slider)sender).Tag)).GetActualValue());
            foreach (cNode node in Globals.myNodes) node.TransportLayer.Retries = Globals.TransportRetries;
        }

        void TransportTimeOutSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            double sliderReading = ((GUIBits.SliderTagStruct)(((Slider)sender).Tag)).GetActualValue();
            double roundReading = Math.Round(sliderReading, 2);
            Globals.TransportTimeOut = roundReading;
            foreach (cNode node in Globals.myNodes) node.TransportLayer.MaxTimeOut = (long)(1e9 * Globals.TransportTimeOut);
        }

        void TransportTypeCombo_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ComboBox thing = (ComboBox)sender;
            String chosen = thing.Items[thing.SelectedIndex].ToString().Replace(' ', '_');
            try { Globals.TransportStyle = (Globals.TransportType)Enum.Parse(typeof(Globals.TransportType), chosen); }
            catch { MessageBox.Show("Transport Type " + chosen + " not Recognised", "Serious Error"); }
            ResetTransportControls();
            switch (Globals.TransportStyle)
            {
                case Globals.TransportType.Best_Effort: TransportSetupBestEffortControls(); break;
                case Globals.TransportType.Reliable: TransportSetupReliableControls(); break;
                case Globals.TransportType.User: TransportSetupUserControls(); break;
                default: MessageBox.Show("Unknown transport type: unable to setup controls.", "User Error");
                    break;
            }
        }

        void TransportParameterOne_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            Globals.TransportParameterOne = ((GUIBits.SliderTagStruct)((Slider)sender).Tag).GetActualValue();
            Globals.TransportParameterOne = Math.Round(Globals.TransportParameterOne, 2);
            foreach (cNode node in Globals.myNodes)
                node.TransportLayer.ParameterOne = Globals.TransportParameterOne;
        }
        void TransportParameterTwo_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            Globals.TransportParameterTwo = ((GUIBits.SliderTagStruct)((Slider)sender).Tag).GetActualValue();
            Globals.TransportParameterTwo = Math.Round(Globals.TransportParameterTwo, 2);
            foreach (cNode node in Globals.myNodes)
                node.TransportLayer.ParameterTwo = Globals.TransportParameterTwo;
        }
        void TransportParameterThree_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            Globals.TransportParameterThree = ((GUIBits.SliderTagStruct)((Slider)sender).Tag).GetActualValue();
            Globals.TransportParameterThree = Math.Round(Globals.TransportParameterThree, 2);
            foreach (cNode node in Globals.myNodes)
                node.TransportLayer.ParameterThree = Globals.TransportParameterThree;
        }
        void TransportParameterFour_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            Globals.TransportParameterFour = ((GUIBits.SliderTagStruct)((Slider)sender).Tag).GetActualValue();
            Globals.TransportParameterFour = Math.Round(Globals.TransportParameterFour, 2);
            foreach (cNode node in Globals.myNodes)
                node.TransportLayer.ParameterFour = Globals.TransportParameterFour;
        }
        void ResetTransportControls()
        {
            Globals.stsTransportTimeOut.Enable(false);
            Globals.stsTransportTimeOut.NameOnSetup.Content = "Timeout";
            Globals.stsTransportAttempts.Enable(false);
            Globals.stsTransportAttempts.NameOnSetup.Content = "Retries";

            Globals.stsTransportParameterOne.Enable(false);
            Globals.stsTransportParameterOne.SetNewRange(0, 10, 1, GUIBits.SliderType.linear);
            Globals.stsTransportParameterOne.NameOnSetup.Content = "Not Used";

            Globals.stsTransportParameterTwo.Enable(false);
            Globals.stsTransportParameterTwo.SetNewRange(0, 10, 1, GUIBits.SliderType.linear);
            Globals.stsTransportParameterTwo.NameOnSetup.Content = "Not Used";

            Globals.stsTransportParameterThree.Enable(false);
            Globals.stsTransportParameterThree.SetNewRange(0, 10, 1, GUIBits.SliderType.linear);
            Globals.stsTransportParameterThree.NameOnSetup.Content = "Not Used";

            Globals.stsTransportParameterFour.Enable(false);
            Globals.stsTransportParameterFour.SetNewRange(0, 10, 1, GUIBits.SliderType.linear);
            Globals.stsTransportParameterFour.NameOnSetup.Content = "Not Used";
        }
    }
    #endregion
    #region Region: The transport class wrapper
    partial class cTransport : cProtocol
    {
        // Some internal parameters for all transport schemes:
        protected int TransportPacketsSentSoFar = 0;
        internal long MaxTimeOut = (long)(1e9 * Globals.TransportTimeOut);
        internal int Retries = Globals.TransportRetries;

        // The initialiser:
        internal cTransport(cNode node)
        {
            this.node = node;
            ClearQueue();
        }

        // Routines to pass packets between the layers for the user routines:
        // Note that A = destination or source, B = destination port, C = source port
        protected void SendPacketToApplicationLayer(cPacket packet, int SourceNode, 
            int DestinationPort, int SourcePort)
        {
            // Finally some idiot checking, then send the packet:
            if (packet == null)
            {
                Globals.ShowMessageBox("Transport Layer is attempting to send a null packet to the Application Layer.\n"
                + "Something has gone wrong.", "Serious protocol error");
            }
            else
            {
                Globals.theQueue.AddEvent(new cEvent(node, packet, node.GetTime(),
                    EventType.Application_PacketArrivesFromTransportLayer,
                    SourceNode, DestinationPort, SourcePort));
            }
        }
        protected void SendPacketToNetworkLayer(cPacket packet, int Destination)
        {
            // Finally some idiot checking, then send the packet:
            if (packet == null)
            {
                Globals.ShowMessageBox("Transport Layer is attempting to send a null packet to the Network Layer.\n"
                + "Something has gone wrong.", "Serious protocol error");
            }
            else
            {

                packet.MetaInformation().SetFinalDestination(Destination);
                Globals.theQueue.AddEvent(new cEvent(node, packet, node.GetTime(),
                    EventType.Network_PacketArrivesFromTransportLayer,
                    Destination));
            }
        }
        protected void CancelCallbacks(int A = -1)
        {
            Globals.theQueue.RemoveEvents(GetMyNumber(), EventType.Transport_Callback, A);
        }
        protected void RequestRelativeCallback(double timeInSeconds, int A, cPacket packet = null)
        {
            Globals.theQueue.AddEvent(new cEvent(node, packet, (long)(node.GetTime() + timeInSeconds * 1e9),
                EventType.Transport_Callback, A));
        }
        protected void RequestAbsoluteCallback(double timeInSeconds, int A, cPacket packet = null)
        {
            Globals.theQueue.AddEvent(new cEvent(node, packet, (long)(timeInSeconds * 1e9),
                EventType.Transport_Callback, A));
        }
    }
    #endregion

    #region Region: The partial MainWindow class for the network layer controls
    public partial class MainWindow : Window
    {
        internal List<UIElement> GetNetworkControls()
        {
            List<UIElement> controls = new List<UIElement>();
            int VOffset = Globals.CONTROLVOFFSETSTART;
            int VOffsetDifference = Globals.CONTROLVOFFSETDELTA;

            // A label and ComboBox for the network protocol:
            Globals.ctsNetworkStyle = GUIBits.SetupNewComboBox<Globals.NetworkType>(controls, VOffset, "network protocol", "Protocol");
            Globals.ctsNetworkStyle.theComboBox.SelectionChanged += new SelectionChangedEventHandler(NetworkTypeCombo_SelectionChanged);
            VOffset += VOffsetDifference;

            // Then a slider for the default HopCount:
            Globals.stsNetworkHopCount = GUIBits.SetupNewIntegerSlider(controls, VOffset, "maximum hop count", "Hop Count", 5, 1, 20);
            Globals.stsNetworkHopCount.theSlider.ValueChanged += new RoutedPropertyChangedEventHandler<double>(NetworkHopCountSlider_ValueChanged);
            NetworkHopCountSlider_ValueChanged(Globals.stsNetworkHopCount.theSlider, null);
            VOffset += VOffsetDifference;

            // Then the two network layer parameters:
            Globals.stsNetworkParameterOne = GUIBits.SetupNewLinearSlider(controls, VOffset, "network parameter A", "Parameter A",
                Globals._UserParameterDefault, Globals._UserParameterMinimum, Globals._UserParameterMaximum);
            Globals.stsNetworkParameterOne.theSlider.ValueChanged += new RoutedPropertyChangedEventHandler<double>(NetworkParameterOne_ValueChanged);
            NetworkParameterOne_ValueChanged(Globals.stsNetworkParameterOne.theSlider, null);
            VOffset += VOffsetDifference;

            Globals.stsNetworkParameterTwo = GUIBits.SetupNewLinearSlider(controls, VOffset, "network parameter B", "Parameter B",
                Globals._UserParameterDefault, Globals._UserParameterMinimum, Globals._UserParameterMaximum);
            Globals.stsNetworkParameterTwo.theSlider.ValueChanged += new RoutedPropertyChangedEventHandler<double>(NetworkParameterTwo_ValueChanged);
            NetworkParameterTwo_ValueChanged(Globals.stsNetworkParameterTwo.theSlider, null);
            VOffset += VOffsetDifference;

            Globals.stsNetworkParameterThree = GUIBits.SetupNewLinearSlider(controls, VOffset, "Network parameter B", "Parameter B",
                Globals._UserParameterDefault, Globals._UserParameterMinimum, Globals._UserParameterMaximum);
            Globals.stsNetworkParameterThree.theSlider.ValueChanged += new RoutedPropertyChangedEventHandler<double>(NetworkParameterThree_ValueChanged);
            NetworkParameterThree_ValueChanged(Globals.stsNetworkParameterThree.theSlider, null);
            VOffset += VOffsetDifference;

            Globals.stsNetworkParameterFour = GUIBits.SetupNewLinearSlider(controls, VOffset, "Network parameter B", "Parameter B",
            Globals._UserParameterDefault, Globals._UserParameterMinimum, Globals._UserParameterMaximum);
            Globals.stsNetworkParameterFour.theSlider.ValueChanged += new RoutedPropertyChangedEventHandler<double>(NetworkParameterFour_ValueChanged);
            NetworkParameterFour_ValueChanged(Globals.stsNetworkParameterFour.theSlider, null);
            VOffset += VOffsetDifference;

            Globals.stsNetworkParameterFive = GUIBits.SetupNewLinearSlider(controls, VOffset, "Network parameter B", "Parameter B",
            Globals._UserParameterDefault, Globals._UserParameterMinimum, Globals._UserParameterMaximum);
            Globals.stsNetworkParameterFive.theSlider.ValueChanged += new RoutedPropertyChangedEventHandler<double>(NetworkParameterFive_ValueChanged);
            NetworkParameterFive_ValueChanged(Globals.stsNetworkParameterFive.theSlider, null);
            VOffset += VOffsetDifference;

            Globals.stsNetworkParameterSix = GUIBits.SetupNewLinearSlider(controls, VOffset, "Network parameter B", "Parameter B",
            Globals._UserParameterDefault, Globals._UserParameterMinimum, Globals._UserParameterMaximum);
            Globals.stsNetworkParameterSix.theSlider.ValueChanged += new RoutedPropertyChangedEventHandler<double>(NetworkParameterSix_ValueChanged);
            NetworkParameterSix_ValueChanged(Globals.stsNetworkParameterSix.theSlider, null);
            VOffset += VOffsetDifference;

            Globals.stsNetworkParameterSeven = GUIBits.SetupNewLinearSlider(controls, VOffset, "Network parameter B", "Parameter B",
            Globals._UserParameterDefault, Globals._UserParameterMinimum, Globals._UserParameterMaximum);
            Globals.stsNetworkParameterSeven.theSlider.ValueChanged += new RoutedPropertyChangedEventHandler<double>(NetworkParameterSeven_ValueChanged);
            NetworkParameterSeven_ValueChanged(Globals.stsNetworkParameterSeven.theSlider, null);
            VOffset += VOffsetDifference;

            // Then send back the list
            return controls;
        }

        private void NetworkHopCountSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            Globals.HopCount = (int)Math.Floor(((GUIBits.SliderTagStruct)(((Slider)sender).Tag)).GetActualValue());
        }

        private void NetworkTypeCombo_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ComboBox thing = (ComboBox)sender;
            String chosen = thing.Items[thing.SelectedIndex].ToString().Replace(' ','_');
            try { Globals.NetworkStyle = (Globals.NetworkType)Enum.Parse(typeof(Globals.NetworkType), chosen); }
            catch { MessageBox.Show("Network Type " + chosen + " not Recognised", "Serious Error"); }
            // Then update the controls:
            ResetNetworkControls();
            switch (Globals.NetworkStyle)
            {
                case Globals.NetworkType.Direct: NetworkSetupDirectControls(); break;
                case Globals.NetworkType.Flooding: NetworkSetupFloodingControls(); break;
                case Globals.NetworkType.Bellman_Ford: NetworkSetupBellmanFordControls(); break;
                case Globals.NetworkType.On_Demand: NetworkSetupOnDemandControls(); break;
                case Globals.NetworkType.User: NetworkSetupUserControls(); break;
                default: MessageBox.Show("Unknown network type: unable to setup controls.", "User Error");
                    break;
            } 
        }

        void NetworkParameterOne_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            Globals.NetworkParameterOne = ((GUIBits.SliderTagStruct)((Slider)sender).Tag).GetActualValue();
            Globals.NetworkParameterOne = Math.Round(Globals.NetworkParameterOne, 2);
            foreach (cNode node in Globals.myNodes)
                node.NetworkLayer.ParameterOne = Globals.NetworkParameterOne;
        }
        void NetworkParameterTwo_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            Globals.NetworkParameterTwo = ((GUIBits.SliderTagStruct)((Slider)sender).Tag).GetActualValue();
            Globals.NetworkParameterTwo = Math.Round(Globals.NetworkParameterTwo, 2);
            foreach (cNode node in Globals.myNodes)
                node.NetworkLayer.ParameterTwo = Globals.NetworkParameterTwo;
        }
        void NetworkParameterThree_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            Globals.NetworkParameterThree = ((GUIBits.SliderTagStruct)((Slider)sender).Tag).GetActualValue();
            Globals.NetworkParameterThree = Math.Round(Globals.NetworkParameterThree, 2);
            foreach (cNode node in Globals.myNodes)
                node.NetworkLayer.ParameterThree = Globals.NetworkParameterThree;
        }
        void NetworkParameterFour_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            Globals.NetworkParameterFour = ((GUIBits.SliderTagStruct)((Slider)sender).Tag).GetActualValue();
            Globals.NetworkParameterFour = Math.Round(Globals.NetworkParameterFour, 2);
            foreach (cNode node in Globals.myNodes)
                node.NetworkLayer.ParameterFour = Globals.NetworkParameterFour;
        }
        void NetworkParameterFive_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            Globals.NetworkParameterFive = ((GUIBits.SliderTagStruct)((Slider)sender).Tag).GetActualValue();
            Globals.NetworkParameterFive = Math.Round(Globals.NetworkParameterFive, 2);
            foreach (cNode node in Globals.myNodes)
                node.NetworkLayer.ParameterFive = Globals.NetworkParameterFive;
        }
        void NetworkParameterSix_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            Globals.NetworkParameterSix = ((GUIBits.SliderTagStruct)((Slider)sender).Tag).GetActualValue();
            Globals.NetworkParameterSix = Math.Round(Globals.NetworkParameterSix, 2);
            foreach (cNode node in Globals.myNodes)
                node.NetworkLayer.ParameterSix = Globals.NetworkParameterSix;
        }
        void NetworkParameterSeven_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            Globals.NetworkParameterSeven = ((GUIBits.SliderTagStruct)((Slider)sender).Tag).GetActualValue();
            Globals.NetworkParameterSeven = Math.Round(Globals.NetworkParameterSeven, 2);
            foreach (cNode node in Globals.myNodes)
                node.NetworkLayer.ParameterSeven = Globals.NetworkParameterSeven;
        }
        private void ResetNetworkControls()
        {
            Globals.stsNetworkHopCount.Enable(false);
            Globals.stsNetworkParameterOne.Enable(false);
            Globals.stsNetworkParameterOne.SetNewRange(0, 10, 1, GUIBits.SliderType.linear);
            Globals.stsNetworkParameterOne.NameOnSetup.Content = "Not Used";
            Globals.stsNetworkParameterTwo.Enable(false);
            Globals.stsNetworkParameterTwo.SetNewRange(0, 10, 1, GUIBits.SliderType.linear);
            Globals.stsNetworkParameterTwo.NameOnSetup.Content = "Not Used";
            Globals.stsNetworkParameterThree.Enable(false);
            Globals.stsNetworkParameterThree.SetNewRange(0, 10, 1, GUIBits.SliderType.linear);
            Globals.stsNetworkParameterThree.NameOnSetup.Content = "Not Used";
            Globals.stsNetworkParameterFour.Enable(false);
            Globals.stsNetworkParameterFour.SetNewRange(0, 10, 1, GUIBits.SliderType.linear);
            Globals.stsNetworkParameterFour.NameOnSetup.Content = "Not Used";
            Globals.stsNetworkParameterFive.Enable(false);
            Globals.stsNetworkParameterFive.SetNewRange(0, 10, 1, GUIBits.SliderType.linear);
            Globals.stsNetworkParameterFive.NameOnSetup.Content = "Not Used";
            Globals.stsNetworkParameterSix.Enable(false);
            Globals.stsNetworkParameterSix.SetNewRange(0, 10, 1, GUIBits.SliderType.linear);
            Globals.stsNetworkParameterSix.NameOnSetup.Content = "Not Used";
            Globals.stsNetworkParameterSeven.Enable(false);
            Globals.stsNetworkParameterSeven.SetNewRange(0, 10, 1, GUIBits.SliderType.linear);
            Globals.stsNetworkParameterSeven.NameOnSetup.Content = "Not Used";
        }
    }
    #endregion
    #region Region: The network class wrapper
    partial class cNetwork : cProtocol
    {
        // First, the constructor for the network layer:
        internal cNetwork(cNode node)
        {
            this.node = node;
            Routes.Clear();         // Clear the routeing table
            ClearQueue();           // Clear the queue of packets
        }

        // The wrapper class provides a sample routeing table.  Routes can be stored
        // with either a next hop or a complete path to the destination.  Routes are
        // time-stamped when they are put into the table, and the time-stamp can be 
        // read and updated by the user.  Routes alos have a cost, and a general
        // purpose double parameter that is stored alongwith them.
        // 
        // The user-accessible functions are:
        //   General purpose function:
        //     protected int GetNumberOfRoutes()
        //     protected void ClearRouteingTable()        
        //     protected string PrintRouteingTable()
        //   To add and delete entries to/from the routeing table:
        //     protected void AddRouteingTableEntry(int Destination, int NextHop, double Cost, double Para = 0.0)
        //     protected void AddRouteingTableEntry(int Destination, byte *Route, int RouteLength, double Cost, double Para = 0.0)
        //     protected void AddRouteingTableEntry(int Destination, List<int> Route, double Cost, double Para = 0.0)
        //     protected Boolean DeleteRouteingTableEntry(int Destination)
        //   To look up routes and other parameters:
        //     protected double LookupCost(int Destination)
        //     internal int LookupNextHop(int Destination)
        //     protected long LookupValidTime(int Destination)
        //     protected double LookupParameter(int Destination)
        //     internal List<int> LookUpRoute(int Destination)
        //     protected byte *LookUpRoute(int Destination, int *Hops)
        //  To examine entries in the routeing table:
        //     protected double GetCostByIndex(int index)
        //     protected int GetDestinationByIndex(int index)
        //     protected int GetNextHopByIndex(int index)
        //     protected long GetValidTimeByIndex(int index)
        //     protected double GetParameterByIndex(int index)

        private class dajpRouteingTableEntry
        {
            internal int Destination;
            internal int NextHop;
            internal List<int> Route;
            internal double Cost;
            internal long ValidTime;
            internal Object Parameter;

            // Table can either store a single next hop value, or a complete route:
            internal dajpRouteingTableEntry(int Dest, int Next, double Cost, long ValidTime, Object Para)
            {
                this.Destination = Dest;
                this.NextHop = Next;
                this.Cost = Cost;
                this.ValidTime = ValidTime;
                this.Parameter = Para;
                this.Route = null;
            }
            internal dajpRouteingTableEntry(int Dest, List<int> Route, double Cost, long ValidTime, Object Para)
            {
                this.Destination = Dest;
                this.NextHop = (Route.Count > 0) ? Route[0] : NOWHERE;
                this.Cost = Cost;
                this.ValidTime = ValidTime;
                this.Parameter = Para;
                this.Route = Route;
            }
        }
        List<dajpRouteingTableEntry> Routes = new List<dajpRouteingTableEntry>();

        unsafe protected void AddRouteingTableEntry(int Destination, byte *Route, int RouteLength, double Cost, Object para = null)
        {
            // For C programmers: you can put in the route as a byte array...
            List<int> newRoute = new List<int>();
            for (int loop = 0; loop < RouteLength; loop++) newRoute.Add(Route[loop]);
            AddRouteingTableEntry(Destination, newRoute, Cost, para);
        }
        protected void AddRouteingTableEntry(int destination, List<int> route, double cost, Object para = null)
        {
            // First find out if this entry is already here, and if so get rid of it
            // before adding in the new entry (to update things):
            int index = Routes.FindIndex(o => o.Destination == destination);
            if (index != -1) Routes.RemoveAt(index);
            Routes.Add(new dajpRouteingTableEntry(destination, route, cost, node.GetTime(), para));
        }
        protected void AddRouteingTableEntry(int destination, int nextHop, double cost, Object para = null)
        {
            // First find out if this entry is already here, and if so get rid of it
            // before adding in the new entry (to update things):
            int index = Routes.FindIndex(o => o.Destination == destination);
            if (index != -1) Routes.RemoveAt(index);
            Routes.Add(new dajpRouteingTableEntry(destination, nextHop, cost, node.GetTime(), para));
        }
        protected Boolean DeleteRouteingTableEntry(int destination)
        {
            // Get rid of the entry to this destination, and return false
            // if the route does not exist:
            int index = Routes.FindIndex(o => o.Destination == destination);
            if (index == -1) return false;
            Routes.RemoveAt(index);
            return true;
        }
        protected int GetNumberOfRoutes()
        {
            return Routes.Count;
        }
        protected void ClearRouteingTable()
        {
            // Clears the routeing table of all entries except the one to the 
            // node itself, which is set back to default values.
            Routes.Clear();
            int MyNumber = GetMyNumber();
            AddRouteingTableEntry(MyNumber, MyNumber, 0.0, 0.0);
        }
        protected double LookupCost(int Destination)
        {
            double Cost = Globals.INFINITY;
            foreach (dajpRouteingTableEntry thing in Routes)
                if (thing.Destination == Destination) Cost = thing.Cost;
            return Cost;
        }
        // The next one is internal, since it's used to plot routes on the screen
        internal int LookupNextHop(int Destination)
        {
            int NextHop = Globals.NOWHERE;
            foreach (dajpRouteingTableEntry thing in Routes)
                if (thing.Destination == Destination) NextHop = thing.NextHop;
            return NextHop;
        }
        protected long LookupValidTime(int Destination)
        {
            long ThisTime = 0;
            foreach (dajpRouteingTableEntry thing in Routes)
                if (thing.Destination == Destination) ThisTime = thing.ValidTime;
            return ThisTime;
        }
        protected Object LookupParameter(int Destination)
        {
            Object ThisPara = null;
            foreach (dajpRouteingTableEntry thing in Routes)
                if (thing.Destination == Destination) ThisPara = thing.Parameter;
            return ThisPara;
        }
        internal List<int> LookUpRoute(int Destination)
        {
            List<int> theRoute = new List<int>();
            foreach (dajpRouteingTableEntry thing in Routes)
                if (thing.Destination == Destination)
                {
                    if (thing.Route != null)
                        foreach (int x in thing.Route) theRoute.Add(x);
                }
            if (theRoute.Count == 0) return null;
            else return theRoute;
        }
        unsafe protected byte *LookUpRoute(int Destination, int *Hops)
        {
            List<int> theRoute = LookUpRoute(Destination);
            if (theRoute == null)
            {
                *Hops = 0;
                return (byte *)this.dummyStorage;
            }
            int countTo = (int)Math.Min(DummyStorageSize, theRoute.Count);
            for (int loop = 0; loop < countTo; loop++)
                dummyStorage[loop] = (byte)theRoute[loop];
            return (byte *)dummyStorage;
        }
        private Boolean CheckIndexValue(int index)
        {
            if (index < 0 || index >= Routes.Count)
            {
                MessageBox.Show("Request for entry " + index.ToString()
                    + " in routeing table with only " + Routes.Count.ToString()
                    + " entries.", "Serious Error");
                return false;
            }
            return true;
        }
        protected double GetCostByIndex(int index)
        {
            if (CheckIndexValue(index) == false) return INFINITY;
            return Routes[index].Cost;
        }
        protected int GetDestinationByIndex(int index)
        {
            if (CheckIndexValue(index) == false) return NOWHERE;
            return Routes[index].Destination;
        }
        protected int GetNextHopByIndex(int index)
        {
            if (CheckIndexValue(index) == false) return NOWHERE;
            return Routes[index].NextHop;
        }
        protected long GetValidTimeByIndex(int index)
        {
            if (CheckIndexValue(index) == false) return 0;
            return Routes[index].ValidTime;
        }
        protected Object GetParameterByIndex(int index)
        {
            if (CheckIndexValue(index) == false) return null;
            return Routes[index].Parameter;
        }

        protected string PrintRouteingTable()
        {
            List<String> RouteStrings = new List<string>();
            StringBuilder Thing = new StringBuilder();
            Thing.Append("Routeing table for node " + GetMyNumber().ToString() + " at time " + node.GetTime().ToString() + "\n");

            // First I need to know if this is a distance-vector or
            // path-vector protocol:
            Boolean distanceVector = true;
            if (Routes.Count > 0)
            {
                if (Routes[0].Route != null) distanceVector = false;
            }

            foreach (dajpRouteingTableEntry entry in Routes)
            {
                StringBuilder thing = new StringBuilder(64);
                thing.Append("  To: " + String.Format("{0,-2}", entry.Destination) + "\t");

                // Then distance vector can be neatly formatted since I know the 
                // rough size of all the fields; path vector is better just to
                // let the format be whatever comes out.
                if (distanceVector == true)
                {
                    thing.Append(RouteToString(entry.Destination) + "\t");
                    thing.Append("  Cost: " + String.Format("{0,-3}", entry.Cost) + "\t");
                    thing.Append("  (Timestamp: " + entry.ValidTime.ToString() + ")");
                }
                else
                {
                    thing.Append("  Cost: " + String.Format("{0,-3}", entry.Cost) + "\t");
                    thing.Append("  (Timestamp: " + entry.ValidTime.ToString() + ")\t");
                    string theRoute = RouteToString(entry.Destination);
                    thing.Append(theRoute);
                }
                RouteStrings.Add(thing.ToString());
            }

            // Then sort in numeric order of destinations:
            RouteStrings.Sort(delegate(string A, string B)
            {
                // XXX Tidy this up a bit...
                if (A == null || B == null) return 0;
                if (A == B) return 0;
                int a, b;
                string[] As = A.Split(' ');
                string[] Bs = B.Split(' ');
                if (As.Length < 4 || Bs.Length < 4) return 0;
                Int32.TryParse(As[3], out a);
                Int32.TryParse(Bs[3], out b);
                return a == b ? 0 : a > b ? 1 : -1;
            });

            foreach (string s in RouteStrings) Thing.AppendLine(s);
            return Thing.ToString();
        }
        private string RouteToString(int dest)
        {
            // Converts an entire route to a string so it can be printed:
            StringBuilder sb = new StringBuilder(128);
            List<int> route = LookUpRoute(dest);
            int nextHop = LookupNextHop(dest);
            // Then there are three options:
            if (nextHop == NOWHERE && route == null)
            {
                return "No route known";
            }
            else if (route != null)
            {
                sb.Append("  Route: " + route[0].ToString());
                for (int loop = 1; loop < route.Count; loop++)
                    sb.Append(":" + route[loop]);
            }
            else
            {
                sb.Append("  Next Hop: " + String.Format("{0,-3}", nextHop));
            }
            return sb.ToString();
        }

        // There's a default method for generating hop costs in here as well.
        internal double DefaultCost(double rxPower, double txPower)
        {
            // Originally, I used hopCost = 1 / rxPower / 10000; but 
            // the current version seems better equiped to take
            // transmit power into account as well:
            double hopCost = Math.Max(1.0, txPower / rxPower / 10);
            return hopCost;
        }

        // There's a default behaviour for queries for the network layer.
        // Currently, this just prints the routeing table:
        internal override string AskQuery(string s)
        {
            // If query is of the form "R x y" then it returns
            // the route to node y, if just "R x" then it
            // returns the entire routeing table.
            string[] words = s.Split(' ');

            if (words.Length > 2)
            {
                int src, dest;
                Int32.TryParse(words[1], out src);
                Int32.TryParse(words[2], out dest);
                string ans = "Route from node " + src.ToString()
                    + " to node " + dest.ToString()
                    + ": " + RouteToString(dest);
                double thisCost = LookupCost(dest);
                if (thisCost < Globals.INFINITY)
                    ans += " (Cost: " + LookupCost(dest) + ")";
                return ans;
            }
            else
            {
              return PrintRouteingTable();
            }
        }

        // Service routine for cNetwork.cs user files:
        protected int GetMaximumHopCount() { return Globals.HopCount; }
        protected void ReportOutcome(cPacket packet, int A)
        {
            Globals.theQueue.AddEvent(new cEvent(node, packet, node.GetTime(),
                EventType.Transport_Callback, A));
        }
        protected void SendPacketToTransportLayer(cPacket packet, int source)
        {
            // Finally some idiot checking, then send the packet:
            if (packet == null)
            {
                Globals.ShowMessageBox("Network Layer is attempting to send a null packet to the Transport Layer.\n"
                + "Something has gone wrong.", "Serious protocol error");
            }
            else
            {
                Globals.theQueue.AddEvent(new cEvent(node, packet, node.GetTime(),
                    EventType.Transport_PacketArrivesFromNetworkLayer, source));
            }
        }
        protected void SendPacketToLogicalLinkLayer(cPacket packet, int NextHop)
        {
            // Finally some idiot checking, then send the packet:
            if (packet == null)
            {
                Globals.ShowMessageBox("Network Layer is attempting to send a null packet to the LLC Layer.\n"
                + "Something has gone wrong.", "Serious protocol error");
            }
            else
            {
                packet.MetaInformation().SetLastHop(node.GetNumber());
                packet.MetaInformation().SetNextHop(NextHop);
                Globals.theQueue.AddEvent(new cEvent(node, packet, node.GetTime(),
                    EventType.LogicalLink_PacketArrivesFromNetworkLayer, NextHop));
            }
        }
        protected void CancelCallbacks(int A = -1)
        {
            Globals.theQueue.RemoveEvents(GetMyNumber(), EventType.Network_Callback, A);
        }
        protected void RequestRelativeCallback(double timeInSeconds, int A, cPacket packet = null)
        {
            Globals.theQueue.AddEvent(new cEvent(node, packet, (long)(node.GetTime() + timeInSeconds * 1e9),
                EventType.Network_Callback, A));
        }
        protected void RequestAbsoluteCallback(double timeInSeconds, int A, cPacket packet = null)
        {
            Globals.theQueue.AddEvent(new cEvent(node, packet, (long)(timeInSeconds * 1e9),
                EventType.Network_Callback, A));
        }
    }
    #endregion

    #region Region: The partial MainWindow class for the logical link layer controls
    public partial class MainWindow : Window
    {
        internal List<UIElement> GetLogicalLinkControls()
        {
            List<UIElement> controls = new List<UIElement>();
            int VOffset = Globals.CONTROLVOFFSETSTART;
            int VOffsetDifference = Globals.CONTROLVOFFSETDELTA;

            // A label and ComboBox for the logical-link style:
            Globals.ctsLogicalLinkType = GUIBits.SetupNewComboBox<Globals.LogicalLinkType>(controls, VOffset, "logical-link prototol", "Protocol");
            Globals.ctsLogicalLinkType.theComboBox.SelectionChanged += new SelectionChangedEventHandler(LogicalLinkTypeCombo_SelectionChanged);
            VOffset += VOffsetDifference;

            // Then a slider for the (initial) timeout interval:
            Globals.stsLogicalLinkTimeOut = GUIBits.SetupNewLinearSlider(controls, VOffset, "logical-link timeout timer", "Init Timeout",
                Globals._LogicalLinkTimeOutDefault, Globals._LogicalLinkTimeOutMinimum, Globals._LogicalLinkTimeOutMaximum);
            Globals.stsLogicalLinkTimeOut.theSlider.ValueChanged += new RoutedPropertyChangedEventHandler<double>(LogicalLinkTimeOutSlider_ValueChanged);
            LogicalLinkTimeOutSlider_ValueChanged(Globals.stsLogicalLinkTimeOut.theSlider, null);
            VOffset += VOffsetDifference;

            // Then a slider for the maximum number of re-transmission attempts:
            Globals.stsLogicalLinkAttempts = GUIBits.SetupNewIntegerSlider(controls, VOffset, "logical-link maximum attempts", "Retries",
                Globals._LogicalLinkRetriesDefault, Globals._LogicalLinkRetriesMinimum, Globals._LogicalLinkRetriesMaximum);
            Globals.stsLogicalLinkAttempts.theSlider.ValueChanged += new RoutedPropertyChangedEventHandler<double>(LogicalLinkAttemptsSlider_ValueChanged);
            LogicalLinkAttemptsSlider_ValueChanged(Globals.stsLogicalLinkAttempts.theSlider, null);
            VOffset += VOffsetDifference;

            // Then the two LogicalLink layer parameters:
            Globals.stsLogicalLinkParameterOne = GUIBits.SetupNewLinearSlider(controls, VOffset, "logical-link parameter A", "Parameter A",
                Globals._UserParameterDefault, Globals._UserParameterMinimum, Globals._UserParameterMaximum);
            Globals.stsLogicalLinkParameterOne.theSlider.ValueChanged += new RoutedPropertyChangedEventHandler<double>(LogicalLinkParameterOne_ValueChanged);
            LogicalLinkParameterOne_ValueChanged(Globals.stsLogicalLinkParameterOne.theSlider, null);
            VOffset += VOffsetDifference;

            Globals.stsLogicalLinkParameterTwo = GUIBits.SetupNewLinearSlider(controls, VOffset, "logical-link parameter B", "Parameter B",
                Globals._UserParameterDefault, Globals._UserParameterMinimum, Globals._UserParameterMaximum);
            Globals.stsLogicalLinkParameterTwo.theSlider.ValueChanged += new RoutedPropertyChangedEventHandler<double>(LogicalLinkParameterTwo_ValueChanged);
            LogicalLinkParameterTwo_ValueChanged(Globals.stsLogicalLinkParameterTwo.theSlider, null);
            VOffset += VOffsetDifference;

            Globals.stsLogicalLinkParameterThree = GUIBits.SetupNewLinearSlider(controls, VOffset, "logical-link parameter C", "Parameter C",
                Globals._UserParameterDefault, Globals._UserParameterMinimum, Globals._UserParameterMaximum);
            Globals.stsLogicalLinkParameterThree.theSlider.ValueChanged += new RoutedPropertyChangedEventHandler<double>(LogicalLinkParameterThree_ValueChanged);
            LogicalLinkParameterThree_ValueChanged(Globals.stsLogicalLinkParameterThree.theSlider, null);
            VOffset += VOffsetDifference;

            Globals.stsLogicalLinkParameterFour = GUIBits.SetupNewLinearSlider(controls, VOffset, "logical-link parameter C", "Parameter C",
                Globals._UserParameterDefault, Globals._UserParameterMinimum, Globals._UserParameterMaximum);
            Globals.stsLogicalLinkParameterFour.theSlider.ValueChanged += new RoutedPropertyChangedEventHandler<double>(LogicalLinkParameterFour_ValueChanged);
            LogicalLinkParameterFour_ValueChanged(Globals.stsLogicalLinkParameterFour.theSlider, null);
            VOffset += VOffsetDifference;
            // Then send back the list
            return controls;
        }

        void LogicalLinkAttemptsSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            Globals.LogicalLinkRetries = (int)Math.Floor(((GUIBits.SliderTagStruct)(((Slider)sender).Tag)).GetActualValue());
            foreach (cNode node in Globals.myNodes) node.LogicalLinkLayer.Retries = Globals.LogicalLinkRetries;
        }

        void LogicalLinkTimeOutSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            double sliderReading = ((GUIBits.SliderTagStruct)(((Slider)sender).Tag)).GetActualValue();
            double roundReading = Math.Round(sliderReading, 2);
            Globals.LogicalLinkTimeOut = roundReading;
            foreach (cNode node in Globals.myNodes) node.LogicalLinkLayer.MaxTimeOut = (long)(1e9 * Globals.LogicalLinkTimeOut);
        }

        void LogicalLinkTypeCombo_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ComboBox thing = (ComboBox)sender;
            String chosen = thing.Items[thing.SelectedIndex].ToString().Replace(' ', '_');
            try { Globals.LogicalLinkStyle = (Globals.LogicalLinkType)Enum.Parse(typeof(Globals.LogicalLinkType), chosen); }
            catch { MessageBox.Show("Logical-Link Type " + chosen + " not Recognised", "Serious Error"); }
            ResetLogicalLinkControls();
            switch (Globals.LogicalLinkStyle)
            {
                case Globals.LogicalLinkType.Best_Effort: LogicalLinkSetupBestEffortControls(); break;
                case Globals.LogicalLinkType.Reliable: LogicalLinkSetupReliableControls(); break;
                case Globals.LogicalLinkType.User: LogicalLinkSetupUserControls(); break;
                default: MessageBox.Show("Unknown logical-link type: unable to setup controls.", "User Error");
                    break;
            }
        }

        void LogicalLinkParameterOne_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            Globals.LogicalLinkParameterOne = ((GUIBits.SliderTagStruct)((Slider)sender).Tag).GetActualValue();
            Globals.LogicalLinkParameterOne = Math.Round(Globals.LogicalLinkParameterOne, 2);
            foreach (cNode node in Globals.myNodes)
                node.LogicalLinkLayer.ParameterOne = Globals.LogicalLinkParameterOne;
        }
        void LogicalLinkParameterTwo_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            Globals.LogicalLinkParameterTwo = ((GUIBits.SliderTagStruct)((Slider)sender).Tag).GetActualValue();
            Globals.LogicalLinkParameterTwo = Math.Round(Globals.LogicalLinkParameterTwo, 2);
            foreach (cNode node in Globals.myNodes)
                node.LogicalLinkLayer.ParameterTwo = Globals.LogicalLinkParameterTwo;
        }
        void LogicalLinkParameterThree_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            Globals.LogicalLinkParameterThree = ((GUIBits.SliderTagStruct)((Slider)sender).Tag).GetActualValue();
            Globals.LogicalLinkParameterThree = Math.Round(Globals.LogicalLinkParameterThree, 2);
            foreach (cNode node in Globals.myNodes)
                node.LogicalLinkLayer.ParameterThree = Globals.LogicalLinkParameterThree;
        }
        void LogicalLinkParameterFour_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            Globals.LogicalLinkParameterFour = ((GUIBits.SliderTagStruct)((Slider)sender).Tag).GetActualValue();
            Globals.LogicalLinkParameterFour = Math.Round(Globals.LogicalLinkParameterFour, 2);
            foreach (cNode node in Globals.myNodes)
                node.LogicalLinkLayer.ParameterFour = Globals.LogicalLinkParameterFour;
        }
        void ResetLogicalLinkControls()
        {
            Globals.stsLogicalLinkTimeOut.Enable(false);
            Globals.stsLogicalLinkAttempts.Enable(false);
            Globals.stsLogicalLinkTimeOut.NameOnSetup.Content = "Timeout";
            Globals.stsLogicalLinkAttempts.NameOnSetup.Content = "Retries";

            Globals.stsLogicalLinkParameterOne.SetNewRange(0, 10, 1, GUIBits.SliderType.linear);
            Globals.stsLogicalLinkParameterOne.NameOnSetup.Content = "Not Used";
            Globals.stsLogicalLinkParameterOne.Enable(false);
            Globals.stsLogicalLinkParameterTwo.SetNewRange(0, 10, 1, GUIBits.SliderType.linear);
            Globals.stsLogicalLinkParameterTwo.NameOnSetup.Content = "Not Used";
            Globals.stsLogicalLinkParameterTwo.Enable(false);
            Globals.stsLogicalLinkParameterThree.SetNewRange(0, 10, 1, GUIBits.SliderType.linear);
            Globals.stsLogicalLinkParameterThree.NameOnSetup.Content = "Not Used";
            Globals.stsLogicalLinkParameterThree.Enable(false);
            Globals.stsLogicalLinkParameterFour.SetNewRange(0, 10, 1, GUIBits.SliderType.linear);
            Globals.stsLogicalLinkParameterFour.NameOnSetup.Content = "Not Used";
            Globals.stsLogicalLinkParameterFour.Enable(false);
        }
    }
    #endregion
    #region Region: The logical link class wrapper
    partial class cLogicalLink : cProtocol
    {
        // Some internal parameters for all schemes:
        protected int LogicalLinkPacketsSentSoFar = 0;
        internal long MaxTimeOut = (long)(Globals.LogicalLinkTimeOut * 1e9);
        internal int Retries = Globals.LogicalLinkRetries;

        // The initialiser:
        internal cLogicalLink(cNode node)
        {
            this.node = node;
            ClearQueue();
        }

        // Logical-link routines can also set and get a parent node:
        protected void SetParent(int number)
        {
            if (number >= 0 && number < Globals.NumberOfNodes && number != Globals.NOWHERE)
                this.node.SetLLCParent(number);
            else
                MessageBox.Show("Attempt to set logical-link parent node to " + number.ToString()
                    + "\nThere are only " + Globals.NumberOfNodes.ToString() + " nodes.",
                    "Probable user error?");
        }
        protected int GetParent() { return this.node.GetLLCParent(); }

        // Functions for the user routines to call:
        protected void ReportOutcome(cPacket packet, int A)
        {
            Globals.theQueue.AddEvent(new cEvent(node, packet, node.GetTime(),
                EventType.Network_Callback, A));
        }
        protected void SendPacketToNetworkLayer(cPacket packet, int LastHop)
        {
            // Finally some idiot checking, then send the packet:
            if (packet == null)
            {
                Globals.ShowMessageBox("LLC Layer is attempting to send a null packet to the Network Layer.\n"
                + "Something has gone wrong.", "Serious protocol error");
            }
            else
            {
                Globals.theQueue.AddEvent(new cEvent(node, packet, node.GetTime(),
                    EventType.Network_PacketArrivesFromLogicalLinkLayer, LastHop));
            }
        }

        protected void SendPacketToMACLayer(cPacket packet, int NextHop)
        {
            // Finally some idiot checking, then send the packet:
            if (packet == null)
            {
                Globals.ShowMessageBox("LLC Layer is attempting to send a null packet to the MAC Layer.\n"
                + "Something has gone wrong.", "Serious protocol error");
            }
            else
            {
                Globals.theQueue.AddEvent(new cEvent(node, packet, node.GetTime(),
                    EventType.MAC_PacketArrivesFromLogicalLinkLayer, NextHop));
            }
        }
        protected void CancelCallbacks(int A = -1)
        {
            Globals.theQueue.RemoveEvents(GetMyNumber(), EventType.LogicalLink_Callback, A);
        }
        protected void RequestRelativeCallback(double timeInSeconds, int A, cPacket packet = null)
        {
            Globals.theQueue.AddEvent(new cEvent(node, packet, (long)(node.GetTime() + timeInSeconds * 1e9),
                EventType.LogicalLink_Callback, A));
        }
        protected void RequestAbsoluteCallback(double timeInSeconds, int A, cPacket packet = null)
        {
            Globals.theQueue.AddEvent(new cEvent(node, packet, (long)(timeInSeconds * 1e9),
                EventType.LogicalLink_Callback, A));
        }
    }
    #endregion

    #region Region: The partial MainWindow class for the multiple access layer controls
    public partial class MainWindow : Window
    {
        internal List<UIElement> GetMACControls()
        {
            List<UIElement> controls = new List<UIElement>();
            int VOffset = Globals.CONTROLVOFFSETSTART;
            int VOffsetDifference = Globals.CONTROLVOFFSETDELTA;

            // A label and ComboBox for the multiple access style:
            Globals.ctsMACStyle = GUIBits.SetupNewComboBox<Globals.MultipleAccessType>(controls, VOffset, "MAC protocol", "Protocol");
            Globals.ctsMACStyle.theComboBox.SelectionChanged += new SelectionChangedEventHandler(MACType_SelectionChanged);
            VOffset += VOffsetDifference;

            // Then a slider for the random wait interval:
            Globals.stsMACInitialBackoff = GUIBits.SetupNewLogSlider(controls, VOffset, "MAC layer default backoff", "Backoff",
                Globals._MACInitialBackoffDefault, Globals._MACInitialBackoffMinimum, Globals._MACInitialBackoffMaximum);
            Globals.stsMACInitialBackoff.theSlider.ValueChanged += new RoutedPropertyChangedEventHandler<double>(MACDefaultBackoff_ValueChanged);
            MACDefaultBackoff_ValueChanged(Globals.stsMACInitialBackoff.theSlider, null);
            VOffset += VOffsetDifference;

            // Then the seven MAC parameters:
            Globals.stsMACParameterOne = GUIBits.SetupNewLinearSlider(controls, VOffset, "multiple access parameter A", "Parameter A",
                Globals._UserParameterDefault, Globals._UserParameterMinimum, Globals._UserParameterMaximum);
            Globals.stsMACParameterOne.theSlider.ValueChanged += new RoutedPropertyChangedEventHandler<double>(MACParameterOne_ValueChanged);
            MACParameterOne_ValueChanged(Globals.stsMACParameterOne.theSlider, null);
            VOffset += VOffsetDifference;

            Globals.stsMACParameterTwo = GUIBits.SetupNewLinearSlider(controls, VOffset, "multiple access parameter B", "Parameter B",
                Globals._UserParameterDefault, Globals._UserParameterMinimum, Globals._UserParameterMaximum);
            Globals.stsMACParameterTwo.theSlider.ValueChanged += new RoutedPropertyChangedEventHandler<double>(MACParameterTwo_ValueChanged);
            MACParameterTwo_ValueChanged(Globals.stsMACParameterTwo.theSlider, null);
            VOffset += VOffsetDifference;

            Globals.stsMACParameterThree = GUIBits.SetupNewLinearSlider(controls, VOffset, "multiple access parameter C", "Parameter C",
                Globals._UserParameterDefault, Globals._UserParameterMinimum, Globals._UserParameterMaximum);
            Globals.stsMACParameterThree.theSlider.ValueChanged += new RoutedPropertyChangedEventHandler<double>(MACParameterThree_ValueChanged);
            MACParameterThree_ValueChanged(Globals.stsMACParameterThree.theSlider, null);
            VOffset += VOffsetDifference;

            Globals.stsMACParameterFour = GUIBits.SetupNewLinearSlider(controls, VOffset, "multiple access parameter D", "Parameter D",
                Globals._UserParameterDefault, Globals._UserParameterMinimum, Globals._UserParameterMaximum);
            Globals.stsMACParameterFour.theSlider.ValueChanged += new RoutedPropertyChangedEventHandler<double>(MACParameterFour_ValueChanged);
            MACParameterFour_ValueChanged(Globals.stsMACParameterFour.theSlider, null);
            VOffset += VOffsetDifference;

            Globals.stsMACParameterFive = GUIBits.SetupNewLinearSlider(controls, VOffset, "multiple access parameter E", "Parameter E",
                Globals._UserParameterDefault, Globals._UserParameterMinimum, Globals._UserParameterMaximum);
            Globals.stsMACParameterFive.theSlider.ValueChanged += new RoutedPropertyChangedEventHandler<double>(MACParameterFive_ValueChanged);
            MACParameterFive_ValueChanged(Globals.stsMACParameterFive.theSlider, null);
            VOffset += VOffsetDifference;

            Globals.stsMACParameterSix = GUIBits.SetupNewLinearSlider(controls, VOffset, "multiple access parameter E", "Parameter E",
                Globals._UserParameterDefault, Globals._UserParameterMinimum, Globals._UserParameterMaximum);
            Globals.stsMACParameterSix.theSlider.ValueChanged += new RoutedPropertyChangedEventHandler<double>(MACParameterSix_ValueChanged);
            MACParameterSix_ValueChanged(Globals.stsMACParameterSix.theSlider, null);
            VOffset += VOffsetDifference;

            Globals.stsMACParameterSeven = GUIBits.SetupNewLinearSlider(controls, VOffset, "multiple access parameter E", "Parameter E",
                Globals._UserParameterDefault, Globals._UserParameterMinimum, Globals._UserParameterMaximum);
            Globals.stsMACParameterSeven.theSlider.ValueChanged += new RoutedPropertyChangedEventHandler<double>(MACParameterSeven_ValueChanged);
            MACParameterSeven_ValueChanged(Globals.stsMACParameterSeven.theSlider, null);
            VOffset += VOffsetDifference;
            // Then send back the list
            return controls;
        }

        void MACDefaultBackoff_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            Globals.MACInitialBackoff = ((GUIBits.SliderTagStruct)(((Slider)sender).Tag)).GetActualValue();
            Globals.MACInitialBackoff = Math.Round(Globals.MACInitialBackoff, 4);
            foreach (cNode node in Globals.myNodes)
                node.MACLayer.DefaultBackoff = Globals.MACInitialBackoff * 1e9; // Convert to nanoseconds
        }

        void MACType_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ComboBox thing = (ComboBox)sender;
            String chosen = thing.Items[thing.SelectedIndex].ToString().Replace(' ', '_');
            try { Globals.MACStyle = (Globals.MultipleAccessType)Enum.Parse(typeof(Globals.MultipleAccessType), chosen); }
            catch { MessageBox.Show("Multiple-Access Type " + chosen + " not Recognised", "Serious Error"); }
            ResetMACControls();
            switch (Globals.MACStyle)
            {
                case Globals.MultipleAccessType.ALOHA: MACSetupALOHAControls(); break;
                case Globals.MultipleAccessType.CSMA: MACSetupCSMAControls(); break;
                case Globals.MultipleAccessType.Polling: MACSetupPollingControls(); break;
                case Globals.MultipleAccessType.User: MACSetupUserControls(); break;
                default: MessageBox.Show("Unknown logical-link type: unable to setup controls.", "User Error");
                    break;
            }
        }
        void MACParameterOne_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            Globals.MACParameterOne = ((GUIBits.SliderTagStruct)((Slider)sender).Tag).GetActualValue();
            Globals.MACParameterOne = Math.Round(Globals.MACParameterOne, 2);
            foreach (cNode node in Globals.myNodes)
                node.MACLayer.ParameterOne = Globals.MACParameterOne;
        }
        void MACParameterTwo_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            Globals.MACParameterTwo = ((GUIBits.SliderTagStruct)((Slider)sender).Tag).GetActualValue();
            Globals.MACParameterTwo = Math.Round(Globals.MACParameterTwo, 2);
            foreach (cNode node in Globals.myNodes)
                node.MACLayer.ParameterTwo = Globals.MACParameterTwo;
        }
        void MACParameterThree_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            Globals.MACParameterThree = ((GUIBits.SliderTagStruct)((Slider)sender).Tag).GetActualValue();
            Globals.MACParameterThree = Math.Round(Globals.MACParameterThree, 2);
            foreach (cNode node in Globals.myNodes)
                node.MACLayer.ParameterThree = Globals.MACParameterThree;
        }
        void MACParameterFour_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            Globals.MACParameterFour = ((GUIBits.SliderTagStruct)((Slider)sender).Tag).GetActualValue();
            Globals.MACParameterFour = Math.Round(Globals.MACParameterFour, 2);
            foreach (cNode node in Globals.myNodes)
                node.MACLayer.ParameterFour = Globals.MACParameterFour;
        }
        void MACParameterFive_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            Globals.MACParameterFive = ((GUIBits.SliderTagStruct)((Slider)sender).Tag).GetActualValue();
            Globals.MACParameterFive = Math.Round(Globals.MACParameterFive, 2);
            foreach (cNode node in Globals.myNodes)
                node.MACLayer.ParameterFive = Globals.MACParameterFive;
        }
        void MACParameterSix_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            Globals.MACParameterSix = ((GUIBits.SliderTagStruct)((Slider)sender).Tag).GetActualValue();
            Globals.MACParameterSix = Math.Round(Globals.MACParameterSix, 2);
            foreach (cNode node in Globals.myNodes)
                node.MACLayer.ParameterSix = Globals.MACParameterSix;
        }
        void MACParameterSeven_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            Globals.MACParameterSeven = ((GUIBits.SliderTagStruct)((Slider)sender).Tag).GetActualValue();
            Globals.MACParameterSeven = Math.Round(Globals.MACParameterSeven, 2);
            foreach (cNode node in Globals.myNodes)
                node.MACLayer.ParameterSeven = Globals.MACParameterSeven;
        }
        void ResetMACControls()
        {
            Globals.stsMACInitialBackoff.Enable(false);

            Globals.stsMACParameterOne.SetNewRange(0, 10, 1, GUIBits.SliderType.linear);
            Globals.stsMACParameterOne.NameOnSetup.Content = "Not Used";
            Globals.stsMACParameterOne.Enable(false);
            Globals.stsMACParameterTwo.SetNewRange(0, 10, 1, GUIBits.SliderType.linear);
            Globals.stsMACParameterTwo.NameOnSetup.Content = "Not Used";
            Globals.stsMACParameterTwo.Enable(false);
            Globals.stsMACParameterThree.SetNewRange(0, 10, 1, GUIBits.SliderType.linear);
            Globals.stsMACParameterThree.NameOnSetup.Content = "Not Used";
            Globals.stsMACParameterThree.Enable(false);
            Globals.stsMACParameterFour.SetNewRange(0, 10, 1, GUIBits.SliderType.linear);
            Globals.stsMACParameterFour.NameOnSetup.Content = "Not Used";
            Globals.stsMACParameterFour.Enable(false);
            Globals.stsMACParameterFive.SetNewRange(0, 10, 1, GUIBits.SliderType.linear);
            Globals.stsMACParameterFive.NameOnSetup.Content = "Not Used";
            Globals.stsMACParameterFive.Enable(false);
            Globals.stsMACParameterSix.SetNewRange(0, 10, 1, GUIBits.SliderType.linear);
            Globals.stsMACParameterSix.NameOnSetup.Content = "Not Used";
            Globals.stsMACParameterSix.Enable(false);
            Globals.stsMACParameterSeven.SetNewRange(0, 10, 1, GUIBits.SliderType.linear);
            Globals.stsMACParameterSeven.NameOnSetup.Content = "Not Used";
            Globals.stsMACParameterSeven.Enable(false);
        }
    }
    #endregion
    #region Region: The multiple access class wrapper
    partial class cMAC : cProtocol
    {
        internal double DefaultBackoff = Globals.MACInitialBackoff * 1e9;

        internal cMAC(cNode node)
        {
            this.node = node;
            ClearQueue();
        }

        // MAC routines can also set and get a parent node:
        protected void SetParent(int number)
        {
            if (number >= 0 && number < Globals.NumberOfNodes && number != Globals.NOWHERE)
                this.node.SetMACParent(number);
            else
                MessageBox.Show("Attempt to set MAC parent node to " + number.ToString()
                    + "\nThere are only " + Globals.NumberOfNodes.ToString() + " nodes.",
                    "Probable user error?");
        }
        protected int GetParent() { return this.node.GetMACParent(); }

        // Functions for the user routines to call:
        protected double GetBackoff() { return Globals.MACInitialBackoff; }
        protected void ReportOutcome(cPacket packet, int A)
        {
            Globals.theQueue.AddEvent(new cEvent(node, packet, node.GetTime(),
                EventType.LogicalLink_Callback, A));
        }
        protected void SetZigbeeMode() 
        { 
            // Enables the possibility of the 250000 kbit/s mode, then makes sure it is used.
            Globals.ZigbeeMode = true;
            Globals.stsDefaultBitRate.SetSliderValue(250000, true);
        }
        protected void RequestRelativeCallback(double timeInSeconds, int A, cPacket packet = null)
        {
            Globals.theQueue.AddEvent(new cEvent(node, packet, (long)(node.GetTime() + timeInSeconds * 1e9),
                EventType.MAC_Callback, A));
        }
        protected void RequestAbsoluteCallback(double timeInSeconds, int A, cPacket packet = null)
        {
            Globals.theQueue.AddEvent(new cEvent(node, packet, (long)(timeInSeconds * 1e9),
                EventType.MAC_Callback, A));
        }
        protected void SendPacketToLogicalLinkLayer(cPacket packet, int lastHop)
        {
            // Finally some idiot checking, then send the packet:
            if (packet == null)
            {
                Globals.ShowMessageBox("MAC Layer is attempting to send a null packet to the LLC Layer.\n"
                + "Something has gone wrong.", "Serious protocol error");
            }
            else
            {
                Globals.theQueue.AddEvent(new cEvent(node, packet, node.GetTime(),
                    EventType.LogicalLink_PacketArrivesFromMACLayer, lastHop));
            }
        }
        protected void SendPacketToPhysicalLayer(cPacket packet, double TxPower, int bitRate)
        {
            // The user protocols specify TxPower in Watts, so I'll check this
            // is sensible:
            if (TxPower > 0.01 || TxPower < 1e-6)
            {
                double specifiedTxPower = TxPower;
                if (TxPower > 0.01) TxPower = 0.01;
                if (TxPower < 1e-6) TxPower = 1e-6;
                MessageBox.Show("Transmit Power specified as " + specifiedTxPower.ToString() + " Watts.\n"
                + "This is outside the legal range.  Power set to " + TxPower.ToString() + " Watts.\n",
                "Warning");
            }
            // I'll also check that the bitrate is sensible:
            if (Globals.CheckBitRate(bitRate) == false)
            {
                int nearestBitRate = Globals.GetNearestLegalBitRate(bitRate);
                MessageBox.Show("Bit rate specified as " + bitRate.ToString() + ".\n"
                + "This is not a legal value.  Bit rate set to " + nearestBitRate.ToString() + ".\n",
                "Warning");
                bitRate = nearestBitRate;
            }
            // Finally some idiot checking, then send the packet:
            if (packet == null)
            {
                Globals.ShowMessageBox("MAC Layer is attempting to send a null packet to the Physical Layer.\n"
                + "Something has gone wrong.", "Serious protocol error");
            }
            else
            {
                packet.MetaInformation().SetTransmitPower(TxPower);
                packet.MetaInformation().SetBitRate(bitRate);
                Globals.theQueue.AddEvent(new cEvent(node, packet, node.GetTime(),
                    EventType.Physical_PacketArrivesFromMACLayer, bitRate, 0, 0, TxPower));
            }
        }
        protected void SendPacketToPhysicalLayer(cPacket packet, double TxPower)
        {
            SendPacketToPhysicalLayer(packet, TxPower, (int)Globals.DefaultBitRate);
        }
        protected void SendPacketToPhysicalLayer(cPacket packet)
        {
            double TxPower = Math.Pow(10,(Globals.DefaultTxPowerdBm - 30.0)/10.0);
            int bitRate = (int)Globals.DefaultBitRate;
            SendPacketToPhysicalLayer(packet, TxPower, bitRate);
        }
        protected void CancelCallbacks(int A = -1)
        {
            Globals.theQueue.RemoveEvents(GetMyNumber(), EventType.MAC_Callback, A);
        }

        protected Boolean IsTransmitterBusy()
        {
            return node.GetTransmitState() == Globals.TransmitterState.Transmitting;
        }
        protected Boolean IsChannelQuiet()
        {
            return node.GetReceiveState() == Globals.ReceiverState.Listening;
        }
        protected void RequestCallbackWhenTransmitterIdle(int x, double y = 0.0)
        {
            // If the transmitter is already off and y = 0.0, request callback right now:
            if (node.GetTransmitState() == Globals.TransmitterState.Off && y == 0.0)
            {
                Globals.theQueue.AddEvent(new cEvent(node, null, node.GetTime(),
                    EventType.MAC_Callback, x));
            }           
            else // will need to wait before starting:
            {
                node.SetMACTransmitterIdleCallback(true, x, y);
            }
        }
        protected void RequestCallbackWhenChannelClear(int x, double y = 0.0)
        {
            // If the channel already is clear and y = 0.0, request callback right now:
            if (node.GetReceiveState() == Globals.ReceiverState.Listening && y == 0.0)
            {
                Globals.theQueue.AddEvent(new cEvent(node, null, node.GetTime(),
                    EventType.MAC_Callback, x));
            }
            else // will need to wait before starting:
            {
                node.SetMACChannelClearCallback(true, x, y);
            }
        }
        protected double HowEmptyIsChannel(double x)
        {
            // Returns the proportion of the last x seconds in which
            // the receiver has been active, but not detecting anything.
            double totalBusy = 0.0;
            double totalIdle = 0.0;
            Boolean stateNow = node.GetReceiveState() == Globals.ReceiverState.Listening;
            // If history is empty, it'll either be full or empty:
            if (node.RxHistory.Count == 0 && stateNow == true) return 1.0;
            if (node.RxHistory.Count == 0 && stateNow == false) return 0.0;
            // Otherwise count back through the history until x seconds ago:
            int currentEvent = node.RxHistory.Count - 1;
            long timeAccountedForSoFar = Globals.SimTime;
            long timeToStartFrom = node.ConvertLocalToGlobalTime((long)(node.GetTime() - 1.0e9 * x)); 
            for (int loop = currentEvent; loop >= 0; loop--)
            {
                long eventTime = node.RxHistory[loop].time;
                if (eventTime > timeToStartFrom)
                {
                    // If haven't reached the start yet:
                    stateNow = node.RxHistory[loop].state == Globals.ReceiverState.Listening;
                    if (stateNow == true) totalIdle += (timeAccountedForSoFar - eventTime);
                    else totalBusy += (timeAccountedForSoFar - eventTime);
                    timeAccountedForSoFar = eventTime;
                }
                else
                {
                    // If have reached the start:
                    stateNow = node.RxHistory[loop].state == Globals.ReceiverState.Listening;
                    if (stateNow == true) totalIdle += (timeAccountedForSoFar - timeToStartFrom);
                    else totalBusy += (timeAccountedForSoFar - timeToStartFrom);
                    timeAccountedForSoFar = timeToStartFrom;
                    break;
                }
            }
            // I might not have reached the start (if the start asked for was in the past),
            // in which case I should assume that nothing has happened for that time:
            if (timeAccountedForSoFar != timeToStartFrom)
            {
                if (stateNow == true) totalIdle += (timeAccountedForSoFar - timeToStartFrom);
                else totalBusy += (timeAccountedForSoFar - timeToStartFrom); 
            }
            // Then work out the proportion, and ensure this is always between zero and one:
            double proportionIdle = totalIdle / (totalIdle + totalBusy);
            if (proportionIdle > 1) proportionIdle = 1.0;
            return proportionIdle;
        }
        protected double GetCurrentReceivePower()
        {
            return node.CurrentTotalReceivedPower + Globals.NoiseFloor;
        }
        protected double GetCurrentTransmitPower()
        {
            if (node.GetTransmitState() == Globals.TransmitterState.Off) return 0.0;
            return node.GetCurrentTransmitPower();
        }
        protected double GetDetectionSINR() { return Math.Pow(10.0, Globals.DetectSINRdB / 10.0); }
        protected void SetDetectionSINR(double newSINR)
        {
            if (newSINR < 0.01 || newSINR > 100)
            {
                printfToMessageBox("Attempt to set SINR for detection to " + newSINR.ToString()
                    + "\nAre you sure?  This seems a bit odd.  (Value is not in dB.)");
            }
            // Make sure DetectSINR is set to something that the user might have wanted,
            // while trapping errors if negative value is input:
            if (newSINR <= 0.0) Globals.DetectSINRdB = -100.0;
            else Globals.DetectSINRdB = Math.Round(10.0 * Math.Log10(newSINR), 4);
        }
        protected void GoToSleep()
        {
            node.SetReceiveState(Globals.ReceiverState.Asleep, null, 0.0, 0.0, false);
        }
        protected void WakeUp()
        {
            // The problem with just setting the receiver to listening is that this 
            // could trigger a callback when the node is set to generate a callback 
            // when the channel is clear, despite the fact that the channel could 
            // be really busy when the node wakes up.  So I'll set it to detecting, 
            // and let the NodeMovedStuff() routine set back to listening if the
            // channel is quiet...
            node.SetReceiveState(Globals.ReceiverState.Detecting, null, 0.0, 0.0, false);
            // Also, check that it's not receiving enough power to detect:
            node.PhysicalLayer.NodeMovedStuff();
        }
    }
    #endregion
}
