﻿using System.Runtime.InteropServices;
using System;
using System.Windows;
namespace DANSE_v4
{
    public partial class MainWindow : Window
    {
        private void TransportSetupBestEffortControls()
        {
        }
    }

    unsafe partial class cBestEffortTransport : cTransport
    {
        ///////////////////////////////////////////////
        // Best-effort transport-layer routine wrapper.
        //

        internal cBestEffortTransport(cNode Here, ref cNode.TransportDelegates Delegates)
            : base(Here)
        {
            Delegates.CallWhenCallback = new cNode.TransportCallbackDelegate(this.Callback);
            Delegates.CallWhenInitialise = new cNode.TransportInitialiseDelegate(this.Initialise);
            Delegates.CallWhenPacketArrivesFromNetworkLayer = new cNode.TransportPacketFromBelowDelegate(this.PacketArrivesFromNetworkLayer);
            Delegates.CallWhenPacketArrivesFromApplicationLayer = new cNode.TransportPacketFromAboveDelegate(this.PacketArrivesFromApplicationLayer);
            Delegates.CallWhenShutdown = new cNode.TransportShutdownDelegate(this.Shutdown);
        }

        [Serializable] struct TransportHeader
        {
            // The only necessary things are the destination and source
            // port numbers.
            internal byte sourcePort;
            internal byte destinationPort;
        }

        void PacketArrivesFromNetworkLayer(cPacket packet, int sourceNode)
        {
            // Some idiot checking:
            if (!(packet.ViewHeader() is TransportHeader))
            {
                Globals.ShowMessageBox("Packet arrived at best-effort transport layer\n"
                    + "with no transport layer header. \n"
                    + "Packet will be deleted.", "User Protocol Error?");
                return;
            }
            // Take outermost header off, and pass packet straight up to application layer (in
            // this case thing.A is the original source, info from the Network layer):
            TransportHeader MyHeader = (TransportHeader)packet.RemoveHeader();
            Globals.theQueue.AddEvent(new cEvent(node, packet, node.GetTime(), 
                EventType.Application_PacketArrivesFromTransportLayer,
                sourceNode, MyHeader.destinationPort, MyHeader.sourcePort));
            // Update log file:
            if (Globals.LogEventsOn == true)
                OutToLog("  Transport: Packet sent up to application layer, arrived from node " + packet.MetaInformation().GetOriginalSource());
        }

        void PacketArrivesFromApplicationLayer(cPacket packet, int destinationNode,
            int destinationPort, int sourcePort)
        {
            // Add a basic header and pass on down (thing.stuff is an int, and the destination):
            TransportHeader newhead = new TransportHeader();
            newhead.sourcePort = (byte)sourcePort;
            newhead.destinationPort = (byte)destinationPort;
            int headersize = sizeof(TransportHeader);
            packet.AddHeader((Object)newhead, headersize);  // Add to packet

            // Just pass the destination on to the network layer:
            Globals.theQueue.AddEvent(new cEvent(node, packet, node.GetTime(), 
                EventType.Network_PacketArrivesFromTransportLayer, destinationNode));
            // Update log file:
            if (Globals.LogEventsOn == true)
                OutToLog("  Transport: Packet sent down to network layer, going to node " + packet.MetaInformation().GetFinalDestination());
        }

        void Callback(int A, cPacket packet = null)
        {
            // No callbacks ever requested, so nothing to do.
        }

        void Initialise(double A, double B, double C, double D)
        {
            // Nothing to initialise.
        }

        void Shutdown()
        {
            // No dynamically assigned memory to free up.
        }
    }
}
