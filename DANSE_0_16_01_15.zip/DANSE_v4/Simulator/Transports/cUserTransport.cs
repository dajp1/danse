﻿using System.Windows;
namespace DANSE_v4
{
    public partial class MainWindow : Window
    {
        private void TransportSetupUserControls()
        {
            Globals.stsTransportAttempts.NameOnSetup.Content = "Not Used";
            Globals.stsTransportTimeOut.NameOnSetup.Content = "Not Used";

            Globals.stsTransportParameterOne.NameOnSetup.Content = "Parameter A";
            Globals.stsTransportParameterTwo.NameOnSetup.Content = "Parameter B";
            Globals.stsTransportParameterThree.NameOnSetup.Content = "Parameter C";
            Globals.stsTransportParameterFour.NameOnSetup.Content = "Parameter D";
            Globals.stsTransportParameterOne.Enable(true);
            Globals.stsTransportParameterTwo.Enable(true);
            Globals.stsTransportParameterThree.Enable(true);
            Globals.stsTransportParameterFour.Enable(true);
        }
    }

    unsafe partial class cUserTransport : cTransport
    {
        ////////////////////////////////////////
        // User transport-layer routine wrapper.
        //

        internal cUserTransport(cNode Here, ref cNode.TransportDelegates Delegates)
            : base(Here)
        {
            Delegates.CallWhenCallback = new cNode.TransportCallbackDelegate(this.Callback);
            Delegates.CallWhenInitialise = new cNode.TransportInitialiseDelegate(this.Initialise);
            Delegates.CallWhenPacketArrivesFromNetworkLayer = new cNode.TransportPacketFromBelowDelegate(this.PacketArrivesFromNetworkLayer);
            Delegates.CallWhenPacketArrivesFromApplicationLayer = new cNode.TransportPacketFromAboveDelegate(this.PacketArrivesFromApplicationLayer);
            Delegates.CallWhenShutdown = new cNode.TransportShutdownDelegate(this.Shutdown);
        }

        /////////////////////////////////////////////
        // Do not modify anything below this line. //
        /////////////////////////////////////////////
    }
}
