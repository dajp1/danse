﻿using System.Runtime.InteropServices;
using System;
using System.Windows;

// This is a simple reliable transport layer, that re-transmits up
// to Globals.TransportRetries times before giving up.  The backoff
// time is set to Globals.TransportTimeOut, modified by the backoff
// factor according to:
//
//   Timeout = Globals.TransportTimeOut * BackoffFactor ^ (attempts - 1)
//
// so setting this factor to one uses the same backoff time, and
// setting to two implements exponential backoff.
//
// There is a maximum number of outstanding packets to each destination, 
// and the layer will keep stored any more packets it is given until the 
// outstanding packets are either acknowledged or the number of 
// attempts is exceeded.

namespace DANSE_v4
{
    public partial class MainWindow : Window
    {
        private void TransportSetupReliableControls()
        {
            Globals.stsTransportTimeOut.Enable(true);
            Globals.stsTransportAttempts.Enable(true);

            Globals.stsTransportParameterOne.NameOnSetup.Content = "Window Size";
            Globals.stsTransportParameterOne.SetNewRange(1, 10, 10, GUIBits.SliderType.integer);
            Globals.stsTransportParameterOne.Enable(true);

            Globals.stsTransportParameterTwo.NameOnSetup.Content = "Backoff Factor";
            Globals.stsTransportParameterTwo.SetNewRange(1, 2, 1, GUIBits.SliderType.linear);
            Globals.stsTransportParameterTwo.Enable(true);
        }
    }

    unsafe partial class cReliableTransport : cTransport
    {
        ////////////////////////////////////////
        // User transport-layer routine wrapper.

        internal cReliableTransport(cNode Here, ref cNode.TransportDelegates Delegates)
            : base(Here)
        {
            Delegates.CallWhenCallback = new cNode.TransportCallbackDelegate(this.Callback);
            Delegates.CallWhenInitialise = new cNode.TransportInitialiseDelegate(this.Initialise);
            Delegates.CallWhenPacketArrivesFromNetworkLayer = new cNode.TransportPacketFromBelowDelegate(this.PacketArrivesFromNetworkLayer);
            Delegates.CallWhenPacketArrivesFromApplicationLayer = new cNode.TransportPacketFromAboveDelegate(this.PacketArrivesFromApplicationLayer);
            Delegates.CallWhenShutdown = new cNode.TransportShutdownDelegate(this.Shutdown);
        }

        [Serializable] internal struct TransportReliableHeader
        {
            internal byte sourcePort;
            internal byte destinationPort;
            internal byte sequenceNumber;
            internal Boolean ACKflag;

            internal TransportReliableHeader(int Source, int Destination, int PacketNumber, Boolean ACKflag)
            {
                this.sourcePort = (byte)Source;
                this.destinationPort = (byte)Destination;
                this.sequenceNumber = (byte)(PacketNumber % 256);
                this.ACKflag = ACKflag;
            }
            internal int GetSize() { return 4; }
        }
        internal class ReliableTransportMetadata
        {
            internal int destinationNode;
            internal int attemptsSoFar;
            internal long whenPutIn;
            internal long whenTimeOut;
            internal int sequenceNumber;
            internal ReliableTransportMetadata(int destination, int attemptsSoFar, long whenOut, long whenIn, int sequenceNumber)
            {
                this.destinationNode = destination;
                this.attemptsSoFar = attemptsSoFar;
                this.whenPutIn = whenIn;
                this.whenTimeOut = whenOut;
                this.sequenceNumber = sequenceNumber;
            }
        }

        // Returns how many packets already sent but not acknowledged to this destination:
        int HowManyOutstanding(int whereTo)
        {
            int howMany = 0;
            foreach (cPacketStoreElement x in PacketStore)
            {
                ReliableTransportMetadata thisMeta = (ReliableTransportMetadata)x.GetMetadata();
                if (whereTo == thisMeta.destinationNode && thisMeta.attemptsSoFar > 0)
                    howMany++;
            }
            return howMany;
        }

        void PacketArrivesFromNetworkLayer(cPacket packet, int sourceNode)
        {
            // Some idiot checking:
            if (!(packet.ViewHeader() is TransportReliableHeader))
            {
                Globals.ShowMessageBox("Packet arrived at best-effort transport layer\n"
                    + "with no transport layer header. \n"
                    + "Packet will be deleted.", "User Protocol Error?");
                return;
            }

            // First, take the outermost header off for examination:
            TransportReliableHeader myHeader
                = (TransportReliableHeader)(packet.RemoveHeader());

            if (myHeader.ACKflag == false)
            {
                // Send this info up to the application layer:
                Globals.theQueue.AddEvent(new cEvent(node, packet, node.GetTime(),
                    EventType.Application_PacketArrivesFromTransportLayer,
                    sourceNode, myHeader.destinationPort, myHeader.sourcePort));
                // Generate and send the acknowledgement:
                TransportReliableHeader newHeader = new TransportReliableHeader(
                    myHeader.destinationPort, myHeader.sourcePort, myHeader.sequenceNumber, true);
                int headersize = newHeader.GetSize();
                // Make up the acknowledgement:
                cPacket newAck = new cPacket(0, node.GetNumber(), packet.MetaInformation().GetSystemNumber());
                newAck.MetaInformation().SetFinalDestination(packet.MetaInformation().GetOriginalSource());
                newAck.MetaInformation().SetOriginalSource(packet.MetaInformation().GetFinalDestination());
                newAck.MetaInformation().SetWhenGenerated(node.ConvertLocalToGlobalTime(node.GetTime()));
                newAck.MetaInformation().SetSystemNumber(packet.MetaInformation().GetSystemNumber());
                newAck.MetaInformation().SetTag("Ack for " + packet.MetaInformation().GetSystemNumber().ToString());
                newAck.AddHeader((Object)newHeader, headersize);
                // thing.A is the source node, so ACK should be sent back to here:
                Globals.theQueue.AddEvent(new cEvent(node, newAck, node.GetTime(),
                    EventType.Network_PacketArrivesFromTransportLayer, sourceNode));
                // Update log file:
                if (Globals.LogEventsOn == true)
                {
                    OutToLog("  Packet " + myHeader.sequenceNumber.ToString()
                        + " sent up to application layer, arrived from node "
                        + packet.MetaInformation().GetOriginalSource().ToString());
                    OutToLog("  Transport layer acknowledgement for sequence number "
                        + myHeader.sequenceNumber.ToString() + " sent to node "
                        + packet.MetaInformation().GetOriginalSource().ToString());
                }
            }
            else
            {
                // If it's an acknowledgement, try and find the relevant packet
                // in the list of stored packets waiting for possible retransmit.
                // Note: this is not a cumulative ACK - individual ACKs are required
                // (it can't be cumulative, different packets might be sent to different
                // destinations).

                int SeqNumberInAck = myHeader.sequenceNumber;
                cPacketStoreElement FoundMatch = null;
                foreach (cPacketStoreElement searcher in PacketStore)
                {
                    int SequenceNumberFromQueue
                        = ((ReliableTransportMetadata)searcher.GetMetadata()).sequenceNumber;
                    if (SeqNumberInAck == SequenceNumberFromQueue) FoundMatch = searcher;
                }
                if (FoundMatch != null)
                {
                    PacketStore.Remove(FoundMatch);
                }
                // Update log file:
                if (Globals.LogEventsOn == true)
                {
                    if (FoundMatch == null) OutToLog("  ACK received, but no matching packet found in store");
                    else OutToLog("  Sequence number " + myHeader.sequenceNumber.ToString() + " acknowledged successfully");
                }
                // It's possible that this has reduced the number of
                // outstanding packets to below the window size, in 
                // which case it's safe to send another packet now:
                if (HowManyOutstanding(sourceNode) < this.WindowSize)
                {
                    // Find the oldest packet in the queue to this destination 
                    // that has not yet been sent:
                    int oldestUnsent = -1; long OldTimeSoFar = (long)(Globals.SimulationLength * 1e9);
                    for (int loop = 0; loop < PacketStore.Count; loop++)
                    {
                        ReliableTransportMetadata thisMeta = (ReliableTransportMetadata)GetMetadataInQueue(loop);
                        long whenThisIn = thisMeta.whenPutIn;
                        int attempts = thisMeta.attemptsSoFar;
                        int whereTo = thisMeta.destinationNode;
                        if (whenThisIn < OldTimeSoFar && attempts == 0 && whereTo == sourceNode)
                        {
                            OldTimeSoFar = whenThisIn;
                            oldestUnsent = loop;
                        }
                    }
                    // and if a suitable packet exists, send it...
                    if (oldestUnsent != -1)
                    {
                        cPacket newPacket = GetPacketInQueue(oldestUnsent);
                        int seqNumber = ((TransportReliableHeader)newPacket.ViewHeader()).sequenceNumber;
                        // Then pass a copy of this packet on down to the MAC layer, keeping
                        // the original packet in the queue.
                        cPacket copyToSend = cPacket.DeepCopy(newPacket);
                        Globals.theQueue.AddEvent(new cEvent(node, copyToSend, node.GetTime(),
                            EventType.Network_PacketArrivesFromTransportLayer, sourceNode));
                        if (Globals.LogEventsOn == true)
                            OutToLog("  Transport: Packet " + packet.MetaInformation().GetSystemNumber().ToString()
                                + " with sequence number " + seqNumber.ToString()
                                + " sent down to network layer, going to node " + sourceNode
                                + " for the first attempt now window size allows");
                        // Set a callback for when this packet times out:
                        long timeOut = node.GetTime() + (long)node.TransportLayer.MaxTimeOut;
                        Globals.theQueue.AddEvent(new cEvent(node, null, timeOut,
                            EventType.Transport_Callback, seqNumber));
                        // Adjust metadata to note packet has now been sent:
                        ReliableTransportMetadata metaData
                            = new ReliableTransportMetadata(sourceNode, 1, timeOut, node.GetTime(), seqNumber);
                        ReplaceMetadataInQueue(oldestUnsent, metaData);
                    }
                }
            }
        }

        void PacketArrivesFromApplicationLayer(cPacket packet, int destinationNode,
            int destinationPort, int sourcePort)
        {
            // It can't be broadcast (application layer doesn't send broadcast packets)
            // so just add a header to the packet with the new sequence number, and 
            // with the acknowledgement set to false:
            int sequenceNumber = TransportPacketsSentSoFar % 256;
            TransportPacketsSentSoFar++;
            TransportReliableHeader newhead = new TransportReliableHeader(
                sourcePort, destinationPort, sequenceNumber, false);
            packet.AddHeader((Object)newhead, newhead.GetSize());

            // Has the window size reached a maximum to this destination?
            if (HowManyOutstanding(destinationNode) < this.WindowSize)
            {
                // Sort out some metadata for this packet:
                long timeOut = node.GetTime() + (long)node.TransportLayer.MaxTimeOut;
                ReliableTransportMetadata metaData
                    = new ReliableTransportMetadata(destinationNode, 1, timeOut, node.GetTime(), sequenceNumber);

                // And put the packet in the queue if required:
                if (node.TransportLayer.Retries > 0)
                {
                    cPacket copyForQueue = cPacket.DeepCopy(packet);
                    PutPacketInQueue(copyForQueue, metaData);

                    // Also set a callback event when the packet times out:
                    Globals.theQueue.AddEvent(new cEvent(node, null, timeOut,
                        EventType.Transport_Callback, sequenceNumber));
                }

                // Then pass this packet on down to the network layer:
                Globals.theQueue.AddEvent(new cEvent(node, packet, node.GetTime(),
                    EventType.Network_PacketArrivesFromTransportLayer, destinationNode));
                if (Globals.LogEventsOn == true)
                    OutToLog("  Transport: Packet " + packet.MetaInformation().GetSystemNumber().ToString()
                        + " with sequence number " + newhead.sequenceNumber.ToString()
                        + " sent down to network layer, going to node " + destinationNode
                        + " for the first attempt");
            }
            else
            {
                // If the number of outstanding packets is greater than or
                // equal to the window size, then just store the packet for now:
                ReliableTransportMetadata metaData
                    = new ReliableTransportMetadata(destinationNode, 0, 0, node.GetTime(), sequenceNumber);
                PutPacketInQueue(packet, metaData);
            }
        }

        void Callback(int A, cPacket packet = null)
        {
            // A timeout has occured.  If the packet has not already been
            // acknowledged, it needs to be re-transmitted.  First, see if
            // a packet with the right sequence number has timed out:
            int sequenceNumberInQueue = A;
            long whenDue = 0;
            cPacketStoreElement x = PacketStore.Find(o =>
                ((ReliableTransportMetadata)(o.GetMetadata())).sequenceNumber == A);
            if (x != null)
            {
                ReliableTransportMetadata thisMeta = (ReliableTransportMetadata)x.GetMetadata();
                whenDue = thisMeta.whenTimeOut;
            }
            if (x == null || Math.Abs(whenDue - node.GetTime()) > 1000)
            {
                // There is nothing suitable in the queue.  Must have already
                // been acknowledged.
                if (Globals.LogEventsOn == true)
                    OutToLog("  Transport: Timeout event for packet sequence number "
                        + sequenceNumberInQueue.ToString()
                        + " but packet already acknowledged");
                return;
            }

            // OK, I have a callback for a real packet in the queue, so if I can, I
            // should re-transmit it.  First check I can retransmit:
            ReliableTransportMetadata theMeta = (ReliableTransportMetadata)x.GetMetadata();
            int attemptsSoFar = theMeta.attemptsSoFar;
            if (attemptsSoFar > node.TransportLayer.Retries)
            {
                // Can't try again, maximum number of retries reached:
                PacketStore.Remove(x);
                if (Globals.LogEventsOn == true)
                    OutToLog("  Transport: Timeout event for packet sequence number "
                        + theMeta.sequenceNumber.ToString()
                        + " but maximum number of retries exceeded");
                return;
            }

            // OK, so I can re-transmit.  I need to update the metadata and work
            // out a new timeout time:
            theMeta.attemptsSoFar++;
            theMeta.whenTimeOut = node.GetTime() 
                + (long)(node.TransportLayer.MaxTimeOut 
                    * Math.Pow(this.BackoffFactor, theMeta.attemptsSoFar - 1));
            int destNode = theMeta.destinationNode;

            // And then make a copy of the packet to send to the MAC layer:
            cPacket copyToSend = cPacket.DeepCopy(x.GetPacket());

            Globals.theQueue.AddEvent(new cEvent(node, copyToSend, node.GetTime(),
                EventType.Network_PacketArrivesFromTransportLayer, destNode));
            if (Globals.LogEventsOn == true)
                OutToLog("  Transport: Packet " + x.GetPacket().MetaInformation().GetSystemNumber().ToString()
                    + " with sequence number " + theMeta.sequenceNumber.ToString()
                    + " sent down to network layer, going to node " + destNode
                    + " for attempt number " + theMeta.attemptsSoFar);

            // Update count of packets sent:
            TransportPacketsSentSoFar++;

            // If I can try yet again, then put in another callback request.
            // If I can't, take the packet out of the queue.
            if (node.TransportLayer.Retries + 1 > theMeta.attemptsSoFar)
            {
                Globals.theQueue.AddEvent(new cEvent(node, null, theMeta.whenTimeOut,
                    EventType.Transport_Callback, sequenceNumberInQueue));
            }
            else
            {
                PacketStore.Remove(x);
            }
        }

        int WindowSize;
        double BackoffFactor;
        void Initialise(double A, double B, double C, double D)
        {
            // A is the maximum number of outstanding packets allowed
            // to any destination, B is the backoff factor
            this.WindowSize = (int)A;
            this.BackoffFactor = B;
        }

        void Shutdown()
        {
            // No dynamically assigned memory to free up.
        }
    }
}
