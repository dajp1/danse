﻿using System;
using System.Collections.Generic;
using System.Windows;

namespace DANSE_v4
{
    // First, an enum that contains all possible event types:
    internal enum EventType
    {
        // The system-level events:
        System_Stop,
        System_Movement,
        System_InsertStoredPacket,
        // The physical layer events:
        Physical_PacketArrivesFromMACLayer,
        Physical_PacketTransmissionFinished,
        Physical_StartToArriveFromBelow,
        Physical_FinishArriving,
        // The MAC layer:
        MAC_PacketArrivesFromLogicalLinkLayer,
        MAC_PacketArrivesFromPhysicalLayer,
        MAC_GoToSleep,
        MAC_WakeUp,
        MAC_Callback,
        MAC_Initialise,
        MAC_Shutdown,
        // The Logical-Link Layer:
        LogicalLink_PacketArrivesFromMACLayer,
        LogicalLink_PacketArrivesFromNetworkLayer,
        LogicalLink_Callback,
        LogicalLink_Initialise,
        LogicalLink_Shutdown,
        // The Network Layer:
        Network_PacketArrivesFromLogicalLinkLayer,
        Network_PacketArrivesFromTransportLayer,
        Network_Callback,
        Network_Initialise,
        Network_Shutdown,
        // The Transport Layer:
        Transport_PacketArrivesFromNetworkLayer,
        Transport_PacketArrivesFromApplicationLayer,
        Transport_Callback,
        Transport_Initialise,
        Transport_Shutdown,
        // The Application Layer:
        Application_PacketArrivesFromTransportLayer,
        Application_Callback,
        Application_Initialise,
        // The Nodes:
        Node_WaitForTxIdle,
        Node_WaitForRxIdle
    }

    // Then a class for the events, as stored in the queue.
    internal class cEvent
    {
        internal cNode node;        // Note node == null means call all nodes.
        internal cPacket packet;    // Packet concerned with things
        internal long time;         // This is global simulation time
        internal EventType type;    // Type of the event
        internal int A, B, C;       // Internal parameters for various things
        internal double D;          // Internal parameters for various things

        // Note: the internal parameters are used for passing information 
        // between layers.  The conventional meanings are:
        //   Application to Transport: A = destination, B = dest port, C = source port
        //   Transport to Application: A = source, B = dest port, C = source port
        //   Transport to Network: A = destination
        //   Network to Transport: A = source
        //   Network to Logical-Link: A = next hop
        //   Logical-Link to Network: A = last hop
        //   Logical-Link to MAC: A = next hop
        //   MAC to Logical-Link: A = last hop
        //   MAC to Physical: A = bit-rate, D = transmit power
        //   Physical to MAC: A = bit-rate, D = receive power

        internal cEvent(cNode node, cPacket packet, long time, EventType type,
                                    int A = 0, int B = 0, int C = 0, double D = 0)
        {
            this.node = node;
            this.packet = packet;
            this.time = time;
            this.type = type;
            this.A = A;
            this.B = B;
            this.C = C;
            this.D = D;
        }
        public override string ToString()
        {
            string thing = "Time: " + this.time.ToString() + "; type: " + this.type.ToString() + "(" + A.ToString() + ")";
            if (node != null) thing += " at node " + this.node.GetNumber();
            if (packet != null) thing += " " + this.packet.ToString();
            return thing;
        }
    }

    // Then the queue itself.  After some thought, I've decided to keep an ordered queue,
    // but ordered backwards, so the next item to be actionned is always at the end of
    // the queue.  This is an attempt to speed things up: the most common time to add 
    // events is "now" as a packet is passed between layers in the same node, and it's much
    // faster to add items to the end of a List than the start, as nothing needs to be moved
    // to make room.  (The alternative of keeping the queue unordered and searching through it
    // would have made debugging rather harder, and I'm not convinced it would have been any
    // faster anyway, although I haven't tried it.)
    internal class cEventQueue
    {
        List<cEvent> theQueue = new List<cEvent>();
        int NumberOfEventsInQueue = 0;  // Faster than using the Count method all the time?
        int TotalEventsSoFar = 0;

        internal int EventCount() { return NumberOfEventsInQueue; }
        internal cEvent ScryEvent(int loop)
        {
            if (loop >= 0 && loop < NumberOfEventsInQueue) return theQueue[loop];
            else return null;
        }

        // Initialise the queue:
        internal cEventQueue() { theQueue.Clear(); NumberOfEventsInQueue = 0; TotalEventsSoFar = 0; }
        internal void Reset() { theQueue.Clear(); NumberOfEventsInQueue = 0; TotalEventsSoFar = 0; }

        // Get when the next event happens:
        internal long NextTime() 
        {
            if (NumberOfEventsInQueue > 0) return theQueue[NumberOfEventsInQueue - 1].time;
            else return 0;
        }

        // Get the next event (for printing on the screen)
        internal string GetNextEventString()
        {
            if (theQueue.Count > 0) return theQueue[theQueue.Count - 1].ToString();
            else return "";
        }
        internal EventType GetNextEventType()
        {
            if (theQueue.Count > 0) return theQueue[theQueue.Count - 1].type;
            else return EventType.System_Stop;
        }

        // Process the next item:
        internal Boolean DoNextEvent()
        {
            if (NumberOfEventsInQueue == 0) return false;
            cEvent ToDo = theQueue[NumberOfEventsInQueue - 1];  // Get the next event
            theQueue.RemoveAt(NumberOfEventsInQueue - 1);       // and remove it from the queue
            Globals.SimTime = ToDo.time;   // Update the time to the new time
            NumberOfEventsInQueue--;       // Keep the count up to date
            return DoEvent(ToDo);          // And do whatever it wants to be done
        }

        private void StartLogFileEntry(string thing, cEvent what)
        {
            Globals.NewLogEvent = new System.Text.StringBuilder(1024);  // Start somewhere to store event, 1024 chars should be big enough.
            Globals.NewLogEvent.AppendLine("Sim Time: " + Globals.SimTime.ToString("###,###,###,###,##0") + ".  Event Type: " + what.type.ToString()
                + ".  Event " + TotalEventsSoFar.ToString() + ", " + NumberOfEventsInQueue.ToString() + " in queue");
            if (what.node != null)
            {
                if (Globals.EnergyMode == Globals.EnergyType.Countdown ||
                    (Globals.EnergyMode == Globals.EnergyType.Down_Not_Zero && what.node.GetNumber() != 0))
                {
                    Globals.NewLogEvent.AppendLine("  Node " + what.node.GetNumber().ToString()
                        + ".  Local Time: " + what.node.GetTime().ToString("###,###,###,###,##0")
                        + ".  Energy Left = " + what.node.GetEnergyLeft().ToString("0.###"));
                }
                else
                {
                    Globals.NewLogEvent.AppendLine("  Node " + what.node.GetNumber().ToString()
                        + ".  Local Time: " + what.node.GetTime().ToString("###,###,###,###,##0")
                        + ".  Energy Used = " + what.node.GetEnergyUsed().ToString("0.###"));
                }
            }
            if (what.packet != null) Globals.NewLogEvent.AppendLine("  " + what.packet.ToString());
            if (thing != null) Globals.NewLogEvent.AppendLine(thing);
        }

        // Removes all events pertaining to the given node:
        internal void RemoveNode(int number)
        {
            theQueue.RemoveAll(
                delegate(cEvent m)
                {
                    if (m.node == null) return false;
                    if (m.node.GetNumber() == number) return true;
                    return false;
                });
            NumberOfEventsInQueue = theQueue.Count;  // Might have lost count
        }
        // Remove all events matching a certain event type at a certain node.
        // Useful for example, for removing all current callback events for
        // a protocol if it decides to reset itself.
        internal void RemoveEvents(int node, EventType what, int A = -1)
        {
            theQueue.RemoveAll(
                delegate(cEvent m)
                {
                    if (m.node == null) return false;
                    if (m.node.GetNumber() != node) return false;
                    if (m.type != what) return false;
                    if (A != -1 && A != m.A) return false;
                    return true;
                });
            NumberOfEventsInQueue = theQueue.Count;  // Might have lost count
        }

        internal Boolean DoEvent(cEvent EventToDo)
        {
            TotalEventsSoFar++;

            // Then sort out whether to log this event or not.  This depends on the current
            // log settings, and all gets a bit complicated.

            Globals.LogEventsOn = false; // Default is not to work out log string to save time
            Boolean LogThisOne = true;   // Also need to check whether this node/packet is logged
            if (EventToDo.node != null)
            {
                if (Globals.WhatToLog == Globals.eWhatToLog.Zero
                    && EventToDo.node.GetNumber() != 0) LogThisOne = false;
                else if (Globals.WhatToLog == Globals.eWhatToLog.ZeroAndOne
                    && (EventToDo.node.GetNumber() != 0 && EventToDo.node.GetNumber() != 1)) LogThisOne = false;
            }
            if (EventToDo.packet != null)
            {
                if (Globals.WhatToLog == Globals.eWhatToLog.PacketZero
                    && EventToDo.packet.MetaInformation().GetSystemNumber() != 0) LogThisOne = false;
                if (Globals.WhatToLog == Globals.eWhatToLog.PacketZeroAndOne
                    && (EventToDo.packet.MetaInformation().GetSystemNumber() != 0
                    && EventToDo.packet.MetaInformation().GetSystemNumber() != 1)) LogThisOne = false;
                if (Globals.WhatToLog == Globals.eWhatToLog.PacketNonZero
                    && EventToDo.packet.MetaInformation().GetSystemNumber() == 0) LogThisOne = false;
            }
            if (Globals.WhatToLog != Globals.eWhatToLog.All &&
                (EventToDo.node == null || EventToDo.packet == null)) LogThisOne = false;

            // Now the big switch statement to work out what to do:
            switch (EventToDo.type)
	        {
                case EventType.System_Stop:
                    if (Globals.LogSystem == true && LogThisOne == true)
                    {
                        StartLogFileEntry("  System: Stop simulation event reached", EventToDo);
                        Globals.LogEventsOn = true;
                    }
                    foreach (cNode node in Globals.myNodes) node.UpdateEnergy();  // Energy up-to-date
                    ((MainWindow)Globals.MainWindow).EndSimulation();  // Surely there's an easier way?
                    break;
                case EventType.System_Movement:
                    if (Globals.LogMovement == true && LogThisOne == true)
                    {
                        StartLogFileEntry("  Movement: Moving all the nodes now", EventToDo);
                        Globals.LogEventsOn = true;
                    }
                    Globals.MoveClass.MoveAll();
                    cEvent NewMovementEvent = new cEvent(null, null, Globals.SimTime + Globals.MoveInterval, EventType.System_Movement);
                    this.AddEvent(NewMovementEvent);
                    break;
                case EventType.System_InsertStoredPacket:
                    if (Globals.LogSystem == true && LogThisOne == true)
                    {
                        StartLogFileEntry("  System: Inserting stored packet", EventToDo);
                        Globals.LogEventsOn = true;
                    }
                    // It's time to take the next packet from the store and send it...
                    cPacket newPacket = Globals.GetNextPacketToSend();
                    // ...except I can't send it if this node or this packet doesn't exist
                    if (newPacket.MetaInformation().GetOriginalSource() < Globals.NumberOfNodes
                        && newPacket != null)
                    {
                        cNode node = Globals.myNodes[newPacket.MetaInformation().GetOriginalSource()];
                        cEvent NewGetPacketEvent = new cEvent(node, newPacket,
                            node.ConvertGlobalToLocalTime(Globals.SimTime), 
                            EventType.Application_Callback, 1);
                        this.AddEvent(NewGetPacketEvent);
                    }
                    // And then add the next packet stored to the queue:
                    Globals.AddNextPacketToGoEventToQueue();
                    break;
                case EventType.Physical_PacketArrivesFromMACLayer:
                case EventType.Physical_PacketTransmissionFinished:
                case EventType.Physical_StartToArriveFromBelow:
                case EventType.Physical_FinishArriving:
                    if (Globals.LogPhysical == true && LogThisOne == true)
                    {
                        StartLogFileEntry(null, EventToDo);
                        Globals.LogEventsOn = true;
                    }
                    EventToDo.node.PhysicalLayer.EventHandler(EventToDo);
                    break;
                case EventType.MAC_PacketArrivesFromLogicalLinkLayer:
                case EventType.MAC_PacketArrivesFromPhysicalLayer:
                case EventType.MAC_Callback:
                case EventType.MAC_GoToSleep:
                case EventType.MAC_WakeUp:
                case EventType.MAC_Initialise:
                case EventType.MAC_Shutdown:
                    if (Globals.LogMultipleAccess == true && LogThisOne == true)
                    {
                        StartLogFileEntry(null, EventToDo);
                        Globals.LogEventsOn = true;
                    }
                    if (EventToDo.type == EventType.MAC_PacketArrivesFromLogicalLinkLayer)
                        EventToDo.node.MACFunctions.CallWhenPacketArrivesFromLogicalLinkLayer(EventToDo.packet, EventToDo.A);
                    else if (EventToDo.type == EventType.MAC_PacketArrivesFromPhysicalLayer)
                        EventToDo.node.MACFunctions.CallWhenPacketArrivesFromPhysicalLayer(EventToDo.packet, EventToDo.D);
                    else if (EventToDo.type == EventType.MAC_Callback)
                        EventToDo.node.MACFunctions.CallWhenCallback(EventToDo.A, EventToDo.packet);
                    else if (EventToDo.type == EventType.MAC_Initialise)
                        EventToDo.node.MACFunctions.CallWhenInitialise(Globals.MACParameterOne, Globals.MACParameterTwo,
                                        Globals.MACParameterThree, Globals.MACParameterFour, Globals.MACParameterFive,
                                        Globals.MACParameterSix, Globals.MACParameterSeven);
                    else if (EventToDo.type == EventType.MAC_Shutdown)
                        EventToDo.node.MACFunctions.CallWhenShutdown();
                    break;
                case EventType.LogicalLink_PacketArrivesFromMACLayer:
                case EventType.LogicalLink_PacketArrivesFromNetworkLayer:
                case EventType.LogicalLink_Callback:
                case EventType.LogicalLink_Initialise:
                case EventType.LogicalLink_Shutdown:
                    if (Globals.LogLogicalLink == true && LogThisOne == true)
                    {
                        StartLogFileEntry(null, EventToDo);
                        Globals.LogEventsOn = true;
                    }

                    if (EventToDo.type == EventType.LogicalLink_PacketArrivesFromNetworkLayer)
                        EventToDo.node.LogicalLinkFunctions.CallWhenPacketArrivesFromNetworkLayer(EventToDo.packet, EventToDo.A);
                    else if (EventToDo.type == EventType.LogicalLink_PacketArrivesFromMACLayer)
                        EventToDo.node.LogicalLinkFunctions.CallWhenPacketArrivesFromMACLayer(EventToDo.packet, EventToDo.A);
                    else if (EventToDo.type == EventType.LogicalLink_Callback)
                        EventToDo.node.LogicalLinkFunctions.CallWhenCallback(EventToDo.A, EventToDo.packet);
                    else if (EventToDo.type == EventType.LogicalLink_Initialise)
                        EventToDo.node.LogicalLinkFunctions.CallWhenInitialise(
                            Globals.LogicalLinkParameterOne, Globals.LogicalLinkParameterTwo, 
                            Globals.LogicalLinkParameterThree, Globals.LogicalLinkParameterFour);
                    else if (EventToDo.type == EventType.LogicalLink_Shutdown)
                        EventToDo.node.LogicalLinkFunctions.CallWhenShutdown();
                    break;
                case EventType.Network_PacketArrivesFromLogicalLinkLayer:
                case EventType.Network_PacketArrivesFromTransportLayer:
                case EventType.Network_Callback:
                case EventType.Network_Initialise:
                case EventType.Network_Shutdown:
                    if (Globals.LogNetwork == true && LogThisOne == true)
                    {
                        StartLogFileEntry(null, EventToDo);
                        Globals.LogEventsOn = true;
                    }

                    if (EventToDo.type == EventType.Network_PacketArrivesFromLogicalLinkLayer)
                        EventToDo.node.NetworkFunctions.CallWhenPacketArrivesFromLogicalLinkLayer(EventToDo.packet, EventToDo.A);
                    else if (EventToDo.type == EventType.Network_PacketArrivesFromTransportLayer)
                        EventToDo.node.NetworkFunctions.CallWhenPacketArrivesFromTransportLayer(EventToDo.packet, EventToDo.A);
                    else if (EventToDo.type == EventType.Network_Callback)
                        EventToDo.node.NetworkFunctions.CallWhenCallback(EventToDo.A, EventToDo.packet);
                    else if (EventToDo.type == EventType.Network_Initialise)
                        EventToDo.node.NetworkFunctions.CallWhenInitialise(
                            Globals.NetworkParameterOne, Globals.NetworkParameterTwo,
                            Globals.NetworkParameterThree, Globals.NetworkParameterFour,
                            Globals.NetworkParameterFive, Globals.NetworkParameterSix, 
                            Globals.NetworkParameterSeven);
                    else if (EventToDo.type == EventType.Network_Shutdown)
                        EventToDo.node.NetworkFunctions.CallWhenShutdown();
                    break;
                case EventType.Transport_PacketArrivesFromNetworkLayer:
                case EventType.Transport_PacketArrivesFromApplicationLayer:
                case EventType.Transport_Callback:
                case EventType.Transport_Initialise:
                case EventType.Transport_Shutdown:
                    if (Globals.LogTransport == true && LogThisOne == true)
                    {
                        StartLogFileEntry(null, EventToDo);
                        Globals.LogEventsOn = true;
                    }

                    if (EventToDo.type == EventType.Transport_PacketArrivesFromNetworkLayer)
                        EventToDo.node.TransportFunctions.CallWhenPacketArrivesFromNetworkLayer(EventToDo.packet, EventToDo.A);
                    else if (EventToDo.type == EventType.Transport_PacketArrivesFromApplicationLayer)
                        EventToDo.node.TransportFunctions.CallWhenPacketArrivesFromApplicationLayer(EventToDo.packet, EventToDo.A, EventToDo.B, EventToDo.C);
                    else if (EventToDo.type == EventType.Transport_Callback)
                        EventToDo.node.TransportFunctions.CallWhenCallback(EventToDo.A, EventToDo.packet);
                    else if (EventToDo.type == EventType.Transport_Initialise)
                        EventToDo.node.TransportFunctions.CallWhenInitialise(
                            Globals.TransportParameterOne, Globals.TransportParameterTwo,
                            Globals.TransportParameterThree, Globals.TransportParameterFour);
                    else if (EventToDo.type == EventType.Transport_Shutdown)
                        EventToDo.node.TransportFunctions.CallWhenShutdown();
                    break;
                case EventType.Application_PacketArrivesFromTransportLayer:
                case EventType.Application_Callback:
                case EventType.Application_Initialise:
                    if (Globals.LogApplication == true && LogThisOne == true)
                    {
                        StartLogFileEntry(null, EventToDo);
                        Globals.LogEventsOn = true;
                    }
                    EventToDo.node.ApplicationLayerOne.EventHandler(EventToDo);
                    break;
                case EventType.Node_WaitForTxIdle:
                case EventType.Node_WaitForRxIdle:
                    EventToDo.node.EventHandler(EventToDo);
                    break;
                default:    
                    MessageBox.Show("Serious Error: Unknown Event Type in Queue", "Serious");
                    theQueue.RemoveAt(0);
                    return false;
                // break;
	        }

            // If Globals.LogsOn is true, then I've been building a new log event, and I should
            // write it to the log file (if one exists) and the screen (if stepping):
            if (Globals.LogEventsOn == true)
            {
                Globals.LogEventCount++;              // Keep a count of logged events.
                Globals.LogFileCurrentContents.Append(Globals.NewLogEvent);  // Always add to string
                Globals.LogFileCurrentContents.AppendLine();
                if (Globals.LogFileOn && EventToDo.type != EventType.System_Stop)
                {
                    // The problem with system stop is that the log file will
                    // already have been closed by the event handler
                    Globals.LogStreamWriter.WriteLine(Globals.NewLogEvent);
                    Globals.LogFileEntryCount++;
                }
            }
            return true;
        }

        // Add an event to the queue.
        // This is a backwards sorted queue.  It finds the right place for the new
        // event, and then adds it in, provided the queue is not already full (unlikely).
        internal Boolean AddEvent(cEvent newevent)
        {
            if (NumberOfEventsInQueue >= Globals.MaximumNumberOfEvents)
            {
                String message = "Attempt to add event to queue.\n";
                message += newevent.ToString();
                message += "\nThe queue is now full with " + NumberOfEventsInQueue.ToString() + " events.";
                message += "\nSomething has probably gone wrong.";
                MessageBox.Show(message, "Warning");
                return false;
            }

            // If the node has run out of energy, then don't queue the event: it can't do anything.
            if (newevent.node != null)
            {
                if ((Globals.EnergyMode == Globals.EnergyType.Countdown && newevent.node.GetEnergyLeft() <= 0.0)
                    || (Globals.EnergyMode == Globals.EnergyType.Down_Not_Zero 
                    && newevent.node.GetNumber() != 0 && newevent.node.GetEnergyLeft() <= 0.0))
                {
                    return false;
                }
            }

            // If the node hasn't been turned on yet, do nothing:
            if (newevent.node != null && 
                newevent.node.GetLocalTimeWhenSwitchedOn() > newevent.time)
            {
                return false;
            }

            // If the simulator is terminating, don't add anything new:
            if (Globals.SimStatus == Globals.status.Terminating) return false;

            // The queue lists events by actual exact simulation time, so the first 
            // thing to do is modify the time of the event according to which node 
            // the event comes from, as all nodes have clocks running at slightly 
            // different rates.

            // For all events except movements, the node in the event specifies
            // which clock is being used to request the event.
            if (newevent.node != null)
            {
                newevent.time = newevent.node.ConvertLocalToGlobalTime(newevent.time);
                // Also, all events queued by nodes take at least 1 microsecond to do,
                // except at the physical layer where they are instantaneous, system
                // events, and any initialisations:
                if (newevent.type == EventType.Physical_FinishArriving
                    || newevent.type == EventType.Physical_PacketArrivesFromMACLayer
                    || newevent.type == EventType.Physical_PacketTransmissionFinished
                    || newevent.type == EventType.Physical_StartToArriveFromBelow
                    || newevent.type == EventType.System_InsertStoredPacket
                    || newevent.type == EventType.System_Movement
                    || newevent.type == EventType.System_Stop
                    || newevent.type == EventType.Application_Initialise
                    || newevent.type == EventType.Transport_Initialise
                    || newevent.type == EventType.Network_Initialise
                    || newevent.type == EventType.LogicalLink_Initialise
                    || newevent.type == EventType.MAC_Initialise
                    )
                {
                    // This is here in case of rounding errors in the double-precision
                    // conversions from local to global time making an event appear to
                    // be one nanosecond in the past:
                    if (newevent.time < Globals.SimTime)
                            newevent.time = Globals.SimTime;
                }
                else
                {
                    if (newevent.time - Globals.SimTime < Globals.MinimumEventTime) 
                        newevent.time += Globals.MinimumEventTime;
                }
            }

            // For debugging:
            if (newevent.time < 0)
            {
                MessageBoxResult Reply = MessageBox.Show("Event queued at negative time: " + newevent.ToString() 
                    + "\n\nContinue the simulation?", "Serious error", MessageBoxButton.YesNo);
                if (Reply == MessageBoxResult.No)
                {
                    // User has selected to terminate.  Stop the simulation.
                    ((MainWindow)Globals.MainWindow).EndSimulation();
                    Globals.SimStatus = Globals.status.Terminating;
                    return false;
                }
            }
            else if (newevent.time < Globals.SimTime)
            {
                MessageBoxResult Reply = MessageBox.Show("Event queued in the past: " + newevent.ToString()
                    + "\n\nContinue the simulation?", "Serious error", MessageBoxButton.YesNo);
                if (Reply == MessageBoxResult.No)
                {
                    // User has selected to terminate.  Stop the simulation.
                    ((MainWindow)Globals.MainWindow).EndSimulation();
                    Globals.SimStatus = Globals.status.Terminating;
                    return false;
                }
            }

            // Then add the event to the queue.  If the queue is empty, or the item can go at the
            // end of the queue, then this is easy:
            if (NumberOfEventsInQueue == 0)
            {
                theQueue.Add(newevent);
                NumberOfEventsInQueue++;
                return true;
            }
            else if (newevent.time < theQueue[NumberOfEventsInQueue - 1].time)
            {
                theQueue.Add(newevent);
                NumberOfEventsInQueue++;
                return true;
            }
            else if (newevent.time == theQueue[NumberOfEventsInQueue - 1].time)
            {
                // Shouldn't put right at the beginning, it should go after any existing
                // events at this same time.
                int loc = NumberOfEventsInQueue - 1;
                while (theQueue[loc].time == newevent.time && loc > 0) loc--;
                theQueue.Insert(loc + 1, newevent);
                NumberOfEventsInQueue++;
                return true;
            }
            // Otherwise it might just fit in right at the start...
            else if (newevent.time > theQueue[0].time)
            {
                theQueue.Insert(0, newevent);
                NumberOfEventsInQueue++;
                return true;
            }
            // or just after the start (movements sometimes fit in here):
            else if (newevent.time > theQueue[1].time)
            {
                theQueue.Insert(1, newevent);
                NumberOfEventsInQueue++;
                return true;
            }
            // otherwise, it's a binary search...
            else
            {
                int AtOrAboveHere = 0;
                int AtOrBelowHere = NumberOfEventsInQueue - 1;
                int CurrentGuess = (AtOrBelowHere - AtOrAboveHere) / 2;
                int MaxIterations = 20; // Break out of loop in case something silly happens...

                while (AtOrBelowHere - AtOrAboveHere > 1 && MaxIterations-- > 0)
                {
                    if (newevent.time > theQueue[CurrentGuess].time)
                    {
                        AtOrBelowHere = CurrentGuess;
                    }
                    else
                    {
                        AtOrAboveHere = CurrentGuess;
                    }
                    CurrentGuess = AtOrAboveHere + (AtOrBelowHere - AtOrAboveHere) / 2;
                }
                if (MaxIterations > 0)
                {
                    theQueue.Insert(AtOrBelowHere, newevent);
                    NumberOfEventsInQueue++;
                    return true;
                }
                else
                {
                    MessageBoxResult Reply = MessageBox.Show(
                        "Did not converge to place in queue after 20 iterations for\n" + newevent.ToString()
                        + "\nSomething strange is happening: too complex a simulation?",
                        "Serious Error", MessageBoxButton.OKCancel);
                    if (Reply != MessageBoxResult.OK)
                    {
                        // User has pressed cancel.  Stop the simulation.
                        ((MainWindow)Globals.MainWindow).EndSimulation();
                    }
                    return false;
                }
            }
        }
    }
}
