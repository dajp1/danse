﻿using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System;

namespace DANSE_v4
{
    // First in this file, the part of the main MainWindow class that
    // controls the setup options and their event handlers:

    public partial class MainWindow : Window
    {
        internal List<UIElement> GetMovementControls()
        {
            List<UIElement> controls = new List<UIElement>();
            int VOffset = Globals.CONTROLVOFFSETSTART;
            int VOffsetDifference = Globals.CONTROLVOFFSETDELTA;

            // First up, a label and ComboBox for the movement style:
            Globals.ctsMoveType = GUIBits.SetupNewComboBox<Globals.MovementType>(controls, VOffset, "type of movement", "Movement");
            Globals.ctsMoveType.theComboBox.SelectionChanged += new SelectionChangedEventHandler(MoveTypeCombo_SelectionChanged);
            VOffset += VOffsetDifference;
            
            // Then a slider for the mean speed of movement:
            Globals.stsMeanSpeed = GUIBits.SetupNewLogSlider(controls, VOffset, "mean node speed", "Mean Speed",
                Globals._MovementSpeedDefault, Globals._MovementSpeedMinimum,
                Globals._MovementSpeedMaximum);
            Globals.stsMeanSpeed.theSlider.ValueChanged += new RoutedPropertyChangedEventHandler<double>(MeanSpeedSlider_ValueChanged);
            MeanSpeedSlider_ValueChanged(Globals.stsMeanSpeed.theSlider, null);
            VOffset += VOffsetDifference;

            // Then a slider for the spread of speed of movement:
            Globals.stsSpreadSpeed = GUIBits.SetupNewLinearSlider(controls, VOffset, "spread of node speeds", "Spread",
                Globals._MovementSpeedSpreadDefault, Globals._MovementSpeedSpreadMinimum,
                Globals._MovementSpeedSpreadMaximum);
            Globals.stsSpreadSpeed.theSlider.ValueChanged += new RoutedPropertyChangedEventHandler<double>(SpreadSpeedSlider_ValueChanged);
            SpreadSpeedSlider_ValueChanged(Globals.stsSpreadSpeed.theSlider, null);

            // Then send back the list
            return controls;
        }

        void MeanSpeedSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            Globals.MovementSpeed = ((GUIBits.SliderTagStruct)(((Slider)sender).Tag)).GetActualValue();
            Globals.MovementSpeed = Math.Round(Globals.MovementSpeed, 2);
            foreach (cNode node in Globals.myNodes) node.SetSpeed(Globals.MovementSpeedNew());
        }
        void SpreadSpeedSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            Globals.MovementSpeedSpread = ((GUIBits.SliderTagStruct)(((Slider)sender).Tag)).GetActualValue();
            Globals.MovementSpeedSpread = Math.Round(Globals.MovementSpeedSpread, 2);
            foreach (cNode node in Globals.myNodes) node.SetSpeed(Globals.MovementSpeedNew());
        }

        void MoveTypeCombo_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ComboBox thing = (ComboBox)sender;
            String chosen = thing.Items[thing.SelectedIndex].ToString();
            try { Globals.MoveMode = (Globals.MovementType)Enum.Parse(typeof(Globals.MovementType), chosen); }
            catch { MessageBox.Show("Movement Type " + chosen + " not Recognised", "Serious Error"); }

            // If I change to targetted half-way through, then I need to reset the target to the current position
            // otherwise I might never get to the target.  This doesn't do any harm for the other cases, so I 
            // might as well always do it.
            foreach (cNode node in Globals.myNodes)
            {
                node.TargetPosition.X = node.GetPosition().X;
                node.TargetPosition.Y = node.GetPosition().Y;
            }
        }
    }

    // Then the movement class itself.  Note there is only one of these,
    // each cNode stores its own movement variables.
    class cMovement
    {
        internal void MoveAll()
        {
            foreach (cNode node in Globals.myNodes)
            {
                Move(node);
                node.PhysicalLayer.NodeMovedStuff();
            }
        }
        private void Move(cNode node)
        {
            Point pos = node.GetPosition();
            // What to do when a move event is called?  That depends entirely
            // on the current movement parameters.
            switch (Globals.MoveMode)   
            {
                case Globals.MovementType.None:
                    return;  // Nothing to do.
                case Globals.MovementType.Linear:
                    // This one bounces the nodes off the walls walls:
                    pos.X += node.GetSpeed() * Math.Cos(node.Direction);
                    pos.Y += node.GetSpeed() * Math.Sin(node.Direction);
                    break;
                case Globals.MovementType.Targetted:
                    // This one generates a random target place, then moves the node there, then
                    // generates another random target place, and so on.  First, check to see if
                    // node has arrived at target (also used to initialise the first target position):
                    double sqdist = CalcSquareDistance(pos, node.TargetPosition);
                    if (sqdist < node.GetSpeed() * node.GetSpeed())
                    {
                        // I've arrived.  Find a new target position and a new speed:
                        node.TargetPosition.X = (2.0 * Globals.rands.NextDouble() - 1.0) * 0.9;
                        node.TargetPosition.Y = (2.0 * Globals.rands.NextDouble() - 1.0) * 0.9;
                        node.Direction = Math.Atan2(node.TargetPosition.Y - pos.Y, node.TargetPosition.X - pos.X);
                        node.SetSpeed(Globals.MovementSpeedNew());
                    }
                    // Then move off in the required direction:
                    pos.X += node.GetSpeed() * Math.Cos(node.Direction);
                    pos.Y += node.GetSpeed() * Math.Sin(node.Direction);
                    break;
                default:
                    MessageBox.Show("Unrecognised Movement Mode", "Serious Error");
                    break;
            }

            // Whatever happens, make sure I bounce off the walls:
            if (pos.X >= 1.0 || pos.X <= -1.0)
            {
                pos.X -= node.GetSpeed() * Math.Cos(node.Direction);
                pos.Y -= node.GetSpeed() * Math.Sin(node.Direction);
                node.Direction = Math.PI - node.Direction;
                pos.X += node.GetSpeed() * Math.Cos(node.Direction);
                pos.Y += node.GetSpeed() * Math.Sin(node.Direction);
            }
            if (pos.Y >= 1.0 || pos.Y <= -1.0)
            {
                pos.X -= node.GetSpeed() * Math.Cos(node.Direction);
                pos.Y -= node.GetSpeed() * Math.Sin(node.Direction);
                node.Direction = -1.0 * node.Direction;
                pos.X += node.GetSpeed() * Math.Cos(node.Direction);
                pos.Y += node.GetSpeed() * Math.Sin(node.Direction);
            }

            // Then if animation is on, I should move the nodes on 
            // the display:
            if (Globals.Animate == true)
            {
                node.Replace();
                node.UpdateIfMoved();
            }

            // Oh, and if I've just moved everything, then I'll need to recalculate all the 
            // channel losses to everything (note this code is the same
            if (Globals.PathLosses != null) CalculatePathLosses();

            node.SetPosition(pos);
        }

        // OK, this is the one that calculates all the path losses.  I'll put it here,
        // since they have to be recalculated after every move of the nodes:
        internal void CalculatePathLosses()
        {
            for (int source = 0; source < Globals.NumberOfNodes; source++)
            {
                for (int destination = 0; destination < Globals.NumberOfNodes; destination++)
                {
                    double deltaX = Globals.myNodes[source].GetPosition().X - Globals.myNodes[destination].GetPosition().X;
                    double deltaY = Globals.myNodes[source].GetPosition().Y - Globals.myNodes[destination].GetPosition().Y;
                    double squaredistance = 10000 * (deltaX * deltaX + deltaY * deltaY); // 100^2 since distances are meters
                    double loss = Globals.GetPathLossFromSquareDistance(squaredistance);
                    Globals.PathLosses[source, destination] = loss;
                }
            }
        }

        double CalcSquareDistance(Point one, Point two)
        {
            return ((one.X - two.X) * (one.X - two.X) + (one.Y - two.Y) * (one.Y - two.Y));
        }
    }
}
