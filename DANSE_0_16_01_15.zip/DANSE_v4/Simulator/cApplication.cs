﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Text;

// This file contains the source code for the application class.

namespace DANSE_v4
{
    #region Region: The application class controls and wrapper

    // First, the part of the Window class that deals with the Simulation Setup controls
    // for the application layer:
    public partial class MainWindow : Window
    {
        internal List<UIElement> GetApplicationControls()
        {
            List<UIElement> controls = new List<UIElement>();
            int VOffset = Globals.CONTROLVOFFSETSTART;
            int VOffsetDifference = Globals.CONTROLVOFFSETDELTA;

            // First up, a label and ComboBox for the application generation style:
            Globals.ctsTrafficDistribution = GUIBits.SetupNewComboBox<Globals.TrafficType>(controls, VOffset, "packet distribution", "Generate");
            Globals.ctsTrafficDistribution.theComboBox.SelectionChanged += new SelectionChangedEventHandler(TrafficTypeCombo_SelectionChanged);
            VOffset += VOffsetDifference;

            // Then a slider for the rate of packet generation:
            Globals.stsTrafficGenerateRate = GUIBits.SetupNewLinearSlider(controls, VOffset, "mean packet rate per node", "Mean Rate", 
                Globals._TrafficGenerateRateDefault,
                Globals._TrafficGenerateRateMinimum,
                Globals._TrafficGenerateRateMaximum);
            Globals.stsTrafficGenerateRate.theSlider.ValueChanged += new RoutedPropertyChangedEventHandler<double>(MeanRateSlider_ValueChanged);
            MeanRateSlider_ValueChanged(Globals.stsTrafficGenerateRate.theSlider, null);
            VOffset += VOffsetDifference;

            // Then a label and ComboBox for the packet size distribution:
            Globals.ctsTrafficSizeType = GUIBits.SetupNewComboBox<Globals.TrafficSizeType>(controls, VOffset, "", "Packets");
            Globals.ctsTrafficSizeType.theComboBox.SelectionChanged += new SelectionChangedEventHandler(PacketSizeTypeCombo_SelectionChanged);
            VOffset += VOffsetDifference;

            // Then a slider for the packet size:
            Globals.stsMeanPacketSize = GUIBits.SetupNewLogIntegerSlider(controls, VOffset, "mean packet size", "Mean Size",
                Globals._MeanPacketSizeDefault,
                Globals._MeanPacketSizeMinimum,
                Globals._MeanPacketSizeMaximum);
            Globals.stsMeanPacketSize.theSlider.ValueChanged += new RoutedPropertyChangedEventHandler<double>(MeanSizeSlider_ValueChanged);
            MeanSizeSlider_ValueChanged(Globals.stsMeanPacketSize.theSlider, null);
            VOffset += VOffsetDifference;

            // Then a slider for the packet priority:
            Globals.stsPacketPriority = GUIBits.SetupNewIntegerSlider(controls, VOffset, "priority", "Priority",
                Globals._PacketPriorityDefault,
                Globals._PacketPriorityMinimum,
                Globals._PacketPriorityMaximum);
            Globals.stsPacketPriority.theSlider.ValueChanged += new RoutedPropertyChangedEventHandler<double>(PrioritySlider_ValueChanged);
            PrioritySlider_ValueChanged(Globals.stsPacketPriority.theSlider, null);
            VOffset += VOffsetDifference;

            // Then a combo box for the target placement algorithm:
            Globals.ctsWhereToSendPackets = GUIBits.SetupNewComboBox<Globals.eNodeTarget>(controls, VOffset, "packet targets", "Target");
            Globals.ctsWhereToSendPackets.theComboBox.SelectionChanged += new SelectionChangedEventHandler(TargetCombo_SelectionChanged);
            VOffset += VOffsetDifference;

            // Then send back the list
            return controls;
        }

        void MeanRateSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            double newValue = ((GUIBits.SliderTagStruct)(((Slider)sender).Tag)).GetActualValue();
            Globals.TrafficGenerateRate = Math.Round(newValue, 3);
            foreach (cNode node in Globals.myNodes) 
                node.TrafficRate = Globals.TrafficGenerateRate / Globals.NumberOfNodes;
        }

        void TrafficTypeCombo_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ComboBox thing = (ComboBox)sender;
            String chosen = thing.Items[thing.SelectedIndex].ToString();
            try { Globals.TrafficDistribution = (Globals.TrafficType)Enum.Parse(typeof(Globals.TrafficType), chosen); }
            catch { MessageBox.Show("Traffic Type " + chosen + " not Recognised", "Serious Error"); }
        }

        void MeanSizeSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            Globals.MeanPacketSize = (int)((GUIBits.SliderTagStruct)(((Slider)sender).Tag)).GetActualValue();
            foreach (cNode node in Globals.myNodes) node.MeanPacketSize = Globals.MeanPacketSize;
        }
        void PrioritySlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            Globals.PacketPriority = (int)((GUIBits.SliderTagStruct)(((Slider)sender).Tag)).GetActualValue();
            foreach (cNode node in Globals.myNodes) node.PacketPriority = Globals.PacketPriority;
        }

        void PacketSizeTypeCombo_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ComboBox thing = (ComboBox)sender;
            String chosen = thing.Items[thing.SelectedIndex].ToString();
            try { Globals.PacketDistribution = (Globals.TrafficSizeType)Enum.Parse(typeof(Globals.TrafficSizeType), chosen); }
            catch { MessageBox.Show("Packet Type " + chosen + " not Recognised", "Serious Error"); }
        }
        void TargetCombo_SelectionChanged(object sender, RoutedEventArgs e)
        {
            ComboBox thing = (ComboBox)sender;
            String chosen = thing.Items[thing.SelectedIndex].ToString();

            GUIBits.ComboBoxTagStruct tagstruct = (GUIBits.ComboBoxTagStruct)thing.Tag;
            tagstruct.SetValue<Globals.eNodeTarget>(chosen, ref Globals.WhereToSendPackets);
        }
    }
    #endregion

    #region Region: The application class and packet generation and reception stuff
    // Next, the first (and perhaps only) part of the application class.
    // It generates packets, receives packets, and stores information about packets
    // received and sent in a file.
    internal class cApplication
    {
        cNode node;
        internal cApplication(cNode node)
        {
            // Constructor.  What this does depends on what sort of application protocol
            // layer is in use.  There are a few pre-defined ones, but no user option.
            this.node = node;
            // Initialise (add event for first packet to be generated):
            AddEventForNextPacket(true);
        }

        // A method to work out the time until the next packet is generated, and queue this
        // as a new Event.  This is required to initialise the nodes, as well as on every
        // callback event.
        internal long AddEventForNextPacket(Boolean FirstPacket)
        {
            // If traffic rate is zero, then stop now.
            if (this.node.TrafficRate == 0.0) return 0;

            // I have to generate the next time a packet is generated, and put this
            // into the queue as a new callback event.  First, generate the time:
            long TimeToNextPacket = 0;
            switch (Globals.TrafficDistribution)
            {
                case Globals.TrafficType.Regular:
                case Globals.TrafficType.Sequence:
                    // The first packet should go immediately...
                    if (FirstPacket == false) TimeToNextPacket = (long)(1.0e9 / this.node.TrafficRate);
                    break;
                case Globals.TrafficType.Exponential:
                    // I can hit problems (taking the log of zero) if the generated
                    // random variable is zero, so I'd better check for this just in case:
                    try
                    {
                        TimeToNextPacket = (long)(Math.Log(Globals.rands.NextDouble()) * -1.0e9 / this.node.TrafficRate);
                    }
                    catch  // If it is crazy, I'll substitute a value from the uniform distribution...
                    {
                        TimeToNextPacket = (long)(2.0e9 / this.node.TrafficRate * Globals.rands.NextDouble());
                    }
                    break;
                case Globals.TrafficType.Uniform:
                    TimeToNextPacket = (long)(2.0e9 / this.node.TrafficRate * Globals.rands.NextDouble());
                    break;
                default:
                    MessageBox.Show("Unknown packet generation distribution.  This shouldn't happen", "Serious Error");
                    break;
            }

            long NextPacketTime = node.GetTime() + TimeToNextPacket;

            // If this is the first packet, then add the preroll time as well (which is in seconds):
            if (FirstPacket == true) NextPacketTime += (long)(Globals.PrerollLength * 1e9);

            // Also, if this is the first packet and distribution is set to sequence, add an offset
            // based on the node number to try and minimise collisions at the start:
            if (FirstPacket == true && Globals.TrafficDistribution == Globals.TrafficType.Sequence)
            {
                NextPacketTime += (long)(1.0e9 / this.node.TrafficRate / Globals.NumberOfNodes * node.GetNumber());
            }

            // It's possible that this next time is greater than the length of the simulation,
            // (or at least more than the postroll time less than the length of the simulation)
            // and if so, I shouldn't put it in the queue either.  I'll make sure I don't by
            // setting the time to after the end of the simulation:
            if (NextPacketTime + (Globals.PostrollLength * 1e9) > Globals.SimulationLength * 1e9
                || NextPacketTime < 0) 
                return node.ConvertGlobalToLocalTime((long)(Globals.SimulationLength * 1e9 + 1000));

            // Now formulate the new callback, and put it in the queue:
            cEvent NewEvent = new cEvent(node, null, NextPacketTime, EventType.Application_Callback);
            Globals.theQueue.AddEvent(NewEvent);
            return NextPacketTime;
        }

        internal void EventHandler(cEvent thing)
        {
            // What to do if an event occurs for the application layer.
            //
            // There are only two possible event types:
            //   Application_PacketArrivesFromTransportNetworkLayer: Write details to file and update stats.
            //   Application_Callback: Generate and send a packet, and set another callback event in the queue.

            if (thing.type == EventType.Application_PacketArrivesFromTransportLayer)
            {
                // Get the relevant associated information:
                int packetDestinationPort = thing.B;
                // Test to see if this packet has been received before, and if
                // so, don't process any further:
                int PacketNumber = thing.packet.MetaInformation().GetSystemNumber();
                if (PacketNumber == 0) return; // It's not a data packet, they start from one
                if (Globals.myPackets[PacketNumber - 1].GetEndTime() > 0) return;

                // Another packet has arrived (rightly or wrongly)
                node.ReceiveAPacket();

                // If it's in the right place and right port, increment the count:
                if (thing.packet.MetaInformation().GetFinalDestination() == node.GetNumber()
                    && packetDestinationPort == thing.packet.MetaInformation().GetDestinationPort())
                {
                    Globals.TotalPacketsReceived++;
                    long Delay = Globals.SimTime - thing.packet.MetaInformation().GetWhenGenerated();
                    if (Delay < Globals.MinDelay) Globals.MinDelay = Delay;
                    if (Delay > Globals.MaxDelay) Globals.MaxDelay = Delay;
                    Globals.TotalDelay += Delay;

                    int PacketsSent = Globals.TotalPacketsSent;
                    int PacketsLogged = Globals.myPackets.Count;

                    if (PacketNumber <= PacketsLogged)
                    {
                        Globals.myPackets[PacketNumber - 1].SetEndTime(Globals.SimTime);
                        Globals.myPackets[PacketNumber - 1].SetNumberOfHops(thing.packet.MetaInformation().GetRoute().Count - 1);
                    }
                    else
                    {
                        MessageBox.Show("Strange error: Packet " + PacketNumber.ToString()
                            + " arrives when " + PacketsSent.ToString() + " sent, and "
                            + PacketsLogged.ToString() + " logged.", "Serious Error");
                    }
                }
                else if (thing.packet.MetaInformation().GetFinalDestination() == node.GetNumber())
                {
                    // It's arrived at the right place, but with the wrong port number:
                    Globals.TotalPacketsReceivedAtWrongPort++;
                }
                else
                {
                    // It hasn't even got to the right node:
                    Globals.TotalPacketsReceivedAtWrongNode++;
                }
                // Update the packet received indicators on the front-screen:
                if (Globals.Animate == true) ((MainWindow)Globals.MainWindow).UpdatePacketIndicators();
                // The log file:
                if (Globals.LogEventsOn == true)
                {
                    Globals.NewLogEvent.AppendLine("  Application: Packet sent to node " 
                        + thing.packet.MetaInformation().GetFinalDestination().ToString()
                        + " arrives at node " + node.GetNumber().ToString() 
                        + " from node " + thing.packet.MetaInformation().GetOriginalSource().ToString());
                }
            }
            else if (thing.type == EventType.Application_Callback)
            {
                // There are two types of callback: type zero means the next random
                // generation during this run, type one is the next packet from the 
                // list of pre-programmed PacketsToGo.

                cPacket NewPacket = thing.packet;

                if (thing.A == 0)
                {
                    // First add the next callback event into the queue for the next packet:
                    long NextPacketAt = this.AddEventForNextPacket(false);

                    // Then generate the packet:
                    NewPacket = GenerateNewPacket();

                    // The log file:
                    if (Globals.LogEventsOn == true)
                    {
                        Globals.NewLogEvent.AppendLine("  Application: Packet generated at node " 
                            + node.GetNumber().ToString() + " going to node " 
                            + NewPacket.MetaInformation().GetFinalDestination().ToString());
                        Globals.NewLogEvent.AppendLine("  Application: Next packet setup for generation at " 
                            + NextPacketAt.ToString());
                    }
                }
                else // Callback just indicates another pre-programmed packet being sent:
                {
                    NewPacket = thing.packet;  // Packet already built and in event
                    if (Globals.LogEventsOn == true)
                    {
                        Globals.NewLogEvent.AppendLine("  Application: Scheduled packet sent from node " 
                            + node.GetNumber().ToString());
                    }
                }

                // Set up a new entry in the myPackets array
                Globals.RawPacketData NewRawPacketData = new Globals.RawPacketData();
                NewRawPacketData.SetOriginalSource(this.node.GetNumber());
                NewRawPacketData.SetFinalDestination(NewPacket.MetaInformation().GetFinalDestination());
                NewRawPacketData.SetPriority(0);
                NewRawPacketData.SetLength(NewPacket.GetPacketSize());
                NewRawPacketData.SetStartTime(Globals.SimTime);
                NewRawPacketData.SetEndTime(-1);
                NewRawPacketData.SetPacketNumber(Globals.TotalPacketsSent + 1); // First packet is number one
                NewRawPacketData.SetNumberOfHops(0);
                Globals.myPackets.Add(NewRawPacketData);

                // Mark another packet as being sent from this node
                node.SendAPacket();
                // Increment the number of packets sent:
                Globals.TotalPacketsSent++;

                // Now formulate the new event, and put it in the queue.  Note that for events going to
                // the transport layer, A = destination, B = destination port, C = source port
                cEvent SendThePacket = new cEvent(node, NewPacket, node.GetTime(),
                    EventType.Transport_PacketArrivesFromApplicationLayer, 
                    NewPacket.MetaInformation().GetFinalDestination(),
                    NewPacket.MetaInformation().GetDestinationPort(),
                    NewPacket.MetaInformation().GetSourcePort());
                Globals.theQueue.AddEvent(SendThePacket);
            }
            else if (thing.type == EventType.Application_Initialise)
            {
                // Start up with the first packet being generated for this run:
                AddEventForNextPacket(true);
                // A bit of common-sense checking:
                if (node.GetNumber() == 0 && 
                    Globals.WhereToSendPackets == Globals.eNodeTarget.Random_Other
                    && Globals.NumberOfNodes == 1)
                {
                    Globals.ShowMessageBox("Random Other packet target selected, but there's only one node."
                        + "\nThis doesn't make sense.", "Configuration Error");
                }
            }
            else
            {
                MessageBox.Show("Major Problem: Unknown Event Type at Application Layer", "Serious Error");
            }
        }

        private cPacket GenerateNewPacket()
        {
            int PacketSize = 0;
            switch (Globals.PacketDistribution)
            {
                case Globals.TrafficSizeType.Regular:
                    PacketSize = this.node.MeanPacketSize;
                    break;
                case Globals.TrafficSizeType.Exponential:
                    // I can hit problems (taking the log of zero) if the generated
                    // random variable is zero, so I'd better check for this just in case:
                    try
                    {
                        PacketSize = (int)(-1 * Math.Log(Globals.rands.NextDouble()) * this.node.MeanPacketSize);
                    }
                    catch  // If it is crazy, I'll substitute a value from the uniform distribution...
                    {
                        PacketSize = (int)(2.0 * this.node.MeanPacketSize * Globals.rands.NextDouble());
                    }
                    // To retain some sanity, I'll cap the maximum packet length at 10,000 bytes.  Note this
                    // means that the mean will not be exact, however since even at maximum packet size of 
                    // 1000 bytes only around 45 out of every million packets is affected, and the mean
                    // is still correct to within 0.01%, I won't worry about it.
                    if (PacketSize > 10000) PacketSize = 10000;
                    break;
                case Globals.TrafficSizeType.Uniform:
                    // Generate packets from size 1 byte up, with a mean value of MeanPacketSize:
                    PacketSize = 1 + (int)Math.Round((2.0 * this.node.MeanPacketSize - 2)* Globals.rands.NextDouble());
                    break;
                default:
                    MessageBox.Show("Unknown packet size distribution.  This shouldn't happen", "Serious Error");
                    break;
            }

            cPacket NewPacket = new cPacket(PacketSize, node.GetNumber(), Globals.TotalPacketsSent + 1);
            // The destination is chosen at random, and put into the metainformation for the packet.
            int Destination = node.GetNumber();
            switch (Globals.WhereToSendPackets)
            {
                case Globals.eNodeTarget.Random:
                    // If random, choose any target including the current node.
                    Destination = Globals.rands.Next(Globals.myNodes.Count);
                    break;
                case Globals.eNodeTarget.Random_Other:
                    // If random, choose any target excluding the current node.
                    if (Globals.NumberOfNodes > 1)
                    {
                        do
                        {
                            Destination = Globals.rands.Next(Globals.myNodes.Count);
                        } while (Destination == node.GetNumber());
                    }
                    else
                    {
                        MessageBoxResult Reply = MessageBox.Show("Asked to send packet to a different node,\n"
                            + "but only one node in the simulation." + "\n\nContinue the simulation?",
                            "Configuration Error", MessageBoxButton.YesNo);
                        if (Reply == MessageBoxResult.No)
                        {
                            // User has selected to terminate.  Stop the simulation.
                            ((MainWindow)Globals.MainWindow).EndSimulation();
                        }
                    }
                    break;
                case Globals.eNodeTarget.Centre:
                    // If centre, choose the centre node for everything:
                    Destination = Globals.CentreNode;
                    break;
                case Globals.eNodeTarget.Zero:
                    // If zero, choose node zero for everything:
                    Destination = 0;
                    break;
                default:
                    MessageBox.Show("Packet destination type not recognised", "Serious Error");
                    break;
            }

            // Set up the metainformation for this packet:
            NewPacket.MetaInformation().SetOriginalSource(this.node.GetNumber());
            NewPacket.MetaInformation().SetFinalDestination(Destination);
            NewPacket.MetaInformation().SetWhenGenerated(Globals.SimTime);
            NewPacket.MetaInformation().SetSystemNumber(Globals.TotalPacketsSent + 1);  // First packet is number one
            StringBuilder tag = new StringBuilder(64);
            tag.Append((Globals.TotalPacketsSent + 1).ToString());
            tag.Append(" (src:");
            tag.Append(this.node.GetNumber().ToString());
            tag.Append(" dest:");
            tag.Append(Destination.ToString());
            tag.Append(")");
            NewPacket.MetaInformation().SetTag(tag.ToString());
            // The port numbers are also chosen at random, and are between zero and 255.
            NewPacket.MetaInformation().SetSourcePort(Globals.rands.Next(255));
            NewPacket.MetaInformation().SetDestinationPort(Globals.rands.Next(255));

            // And return the packet generated:
            return NewPacket;
        }
    }
    #endregion
}
