﻿using System;
using System.Runtime.InteropServices;
using System.Windows;
namespace DANSE_v4
{
    public partial class MainWindow : Window
    {
        private void MACSetupALOHAControls()
        {
            Globals.stsMACInitialBackoff.NameOnSetup.Content = "Init Max Wait";
            Globals.stsMACInitialBackoff.SetNewRange(0.0, 5.0, 0.0, GUIBits.SliderType.linear);
            Globals.stsMACInitialBackoff.Enable(true);
        }
    }

    unsafe class cALOHA : cMAC
    {
        //////////////////////////////////////////////////////
        // Simple ALOHA: just send after waiting for a short
        // random backup time to prevent some collisions.
        //

        internal cALOHA(cNode Here, ref cNode.MACDelegates Delegates)
            : base(Here)
        {
            Delegates.CallWhenCallback = new cNode.MACCallbackDelegate(this.Callback);
            Delegates.CallWhenInitialise = new cNode.MACInitialiseDelegate(this.Initialise);
            Delegates.CallWhenPacketArrivesFromLogicalLinkLayer = new cNode.MACPacketFromAboveDelegate(this.PacketArrivesFromLogicalLinkLayer);
            Delegates.CallWhenPacketArrivesFromPhysicalLayer = new cNode.MACPacketFromBelowDelegate(this.PacketArrivesFromPhysicalLayer);
            Delegates.CallWhenShutdown = new cNode.MACShutdownDelegate(this.Shutdown);
        }

        // Default header for the internal protocols:
        [Serializable] struct MultipleAccessHeader
        {
            internal byte transmitter;
            internal byte receiver;

            internal MultipleAccessHeader(int transmitter, int receiver)
            {
                this.transmitter = (byte)(transmitter);
                this.receiver = (byte)(receiver);
            }
        }

        // The algorithm used when a packet arrives from the layer above:
        //   If transmitter is free, queue is empty and random wait is 
        //     zero, then just send it.
        //   If transmitter is free, queue is empty and random wait is
        //     not zero, then put packet in queue, and generate a callback
        //     event for the random time.
        //   If transmitter is not free but queue is empty, then add it to
        //     the queue, and request a callback for when the transmitter 
        //     finishes
        //   If queue is not empty, then just add it to the queue.
        //   The callback routine then:
        //     If the transmitter is busy, set another callback for when the
        //       transmitter becomes free (can happen if another node starts
        //       transmitting while waiting for initial random time).
        //     Get the first packet from the queue, and send it.
        //     If the queue is not empty, callback for when the transmitter
        //       finishes.

        void PacketArrivesFromLogicalLinkLayer(cPacket packet, int nextHop)
        {
            // First thing is to add the header so the frame knows where it's going,
            // and update the metadata for the hops:
            MultipleAccessHeader newHeader
                = new MultipleAccessHeader(node.GetNumber(), nextHop);
            packet.AddHeader((Object)newHeader, sizeof(MultipleAccessHeader));

            // If the queue is not empty, then just add this packet to the queue:
            if (PacketStore.Count > 0) 
            {
                PacketStore.Add(new cPacketStoreElement(node, packet));
                // Update the log file
                if (Globals.LogEventsOn == true)
                    OutToLog("  Multiple Access: Packet added to queue for later transmission");
            }

            // Otherwise, if the transmitter is free and random wait is 
            //   zero, then just send it.
            else if (node.GetTransmitState() == Globals.TransmitterState.Off
                    && this.maxRandomWait == 0.0)
            {
                SendThisPacket(packet);
            }

            // Otherwise if the random wait is not zero, then 
            //   put the packet in the queue, and generate a callback
            //   event for the random time.
            else if (this.maxRandomWait > 0.0)
            {
                PacketStore.Add(new cPacketStoreElement(node, packet));
                double howLong = Globals.rands.NextDouble() * this.maxRandomWait;
                RequestRelativeCallback(howLong, 0);
                // Update the log file
                if (Globals.LogEventsOn == true)
                    OutToLog("  Multiple Access: Packet added to queue for transmission after " 
                        + howLong.ToString("0.000") + " seconds");
            }

            // Otherwise, the random wait must be zero but the transmitter
            // is busy, so store the packet and put in a callback for
            // when the transmitter becomes free:
            else if (node.GetTransmitState() != Globals.TransmitterState.Off)
            {
                PacketStore.Add(new cPacketStoreElement(node, packet));
                node.SetMACTransmitterIdleCallback(true, 0);
                // Update the log file
                if (Globals.LogEventsOn == true)
                    OutToLog("  Multiple Access: Packet added to queue for transmission");
            }

            // Otherwise, something very strange is happening:
            else
            {
                Globals.ShowMessageBox("ALOHA should not get to this point", "Logical error");
            }
        }

        private void SendThisPacket (cPacket ToGo)
        {
            Globals.theQueue.AddEvent(new cEvent(node, ToGo, node.GetTime(),
                EventType.Physical_PacketArrivesFromMACLayer,
                (int)Globals.DefaultBitRate, 0, 0, Math.Pow(10, (Globals.DefaultTxPowerdBm - 30.0) / 10.0)));
            // Update the log file
            if (Globals.LogEventsOn == true)
                OutToLog("  Multiple Access: Packet sent to physical layer to transmit");
        }

        void Callback(int A, cPacket packet = null)
        {
            // First, just check that there is a packet waiting to be sent.
            if (PacketStore.Count == 0) return;

            // If the transmitter is busy, request another callback when it becomes
            // free:
            if (node.GetTransmitState() == Globals.TransmitterState.Transmitting)
            {
                // This can happen if a packet arrives while another packet is being
                // transmitted (so store was empty when it arrived), and the 
                // random delay timeout happens while the packet is still being
                // transmitted.
                RequestCallbackWhenTransmitterIdle(0);
                return;
            }

            //   Get the first packet from the queue, and send it.
            cPacket ToGo = RemovePacketFromQueue(0);
            SendThisPacket(ToGo);

            //   If the queue is not empty, callback for when the transmitter
            //     finishes.
            if (PacketStore.Count > 0)
            {
                node.SetMACTransmitterIdleCallback(true, 0);
                // Update the log file
                if (Globals.LogEventsOn == true)
                    OutToLog("  Multiple Access: Next packet scheduled for transmission");
            }
        }

        void PacketArrivesFromPhysicalLayer(cPacket packet, double RxPower)
        {
            // Some idiot checking:
            if (!(packet.ViewHeader() is MultipleAccessHeader))
            {
                Globals.ShowMessageBox("Packet arrived at multiple access layer\n"
                    + "without a suitable header. \n"
                    + "Packet will be deleted.", "User Protocol Error?");
                return;
            }

            // Take the header off:
            MultipleAccessHeader thisHeader = (MultipleAccessHeader)packet.RemoveHeader();
            // If the frame is for me or broadcast, pass up to the logical-link layer,
            // otherwise, just ignore it.
            if (thisHeader.receiver == node.GetNumber() || thisHeader.receiver == BROADCAST)
            {
                // Pass straight up to the logical-link layer:
                Globals.theQueue.AddEvent(new cEvent(node, packet, node.GetTime(),
                    EventType.LogicalLink_PacketArrivesFromMACLayer,
                    thisHeader.transmitter));
                // Update the log file
                if (Globals.LogEventsOn == true)
                    OutToLog("  Multiple Access: Packet received from physical layer, going to node " + packet.MetaInformation().GetFinalDestination().ToString() + " pass up to logical link layer");
            }
        }

        double maxRandomWait = 0.0;
        void Initialise(double A, double B, double C, double D, double E, double F, double G)
        {
            // Set-up stuff: for ALOHA this is just a random wait
            this.maxRandomWait = Globals.MACInitialBackoff;
        }
        
        void Shutdown() { }
    }
}
