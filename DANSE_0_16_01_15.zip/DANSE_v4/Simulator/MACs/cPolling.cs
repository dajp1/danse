﻿using System;
using System.Windows;
using System.Collections.Generic;

namespace DANSE_v4
{
    public partial class MainWindow : Window
    {
        private void MACSetupPollingControls()
        {
            Globals.stsMACInitialBackoff.NameOnSetup.Content = "Not Used";
            Globals.stsMACInitialBackoff.Enable(false);

            // The GUI controls for this protocol are:
            // A = maxReplyTime, the maximum time the co-ordinator waits for a response
            //     to a poll before giving up.  Must be longer than the maximum frame time,
            //     otherwise the coordinator can give a poll to someone else while a frame
            //     is still going.  This is a log slider, from 0.1 seconds to 10 seconds,
            //     default value is one second.
            // B = minTotalPollTime, the minimum time for a whole poll sequence.  If the
            //     poll sequence takes less time than this, the co-ordinator waits at the
            //     end before doing another random access request.  Log slider, from 0.1
            //     seconds to 100 seconds, default value is ten seconds.
            // C = randomAccessPeriod, the length of time the co-ordinator waits for replies
            //     to the message asking anyone new to join the network.  Log slider from
            //     0.1 to 2 seconds, default value one second.
            // D = packetsPerPoll, the maximum number of packets a node is allowed to send 
            //     after receiving the poll.  Linear integer slider from one to ten, 
            //     default value is one.
            // E = registrationTimeout, the amount of time that a node waits without being 
            //     asked for a poll before it gives up and tries to register again.  A log
            //     slider from one second to 1000 seconds, default value 100 seconds.

            Globals.stsMACParameterOne.NameOnSetup.Content = "Max Reply Time";
            Globals.stsMACParameterOne.SetNewRange(0.1, 10.0, 1.0, GUIBits.SliderType.log);
            Globals.stsMACParameterOne.Enable(true);

            Globals.stsMACParameterTwo.NameOnSetup.Content = "Min Poll Time";
            Globals.stsMACParameterTwo.SetNewRange(0.1, 100.0, 10.0, GUIBits.SliderType.log);
            Globals.stsMACParameterTwo.Enable(true);

            Globals.stsMACParameterThree.NameOnSetup.Content = "Access Time";
            Globals.stsMACParameterThree.SetNewRange(0.1, 2.0, 1.0, GUIBits.SliderType.log);
            Globals.stsMACParameterThree.Enable(true);

            Globals.stsMACParameterFour.NameOnSetup.Content = "Packets/Poll";
            Globals.stsMACParameterFour.SetNewRange(1, 10, 1, GUIBits.SliderType.integer);
            Globals.stsMACParameterFour.Enable(true);

            Globals.stsMACParameterFive.NameOnSetup.Content = "Reg. Timeout";
            Globals.stsMACParameterFive.SetNewRange(1.0, 1000.0, 100.0, GUIBits.SliderType.log);
            Globals.stsMACParameterFive.Enable(true);
        }
    }

    class cPolling : cMAC
    {
        // This is a simple polling MAC layer.  Operation is as follows.
        // For the co-ordinator (always node zero)
        // 1) On initialisation, the co-ordinator sends out a "is 
        //     there anyone there" packet.  It then waits for a time
        //     set by "randomAccessPeriod" for replies.  If anything
        //     comes, they are added to the list.
        // 2) The co-ordinator then sends out a poll to the first node
        //     in the list.  If there is no reply by "maxReplyTime" it
        //     moves on and sends to the next in the list.
        // 3) Once it gets to the end of the list, it checks the total
        //     poll time against "minTotalPollTime", and if it's been
        //     quicker than the minimum, it waits until the minimum
        //     time is over, then starts the poll cycle again with 
        //     another "is there anyone there" packet.
        // 4) The co-ordinator is allowed to send packets whenever
        //     a poll reply is received.
        //
        // For the other nodes:
        // 1) Initially, "amIRegistered" is set to false.
        // 2) If a poll is receiver, "amIRegistered" is set to true.
        // 3) If "maxTotalPollTime" is exceeded and no poll has been 
        //     received, the node is de-registered.
        // 4) If a "is there anyone there" packet arrives and the node 
        //     is not registered, it replies with a "yes, I'm here"
        //     packet.
        // 5) If a packet arrives to be sent, it waits until the poll
        //     is received.  Then the node is allowed to send up to 
        //     "packetsPerPoll" packets to the physical layer.

        internal cPolling(cNode Here, ref cNode.MACDelegates Delegates) : base(Here)
        {
            Delegates.CallWhenCallback = new cNode.MACCallbackDelegate(this.Callback);
            Delegates.CallWhenInitialise = new cNode.MACInitialiseDelegate(this.Initialise);
            Delegates.CallWhenPacketArrivesFromLogicalLinkLayer = new cNode.MACPacketFromAboveDelegate(this.PacketArrivesFromLogicalLinkLayer);
            Delegates.CallWhenPacketArrivesFromPhysicalLayer = new cNode.MACPacketFromBelowDelegate(this.PacketArrivesFromPhysicalLayer);
            Delegates.CallWhenShutdown = new cNode.MACShutdownDelegate(this.Shutdown);
        }

        double maxReplyTime;
        double minTotalPollTime;
        double randomAccessPeriod;
        double registrationTimeout;
        const double oneJiffy = 2e-9;

        double whenRandomAccessStarted;
        double whenLastPollArrived;
        double whenPollLastSent;

        int packetsPerPoll;
        int numberOfPacketsSentThisPoll;
        int indexOfCurrentPolledNode;
        int theCoordinator;
        int myNumber;

        Boolean amIRegistered = false;
        Boolean amICoordinator = false;

        List<int> OtherNodes = new List<int>(); // Only for the co-ordinator
        enum PollingState{ initialise, waitingForPollReply, waitingForNewNodesToReply,
            waitingForMinimumTotalPollTime, waitingForTransmitterToFinish, 
            waitingForRandomAccessDelay }
        PollingState state = PollingState.initialise;

        enum PollingPacketType
        {
            Data = 0, Poll = 1, Finished = 2,  Access = 3, Join = 4
        }
        [Serializable] class MACPollingHeader
        {
            // Just contains the destination (next-hop) 
            // and source (current node) addresses:
            byte destinationNode;
            byte sourceNode;

            PollingPacketType type;
            internal MACPollingHeader(int destination, int source, PollingPacketType what)
            {
                destinationNode = (byte)destination;
                sourceNode = (byte)source;
                type = what;
            }
            internal int GetHeaderSize() { return 3; }
            internal PollingPacketType GetSort() { return type; }
            internal int GetDestination() { return destinationNode; }
            internal int GetSource() { return sourceNode; }
        }

        void StartPollingSequence()
        {
            // Starts a polling sequence: reset who to poll, and send new random
            // access request.
            if (amICoordinator == false)
                printfToMessageBox("Attempt to start polling sequence by non-coordinator.");
            // Clear all timeouts, and set index of next polled node to zero:
            CancelCallbacks();
            indexOfCurrentPolledNode = 0;
            // Generate new packet asking for new nodes to register:
            cPacket packet = new cPacket(0, myNumber, 0);
            packet.MetaInformation().SetFinalDestination(BROADCAST);
            packet.MetaInformation().SetTag("MAC: Anyone New?");
            MACPollingHeader header = new MACPollingHeader(BROADCAST, myNumber, PollingPacketType.Access);
            packet.AddHeader(header, header.GetHeaderSize());
            SendPacketToPhysicalLayer(packet);
            // Callback when the random access period is over:
            RequestRelativeCallback(randomAccessPeriod, (int)CallbackTypes.cbRandomAccessPeriodOver);
            state = PollingState.waitingForNewNodesToReply;
            whenRandomAccessStarted = GetMyTime();
            // Update the log file
            if (Globals.LogEventsOn == true)
                OutToLog("  Polling: Looking for new members until time " + (long)(1e9 * (GetMyTime() + randomAccessPeriod)));
        }
        void SendPollToNode(int dest)
        {
            if (amICoordinator == false)
                printfToMessageBox("Attempt to send poll not from co-ordinator.");
            // Generate and send new poll message:
            cPacket packet = new cPacket(0, myNumber, 0);
            packet.MetaInformation().SetFinalDestination(dest);
            packet.MetaInformation().SetTag("MAC: Poll to node " + dest.ToString());
            MACPollingHeader header = new MACPollingHeader(dest, myNumber, PollingPacketType.Poll);
            packet.AddHeader(header, header.GetHeaderSize());
            SendPacketToPhysicalLayer(packet);
            // Clear all polling callbacks, and set in a new one for this poll attempt:
            CancelCallbacks((int)CallbackTypes.cbMaxReplyPeriodOver);
            RequestRelativeCallback(maxReplyTime, (int)CallbackTypes.cbMaxReplyPeriodOver);
            state = PollingState.waitingForPollReply;
            whenPollLastSent = GetMyTime();
            // Update the log file
            if (Globals.LogEventsOn == true)
                OutToLog("  Polling: Sent poll to node " + dest + " will timeout at " + (long)(1e9 * (GetMyTime() + maxReplyTime)));
        }
        void SendFinishedResponseToCoordinator()
        {
            // Just build an "I'm finished packet and send it"
            cPacket packet = new cPacket(0, myNumber, 0);
            packet.MetaInformation().SetFinalDestination(this.theCoordinator);
            packet.MetaInformation().SetTag("MAC: Node " + this.myNumber.ToString() + " finished");
            MACPollingHeader header = new MACPollingHeader(this.theCoordinator, myNumber, PollingPacketType.Finished);
            packet.AddHeader(header, header.GetHeaderSize());
            SendPacketToPhysicalLayer(packet);
        }
        void SendHelloIAmHerePacket()
        {
            // If I'm not already registered, build a registration packet and send it:
            if (amIRegistered == true) return; // No need, I'm already registered
            cPacket packet = new cPacket(0, myNumber, 0);
            packet.MetaInformation().SetFinalDestination(this.theCoordinator);
            packet.MetaInformation().SetTag("MAC: Node " + this.myNumber.ToString() + " I'm here!");
            MACPollingHeader header = new MACPollingHeader(this.theCoordinator, myNumber, PollingPacketType.Join);
            packet.AddHeader(header, header.GetHeaderSize());
            SendPacketToPhysicalLayer(packet);
        }
        void DoPollReplyStuff()
        {
            // What to do when a poll reply arrives (or the co-
            // ordinator gives up waiting): move onto the next node
            // in the list and send a poll packet.  If at the end of
            // the list, check the time since this polling cycle
            // started, and either send a new random access request
            // immediately, or wait until the next one is due.

            // Clear all callbacks waiting for polls to complete:
            CancelCallbacks((int)CallbackTypes.cbMaxReplyPeriodOver);

            indexOfCurrentPolledNode++;
            if (indexOfCurrentPolledNode < OtherNodes.Count)
            {
                double theTime = GetMyTime();
                SendPollToNode(OtherNodes[indexOfCurrentPolledNode]);
            }
            else
            {
                double howLongToWait = whenRandomAccessStarted + minTotalPollTime - GetMyTime();
                if (howLongToWait > 0)
                {
                    RequestRelativeCallback(howLongToWait, (int)CallbackTypes.cbTotalPollTimeOver);
                    state = PollingState.waitingForMinimumTotalPollTime;
                    // Update the log file
                    if (Globals.LogEventsOn == true)
                        OutToLog("  Polling: Finished round, will start again at " + (long)(1e9 * (GetMyTime() + howLongToWait)));
                }
                else
                {
                    StartPollingSequence();
                    // Update the log file
                    if (Globals.LogEventsOn == true)
                        OutToLog("  Polling: Finished round, starting immediately");
                }
            }
        }
        void SendOldestPacketInQueue()
        {
            // I always send the first packet in the queue:
            cPacket toGo = RemovePacketFromQueue(0);
            SendPacketToPhysicalLayer(toGo);
            numberOfPacketsSentThisPoll++;
            // Then request a callback so I can another, or the "finished" packet:
            RequestCallbackWhenTransmitterIdle((int)CallbackTypes.cbTransmitFinished, oneJiffy);
            state = PollingState.waitingForTransmitterToFinish;
        }

        void PacketArrivesFromPhysicalLayer(cPacket packet, double rxPower)
        {
            if (!(packet.ViewHeader() is MACPollingHeader))
            {
                // Something very badly wrong:
                printfToMessageBox("Polling receives a MAC packet without a polling header.");
            }
            // Get the header from the packet:
            MACPollingHeader header = (MACPollingHeader)packet.RemoveHeader();
            // If it's not intended for me, ignore it:
            int destNode = header.GetDestination();
            if (destNode != myNumber && destNode != BROADCAST) return;
            // Find out where it came from and is intended for:
            int sourceNode = header.GetSource();
            // If it is data, pass straight up to the logical-link layer:
            PollingPacketType type = header.GetSort();
            switch (type)
            {
                case PollingPacketType.Data:
                    // This is a data packet.  Send it up to the higher layer:
                    SendPacketToLogicalLinkLayer(packet, sourceNode);
                    break;
                case PollingPacketType.Poll:
                    // This is a poll.  If it was sent to me, and there is a packet 
                    // in the queue, then send it, then send the poll reply back.  
                    // If not just send the poll back.
                    if (amICoordinator == false)
                    {
                        amIRegistered = true;
                        whenLastPollArrived = GetMyTime();
                        numberOfPacketsSentThisPoll = 0;
                        CancelCallbacks((int)CallbackTypes.cbRegistrationTimesOut);
                        RequestRelativeCallback(registrationTimeout, (int)CallbackTypes.cbRegistrationTimesOut);
                        if (PacketStore.Count > 0)
                        {
                            SendOldestPacketInQueue();
                        }
                        else
                        {
                            // If nothing in the packet store, just send the poll back:
                            SendFinishedResponseToCoordinator();
                        }
                    }
                    break;
                case PollingPacketType.Finished:
                    // This is a poll reply.
                    if (amICoordinator == true) DoPollReplyStuff();
                    break;
                case PollingPacketType.Access:
                    // This is an init request.  Non-group members waiting to join 
                    // wait for a random number of seconds, and then send a response.
                    if (amICoordinator == false && amIRegistered == false)
                    {
                        theCoordinator = sourceNode; // This is how I know who the coordinator is
                        double howLongToSendAccessRequest = (Globals.PhysicalHeaderSize + 3) * 8 / Globals.DefaultBitRate;
                        double howLongToWait = Globals.rands.NextDouble() * (this.randomAccessPeriod - howLongToSendAccessRequest);
                        RequestRelativeCallback(howLongToWait, (int)CallbackTypes.cbSendAccessRequestNow);
                        state = PollingState.waitingForRandomAccessDelay;
                    }
                    break;
                case PollingPacketType.Join:
                    // This is a join request, received by the controller from a node
                    // that does not consider itself a member of the group (yet).
                    int q = myNumber;
                    if (amICoordinator == true && OtherNodes.Contains(sourceNode) == false)
                    {
                        OtherNodes.Add(sourceNode);
                        // Update the log file
                        if (Globals.LogEventsOn == true)
                            OutToLog("  Polling: Adding new user " + sourceNode + " to the list of nodes");
                    }
                    break;
                default:
                    printfToMessageBox("MAC packet arrived with mode = " + header.GetType()
                        + ".\nThat should not happen.");
                    break;
            }
        }

        void PacketArrivesFromLogicalLinkLayer(cPacket packet, int nextHop)
        {
            // Generate a MAC-layer header for this packet:
            MACPollingHeader newHeader = new MACPollingHeader(nextHop, myNumber, PollingPacketType.Data);
            // Add this header to the packet:
            packet.AddHeader(newHeader, 2);
            // Put the packet in the queue (and wait for the poll to arrive):
            PutPacketInQueue(packet);
        }

        enum CallbackTypes{ 
            cbRandomAccessPeriodOver = 1,
            cbTransmitFinished = 2,
            cbTotalPollTimeOver = 3,
            cbMaxReplyPeriodOver = 4,
            cbSendAccessRequestNow = 5,
            cbRegistrationTimesOut = 6
        }

        void Callback(int A, cPacket packet = null)
        {
            CallbackTypes x = (CallbackTypes)A;
            // Update the log file
            if (Globals.LogEventsOn == true)
                OutToLog("  Polling: Callback of type " + x.ToString());

            switch (x)
            {
                case CallbackTypes.cbRandomAccessPeriodOver:
                    // Check I'm in the right state:
                    if (state != PollingState.waitingForNewNodesToReply)
                        printfToMessageBox("Polling receives random access period over callback, but not in random period.");

                    // End of the random access period.  The co-ordinator is now allowed to 
                    // send packets if it has any, otherwise if there are any nodes out there
                    // it sends a poll, otherwise it just waits for the next polling interval
                    if (PacketStore.Count > 0)
                    {
                        numberOfPacketsSentThisPoll = 0;
                        SendOldestPacketInQueue();
                    }
                    else if (OtherNodes.Count > 0)
                    {
                        SendPollToNode(OtherNodes[0]);
                    }
                    else
                    {
                        RequestRelativeCallback(minTotalPollTime, (int)CallbackTypes.cbTotalPollTimeOver);
                        state = PollingState.waitingForMinimumTotalPollTime;
                        // Update the log file
                        if (Globals.LogEventsOn == true)
                            OutToLog("  Polling: No nodes known, will try again at " + (long)(1e9 * (GetMyTime() + minTotalPollTime)));
                    }
                    break;
                case CallbackTypes.cbTransmitFinished:
                    // Check I'm in the right state:
                    if (state != PollingState.waitingForTransmitterToFinish)
                        printfToMessageBox("Polling receives transmit finished callback, but not in waiting for transmitter to be ready.");

                    // If I am allowed to send another packet and I've got one to send,
                    // then do so.  If not, and I am the co-ordinator, then start the
                    // polling sequence.  If not, and I am not the co-ordinator, then
                    // send the poll response back.
                    if (numberOfPacketsSentThisPoll < this.packetsPerPoll && PacketStore.Count > 0)
                    {
                        SendOldestPacketInQueue();
                    }
                    else if (amICoordinator == true && OtherNodes.Count > 0)
                    {
                        SendPollToNode(OtherNodes[0]);
                    }
                    else if (amICoordinator == true && OtherNodes.Count == 0)
                    {
                        // This should never happen - who did I send the packet to?
                        RequestRelativeCallback(minTotalPollTime, (int)CallbackTypes.cbTotalPollTimeOver);
                        state = PollingState.waitingForMinimumTotalPollTime;
                        // Update the log file
                        if (Globals.LogEventsOn == true)
                            OutToLog("  Polling: Finished sending a packet but no-one there?");
                    }
                    else
                    {
                        // I'm not the co-ordinator, so just send a finished signal back
                        Globals.TransmitterState thing = node.GetTransmitState();
                        Boolean xy = IsTransmitterBusy();
                        SendFinishedResponseToCoordinator();
                    }
                    break;
                case CallbackTypes.cbTotalPollTimeOver:
                    // Check I'm in the right state:
                    if (state != PollingState.waitingForMinimumTotalPollTime)
                        printfToMessageBox("Polling receives a poll time over callback, but not waiting for one.");

                    // Total poll time over, so it's time to send the next random
                    // access poll (if I had to wait for this, that is...)
                    double timeSinceStartOfPollCycle = GetMyTime() - whenRandomAccessStarted;
                    if (timeSinceStartOfPollCycle > this.minTotalPollTime - oneJiffy)
                    {
                        StartPollingSequence();
                    }
                    break;
                case CallbackTypes.cbMaxReplyPeriodOver:
                    // Check I'm in the right state:
                    if (state != PollingState.waitingForPollReply)
                        printfToMessageBox("Polling receives a max reply period callback, but not waiting for a poll reply.");

                    // Give up waiting for a reply, move on to the next node:
                    double timeSincePollSent = GetMyTime() - whenPollLastSent;
                    if (timeSincePollSent > this.maxReplyTime - oneJiffy)
                    {
                        DoPollReplyStuff();
                    }
                    break;
                case CallbackTypes.cbSendAccessRequestNow:
                    // Check I'm in the right state:
                    if (state != PollingState.waitingForRandomAccessDelay)
                        printfToMessageBox("Polling ready to send access request, but not in waiting to send state.");

                    // Random wait over, send the hello packet to the co-ordinator:
                    SendHelloIAmHerePacket();
                    break;
                case CallbackTypes.cbRegistrationTimesOut:
                    // If no poll received for long enough, deregister.
                    if (GetMyTime() - whenLastPollArrived > registrationTimeout - oneJiffy)
                        amIRegistered = false;
                    break;
                default:
                    break;
            }
        }

        void Initialise(double A, double B, double C, double D, double E, double F, double G)
        {
            this.state = PollingState.initialise;

            // Set my number:
            this.myNumber = GetMyNumber();

            // Set up the private variables from the sliders on the GUI:
            this.maxReplyTime = A;
            this.minTotalPollTime = B;
            this.randomAccessPeriod = C;
            this.packetsPerPoll = (int)D;
            this.registrationTimeout = E;

            // If this is the co-ordinator, I need to set up the list of nodes,
            // queue a "is there anyone there" packet, and then set the callback
            // timer for the end of the random access period:
            if (this.myNumber == Globals.CentreNode)
            {
                amICoordinator = true;
                theCoordinator = this.myNumber;
                OtherNodes.Clear();
                StartPollingSequence();

                // Also do some sense checking:
                if (this.registrationTimeout < this.minTotalPollTime)
                    printfToMessageBox("Registration timeout is less than total poll time.\n"
                        + "This is odd - are you sure?");
                if (this.randomAccessPeriod >= this.minTotalPollTime)
                    printfToMessageBox("Total poll time isn't longer than random access period.\n"
                        + "This is odd - are you sure?");
                if (this.maxReplyTime >= this.minTotalPollTime)
                    printfToMessageBox("Total poll time isn't longer than maximum reply time.\n"
                        + "This is odd - are you sure?");
                if (this.packetsPerPoll == 0)
                    printfToMessageBox("Cannot send any packets when poll received.\n"
                        + "This is odd - are you sure?");
            }
        }

        void Shutdown()
        {
            if (state == PollingState.initialise) return; // Stops warning that state not used
        }
    }
}
