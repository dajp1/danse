        [Serializable]
        struct MACHeader
        {
            // Just contains the destination (next-hop) 
            // and source (current node) addresses:
            internal byte destinationNode;
            internal byte sourceNode;
        }

        void PacketArrivesFromPhysicalLayer(cPacket packet, double rxPower)
        {
            // Get the header from the packet:
            MACHeader* header = (MACHeader*)RemoveHeader(packet);
            // Find out where it came from:
            int sourceNode = header->sourceNode;
            // Pass straight up to the logical-link layer:
            SendPacketToLogicalLinkLayer(packet, sourceNode);
        }

        void PacketArrivesFromLogicalLinkLayer(cPacket packet, int nextHop)
        {
            // Generate a MAC-layer header for this packet:
            MACHeader newHeader;
            newHeader.destinationNode = (byte)nextHop;
            newHeader.sourceNode = (byte)GetMyNumber();
            // Add this header to the packet:
            AddHeader(packet, (byte*)&newHeader, sizeof(MACHeader));
            // Send packet down to the physical layer:
            SendPacketToPhysicalLayer(packet);
            packetsSentSoFar++;
        }

        void Callback(int A, cPacket packet)
        {
            // No callbacks used.
        }

        void Initialise(double A, double B, double C, double D, double E, double F, double G)
        {
            // Nothing to do.
        }

        void Shutdown()
        {
            // No dynamically assigned memory to free up.
        }

        int packetsSentSoFar = 0;  // Keep a count of packets sent
        override internal string AskQuery(string s)
        {
            return "MAC layer of node " + GetMyNumber().ToString() + " has sent " + packetsSentSoFar + " packets.";
        }