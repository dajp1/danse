﻿using System;
namespace DANSE_v4
{
    unsafe partial class cUserMAC : cMAC
    {
        /////////////////////////////////////////////
        // Do not modify anything above this line. //
        /////////////////////////////////////////////
        //
        // This file can be used to enter code for a 
        // user-defined transport layer.  Dummy versions
        // for the required functions are provided:

        [Serializable]
        struct MACHeader
        {
            // Just contains the destination (next-hop) 
            // and source (current node) addresses:
            internal byte destinationNode;
            internal byte sourceNode;
        }

        [Serializable]
        struct RTSCTS
        {
            //This is a RTS or CTS frame
            internal byte RTSorCTS;
            internal byte address;
            internal const int RTSCTSSIZE = 2;
        }
        const int RTS = 200;
        const int CTS = 201;

        Boolean RTSReceived = false;
        Boolean CTSReceived = false;

        const double SLEEPTIME = 0.5;
        const double MAXWAKETIME = 1.5;
        const double RTSTIME = 0.1;
        const double PCKTIME = 0.9;

        int packetsSentSoFar = 0;

        void PacketArrivesFromPhysicalLayer(cPacket packet, double rxPower)
        {
            int length = GetPacketSize(packet);
            if (length == RTSCTS.RTSCTSSIZE)// if packet is 2 bytes long, packet is a RTS packet
            {
                byte* Contents = GetPacketContents(packet);
                int firstByte = Contents[0];
                int secondByte = Contents[1];

                // Check if packet is for me and if it is an RTS packet
                if (firstByte == RTS && secondByte == GetMyNumber())
                {
                    RTSReceived = true;

                    RTSCTS newPacket;
                    newPacket.RTSorCTS = CTS;
                    //Set address field in the CTS:
                    newPacket.address = (byte)GetMyNumber();

                    cPacket newCTS = MakePacket((byte*)&newPacket, 2);

                    //Add tag to make debugging using the PHY output easier:
                    SetPacketTag(newCTS, "CTS");

                    SendPacketToPhysicalLayer(newCTS);
                    //RequestRelativeCallback(MAXWAKETIME + PCKTIME, 3);
                    // RequestRelativeCallback(PCKTIME, 3);
                }
                if (firstByte == CTS)
                {
                    CTSReceived = true;
                }
            }
            else // if greater than 2 bytes long, packet is data packet
            {
                // Get the header from the packet:
                MACHeader* header = (MACHeader*)RemoveHeader(packet);
                // Find out where it came from:
                int sourceNode = header->sourceNode;
                // Pass straight up to the logical-link layer:
                SendPacketToLogicalLinkLayer(packet, sourceNode);
                GoToSleep();
            }
        }

        void PacketArrivesFromLogicalLinkLayer(cPacket packet, int nextHop)
        {
            // Generate a MAC-layer header for this packet:
            MACHeader newHeader;
            newHeader.destinationNode = (byte)nextHop;
            newHeader.sourceNode = (byte)GetMyNumber();
            // Add this header to the packet:
            AddHeader(packet, (byte*)&newHeader, sizeof(MACHeader));
            // Send packet down to the physical layer:
            PutPacketInQueue(packet);
            // SendPacketToPhysicalLayer(packet);
            packetsSentSoFar++;
        }

        void Callback(int A, cPacket packet)
        {
            // Set up switch statement for the callback types:
            switch (A)
            {
                case 0: // This is a go-to-sleep
                    RequestRelativeCallback(SLEEPTIME, 1);
                    GoToSleep();
                    break;
                case 1: // This is a wake-up
                    RequestRelativeCallback(MAXWAKETIME, 0);
                    WakeUp();
                    RTSReceived = false;
                    CTSReceived = false;
                    if (GetQueueLength() > 0)
                    {
                        double time = rand() / (double)RAND_MAX * 0.1;
                        printf("At time %f, new time generated at node %d of %f", GetMyTime(), GetMyNumber(), time);
                        RequestRelativeCallback(time, 2);
                    }
                    break;
                case 2: // This is a random wait before transmitting RTS packet
                    if (IsChannelQuiet() == true)
                    {
                        RTSCTS newPacket;
                        newPacket.RTSorCTS = RTS;

                        // Find where packet is going
                        if (GetQueueLength() > 0)
                        {
                            cPacket nextOne = GetPacketInQueue(0);
                            MACHeader* packetHeader = (MACHeader*)ViewHeader(nextOne);
                            int destNode = packetHeader->destinationNode;
                            newPacket.address = (byte)destNode;

                            cPacket newRTS = MakePacket((byte*)&newPacket, 2);
                            SetPacketTag(newRTS, "RTS");
                            SendPacketToPhysicalLayer(newRTS);
                            RequestRelativeCallback(RTSTIME, 3);
                        }
                    }
                    break;
                case 3: //happens when RTS has been sent
                    {
                        //if node has no packets to send
                        if (CTSReceived == true)
                        {
                            if (GetQueueLength() > 0)
                            {
                                cPacket toBeSent = GetPacketInQueue(0);
                                RemovePacketFromQueue(0);
                                SendPacketToPhysicalLayer(toBeSent);
                            }
                        }
                        else
                            GoToSleep();
                    }
                    break;
            }
        }

        void Initialise(double A, double B, double C, double D, double E, double F, double G)
        {
            // Set callback request to wake up after one second:
            RequestRelativeCallback(100, 0);
        }

        void Shutdown()
        {
            // No dynamically assigned memory to free up.
        }

        override internal string AskQuery(string s)
        {
            return "MAC layer of node " + GetMyNumber().ToString() + " has sent " + packetsSentSoFar + " packets.";
        }

        /////////////////////////////////////////////
        // Do not modify anything below this line. //
        /////////////////////////////////////////////
    }
}
