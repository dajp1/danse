﻿using System.Windows;
namespace DANSE_v4
{
    public partial class MainWindow : Window
    {
        private void MACSetupUserControls()
        {
            Globals.stsMACInitialBackoff.Enable(false);
            Globals.stsMACInitialBackoff.NameOnSetup.Content = "Not Used";
            Globals.stsMACParameterOne.Enable(true);
            Globals.stsMACParameterTwo.Enable(true);
            Globals.stsMACParameterThree.Enable(true);
            Globals.stsMACParameterFour.Enable(true);
            Globals.stsMACParameterFive.Enable(true);
            Globals.stsMACParameterSix.Enable(true);
            Globals.stsMACParameterSeven.Enable(true);
            Globals.stsMACParameterOne.NameOnSetup.Content = "Parameter A";
            Globals.stsMACParameterTwo.NameOnSetup.Content = "Parameter B";
            Globals.stsMACParameterThree.NameOnSetup.Content = "Parameter C";
            Globals.stsMACParameterFour.NameOnSetup.Content = "Parameter D";
            Globals.stsMACParameterFive.NameOnSetup.Content = "Parameter E";
            Globals.stsMACParameterSix.NameOnSetup.Content = "Parameter F";
            Globals.stsMACParameterSeven.NameOnSetup.Content = "Parameter G";
        }
    }

    unsafe partial class cUserMAC : cMAC
    {
        ////////////////////////////////////
        // User MAC routine wrapper.
        //

        internal cUserMAC(cNode Here, ref cNode.MACDelegates Delegates)
            : base(Here)
        {
            Delegates.CallWhenCallback = new cNode.MACCallbackDelegate(this.Callback);
            Delegates.CallWhenInitialise = new cNode.MACInitialiseDelegate(this.Initialise);
            Delegates.CallWhenPacketArrivesFromLogicalLinkLayer = new cNode.MACPacketFromAboveDelegate(this.PacketArrivesFromLogicalLinkLayer);
            Delegates.CallWhenPacketArrivesFromPhysicalLayer = new cNode.MACPacketFromBelowDelegate(this.PacketArrivesFromPhysicalLayer);
            Delegates.CallWhenShutdown = new cNode.MACShutdownDelegate(this.Shutdown);
        }
    }
}
