﻿using System;
using System.Runtime.InteropServices;
using System.Windows;
namespace DANSE_v4
{
    public partial class MainWindow : Window
    {
        private void MACSetupCSMAControls()
        {
            Globals.stsMACInitialBackoff.NameOnSetup.Content = "Init Max Wait";
            Globals.stsMACInitialBackoff.SetNewRange(0.01, 10.0, 1.0, GUIBits.SliderType.log);
            Globals.stsMACInitialBackoff.Enable(true);

            Globals.stsMACParameterOne.NameOnSetup.Content = "Persistent";
            Globals.stsMACParameterOne.SetNewRange(0.0, 1.0, 0.0, GUIBits.SliderType.checkbox);
            Globals.stsMACParameterOne.Enable(true);

            Globals.stsMACParameterTwo.NameOnSetup.Content = "Initial p";
            Globals.stsMACParameterTwo.SetNewRange(0.0, 1.0, 1.0, GUIBits.SliderType.linear);
            Globals.stsMACParameterTwo.Enable(true);

            Globals.stsMACParameterThree.NameOnSetup.Content = "Backoff Modify";
            Globals.stsMACParameterThree.SetNewRange(1.0, 2.0, 1.0, GUIBits.SliderType.linear);
            Globals.stsMACParameterThree.Enable(true);

            Globals.stsMACParameterFour.NameOnSetup.Content = "Slot Time";
            Globals.stsMACParameterFour.SetNewRange(0.001, 1.0, 0.01, GUIBits.SliderType.log);
            Globals.stsMACParameterFour.Enable(true);

            Globals.stsMACParameterFive.NameOnSetup.Content = "Max Attempts";
            Globals.stsMACParameterFive.SetNewRange(1, 20, 10, GUIBits.SliderType.integer);
            Globals.stsMACParameterFive.Enable(true);

            Globals.stsMACParameterSix.NameOnSetup.Content = "Interframe Gap";
            Globals.stsMACParameterSix.SetNewRange(0.00099, 1.0, 0.01, GUIBits.SliderType.logwithzero);
            Globals.stsMACParameterSix.Enable(true);

            MACSetupCSMAControlsEnable();
        }
        internal void MACSetupCSMAControlsEnable()
        {
            // This is a hack to allow changes in the persistence parameter to 
            // enable/disable the relevant other controls for the CSMA MAC.  It has
            // to be explicly called by the checkbox handler in the GUIStuff file.
            // It's a really horrible hack, but I haven't thought of a better way
            // to do it.
            if ((string)Globals.stsMACParameterOne.theCheckBox.Content == " Enabled")
            {
                Globals.stsMACInitialBackoff.Enable(false);
                Globals.stsMACParameterFour.Enable(true);
                Globals.stsMACParameterTwo.Enable(true);
            }
            else
            {
                Globals.stsMACInitialBackoff.Enable(true);
                Globals.stsMACParameterFour.Enable(false);
                Globals.stsMACParameterTwo.Enable(false);
            }
        }
    }

    class cCSMA : cMAC
    {
        ////////////////////////////////////////////////////////////////////
        // This is a flexible CSMA (Carrier Sense Multiple Access) MAC layer
        //
        // It can do exponential backoff, p-persistant and non-persistent
        // CSMA.

        internal cCSMA(cNode Here, ref cNode.MACDelegates Delegates)
            : base(Here)
        {
            Delegates.CallWhenCallback = new cNode.MACCallbackDelegate(this.Callback);
            Delegates.CallWhenInitialise = new cNode.MACInitialiseDelegate(this.Initialise);
            Delegates.CallWhenPacketArrivesFromLogicalLinkLayer = new cNode.MACPacketFromAboveDelegate(this.PacketArrivesFromLogicalLinkLayer);
            Delegates.CallWhenPacketArrivesFromPhysicalLayer = new cNode.MACPacketFromBelowDelegate(this.PacketArrivesFromPhysicalLayer);
            Delegates.CallWhenShutdown = new cNode.MACShutdownDelegate(this.Shutdown);
        }

        // Default headers for the internal MAC protocols:
        [Serializable] class MultipleAccessHeader
        {
            internal byte transmitter;
            internal byte receiver;

            internal MultipleAccessHeader(int transmitter, int receiver)
            {
                this.transmitter = (byte)(transmitter);
                this.receiver = (byte)(receiver);
            }
            internal int GetSize() { return 2; }
        }

        // The algorithm used when a packet arrives from the layer above:
        // 
        // First, for persistent CSMA:
        //   If packet store is not empty, just add the packet to the queue.
        //   Else, if the channel is not clear, wait until it is clear.
        //   Else, if a random number is less than p, transmit the frame.
        //   Else, set attempts = 1 and wait for a slot time.
        //
        // Then for non-persistent CSMA:
        //   If packet store is not empty, just add the packet to the queue.
        //   Else, if the channel is not clear, set attempts = 1 and wait for a random time.
        //   Else transmit the frame.
        // 
        // The callback routine then.  First, check the channel.
        //   Then, for persistent CSMA:
        //     If channel is not clear, wait until it is clear.
        //     Else if channel random number is less than p, transmit the frame.
        //     Else transmit the frame.
        //   Or for non-persistent CSMA:
        //     If channel is not clear, wait another random time.
        //     Else transmit the frame.
        //
        // On transmitting a frame:
        //   Set p and maxBackoffTime back to their default values.
        //   If there is another frame to send, request a callback for
        //     when the transmitter becomes free for a minimumIFS.
        //
        // On waiting for the next time:
        //   If persistent CSMA, increase number of attempts and wait for
        //     a slot time.
        //   If non-persistent CSMA, increase number of attempts and wait
        //     for a random time.
        
        // I need to keep a note of a few private variables:
        double currentMaximumBackoff = 0.0;
        double initialMaximumBackoff = 0.0;
        double minimumInterframeSpace = 0.0;
        Boolean persistent = false;
        double slotTime = 0.0;
        double initialp = 1;
        double currentp = 1;
        double backoffFactor = 0;
        int maxAttempts = 4;
        int currentAttempts = 0;

        void PacketArrivesFromLogicalLinkLayer(cPacket packet, int nextHop)
        {
            // First thing is to add the header so the frame knows where it's going,
            // and then just add it to the queue:
            MultipleAccessHeader newHeader
                = new MultipleAccessHeader(node.GetNumber(), nextHop);
            packet.AddHeader((Object)newHeader, newHeader.GetSize());
            PutPacketInQueue(packet);
            int myNumber = GetMyNumber();

            if (PacketStore.Count > 1)
            {
                // Update the log file
                if (Globals.LogEventsOn == true)
                    OutToLog("  Multiple Access: Packet added to queue for later transmission");
                return;
            }

            if (this.persistent == true) AttemptPersistentSend();
            else if (this.persistent == false) AttemptNonPersistentSend();
        }

        private void AttemptNonPersistentSend()
        {
            //  If non-persistent, then if the channel is not clear, 
            //    increment the number of attempts, and if another attempt
            //    is possible, wait for a random time.
            //  If the channel is clear, just transmit the frame.

            if (node.GetTransmitState() == Globals.TransmitterState.Transmitting)
            {
                RequestCallbackWhenTransmitterIdle((int)CallbackTypes.cbTransmitterNowAvailable);
                // Update the log file
                if (Globals.LogEventsOn == true)
                    OutToLog("  Multiple Access: Transmitter busy, waiting until it's free");
                return;
            }

            Boolean goAgain = CanITryAgain();
            if (node.GetReceiveState() != Globals.ReceiverState.Listening)
            {
                if (goAgain == true)
                {
                    double x = Globals.rands.NextDouble() * this.currentMaximumBackoff;
                    RequestRelativeCallback(x, (int)CallbackTypes.cbNonPersistentWaitingForBackoff);
                    // Update the log file
                    if (Globals.LogEventsOn == true)
                        OutToLog("  Multiple Access: Channel not clear, waiting for " + x.ToString("0.00")
                            + " seconds before trying again: " + (this.maxAttempts - this.currentAttempts) + " attempts left");
                }
                else if (goAgain == false)
                {
                    GiveUp();
                    // Update the log file
                    if (Globals.LogEventsOn == true)
                        OutToLog("  Multiple Access: Channel not clear, and no more attempts left.  Giving up.");
                }
            }
            else
            {
                // No need to wait, I can go now:
                if (Globals.LogEventsOn == true)
                    OutToLog("  Multiple Access: Channel clear for attempt " + this.currentAttempts + " so sending immediately");
                SendCurrentPacket();
            }
        }

        private void AttemptPersistentSend()
        {
            // For persistent CSMA:
            //   If the channel is not clear, count this as an attempt,
            //     and wait until it is clear.
            //   Else, if a random number is less than p, transmit the frame.
            //   Else, wait for a slot time.

            if (node.GetTransmitState() == Globals.TransmitterState.Transmitting)
            {
                RequestCallbackWhenTransmitterIdle((int)CallbackTypes.cbTransmitterNowAvailable);
                // Update the log file
                if (Globals.LogEventsOn == true)
                    OutToLog("  Multiple Access: Transmitter busy, waiting until it's free");
                return;
            }

            if (node.GetReceiveState() != Globals.ReceiverState.Listening)
            {
                if (CanITryAgain() == true)
                {
                    RequestCallbackWhenChannelClear(0);
                    // Update the log file
                    if (Globals.LogEventsOn == true)
                        OutToLog("  Multiple Access: Waiting for channel to be clear, " 
                            + (this.maxAttempts - this.currentAttempts) + " attempts left");
                }
                else
                {
                    GiveUp();
                    // Update the log file
                    if (Globals.LogEventsOn == true)
                        OutToLog("  Multiple Access: Channel not clear, and no more attempts left.  Giving up.");
                }
            }
            else
            {
                double x = Globals.rands.NextDouble();
                if (x < this.currentp)
                {
                    // No need to wait, I can go now:
                    SendCurrentPacket();
                    // Update the log file
                    if (Globals.LogEventsOn == true)
                        OutToLog("  Multiple Access: Channel clear and rand = " + x.ToString("0.00")
                            + " < " + this.currentp.ToString("0.00") + ", so sending immediately");
                }
                else
                {
                    // I have to wait for a slot:
                    RequestRelativeCallback(this.slotTime, (int)CallbackTypes.cbPersistentWaitingForSlotTime);
                    // Update the log file
                    if (Globals.LogEventsOn == true)
                        OutToLog("  Multiple Access: Channel clear and rand = " + x.ToString("0.00")
                           + " < " + this.currentp.ToString("0.00") + ", so sending immediately");
                }
            }
        }

        enum CallbackTypes
        {
            cbPersistentWaitingForClearChannel = 0,
            cbPersistentWaitingForSlotTime = 1,
            cbNonPersistentWaitingForBackoff = 2,
            cbIFSGapOver = 3,
            cbTransmitterNowAvailable = 4
        }
        void Callback(int A, cPacket packet = null)
        {
            // First, just check that there is a packet waiting to be sent.
            if (PacketStore.Count == 0) return;

            // If waiting for transmitter to be idle, might now have to 
            // wait again for a minimum interframe gap before I can start
            // to attempt another transmit:
            if (A == (int)CallbackTypes.cbTransmitterNowAvailable)
            {
                if (this.minimumInterframeSpace > 0)
                {
                    RequestRelativeCallback(this.minimumInterframeSpace, (int)CallbackTypes.cbIFSGapOver);
                    // Update the log file
                    if (Globals.LogEventsOn == true)
                        OutToLog("  Multiple Access: Transmitter now free, waiting for " 
                            + this.minimumInterframeSpace.ToString("0.00") + " before transmission");
                    return;
                }
            }

            // If persistent, try again:
            if (this.persistent == true) AttemptPersistentSend();

            // If non-persistent, try again:
            if (this.persistent == false) AttemptNonPersistentSend();
        }

        private Boolean CanITryAgain()
        {
            this.currentAttempts++;

            // For each attempt, the value of p or maximum backoff might
            // change (this is exponential backoff).  However this 
            // doesn't happen the first time, so the actual set numbers
            // get used for the first attempt.
            if (this.currentAttempts > 1)
            {
                this.currentp /= this.backoffFactor;
                this.currentMaximumBackoff *= this.backoffFactor;
            }

            if (currentAttempts >= this.maxAttempts) return false;
            else return true;
        }
        private void SendCurrentPacket()
        {
            if (PacketStore.Count == 0) return;
            // Take the first packet out of the queue and send it:
            cPacket packetToGo = PacketStore[0].GetPacket();
            PacketStore.RemoveAt(0);

            SendPacketToPhysicalLayer(packetToGo);
            // Update the log file:
            if (Globals.LogEventsOn == true)
                OutToLog("  Multiple Access: Packet sent to physical layer to transmit");

            double timeToSendPacket = packetToGo.GetPacketSize() * 8 / Globals.DefaultBitRate;
            TidyUpReadyForNext(true, timeToSendPacket);
        }
        private void GiveUp()
        {
            if (PacketStore.Count > 0) PacketStore.RemoveAt(0);
            TidyUpReadyForNext(false, 0.0);
        }
        private void TidyUpReadyForNext(Boolean wasPacketSent, double timeToWait)
        {
            // Finished with the current packet.  Tidy up.
            // Set backoff time, attempts and p back to default values:
            this.currentp = this.initialp;
            this.currentMaximumBackoff = this.initialMaximumBackoff;
            this.currentAttempts = 0;

            // If there is another packet waiting to be sent, then put in a callback request
            // for when the interframe gap is over plus the time required to transmit this packet:
            if (PacketStore.Count > 0)
            {
                RequestRelativeCallback(timeToWait + this.minimumInterframeSpace, (int)CallbackTypes.cbIFSGapOver);
            }
        }

        void PacketArrivesFromPhysicalLayer(cPacket packet, double RxPower)
        {
            // Some idiot checking:
            if (!(packet.ViewHeader() is MultipleAccessHeader))
            {
                Globals.ShowMessageBox("Packet arrived at multiple access layer\n"
                    + "without a suitable header. \n"
                    + "Packet will be deleted.", "User Protocol Error?");
                return;
            }

            // Take the header off:
            MultipleAccessHeader thisHeader = (MultipleAccessHeader)packet.RemoveHeader();
            // If the frame is for me or broadcast, pass up to the logical-link layer,
            // otherwise, just ignore it.
            if (thisHeader.receiver == node.GetNumber() || thisHeader.receiver == BROADCAST)
            {
                // Pass straight up to the logical-link layer:
                Globals.theQueue.AddEvent(new cEvent(node, packet, node.GetTime(),
                    EventType.LogicalLink_PacketArrivesFromMACLayer,
                    thisHeader.transmitter));
                // Update the log file
                if (Globals.LogEventsOn == true)
                    OutToLog("  Multiple Access: Packet received from physical layer, going to node " 
                        + packet.MetaInformation().GetFinalDestination().ToString() 
                        + " pass up to logical link layer");
            }
        }

        void Initialise(double A, double B, double C, double D, double E, double F, double G)
        {
            // Warn user...
            //if (GetMyNumber() == 0)
            //{
            //    printfToMessageBox("Warning: CSMA is being re-written, and is currently work in progress.", "Warning");
            //    this.persistent = (A == 0) ? false : true;
            //}

            // Set private variables to initial values:
            this.initialMaximumBackoff = Globals.MACInitialBackoff;
            this.persistent = (A == 0) ? false : true;
            this.initialp = B;
            this.backoffFactor = C;
            this.slotTime = D;
            this.maxAttempts = (int)E;
            this.minimumInterframeSpace = F;

            this.currentMaximumBackoff = this.initialMaximumBackoff;
            this.currentp = this.initialp;
        }

        void Shutdown() { }
    }
}
