﻿using System;
using System.Runtime.InteropServices;
using System.Windows;
namespace DANSE_v4
{
    public partial class MainWindow : Window
    {
        private void NetworkSetupBellmanFordControls()
        {
            Globals.stsNetworkHopCount.Enable(true);

            Globals.stsNetworkParameterOne.NameOnSetup.Content = "Mean Interval";
            Globals.stsNetworkParameterOne.SetNewRange(1, 1000, 50, GUIBits.SliderType.log);
            Globals.stsNetworkParameterOne.Enable(true);

            Globals.stsNetworkParameterTwo.NameOnSetup.Content = "Stop After";
            Globals.stsNetworkParameterTwo.SetNewRange(1, 1e6, 1e3, GUIBits.SliderType.loginteger);
            Globals.stsNetworkParameterTwo.Enable(true);
        }
    }

    unsafe class cSimpleBellmanFordRouteing : cNetwork
    {
        ////////////////////////////////////////////////////////////////
        // This is a simple generic Bellman-Ford algorithm.
        // Parameters are time to live, how long (in seconds) between 
        // routeing updates, and when (again seconds) to stop sending 
        // updates.  (It is assumed the network is static, and once the 
        // routes are established, they won't change.)
        //
        // The cost of a link is related to the received power.  Costs
        // are always single bytes (to lower the size of update packets)
        // Currently, cost = 1 / rxPower / 100000, which seems to 
        // give sensible costs within the 0 - 255 limits while still
        // ensureing good routes for the default propagation model.
        /////////////////////////////////////////////////////////////////

        double MeanUpdateTime;
        double StopRouteingNow;

        internal cSimpleBellmanFordRouteing(cNode Here, ref cNode.NetworkDelegates Delegates)
            : base(Here)
        {
            Delegates.CallWhenCallback = new cNode.NetworkCallbackDelegate(this.Callback);
            Delegates.CallWhenInitialise = new cNode.NetworkInitialiseDelegate(this.Initialise);
            Delegates.CallWhenPacketArrivesFromLogicalLinkLayer = new cNode.NetworkPacketFromBelowDelegate(this.PacketArrivesFromLogicalLinkLayer);
            Delegates.CallWhenPacketArrivesFromTransportLayer = new cNode.NetworkPacketFromAboveDelegate(this.PacketArrivesFromTransportLayer);
            Delegates.CallWhenShutdown = new cNode.NetworkShutdownDelegate(this.Shutdown);
        }

        [Serializable] private struct NetworkHeader
        {
            internal byte SourceNode;
            internal byte DestinationNode;
            internal byte TimeToLive;
            internal Boolean RouteingInfo;

            internal NetworkHeader (int source, int destination, int ttl, Boolean routeingFlag)
            {
                this.SourceNode = (byte)source;
                this.DestinationNode = (byte)destination;
                this.TimeToLive = (byte)ttl;
                this.RouteingInfo = routeingFlag;
            }
            internal NetworkHeader(int source, int destination, Boolean routeingFlag)
            {
                this.SourceNode = (byte)source;
                this.DestinationNode = (byte)destination;
                this.TimeToLive = (byte)Globals.HopCount;
                this.RouteingInfo = routeingFlag;
            }
        }

        void PacketArrivesFromLogicalLinkLayer(cPacket packet, int ReceivedFrom)
        {
            // Some idiot checking:
            if (!(packet.ViewHeader() is NetworkHeader))
            {
                Globals.ShowMessageBox("Packet arrived at Bellman-Ford network layer\n"
                    + "without a Bellman-Ford header. \n"
                    + "Packet will be deleted.", "User Protocol Error?");
                return;
            }

            NetworkHeader header = (NetworkHeader)packet.RemoveHeader();
            if (header.RouteingInfo == false)                  // If packet is data
            {
                if (header.DestinationNode == GetMyNumber())   // If packet addressed to me,
                {
                    SendPacketToTransportLayer(packet,      // and sent to the transport
                        header.SourceNode);                // layer.
                }
                else
                {
                    // For someone else, so pass on.  If no route is known,
                    // attempt to send direct to the final destination:
                    int nextHop = LookupNextHop(header.DestinationNode);
                    header.TimeToLive--;
                    if (header.TimeToLive > 0)
                    {
                        packet.AddHeader((Object)header, sizeof(NetworkHeader));  // Add to packet
                        if (nextHop == NOWHERE) nextHop = header.DestinationNode;
                        SendPacketToLogicalLinkLayer(packet, nextHop);   //  final destination.
                        printfToLog("Packet being forwarded to node: %d", nextHop);
                    }
                }
            }
            else if (header.RouteingInfo == true)       // Packet is routeing information
            {
                int Source = header.SourceNode;
                ProcessRouteingPacket(packet, Source);   // and process the table.
            }
        }

        void ProcessRouteingPacket(cPacket packet, int Source)
        {
            int SizeOfContents = GetPacketSize(packet);
            byte* Table = GetPacketContents(packet);

            // The hop cost is currently worked out based on channel loss:
            double rxPower = GetRxPower(packet);
            double txPower = Math.Pow(10,(Globals.DefaultTxPowerdBm - 30.0)/10.0);
            double hopCost = Math.Round(DefaultCost(rxPower, txPower));

            printfToLog("Receiving routeing table size %d from node %d", SizeOfContents, Source);

            // Now go through the table, and process the inputs:
            for (int loop = 0; loop < SizeOfContents; loop += 2)
            {
                byte thisDestination = Table[loop];
                byte thisCost = Table[loop + 1];
                printfToLog("Routeing table entry to %d cost: %e", thisDestination, thisCost);

                // Add the cost to get to the node.  This is currently
                // worked out based on the receive power.
                if (hopCost < 1) hopCost = 1;       // Set minimum hop cost to one;

                double totalCost = thisCost + hopCost;
                if (totalCost > 255) totalCost = 255; // Maximum cost is 255

                // Look up current cost to this destination:
                double CurrentCost = LookupCost(thisDestination);

                // If the destination is not known, or th current cost is 
                // less than the existing cost, add it into the 
                // table with the new cost:
                if (CurrentCost == INFINITY || CurrentCost > totalCost)
                {
                    AddRouteingTableEntry(thisDestination, Source, totalCost);
                }
            }

            printfToLog(PrintRouteingTable());
        }

        void PacketArrivesFromTransportLayer(cPacket packet, int Destination)
        {
            int myNumber = GetMyNumber();
            if (Destination == myNumber)                // If packet is addressed to me,
            {
                SendPacketToTransportLayer(packet, myNumber);  // send it back up to the transport layer.
            }
            else                                        // otherwise it must be addressed to 
            {                                           //   someone else, so:
                NetworkHeader newhead = new NetworkHeader();
                newhead.DestinationNode = (byte)Destination;
                newhead.SourceNode = (byte)myNumber;         // Set source
                newhead.RouteingInfo = false;                // This is a data packet
                newhead.TimeToLive = (byte)Globals.HopCount;
                packet.AddHeader((Object)newhead, sizeof(NetworkHeader));  // Add to packet

                // Look up next hop in the routeing table.  If there is nothing
                // there, then try sending direct to the destination:
                int NextHop = LookupNextHop(Destination);
                if (NextHop == Globals.NOWHERE) NextHop = Destination;
                SendPacketToLogicalLinkLayer(packet, NextHop);  // Send the packet to the logical-link layer
            }
        }

        void Callback(int A, cPacket packet = null)
        {
            // Things to do when a callback occurs.
            // First, if the routeing tables are still being built up, request
            // another call back sometime in the future...
            double sendNextTableAfter = Globals.rands.NextDouble() * MeanUpdateTime * 2;
            if (node.GetTime() + sendNextTableAfter * 1e9 < StopRouteingNow * 1e9)
                RequestRelativeCallback(sendNextTableAfter, 0);

            // Next, I need to build up the contents of a routeing packet.
            // This packet will contain the number and cost of getting
            // from here to everywhere I currently know about:
            SimpleBellmanFordBroadcastRouteingPacket();
        }

        void SimpleBellmanFordBroadcastRouteingPacket()
        {
            // Reserve a block of memory to build the packet in:
            int sizeOfRouteingTable = GetNumberOfRoutes();
            byte* Content = (byte*)malloc(sizeOfRouteingTable * 2);

            // Then fill up the memory with the routeing table:
            int loop;
            int pointer = 0;
            for (loop = 0; loop < sizeOfRouteingTable; loop++)
            {
                Content[pointer++] = (byte)GetDestinationByIndex(loop);

                // For cost, I'm only sending a byte, but cost is stored
                // as a double, so I need to convert:
                double ThisCost = GetCostByIndex(loop);
                if (ThisCost > 255) ThisCost = 255;
                Content[pointer++] = (byte)ThisCost;
            }

            // Then generate the content for the packet, after which I can 
            // free up the memory required for building it...
            cPacket RouteingPacket = MakePacket(Content, sizeOfRouteingTable * 2);

            // Make and add a header:
            NetworkHeader NewHeader = new NetworkHeader();
            NewHeader.DestinationNode = (byte)BROADCAST;
            NewHeader.SourceNode = (byte)GetMyNumber();
            NewHeader.RouteingInfo = true;
            NewHeader.TimeToLive = 1;
            RouteingPacket.AddHeader((Object)NewHeader, sizeof(NetworkHeader));

            // Set a tag for displaying the packet:
            RouteingPacket.MetaInformation().SetTag("Routeing Info");

            // And send the packet:
            SendPacketToLogicalLinkLayer(RouteingPacket, BROADCAST);

            // Now free up the memory reserved for this packet:
            free(Content);
        }

        void Shutdown() { }

        void Initialise(double A, double B, double C, double D, double E, double F, double G)
        {
            // Things to do at the start of the simulation, 
            // before any packets have been sent: set up the 
            // routeing tables (using Bellman-Ford).

            ClearRouteingTable();   // Clear the routeing table
            MeanUpdateTime = A;     // Parameter one is mean update time
            StopRouteingNow = B;    // Parameter two is when to stop updating

            // Then I need to add myself into my own routeing table:
            int MyOwnNumber = GetMyNumber();
            AddRouteingTableEntry(MyOwnNumber, MyOwnNumber, 0);

            // To avoid collisions, wait for a random time before sending the first
            // routeing packet out:
            double TimeToWait = Globals.rands.NextDouble() * (MeanUpdateTime * 2);
            RequestRelativeCallback(TimeToWait, 0);
        }

        /////////////////////////////////////////////
        // Do not modify anything below this line. //
        /////////////////////////////////////////////
    }
}
