﻿using System.Runtime.InteropServices;
using System;
using System.Windows;
using System.Collections.Generic;
using System.Text;
namespace DANSE_v4
{
    public partial class MainWindow : Window
    {
        private void NetworkSetupOnDemandControls()
        {
            Globals.stsNetworkHopCount.Enable(true);

            Globals.stsNetworkParameterOne.NameOnSetup.Content = "Route Timeout";
            Globals.stsNetworkParameterOne.SetNewRange(1, 10000, 100, GUIBits.SliderType.log);
            Globals.stsNetworkParameterOne.Enable(true);

            Globals.stsNetworkParameterTwo.NameOnSetup.Content = "Attempts";
            Globals.stsNetworkParameterTwo.SetNewRange(1, 10, 1, GUIBits.SliderType.integer);
            Globals.stsNetworkParameterTwo.Enable(true);

            Globals.stsNetworkParameterThree.NameOnSetup.Content = "Proxy Replies";
            Globals.stsNetworkParameterThree.SetNewRange(0, 1, 0, GUIBits.SliderType.checkbox);
            Globals.stsNetworkParameterThree.Enable(true);

            Globals.stsNetworkParameterFour.NameOnSetup.Content = "Reply Spying";
            Globals.stsNetworkParameterFour.SetNewRange(0, 1, 0, GUIBits.SliderType.checkbox);
            Globals.stsNetworkParameterFour.Enable(true);

            Globals.stsNetworkParameterFive.NameOnSetup.Content = "Route to Hops";
            Globals.stsNetworkParameterFive.SetNewRange(0, 1, 0, GUIBits.SliderType.checkbox);
            Globals.stsNetworkParameterFive.Enable(true);
        }
    }

    class cOnDemandRouteing : cNetwork
    {
        // Code for a simple on-demand network layer.  It works like this:
        //
        // When a packet arrives from the transport layer:
        //   If there is an entry in the routeing table, then add a header with
        //     this route programmed into the header, and transmit to the next 
        //     hop.
        //   Else if there is no entry in the routeing table, then put the packet
        //     into the store, send out an AllRoutesExplorer frame, mark the
        //     number of AllRoutesExplorer frames sent out as one, and set a 
        //     timeout timer to MaxRouteingTime.
        //   If MaxRouteingTime times out and there is still no route in the table,
        //     then check ExplorerAttempts, and if number of AllRoutesExplorers is 
        //     less than ExplorerAttempts send another AllRoutesExplorer frame.
        //
        // When a data packet arrives from the LLC layer:
        //   If this is the final destination, receive the packet and pass up
        //     to the transport layer.
        //   Else if this node is in the route in the packet, then forward the 
        //     packet onto the next node in the specified route.
        //   Else ignore the packet.
        //
        // When an AllRoutesExplorer frame arrives:
        //    If your number is already in the frame, then delete the frame.
        //    Else if you are the destination, send a reply back along the
        //      path the explorer frame came on.
        //    Else if the number of hops in the frame is equal to MaxHops,
        //      then delete the frame.
        //    Else if you receive an AllRoutesExplorer frame and the route to 
        //      the destination is in your routeing table, then add the total 
        //      route to the packet, and reply back along the route the packet 
        //      has taken.
        //    Else if the route to the destination is not in your routeing
        //      table, then add your number to the packet, and re-broadcast the 
        //      packet.
        // 
        // When an ExplorerReply frame arrives:
        //    If the cost to the destination is cheaper that you know, then
        //      update (or add) the route to your routeing table:
        //    If you are the final destination and the route is not known, 
        //      add the route(s) to your routeing table, and send any packets
        //      in your packet store going to the new destination down to the
        //      logical-link control layer.
        //
        // All entries in routeing tables time out in RouteTimeOut, and
        // are deleted and have to be re-discovered.

        double maxRouteingTime = 10.0;
        int explorerAttempts = 1;
        int maximumHops = 10;
        int myNumber = 0;
        Boolean replySpying = false;
        Boolean proxyReplies = false;
        Boolean alsoAddHops = false;

        internal cOnDemandRouteing(cNode Here, ref cNode.NetworkDelegates Delegates)
            : base(Here)
        {
            Delegates.CallWhenCallback = new cNode.NetworkCallbackDelegate(this.Callback);
            Delegates.CallWhenInitialise = new cNode.NetworkInitialiseDelegate(this.Initialise);
            Delegates.CallWhenPacketArrivesFromLogicalLinkLayer = new cNode.NetworkPacketFromBelowDelegate(this.PacketArrivesFromLogicalLinkLayer);
            Delegates.CallWhenPacketArrivesFromTransportLayer = new cNode.NetworkPacketFromAboveDelegate(this.PacketArrivesFromTransportLayer);
            Delegates.CallWhenShutdown = new cNode.NetworkShutdownDelegate(this.Shutdown);
        }

        [Serializable] class OnDemandHeader
        {
            internal byte sourceNode;
            internal byte destinationNode;
            internal int routeCost;
            internal enum PacketType { data, explorer, reply }
            internal PacketType type;
            internal List<int> route = new List<int>();
            internal int GetSize() { return 3 + route.Count; }
        }
        class metaOnDemand
        {
            internal int destination;
            internal int explorersSent;
            internal double whenExplorerSent;
            internal enum eStatus { waiting, sent }
            internal eStatus state;
        }

        void PacketArrivesFromLogicalLinkLayer(cPacket packet, int receivedFrom)
        {
            // Some idiot checking:
            if (!(packet.ViewHeader() is OnDemandHeader))
            {
                printfToMessageBox("Packet arrived at network layer\n"
                    + "without a network header. \n"
                    + "Packet will be deleted.", "User Protocol Error?");
                return;
            }

            // Get a pointer to the NetworkHeader and cast to the structure type:
            OnDemandHeader thisHeader = (OnDemandHeader)packet.ViewHeader();

            StringBuilder fullRoute = new StringBuilder(120);
            if (Globals.LogEventsOn == true)
            {
                for (int loop = 0; loop < thisHeader.route.Count; loop++)
                    fullRoute.Append(thisHeader.route[loop].ToString() + ":");
                OutToLog("  Network: " + thisHeader.type.ToString() 
                    + " packet arrived with route " + fullRoute);
            }
            
            // Then find out what sort of packet this is:
            switch (thisHeader.type)
            {
                case OnDemandHeader.PacketType.data:
                    // If the packet is addressed to me, get the source node and send
                    // the packet up to the transport layer:
                    if (thisHeader.destinationNode == GetMyNumber())
                    {
                        int sourceNode = thisHeader.sourceNode;
                        packet.RemoveHeader();
                        SendPacketToTransportLayer(packet, sourceNode);
                    }
                    else
                    {
                        // Otherwise check if this node is in the stored route, and
                        // if so, send the packet onto the next node (if there is one)
                        // or direct to the final destination (if there isn't).
                        // If this node is not in the route, then ignore.
                        if (thisHeader.route.Contains(myNumber))
                        {
                            int index = thisHeader.route.IndexOf(myNumber);
                            if (index == thisHeader.route.Count - 1)
                            {
                                // This is the last node in the route, which is odd,
                                // since the route should end at the destination.  In
                                // this case, I'll try and send it straight to the 
                                // final destination:
                                SendPacketToLogicalLinkLayer(packet, thisHeader.destinationNode);
                                // Update the log file
                                if (Globals.LogEventsOn == true)
                                    OutToLog("  Network: Data packet arrived for " 
                                        + thisHeader.destinationNode + " but my number " 
                                        + myNumber +" not in route, so sending direct");
                            }
                            else if (index != -1)
                            {
                                // Node is in the route somewhere, I just need to get
                                // the next hop:
                                int nextHop = thisHeader.route[index + 1];
                                SendPacketToLogicalLinkLayer(packet, nextHop);
                                // Update the log file
                                if (Globals.LogEventsOn == true)
                                    OutToLog("  Network: Data packet arrived for "
                                        + thisHeader.destinationNode + " sending on to " + nextHop);
                            }
                        }
                    }
                    break;
                case OnDemandHeader.PacketType.explorer:
                    // If this node is not in the route, and the route length
                    // is less than the number of entries in the routeing table
                    // so far, then add this node to the route and re-broadcast.

                    // If my node is already in the route, then delete:
                    if (thisHeader.route.Contains(myNumber) == true) return;

                    // Add my node to the count:
                    thisHeader.route.Add(myNumber);
                    // add the cost of the last hop:
                    double rxPower = GetRxPower(packet);
                    double txPower = Math.Pow(10, (Globals.DefaultTxPowerdBm - 30.0) / 10.0);
                    double hopCost = DefaultCost(rxPower, txPower);
                    thisHeader.routeCost += (int)hopCost;
                    // update the tag:
                    string x = packet.MetaInformation().GetTag();
                    x += ":" + myNumber.ToString();
                    packet.MetaInformation().SetTag(x);
                    // header will have increased in size by one byte, so:
                    packet.RemoveHeader();
                    packet.AddHeader(thisHeader, thisHeader.GetSize());

                    // If intended for me, then reply:
                    if (thisHeader.destinationNode == myNumber)
                    {
                        // Packet is looking for me.  Convert to a reply
                        thisHeader.type = OnDemandHeader.PacketType.reply;
                        StringBuilder replyRoute = new StringBuilder(128);
                        if (thisHeader.route.Count > 0) replyRoute.Append(thisHeader.route[0]);
                        for (int loop = 1; loop < thisHeader.route.Count; loop++)
                            replyRoute.Append(":" + thisHeader.route[loop]);
                        string replyTag = "Explorer reply from " + myNumber 
                            + " to " + thisHeader.sourceNode + " route: " + replyRoute;
                        packet.MetaInformation().SetTag(replyTag);
                        packet.MetaInformation().SetFinalDestination(thisHeader.sourceNode);
                        packet.MetaInformation().SetOriginalSource(myNumber);

                        // then send back along the path to the source:
                        SendPacketToLogicalLinkLayer(packet, receivedFrom);
                        // Update the log file
                        if (Globals.LogEventsOn == true)
                        {
                            OutToLog("  Network: Sending route reply to " 
                                + thisHeader.sourceNode + " with route " 
                                + fullRoute + "; sending reply");
                        }
                    }

                    // else if destination is in my routeing table, then
                    // fill in remainder of route and reply (if proxies
                    // are enabled).
                    else if (LookUpRoute(thisHeader.destinationNode) != null
                        && this.proxyReplies == true)
                    {
                        List<int> routeOn = LookUpRoute(thisHeader.destinationNode);
                        routeOn.RemoveAt(0); // Delete last one
                        foreach (int hop in routeOn) thisHeader.route.Add(hop);
                        thisHeader.routeCost += (int)LookupCost(thisHeader.destinationNode);
                        // header will have increased in size by one byte, so:
                        packet.RemoveHeader();
                        packet.AddHeader(thisHeader, thisHeader.GetSize());
                        thisHeader.type = OnDemandHeader.PacketType.reply;
                        // convert to reply and update the tag string
                        StringBuilder replyRoute = new StringBuilder(128);
                        if (thisHeader.route.Count > 0) replyRoute.Append(thisHeader.route[0]);
                        for (int loop = 1; loop < thisHeader.route.Count; loop++)
                            replyRoute.Append(":" + thisHeader.route[loop]);
                        string replyTag = "Explorer reply from " + myNumber
                            + " to " + thisHeader.sourceNode + " route: " + replyRoute;
                        packet.MetaInformation().SetTag(replyTag);
                        // then send back along the path to the source:
                        SendPacketToLogicalLinkLayer(packet, receivedFrom);
                        // Update the log file
                        if (Globals.LogEventsOn == true)
                        {
                            StringBuilder builtRoute = new StringBuilder(120);
                            for (int loop = 0; loop < thisHeader.route.Count; loop++)
                                builtRoute.Append(thisHeader.route[loop].ToString() + ":");
                            OutToLog("  Network: Explorer intercepted by proxy "
                                + myNumber + " and returned with route " + builtRoute);
                        }
                    }

                    // else, re-broadcast the explorer if maximum hops is not yet reached:
                    else if (thisHeader.route.Count <= this.maximumHops)
                    {
                        OutToLog("  Network: Forwarding explorer");
                        SendPacketToLogicalLinkLayer(packet, BROADCAST);
                    }
                    break;
                case OnDemandHeader.PacketType.reply:
                    // If my node is not in this route, then delete:
                    if (thisHeader.route.Contains(myNumber) == false) return;
                    int myIndex = thisHeader.route.FindIndex(o => o == myNumber);

                    // If spying is off and this is not my reply, then just
                    // send along to the next node in the route:
                    if (this.replySpying == false && thisHeader.sourceNode != myNumber)
                    {
                        if (myIndex == 0) return; // No previous node to forward reply to
                        SendPacketToLogicalLinkLayer(packet, thisHeader.route[myIndex - 1]);
                        if (Globals.LogEventsOn == true)
                        {
                            OutToLog("  Network: Reply forwarded to next node "
                                + thisHeader.route[myIndex - 1] + " with route " + fullRoute);
                        }
                        return;
                    }

                    // If this is a cheaper cost to the destination than I know about,
                    // then update my routeing table:
                    if (thisHeader.routeCost < LookupCost(thisHeader.destinationNode))
                    {
                        List<int> newRoute = new List<int>();
                        int startFrom = thisHeader.route.FindIndex(o => o == myNumber);
                        for (int loop = startFrom; loop < thisHeader.route.Count; loop++)
                            newRoute.Add(thisHeader.route[loop]);
                        AddRouteingTableEntry(thisHeader.destinationNode, newRoute, thisHeader.routeCost);
                        if (Globals.LogEventsOn == true)
                        {
                            OutToLog("  Network: Cheaper route to " + thisHeader.sourceNode
                                + " found, with route " + fullRoute);
                        }

                        // If adding routes to the intermediate hops as well, then add the
                        // routes to the intermediate hops...
                        if (this.alsoAddHops == true)
                        {
                            for (int loop = startFrom + 1; loop < thisHeader.route.Count - 1; loop++)
                            {
                                int routeTo = thisHeader.route[loop];
                                List<int> anotherRoute = new List<int>();
                                for (int lop = startFrom; lop <= loop; lop++)
                                    anotherRoute.Add(thisHeader.route[lop]);
                                AddRouteingTableEntry(routeTo, anotherRoute, thisHeader.routeCost);
                            }
                        }
                    }


                    // If there are any packets waiting in the queue to be sent to this
                    // destination node, and I now have a route, then I can send them and 
                    // remove them from the queue:
                    foreach (cPacketStoreElement pse in PacketStore)
                    {
                        int destination = ((metaOnDemand)pse.GetMetadata()).destination;
                        List<int> theRoute = LookUpRoute(destination);
                        if (theRoute != null)
                        {
                            // Add an on-demand routeing header:
                            OnDemandHeader MyHeader = new OnDemandHeader();
                            MyHeader.destinationNode = (byte)destination;
                            MyHeader.sourceNode = (byte)myNumber;
                            MyHeader.type = OnDemandHeader.PacketType.data;
                            foreach (int y in theRoute) MyHeader.route.Add(y);
                            // Add the header to the packet,
                            cPacket toGo = pse.GetPacket();
                            toGo.AddHeader(MyHeader, MyHeader.GetSize());
                            // Set the next hop, and send the packet down to the LLC:
                            SendPacketToLogicalLinkLayer(toGo, theRoute[1]);
                            // Let the queue know packet has been sent:
                            ((metaOnDemand)(pse.GetMetadata())).state = metaOnDemand.eStatus.sent;

                            if (Globals.LogEventsOn)
                            {
                                OutToLog("  Network: Sending stored packet into network");
                            }
                        }
                    }
                    // Then remove all packets just sent:
                    PacketStore.RemoveAll(o =>
                        ((metaOnDemand)o.GetMetadata()).state == metaOnDemand.eStatus.sent);

                    // Also, if this was not the original source of the explorer, I need to send
                    // this reply on:
                    if (myIndex == 0) return; // No previous node to forward reply to
                    SendPacketToLogicalLinkLayer(packet, thisHeader.route[myIndex - 1]);
                    if (Globals.LogEventsOn)
                    {
                        OutToLog("  Network: Forwarding reply to next node " + thisHeader.route[myIndex - 1]);
                    }
                    break;
                default:
                    printfToMessageBox("Unknown packet type arrived at on-demand routeing layer.");
                    break;
            }

        }

        void PacketArrivesFromTransportLayer(cPacket packet, int destination)
        {
            if (destination == GetMyNumber())
            {
                // If packet is addressed to me, send it right back up to the transport layer:
                SendPacketToTransportLayer(packet, GetMyNumber());
            }
            else
            {
                // If I know a route to this destination, then add this route to the
                // network layer header, and send this packet along the route:
                if (LookUpRoute(destination) != null)
                {
                    OnDemandHeader MyHeader = new OnDemandHeader();
                    MyHeader.destinationNode = (byte)destination;
                    MyHeader.sourceNode = (byte)myNumber;
                    MyHeader.type = OnDemandHeader.PacketType.data;
                    List<int> theRoute = LookUpRoute(destination);
                    foreach (int x in theRoute) MyHeader.route.Add(x);
                    // Add the header to the packet, 
                    packet.AddHeader(MyHeader, MyHeader.GetSize());
                    // Set the next hop, and send the packet down to the LLC:
                    int nextHop = theRoute[1];
                    SendPacketToLogicalLinkLayer(packet, nextHop);
                    return;
                }
                // Otherwise, I don't know the route, so store the packet, and 
                // send out an explorer packet to find the route.
                else
                {
                    // Put packet in the queue with some meta data:
                    metaOnDemand newMeta = new metaOnDemand();
                    newMeta.destination = destination;
                    newMeta.explorersSent = 1;
                    newMeta.whenExplorerSent = GetMyTime();
                    newMeta.state = metaOnDemand.eStatus.waiting;
                    PutPacketInQueue(packet, newMeta);
                    // Update the log file
                    if (Globals.LogEventsOn == true)
                        OutToLog("  Network: Packet arrived for " + destination + " and stored, since no route known");
                    // and send an explorer:
                    SendExplorerFrame(destination);
                }
            }
        }

        void SendExplorerFrame(int destination)
        {
            // Build a new explorer packet:
            cPacket explorer = new cPacket(0, myNumber, 0);
            explorer.MetaInformation().SetFinalDestination(destination);
            explorer.MetaInformation().SetTag("Explorer from " + myNumber + " to " 
                + destination + " route: " + myNumber);
            // Generate a new header for this packet:
            OnDemandHeader MyHeader = new OnDemandHeader();
            MyHeader.destinationNode = (byte)destination;
            MyHeader.sourceNode = (byte)myNumber;
            MyHeader.routeCost = 0;
            MyHeader.type = OnDemandHeader.PacketType.explorer;
            MyHeader.route = new List<int>();
            MyHeader.route.Add(myNumber);
            // Add the header to the packet,
            explorer.AddHeader(MyHeader, MyHeader.GetSize());
            // and send out the explorer:
            SendPacketToLogicalLinkLayer(explorer, BROADCAST);
            // request a callback when attempt times out:
            RequestRelativeCallback(this.maxRouteingTime, destination);
            // Update the log file
            if (Globals.LogEventsOn == true)
                OutToLog("  Network: Sending an explorer frame from " + myNumber + " to " + destination);
            return;
        }

        void Callback(int A, cPacket packet = null)
        {
            // Callbacks happen when routeing times out, with A = destination node.
            List<int> thing = LookUpRoute(A);
            if (thing != null) return; // Fine, a route was found in time.
            // Find a packet waiting in the queue to get to this destination:
            cPacketStoreElement waiting =
                PacketStore.Find(x => ((metaOnDemand)x.GetMetadata()).destination == A);
            if (waiting == null) return; // Nothing in queue waiting.
            // Check how many times I've tried:
            int attempts = ((metaOnDemand)waiting.GetMetadata()).explorersSent;
            if (attempts >= this.explorerAttempts) return; // Give up.
            // Update the log file
            if (Globals.LogEventsOn == true)
                OutToLog("  Network: Explorer timed out, sending attempt " + (attempts + 1));
            // Otherwise, try again:
            ((metaOnDemand)waiting.GetMetadata()).explorersSent++;
            SendExplorerFrame(A);
        }

        void Initialise(double A, double B, double C, double D, double E, double F, double G)
        {
            // Warn user...
            // if (GetMyNumber() == 0)
            //    printfToMessageBox("Warning: On-Demand is new, and still being tested.", "Warning");

            // Things to do at the start of the simulation,
            // before any packets have been sent: set up the 
            // parameters to their initial values.
            this.myNumber = GetMyNumber();
            this.maximumHops = GetMaximumHopCount();
            this.maxRouteingTime = A;
            this.explorerAttempts = (int)B;
            this.proxyReplies = (C == 0.0) ? false : true;
            this.replySpying = (D == 0.0) ? false : true;
            this.alsoAddHops = (E == 0.0) ? false : true;
        }

        void Shutdown()
        {
        }
    }
    // End of on-demand routeing.
}
