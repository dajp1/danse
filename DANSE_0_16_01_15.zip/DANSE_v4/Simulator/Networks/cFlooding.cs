﻿using System.Runtime.InteropServices;
using System;
using System.Windows;
using System.Collections.Generic;
namespace DANSE_v4
{
    public partial class MainWindow : Window
    {
        private void NetworkSetupFloodingControls()
        {
            Globals.stsNetworkHopCount.Enable(true);

            Globals.stsNetworkParameterOne.NameOnSetup.Content = "Store Route";
            Globals.stsNetworkParameterOne.SetNewRange(0, 1, 0, GUIBits.SliderType.checkbox);
            Globals.stsNetworkParameterOne.Enable(true);
        }
    }

    class cFloodingRouteing : cNetwork
    {
        //////////////////////////////////////////////////////
        // Flooding: send out broadcasts everywhere.
        //

        internal cFloodingRouteing(cNode Here, ref cNode.NetworkDelegates Delegates): base(Here)
        {
            Delegates.CallWhenCallback = new cNode.NetworkCallbackDelegate(this.Callback);
            Delegates.CallWhenInitialise = new cNode.NetworkInitialiseDelegate(this.Initialise);
            Delegates.CallWhenPacketArrivesFromLogicalLinkLayer = new cNode.NetworkPacketFromBelowDelegate(this.PacketArrivesFromLogicalLinkLayer);
            Delegates.CallWhenPacketArrivesFromTransportLayer = new cNode.NetworkPacketFromAboveDelegate(this.PacketArrivesFromTransportLayer);
            Delegates.CallWhenShutdown = new cNode.NetworkShutdownDelegate(this.Shutdown);
        }

        // Network header:
        [Serializable] private class NetworkFloodingHeader
        {
            internal byte HopsLeft;
            internal byte OriginalSource;
            internal byte FinalDestination;
            internal List<int> route = new List<int>();

            internal NetworkFloodingHeader(int InitHopCount, int Source, int Destination)
            {
                HopsLeft = (byte)InitHopCount;
                OriginalSource = (byte)Source;
                FinalDestination = (byte)Destination;
                route.Clear();
            }
            internal NetworkFloodingHeader(int Source, int Destination)
            {
                HopsLeft = (byte)Globals.HopCount;
                OriginalSource = (byte)Source;
                FinalDestination = (byte)Destination;
                route.Clear();
            }
            internal int GetLength() { return 3 + route.Count; }
        }

        void PacketArrivesFromLogicalLinkLayer(cPacket packet, int receivedFrom)
        {
            // Some idiot checking:
            if (!(packet.ViewHeader() is NetworkFloodingHeader))
            {
                Globals.ShowMessageBox("Packet arrived at flooding network layer\n"
                    + "without a suitable header. \n"
                    + "Packet will be deleted.", "User Protocol Error?");
                return;
            }

            // Extract from the header the source and destination:
            NetworkFloodingHeader ThisHeader = (NetworkFloodingHeader)packet.RemoveHeader();
            int Source = ThisHeader.OriginalSource;
            int Destination = ThisHeader.FinalDestination;
            // If this is for me, then remove the header and pass up to the next layer:
            if (Destination == node.GetNumber())
            {
                Globals.theQueue.AddEvent(new cEvent(node, packet, node.GetTime(),
                    EventType.Transport_PacketArrivesFromNetworkLayer, Source));
                // Update the log file
                if (Globals.LogEventsOn == true)
                    OutToLog("  Network: Flooded packet received for me - passing up to transport layer");
            }
            // Otherwise if hop count not yet zero, send it back out again:
            else
            {
                ThisHeader.HopsLeft--;
                if (this.storeRoute == true)
                {
                    // If I'm already in the route, delete the packet:
                    if (ThisHeader.route.Contains(GetMyNumber()))
                    {
                        // Update the log file
                        if (Globals.LogEventsOn == true)
                            OutToLog("  Network: Flooded packet been here before, so ignoring");
                        return;
                    }
                    // otherwise, add my address to the packet
                    else
                    {
                        ThisHeader.route.Add(GetMyNumber());
                    }
                }
                // Add modified header back to packet:
                packet.AddHeader(ThisHeader, ThisHeader.GetLength());

                if (ThisHeader.HopsLeft == 0) return; // Just kill the packet
                Globals.theQueue.AddEvent(new cEvent(node, packet, node.GetTime(),
                    EventType.LogicalLink_PacketArrivesFromNetworkLayer, Globals.BROADCAST));
                // Update the log file
                if (Globals.LogEventsOn == true)
                    OutToLog("  Network: Flooded packet passed on, with " + ThisHeader.HopsLeft.ToString() + " hops left");
            }
        }

        void PacketArrivesFromTransportLayer(cPacket packet, int destination)
        {
            // First check to see if this packet is addressed to this node, and if
            // so, just send it right back up again:
            if (destination == node.GetNumber())
            {
                Globals.theQueue.AddEvent(new cEvent(node, packet, node.GetTime(),
                    EventType.Transport_PacketArrivesFromNetworkLayer, destination));
                if (Globals.LogEventsOn == true)
                    OutToLog("  Network: Internal loopback of packet");
            }
            else
            {
                // Work out where this packet is going to, and where it's coming from:
                int source = node.GetNumber();
                // Add a basic header and pass on down (thing.stuff is an int, and the destination):
                NetworkFloodingHeader newhead = new NetworkFloodingHeader(source, destination);
                int headersize = newhead.GetLength();
                if (this.storeRoute == true) newhead.route.Add(GetMyNumber());
                packet.AddHeader((Object)newhead, headersize);  // Add to packet
                // Route the packet to everyone
                packet.MetaInformation().SetLastHop(node.GetNumber());
                packet.MetaInformation().SetNextHop(Globals.BROADCAST);
                // Update the log file
                if (Globals.LogEventsOn == true)
                    OutToLog("  Network: Flooding packet to everyone within reach");
                // And send the packet to the logical-link layer
                Globals.theQueue.AddEvent(new cEvent(node, packet, node.GetTime(),
                    EventType.LogicalLink_PacketArrivesFromNetworkLayer, Globals.BROADCAST));
            }
        }

        void Callback(int A, cPacket packet = null)
        {
            // Things to do when a callback occurs.
        }

        Boolean storeRoute = false;
        void Initialise(double A, double B, double C, double D, double E, double F, double G)
        {
            // Things to do at the start of the simulation. 
            storeRoute = (A == 0) ? false : true;
        }

        void Shutdown()
        {
            // Things to do when flooding is shutting down.
        }

        /////////////////////////////////////////////
        // Do not modify anything below this line. //
        /////////////////////////////////////////////
    }
}
