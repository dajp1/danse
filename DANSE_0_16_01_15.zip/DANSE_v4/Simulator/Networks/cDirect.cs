﻿using System.Runtime.InteropServices;
using System;
using System.Windows;
namespace DANSE_v4
{
    public partial class MainWindow : Window
    {
        private void NetworkSetupDirectControls()
        {
        }
    }

    class cDirectRouteing : cNetwork
    {
        //////////////////////////////////////////////////////
        // Direct routeing: always send direct to destination.
        //

        internal cDirectRouteing(cNode Here, ref cNode.NetworkDelegates Delegates): base(Here)
        {
            Delegates.CallWhenCallback = new cNode.NetworkCallbackDelegate(this.Callback);
            Delegates.CallWhenInitialise = new cNode.NetworkInitialiseDelegate(this.Initialise);
            Delegates.CallWhenPacketArrivesFromLogicalLinkLayer = new cNode.NetworkPacketFromBelowDelegate(this.PacketArrivesFromLogicalLinkLayer);
            Delegates.CallWhenPacketArrivesFromTransportLayer = new cNode.NetworkPacketFromAboveDelegate(this.PacketArrivesFromTransportLayer);
            Delegates.CallWhenShutdown = new cNode.NetworkShutdownDelegate(this.Shutdown);
        }

        [Serializable] struct NetworkHeader
        {
            internal byte sourceNode;
            internal byte destinationNode;
        }

        internal void PacketArrivesFromLogicalLinkLayer(cPacket packet, int receivedFrom)
        {
            // Some idiot checking:
            if (!(packet.ViewHeader() is NetworkHeader))
            {
                Globals.ShowMessageBox("Packet arrived at direct network layer\n"
                    + "without a suitable header. \n"
                    + "Packet will be deleted.", "User Protocol Error?");
                return;
            }

            // Get a pointer to the NetworkHeader and cast to the structure type:
            NetworkHeader thisHeader = (NetworkHeader)packet.RemoveHeader();

            // If the packet is addressed to me, get the source node and send
            // the packet up to the transport layer:
            if (thisHeader.destinationNode == GetMyNumber())
            {
                int sourceNode = thisHeader.sourceNode;
                SendPacketToTransportLayer(packet, sourceNode);
                if (Globals.LogEventsOn == true)
                    OutToLog("  Network: Sending up to transport layer");
            }
            else
            {
                // Otherwise ignore the packet.  Don't do anything.  It's
                // not for me, and there is no routeing function available.
                if (Globals.LogEventsOn == true)
                    OutToLog("  Network: Not for me, so destroying packet");
            }
        }

        internal void PacketArrivesFromTransportLayer(cPacket packet, int destination)
        {
            if (destination == GetMyNumber())
            {
                // If packet is addressed to me, send it right back up to the transport layer:
                SendPacketToTransportLayer(packet, GetMyNumber());
                if (Globals.LogEventsOn == true)
                    OutToLog("  Network: Internal loopback of packet");
            }
            else
            {
                // Otherwise it must be for someone else, so generate a new NetworkHeader,
                int source = node.GetNumber();
                // Add a basic header and pass on down (thing.stuff is an int, and the destination):
                NetworkHeader newhead = new NetworkHeader();
                newhead.sourceNode = (byte)source;
                newhead.destinationNode = (byte)destination;
                int headersize = 0;  unsafe { headersize = sizeof(NetworkHeader); }
                packet.AddHeader((Object)newhead, headersize);  // Add to packet

                // Set the next hop to the final destination, and send the packet
                // down to the logical-link layer:
                int nextHop = destination;
                SendPacketToLogicalLinkLayer(packet, nextHop);
                if (Globals.LogEventsOn == true)
                    OutToLog("  Network: Routeing packet direct to the destination, node " 
                        + destination.ToString());
            }
        }

        void Callback(int A, cPacket packet = null)
        {
            // Nothing to do when a callback occurs.
        }

        void Initialise(double A, double B, double C, double D, double E, double F, double G)
        {
            // Nothing to do when initialised.
        }

        internal void Shutdown()
        {
            // Nothing to do on shutdown.
        }
    }

    // End of direct routeing methods.
}
