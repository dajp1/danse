﻿using System.Windows;
namespace DANSE_v4
{
    public partial class MainWindow : Window
    {
        private void NetworkSetupUserControls()
        {
            Globals.stsNetworkHopCount.Enable(true);
            Globals.stsNetworkParameterOne.Enable(true);
            Globals.stsNetworkParameterTwo.Enable(true);
            Globals.stsNetworkParameterThree.Enable(true);
            Globals.stsNetworkParameterFour.Enable(true);
            Globals.stsNetworkParameterFive.Enable(true);
            Globals.stsNetworkParameterSix.Enable(true);
            Globals.stsNetworkParameterSeven.Enable(true);
            Globals.stsNetworkParameterOne.NameOnSetup.Content = "Parameter A";
            Globals.stsNetworkParameterTwo.NameOnSetup.Content = "Parameter B";
            Globals.stsNetworkParameterThree.NameOnSetup.Content = "Parameter C";
            Globals.stsNetworkParameterFour.NameOnSetup.Content = "Parameter D";
            Globals.stsNetworkParameterFive.NameOnSetup.Content = "Parameter E";
            Globals.stsNetworkParameterSix.NameOnSetup.Content = "Parameter F";
            Globals.stsNetworkParameterSeven.NameOnSetup.Content = "Parameter G";
        }
    }

    unsafe partial class cUserNetwork : cNetwork
    {
        ////////////////////////////////////
        // User routeing routine wrapper.
        //

        internal cUserNetwork(cNode Here, ref cNode.NetworkDelegates Delegates): base(Here)
        {
            Delegates.CallWhenCallback = new cNode.NetworkCallbackDelegate(this.Callback);
            Delegates.CallWhenInitialise = new cNode.NetworkInitialiseDelegate(this.Initialise);
            Delegates.CallWhenPacketArrivesFromLogicalLinkLayer = new cNode.NetworkPacketFromBelowDelegate(this.PacketArrivesFromLogicalLinkLayer);
            Delegates.CallWhenPacketArrivesFromTransportLayer = new cNode.NetworkPacketFromAboveDelegate(this.PacketArrivesFromTransportLayer);
            Delegates.CallWhenShutdown = new cNode.NetworkShutdownDelegate(this.Shutdown);
        }

        /////////////////////////////////////////////
        // Do not modify anything below this line. //
        /////////////////////////////////////////////
    }
}
