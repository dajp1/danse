﻿using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System;

namespace DANSE_v4
{
    public partial class MainWindow : Window
    {
        internal List<UIElement> GetSystemControls()
        {
            List<UIElement> things = new List<UIElement>();
            int VOffset = Globals.CONTROLVOFFSETSTART;
            int VOffsetDifference = Globals.CONTROLVOFFSETDELTA;

            // The number of nodes in the simulation:
            Globals.stsNumberOfNodes = GUIBits.SetupNewSquareRootIntegerSlider(things, VOffset, "number of nodes", "Nodes",
                Globals._NumberOfNodesDefault, Globals._NumberOfNodesMinimum, Globals._NumberOfNodesMaximum);
            Globals.stsNumberOfNodes.theSlider.ValueChanged += new RoutedPropertyChangedEventHandler<double>(sldNumberOfNodes_ValueChanged);
            VOffset += VOffsetDifference;

            // Then a combo box for the node placement algorithm:
            Globals.ctsHowToPlaceNodes = GUIBits.SetupNewComboBox<Globals.eNodePlacement>(things, VOffset, "node placement type", "Placement");
            Globals.ctsHowToPlaceNodes.theComboBox.SelectionChanged += new SelectionChangedEventHandler(PlacementCombo_SelectionChanged);
            VOffset += VOffsetDifference;

            // The length of the simulation:
            Globals.stsSimulationLength = GUIBits.SetupNewLog125Slider(things, VOffset, "simulation length", "Length", Globals._SimulationLengthDefault,
                Globals._SimulationLengthMinimum, Globals._SimulationLengthMaximum);
            Globals.stsSimulationLength.theSlider.ValueChanged += new RoutedPropertyChangedEventHandler<double>(SimulationLength_ValueChanged);
            VOffset += VOffsetDifference;

            // The length of the pre-roll (time before packet generation starts):
            Globals.stsPrerollLength = GUIBits.SetupNewLog0125Slider(things, VOffset, "preroll length", "Preroll", Globals._PrerollLengthDefault,
                Globals._PrerollLengthMinimum, Globals._PrerollLengthMaximum);
            Globals.stsPrerollLength.theSlider.ValueChanged += new RoutedPropertyChangedEventHandler<double>(PrerollLength_ValueChanged);
            VOffset += VOffsetDifference;

            // The length of the post-roll (time before end of simulation when packet generation stops):
            Globals.stsPostrollLength = GUIBits.SetupNewLog0125Slider(things, VOffset, "postroll length", "Postroll", Globals._PostrollLengthDefault,
                Globals._PostrollLengthMinimum, Globals._PostrollLengthMaximum);
            Globals.stsPostrollLength.theSlider.ValueChanged += new RoutedPropertyChangedEventHandler<double>(PostrollLength_ValueChanged);
            VOffset += VOffsetDifference;

            // A combobox for working out when and how to wake up nodes initially:
            Globals.ctsSwitchingOn = GUIBits.SetupNewComboBox<Globals.SwitchingOnType>(things, VOffset, "switch on", "Switch On");
            Globals.ctsSwitchingOn.theComboBox.SelectionChanged += new SelectionChangedEventHandler(SwitchingOn_SelectionChanged);
            VOffset += VOffsetDifference;

            // Then a ComboBox for the synchronisation mode:
            Globals.ctsClockSync = GUIBits.SetupNewComboBox<Globals.ClockSyncType>(things, VOffset, "clock sync", "Clocks");
            Globals.ctsClockSync.theComboBox.SelectionChanged += new SelectionChangedEventHandler(ClockSync_SelectionChanged);
            VOffset += VOffsetDifference;

            // Then a slider for changing the clock accuracy.  Here, 1.0 means 1 part per thousand off.
            Globals.stsClockAccuracy = GUIBits.SetupNewLog125Slider(things, VOffset, "clock accuracy (ppm)", "Offset (ppm)",
                Globals._ClockAccuracyDefault, Globals._ClockAccuracyMinimum, Globals._ClockAccuracyMaximum);
            Globals.stsClockAccuracy.theSlider.ValueChanged += new RoutedPropertyChangedEventHandler<double>(ClockAccuracy_ValueChanged);
            ClockAccuracy_ValueChanged(Globals.stsClockAccuracy.theSlider, null);
            VOffset += VOffsetDifference;

            // Then a combo box for the energy mode.
            Globals.ctsEnergyMode = GUIBits.SetupNewComboBox<Globals.EnergyType>(things, VOffset, "energy mode", "Energy Mode");
            Globals.ctsEnergyMode.theComboBox.SelectionChanged += new SelectionChangedEventHandler(EnergyMode_SelectionChanged);
            VOffset += VOffsetDifference;

            // Then send back the list:
            return things;
        }

        void sldNumberOfNodes_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            // It's a square root control, so first, I'll get the actual value for number of nodes:
            GUIBits.SliderTagStruct thisTag = (GUIBits.SliderTagStruct)((Slider)sender).Tag;
            int Nodes = (int)thisTag.GetActualValue();
            int OldNodes = Globals.NumberOfNodes;
            ChangeNumberOfNodes(Nodes);
            thisTag.theLabel.Content = Globals.NumberOfNodes.ToString();
            if (OldNodes != Globals.NumberOfNodes)
                Globals.stsNumberOfNodes.SetSliderValue(Globals.NumberOfNodes, false);
        }
        void ChangeNumberOfNodes(int Nodes)
        {
            switch (Globals.HowToPlaceNodes)
            {
            case Globals.eNodePlacement.Linear:
            case Globals.eNodePlacement.Random:
            case Globals.eNodePlacement.Circle:
            case Globals.eNodePlacement.Ring:
                // Sets the number of nodes, which is allowed to be 1,2...10,12,15,20...50,60,70...100
                if (Nodes == 11 || Nodes == 12) Nodes = 12;
                else if (Nodes > 12 && Nodes < 50) Nodes -= (Nodes + 2) % 5 - 2;
                else if (Nodes > 50) Nodes -= (Nodes + 5) % 10 - 5;
                break;
            case Globals.eNodePlacement.Cross:
                // Must be a multiple of four or multiple of four plus one to make a nice symmetric cross:
                if (Nodes % 4 == 2) Nodes--;
                if (Nodes % 4 == 3) Nodes++;
                break;
            case Globals.eNodePlacement.Square:
                // With square, the readings are whichever of the nearest of the possible square values,
                // up to a maximum of the 100 nodes (10 by 10 square).
                double BestSquareFit = 1e10; int BestSquareMatch = 0;
                for (int loop = 0; loop < Globals.SquareGrids.Length; loop++)
                {
                    int HowManyInHere = 0;
                    foreach(int ele in Globals.SquareGrids[loop]) HowManyInHere += ele;
                    double HowClose = (HowManyInHere - Nodes) * (HowManyInHere - Nodes);
                    if (HowClose < BestSquareFit) { BestSquareFit = HowClose; BestSquareMatch = loop; }
                }
                int SquareGridRow = BestSquareMatch;

                Nodes = 0; for (int loop = 0; loop < Globals.SquareGrids[SquareGridRow].Length; loop++)
                    Nodes += Globals.SquareGrids[SquareGridRow][loop];
                break;
            case Globals.eNodePlacement.Hexagonal:
                // With hexagonal, the readings are whichever are the nearest of the possible hex values:
                double BestHexFit = 1e10; int BestHexMatch = 0;
                for (int loop = 0; loop < Globals.HexGrids.Length; loop++)
                {
                    int HowManyInHere = 0;
                    foreach (int ele in Globals.HexGrids[loop]) HowManyInHere += ele;
                    double HowClose = (HowManyInHere - Nodes) * (HowManyInHere - Nodes);
                    if (HowClose < BestHexFit) { BestHexFit = HowClose; BestHexMatch = loop; }
                }
                int HexGridRow = BestHexMatch;

                Nodes = 0; for (int loop = 0; loop < Globals.HexGrids[HexGridRow].Length; loop++)
                    Nodes += Globals.HexGrids[HexGridRow][loop];
                break;
            case Globals.eNodePlacement.Preloaded:
                // With preloaded, anything is OK provided it's less than 100, and the number of nodes loaded
                if (Nodes > 100) Nodes = 100;
                if (Nodes > Globals.myPreloadedNodes.Count) Nodes = Globals.myPreloadedNodes.Count;
                break;
            default:
                MessageBox.Show("Unexpected request for how to place nodes.  Something's Wrong.", "Serious Error");
                break;
            }

            if (Nodes == Globals.NumberOfNodes) return; // Nothing changed.
            Globals.NumberOfNodes = Nodes;
            // If changing the number of nodes, I also need to change the energy left indicators
            ResetEnergyAndPacketIndicators();
            // And re-set all the nodes, including the selected node:
            Globals.SelectedNode = Globals.NOWHERE;
            SetupNodes(Canvas2D);
            // Then reset the simulation:
            ResetSimulation();
        }

        void PlacementCombo_SelectionChanged(object sender, RoutedEventArgs e)
        {
            ComboBox thing = (ComboBox)sender;
            String chosen = thing.Items[thing.SelectedIndex].ToString();

            GUIBits.ComboBoxTagStruct tagstruct = (GUIBits.ComboBoxTagStruct)thing.Tag;
            tagstruct.SetValue<Globals.eNodePlacement>(chosen, ref Globals.HowToPlaceNodes);

            // If changing the method of placement, I might need to round up/down the 
            // number of nodes, in case there is no pattern with the current number 
            // of nodes.
            ChangeNumberOfNodes(Globals.NumberOfNodes);

            // I also need to change the energy left indicators
            ResetEnergyAndPacketIndicators();
            // And re-set all the nodes:
            SetupNodes(Canvas2D);
            // Then reset the simulation:
            ResetSimulation();
        }

        void SimulationLength_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            GUIBits.SliderTagStruct thisTag = (GUIBits.SliderTagStruct)((Slider)sender).Tag;
            long NewSimLength = (long)(thisTag.GetActualValue());
            // If this is a new length (slider might not have moved far enough to change things)
            if (NewSimLength != Globals.SimulationLength)
            {
                Globals.SimulationLength = NewSimLength;
                ResetSimulation();
            }
        }

        void PrerollLength_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            GUIBits.SliderTagStruct thisTag = (GUIBits.SliderTagStruct)((Slider)sender).Tag;
            Globals.PrerollLength = (long)(thisTag.GetActualValue());
        }

        void PostrollLength_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            GUIBits.SliderTagStruct thisTag = (GUIBits.SliderTagStruct)((Slider)sender).Tag;
            Globals.PostrollLength = (long)(thisTag.GetActualValue());
        }

        void SwitchingOn_SelectionChanged(object sender, RoutedEventArgs e)
        {
            ComboBox thing = (ComboBox)sender;
            String chosen = thing.Items[thing.SelectedIndex].ToString();
            try { Globals.SwitchingOn = (Globals.SwitchingOnType)Enum.Parse(typeof(Globals.SwitchingOnType), chosen); }
            catch { MessageBox.Show("Switching-on type " + chosen + " not recognised", "Serious Error"); }
        }

        void ClockSync_SelectionChanged(object sender, RoutedEventArgs e)
        {
            ComboBox thing = (ComboBox)sender;
            String chosen = thing.Items[thing.SelectedIndex].ToString();
            try { Globals.ClockSync = (Globals.ClockSyncType)Enum.Parse(typeof(Globals.ClockSyncType), chosen); }
            catch { MessageBox.Show("Synchronisation type " + chosen + " not recognised", "Serious Error"); }
        }

        void ClockAccuracy_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            Globals.ClockAccuracy = ((GUIBits.SliderTagStruct)(((Slider)sender).Tag)).GetActualValue() / 1.0e6; // Slider is in +/- parts per million
            foreach (cNode node in Globals.myNodes) node.SetClockSpeedFactor(1.0 + Globals.ClockAccuracy * (Globals.rands.NextDouble() - 0.5) * 2.0);
        }

        void EnergyMode_SelectionChanged(object sender, RoutedEventArgs e)
        {
            ComboBox thing = (ComboBox)sender;
            String chosen = thing.Items[thing.SelectedIndex].ToString().Replace(' ', '_');
            try { Globals.EnergyMode = (Globals.EnergyType)Enum.Parse(typeof(Globals.EnergyType), chosen); }
            catch { MessageBox.Show("Energy mode " + chosen + " not recognised", "Serious Error"); }
            
            // Update the main screen label:
            switch (Globals.EnergyMode)
            {
                case Globals.EnergyType.Countdown:
                    lblEnergy.Content = "Energy Left";
                    break;
                case Globals.EnergyType.Addup:
                    lblEnergy.Content = "Energy Used";
                    break;
                case Globals.EnergyType.Down_Not_Zero:
                    lblEnergy.Content = "Energy";
                    break;
                default:
                    MessageBox.Show("Unknown energy mode.", "Serious error");
                    break;
            }
            UpdateEnergyIndicators();
        }
    }
}
