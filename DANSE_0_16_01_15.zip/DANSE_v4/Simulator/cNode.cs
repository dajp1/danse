﻿using System;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Collections.Generic;

namespace DANSE_v4
{
    // This is the class that represents a node.  It has lots of parameters, but not
    // a lot of methods.  They're elsewhere...
    class cNode
    {
        // Location of the node, and which grid it's on:
        private Canvas whereAmI = null;
        private Point Position = new Point(0, 0);
        internal Point GetPosition() { return Position; }
        internal void SetPosition(Point pos) { Position = pos; }
        // If it's moving, the direction and the target position it's going to:
        internal Point TargetPosition = new Point(0, 0);
        internal double Direction = (Globals.rands.NextDouble() - 0.5) * 2 * Math.PI;
        private double Speed = Globals.MovementSpeedNew();
        internal double GetSpeed() { return Speed; }
        internal void SetSpeed(double value) { Speed = value; }
        // What it looks like, and the current range of transmissions
        private Ellipse ellNode, ellRxRange, ellDetectRange;
        private TextBlock tbNumberName;
        private Polyline polylinePath;
        private Line lineMACParent, lineLLCParent;
        private Boolean MouseOnThisNode = false;
        // The index number of the node:
        private int nodeNumber; internal int GetNumber() { return nodeNumber; }
        // The clock of this node can vary with respect to the master system clock, by a factor:
        private double ClockSpeedFactor = 1.0;
        private long ClockOffset = 0;
        internal void SetClockSpeedFactor(double value) { ClockSpeedFactor = value; }
        // Each node can generate traffic at its own rate (although they usually don't)
        internal double TrafficRate = Globals.TrafficGenerateRate / Globals.NumberOfNodes;
        internal int MeanPacketSize = Globals.MeanPacketSize;
        internal int PacketPriority = Globals.PacketPriority;
        // Each node keeps a count of the packets received successfully.
        private int nodePacketsReceived = 0;
        internal int GetPacketsReceived() { return nodePacketsReceived; }
        internal void ReceiveAPacket() { nodePacketsReceived++; }
        private int nodePacketsSent = 0;
        internal int GetPacketsSent() { return nodePacketsSent; }
        internal void SendAPacket() { nodePacketsSent++; }
        // The nodes have a receive and transmit state:
        private cPacket PacketBeingReceived = null;
        private double PacketBeingReceivedPower = 0.0;
        internal cPacket GetPacketBeingReceived() { return PacketBeingReceived; }
        internal double GetPacketBeingReceivedPower() { return PacketBeingReceivedPower; }
        List<Globals.ReceiveSINRHistoryItem> SINRHistory = new List<Globals.ReceiveSINRHistoryItem>();
        private cPacket PacketBeingTransmitted = null;
        internal double CurrentTotalReceivedPower = 0.0;
        private double CurrentTransmitPower = 0.0;
        internal double GetCurrentTransmitPower() { return CurrentTransmitPower; }
        // Nodes keep a history of their activity for the PHY Activity graph:
        internal List<Globals.TxActivity> TxHistory = new List<Globals.TxActivity>();
        internal List<Globals.RxActivity> RxHistory = new List<Globals.RxActivity>();
        // It's possible to assign a parent, or clusterhead node for each node:
        private int myMACParent = Globals.NOWHERE;
        internal void SetMACParent(int x) { myMACParent = x; }
        internal int GetMACParent() { return myMACParent; }
        private int myLLCParent = Globals.NOWHERE;
        internal void SetLLCParent(int x) { myLLCParent = x; }
        internal int GetLLCParent() { return myLLCParent; }
        // The active channels:
        private int receiveChannel;
        internal Boolean SetReceiveChannel(int newChannel) 
        {
            if (ReceiveState == Globals.ReceiverState.Receiving && newChannel != this.receiveChannel)
            {
                MessageBox.Show("Request to change receive channel while receiving.\n"
                    + "Request denied.",
                    "Strange behaviour alert");
                return false;
            }
            if (newChannel < 0 || newChannel >= Globals._MACNumberOfChannels)
            {
                MessageBox.Show("Can't set node " + this.nodeNumber.ToString() + " receive channel to "
                    + newChannel.ToString() + ".\n"
                    + "Only " + Globals._MACNumberOfChannels.ToString() + " channels available.",
                    "User error");
                return false;
            }
            receiveChannel = newChannel;
            return true;
        }
        internal int GetReceiveChannel() { return receiveChannel; }
        private int transmitChannel;
        internal Boolean SetTransmitChannel(int newChannel) 
        {
            if (TransmitState == Globals.TransmitterState.Transmitting)
            {
                MessageBox.Show("Request to change transmit channel while transmitting.\n"
                    + "Request is denied.",
                    "Strange behaviour alert");
                return false;
            }
            if (newChannel < 0 || newChannel >= Globals._MACNumberOfChannels)
            {
                MessageBox.Show("Can't set node "+ this.nodeNumber.ToString() +" transmit channel to " 
                    + newChannel.ToString() + ".\n"
                    + "Only " + Globals._MACNumberOfChannels.ToString() + " channels available.",
                    "User error");
                return false;
            }
            transmitChannel = newChannel;
            return true;
        }
        internal int GetTransmitChannel() { return transmitChannel; }

        // The state of the node, and the energy counter:
        // private double EnergyLeft = Globals.InitialEnergy;
        private double EnergyUsedListening, EnergyUsedReceiving;
        private double EnergyUsedAsleep, EnergyUsedRxOff;
        private double EnergyUsedTransmitting, EnergyUsedTxOff;
        internal double GetEnergyUsed() 
        {
            double EnergyUsed = EnergyUsedListening + EnergyUsedReceiving + EnergyUsedAsleep
                                    + EnergyUsedRxOff + EnergyUsedTransmitting + EnergyUsedTxOff;
            return EnergyUsed; 
        }
        internal double GetEnergyLeft() { return Math.Max(0.0, Globals.InitialEnergy - GetEnergyUsed()); }
        internal double GetEnergyUsedListening() { return EnergyUsedListening; }
        internal double GetEnergyUsedReceiving() { return EnergyUsedReceiving; }
        internal double GetEnergyUsedAsleep() { return EnergyUsedAsleep; }
        internal double GetEnergyUsedRxOff() { return EnergyUsedRxOff; }
        internal double GetEnergyUsedTransmitting() { return EnergyUsedTransmitting; }
        internal double GetEnergyUsedTxOff() { return EnergyUsedTxOff; }
        private long localTimeWhenSwitchedOn;
        internal long GetLocalTimeWhenSwitchedOn() { return localTimeWhenSwitchedOn; }
        private Globals.ReceiverState ReceiveState = Globals.ReceiverState.Listening;
        private Globals.TransmitterState TransmitState = Globals.TransmitterState.Off;
        internal Globals.ReceiverState GetReceiveState() { return ReceiveState; }
        internal Globals.TransmitterState GetTransmitState() { return TransmitState; }
        private long WhenCurrentTxFinishes = 0;
        internal long GetWhenTxFinishes() { return(WhenCurrentTxFinishes); }
        private Boolean MACCallbackWhenTransmitterIdle = false;
        private int MACCallbackWhenTransmitterIdleIndex = 0;
        private long MACCallbackWhenTransmitterIdleForPeriod = 0;
        private long MACCallbackTimeWhenTransmitterLastBecameIdle = 0;
        internal void SetMACTransmitterIdleCallback(Boolean what, int x, double howlong = 0.0)
        {
            MACCallbackWhenTransmitterIdle = what;
            MACCallbackWhenTransmitterIdleIndex = x;
            MACCallbackWhenTransmitterIdleForPeriod = (long)(howlong * 1e9);
            // If transmitter is already off, then test again after howlong:
            if (TransmitState == Globals.TransmitterState.Off)
            {
                MACCallbackWhenTransmitterIdle = false; // Started count already
                long timeToWait = (long)(GetTime() + howlong*1e9);
                Globals.theQueue.AddEvent(new cEvent(this, null, timeToWait,
                    EventType.Node_WaitForTxIdle, MACCallbackWhenTransmitterIdleIndex));
            }
        }
        private Boolean MACCallbackWhenChannelClear = false;
        private int MACCallbackWhenChannelClearIndex = 0;
        private long MACCallbackWhenChannelClearForPeriod = 0;
        private long MACCallbackTimeWhenChannelLastBecameClear = 0;
        internal void SetMACChannelClearCallback(Boolean what, int x, double howlong = 0.0)
        {
            MACCallbackWhenChannelClear = what;
            MACCallbackWhenChannelClearIndex = x;
            MACCallbackWhenChannelClearForPeriod = (long)(howlong * 1e9);
            // If channel already quiet, then test again after howlong:
            if (ReceiveState == Globals.ReceiverState.Listening)
            {
                MACCallbackWhenChannelClear = false; // Started count already
                long timeToWait = (long)(GetTime() + howlong * 1e9);
                Globals.theQueue.AddEvent(new cEvent(this, null, timeToWait,
                    EventType.Node_WaitForRxIdle, MACCallbackWhenChannelClearIndex));
            }
        }
        private long WhenEnergyLastUpdated = 0;

        internal cApplication ApplicationLayerOne;
        internal cTransport TransportLayer;
        internal cNetwork NetworkLayer;
        internal cLogicalLink LogicalLinkLayer;
        internal cMAC MACLayer;
        internal cPhysical PhysicalLayer;

        // The delegate functions for the protocol event calls:
        internal delegate void TransportPacketFromAboveDelegate(cPacket packet, int Destination, int DestPort, int SourcePort);
        internal delegate void TransportPacketFromBelowDelegate(cPacket packet, int Source);
        internal delegate void TransportCallbackDelegate(int A, cPacket packet = null);
        internal delegate void TransportInitialiseDelegate(double A, double B, double C, double D);
        internal delegate void TransportShutdownDelegate();

        internal class TransportDelegates
        {
            internal TransportPacketFromAboveDelegate CallWhenPacketArrivesFromApplicationLayer = null;
            internal TransportPacketFromBelowDelegate CallWhenPacketArrivesFromNetworkLayer = null;
            internal TransportCallbackDelegate CallWhenCallback = null;
            internal TransportInitialiseDelegate CallWhenInitialise = null;
            internal TransportShutdownDelegate CallWhenShutdown = null;
        }
        internal TransportDelegates TransportFunctions = new TransportDelegates();

        internal delegate void NetworkPacketFromAboveDelegate(cPacket packet, int Destination);
        internal delegate void NetworkPacketFromBelowDelegate(cPacket packet, int Source);
        internal delegate void NetworkCallbackDelegate(int A, cPacket packet = null);
        internal delegate void NetworkInitialiseDelegate(double A, double B, double C, double D, double E, double F, double G);
        internal delegate void NetworkShutdownDelegate();
        
        internal class NetworkDelegates
        {
            internal NetworkPacketFromAboveDelegate CallWhenPacketArrivesFromTransportLayer = null;
            internal NetworkPacketFromBelowDelegate CallWhenPacketArrivesFromLogicalLinkLayer = null;
            internal NetworkCallbackDelegate CallWhenCallback = null;
            internal NetworkInitialiseDelegate CallWhenInitialise = null;
            internal NetworkShutdownDelegate CallWhenShutdown = null;
        }
        internal NetworkDelegates NetworkFunctions = new NetworkDelegates();

        internal delegate void LogicalLinkPacketFromAboveDelegate(cPacket packet, int Destination);
        internal delegate void LogicalLinkPacketFromBelowDelegate(cPacket packet, int Source);
        internal delegate void LogicalLinkCallbackDelegate(int A, cPacket packet = null);
        internal delegate void LogicalLinkInitialiseDelegate(double A, double B, double C, double D);
        internal delegate void LogicalLinkShutdownDelegate();

        internal class LogicalLinkDelegates
        {
            internal LogicalLinkPacketFromAboveDelegate CallWhenPacketArrivesFromNetworkLayer = null;
            internal LogicalLinkPacketFromBelowDelegate CallWhenPacketArrivesFromMACLayer = null;
            internal LogicalLinkCallbackDelegate CallWhenCallback = null;
            internal LogicalLinkInitialiseDelegate CallWhenInitialise = null;
            internal LogicalLinkShutdownDelegate CallWhenShutdown = null;
        }
        internal LogicalLinkDelegates LogicalLinkFunctions = new LogicalLinkDelegates();

        internal delegate void MACPacketFromAboveDelegate(cPacket packet, int NextHop);
        internal delegate void MACPacketFromBelowDelegate(cPacket packet, double RxPower);
        internal delegate void MACCallbackDelegate(int A, cPacket packet = null);
        internal delegate void MACInitialiseDelegate(double A, double B, double C, double D, double E, double F, double G);
        internal delegate void MACShutdownDelegate();

        internal class MACDelegates
        {
            internal MACPacketFromAboveDelegate CallWhenPacketArrivesFromLogicalLinkLayer = null;
            internal MACPacketFromBelowDelegate CallWhenPacketArrivesFromPhysicalLayer = null;
            internal MACCallbackDelegate CallWhenCallback = null;
            internal MACInitialiseDelegate CallWhenInitialise = null;
            internal MACShutdownDelegate CallWhenShutdown = null;
        }
        internal MACDelegates MACFunctions = new MACDelegates();

        internal cNode(Canvas where, double newX, double newY)
        {
            this.nodeNumber = Globals.myNodes.Count;
            this.whereAmI = where;
            // Set up the location:
            Position.X = newX; Position.Y = newY;
            TargetPosition.X = Position.X;  TargetPosition.Y = Position.Y;
            
            // Create and display the visual image:
            ellNode = new Ellipse();
            ellNode.HorizontalAlignment = System.Windows.HorizontalAlignment.Left;
            ellNode.VerticalAlignment = System.Windows.VerticalAlignment.Top;
            ellNode.Width = 10;
            ellNode.Height = 10;
            ellNode.Fill = Globals.NodeDefaultBrush;
            ellNode.Stroke = Globals.NodeInvisibleBrush;
            Grid.SetZIndex(ellNode, Globals.Z_NodeEllipse);
            where.Children.Add(ellNode);
            ellNode.MouseDown += new MouseButtonEventHandler(ellNode_MouseDown);
            ellNode.MouseEnter += new System.Windows.Input.MouseEventHandler(ellNode_MouseEnter);
            ellNode.MouseLeave += new MouseEventHandler(ellNode_MouseLeave);

            tbNumberName = new TextBlock();
            tbNumberName.Text = this.nodeNumber.ToString();
            tbNumberName.Foreground = Globals.TextBlackBrush;
            tbNumberName.Opacity = 0.5;
            tbNumberName.Visibility = Globals.ShowNumbers ? Visibility.Visible : Visibility.Hidden;
            Grid.SetZIndex(tbNumberName, Globals.Z_NodeEllipse);
            where.Children.Add(tbNumberName);

            // Place ellipse and node number on the screen:
            Replace();

            // Also, put the big range ellipses on the screen:
            ellRxRange = new Ellipse();
            Canvas.SetLeft(ellRxRange, Canvas.GetLeft(ellNode) - 80);
            Canvas.SetTop(ellRxRange, Canvas.GetTop(ellNode) - 80);
            ellRxRange.Width = 160; ellRxRange.Height = 160;
            ellRxRange.HorizontalAlignment = HorizontalAlignment.Left;
            ellRxRange.VerticalAlignment = VerticalAlignment.Top;
            ellRxRange.Opacity = 0.3;
            ellRxRange.Visibility = Visibility.Hidden;
            ellRxRange.Fill = Globals.RangeDefaultBrush;
            ellRxRange.Stroke = Globals.RangeDefaultBrush;
            Grid.SetZIndex(ellRxRange, Globals.Z_ReceiveRange);
            where.Children.Add(ellRxRange);
            ellRxRange.MouseEnter += new System.Windows.Input.MouseEventHandler(ellRange_MouseEnter);
            ellRxRange.MouseLeave += new MouseEventHandler(ellRange_MouseLeave);

            ellDetectRange = new Ellipse();
            Canvas.SetLeft(ellDetectRange, Canvas.GetLeft(ellNode) - 80);
            Canvas.SetTop(ellDetectRange, Canvas.GetTop(ellNode) - 80);
            ellDetectRange.Width = 160; ellDetectRange.Height = 160;
            ellDetectRange.HorizontalAlignment = HorizontalAlignment.Left;
            ellDetectRange.VerticalAlignment = VerticalAlignment.Top;
            ellDetectRange.Opacity = 0.1;
            ellDetectRange.Visibility = Visibility.Hidden;
            ellDetectRange.Fill = Globals.RangeDefaultBrush;
            ellDetectRange.Stroke = Globals.RangeDefaultBrush;
            Grid.SetZIndex(ellDetectRange, Globals.Z_DetectRange);
            where.Children.Add(ellDetectRange);

            // And there's a polyline that can trace out the path of a routed packet:
            polylinePath = new Polyline();
            polylinePath.Stroke = Globals.NodePolyLinePathBrush;
            polylinePath.StrokeThickness = 1;
            polylinePath.Visibility = Visibility.Hidden;
            polylinePath.Points.Clear();
            Grid.SetZIndex(polylinePath, Globals.Z_PacketRoute);
            where.Children.Add(polylinePath);

            // and simple lines that can connect a node to its parent:
            lineMACParent = new Line();
            lineMACParent.Stroke = Globals.NodeLineMACParentBrush;
            lineMACParent.StrokeThickness = 1;
            lineMACParent.Visibility = Visibility.Hidden;
            Grid.SetZIndex(lineMACParent, Globals.Z_MACParents);
            where.Children.Add(lineMACParent);

            lineLLCParent = new Line();
            lineLLCParent.Stroke = Globals.NodeLineLLCParentBrush;
            lineLLCParent.StrokeThickness = 1;
            lineLLCParent.Visibility = Visibility.Hidden;
            Grid.SetZIndex(lineLLCParent, Globals.Z_LLCParents);
            where.Children.Add(lineLLCParent);

            // Finally, initialise the node:
            Initialise();
        }
        internal void DestroyNode()
        {
            // Remove any existing events pertaining to this node:
            Globals.theQueue.RemoveNode(this.nodeNumber);
            // Remove all the visible bits of the node:
            this.whereAmI.Children.Remove(ellNode);
            this.whereAmI.Children.Remove(tbNumberName);
            this.whereAmI.Children.Remove(ellRxRange);
            this.whereAmI.Children.Remove(ellDetectRange);
            this.whereAmI.Children.Remove(polylinePath);
            this.whereAmI.Children.Remove(lineMACParent);
            this.whereAmI.Children.Remove(lineLLCParent);
        }

        internal void SetNumberVisibility(Boolean vis)
        {
            tbNumberName.Visibility = vis ? Visibility.Visible : Visibility.Hidden;
        }

        internal void ellNode_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (Globals.SelectedNode == this.nodeNumber)
            {
                ellNode.Stroke = Globals.NodeInvisibleBrush;
                Globals.SelectedNode = Globals.NOWHERE;
            }
            else if (Globals.SelectedNode == Globals.NOWHERE)
            {
                ellNode.Stroke = Globals.NodeSelectedBrush;
                Globals.SelectedNode = this.nodeNumber;
                if (Globals.ShowRoutes) ShowRouteingLines(0.5);
            }
            else
            {
                ellNode.Stroke = Globals.NodeSelectedBrush;
                Globals.myNodes[Globals.SelectedNode].ellNode.Stroke = Globals.NodeInvisibleBrush;
                Globals.SelectedNode = this.nodeNumber;
                if (Globals.ShowRoutes) ShowRouteingLines(0.5);
            }
        }

        private void ellNode_MouseLeave(object sender, MouseEventArgs e)
        {
            MouseOnThisNode = false;
            ClearRouteingLines();
            ((MainWindow)Globals.MainWindow).SetDefaultNodeInfoBox(Globals.NOWHERE);

            if (Globals.ShowParents == true)
            {
                for (int loop = 0; loop < Globals.NumberOfNodes; loop++)
                {
                    Globals.myNodes[loop].ShowParentLine(0.5, true);
                    Globals.myNodes[loop].ShowParentLine(0.5, false);
                }
            }
        }
        internal void ClearRouteingLines()
        {
            // Delete any routeing lines that might be hanging around:
            for (int loop = 0; loop < Globals.RouteLines.Count; loop++)
                Globals.NodeCanvas.Children.Remove(Globals.RouteLines[loop]);
            Globals.RouteLines.Clear();
            GUIBits.ClearDisplayLines();
        }
        private void ellNode_MouseEnter(object sender, System.Windows.Input.MouseEventArgs e)
        {
            // What to do is the mouse is put over the node: print the details
            // about this node in the txtInfoBox (not the floating one).
            ((MainWindow)Globals.MainWindow).SetDefaultNodeInfoBox(nodeNumber);
            MouseOnThisNode = true;

            // Now, if ShowRoutes is enabled, plot a series of lines showing all the routes 
            // away from this node, by searching through the routeing tables of all the nodes.
            ClearRouteingLines();
            if (Globals.ShowRoutes == true) ShowRouteingLines(1.0);

            // If ShowParents is enabled, then turn off all lines except those from nodes that
            // share the same tree branch as this one (in other words, look down the tree, and
            // up to the central node, but that's all:
            if (Globals.ShowParents == true)
            {
                SetParentLines(true);
                SetParentLines(false);
            }
        }
        private void SetParentLines(Boolean isMACLayer)
        {
            List<int> toShow = new List<int>();
            toShow.Add(nodeNumber);
            // Do the stuff going up to the root from this one:
            int whenToGiveUp = 20;
            int currentNode = this.nodeNumber;
            bool finished = false;
            while (whenToGiveUp-- > 0 && finished == false)
            {
                int previousGeneration;
                if (isMACLayer) previousGeneration = Globals.myNodes[currentNode].GetMACParent();
                else previousGeneration = Globals.myNodes[currentNode].GetMACParent();
                if (previousGeneration == Globals.NOWHERE || toShow.Contains(previousGeneration))
                {
                    finished = true;
                }
                else
                {
                    currentNode = previousGeneration;
                    toShow.Add(currentNode);
                }
            }

            for (int loop = 0; loop < Globals.NumberOfNodes; loop++)
            {
                // For each node, check to see if this node is on its route:
                whenToGiveUp = 20;
                currentNode = loop;
                finished = false;
                while (whenToGiveUp-- > 0 && finished == false)
                {
                    int previousGeneration;
                    if (isMACLayer) previousGeneration = Globals.myNodes[currentNode].GetMACParent();
                    else previousGeneration = Globals.myNodes[currentNode].GetLLCParent();
                    if (previousGeneration == Globals.NOWHERE)
                    {
                        finished = true;
                    }
                    else
                    {
                        currentNode = previousGeneration;
                        if (currentNode == nodeNumber) toShow.Add(loop);
                    }
                }
            }
            // and if so, show the parent lines:
            for (int loop = 0; loop < Globals.NumberOfNodes; loop++)
            {
                if (toShow.Contains(loop))
                {
                    Globals.myNodes[loop].ShowParentLine(0.5, isMACLayer);
                }
                else Globals.myNodes[loop].ClearParentLine(isMACLayer);
            }
        }
        internal void ShowRouteingLines(double opacity)
        {
            // First of all, clear the current routeing lines:
            ClearRouteingLines();
            // If there is a selected node and the mouse is on a different node,
            // then only plot the routes to and from the selected node to this node:
            if (Globals.SelectedNode != nodeNumber && Globals.SelectedNode != Globals.NOWHERE
                && MouseOnThisNode == true)
            {
                ShowRouteingLine(Globals.SelectedNode, nodeNumber, Globals.LineRouteFromBrush, opacity, Globals.Z_RoutesAway);
                ShowRouteingLine(nodeNumber, Globals.SelectedNode, Globals.LineRouteToBrush, opacity, Globals.Z_RoutesTo);
            }
            else // otherwise, show all of them:
            {
                for (int dest = 0; dest < Globals.NumberOfNodes; dest++)
                {
                    if (dest != nodeNumber)
                    {
                        ShowRouteingLine(nodeNumber, dest, Globals.LineRouteFromBrush, opacity, Globals.Z_RoutesAway);
                        ShowRouteingLine(dest, nodeNumber, Globals.LineRouteToBrush, opacity, Globals.Z_RoutesTo);
                    }
                }
            }
        }
        private void ShowRouteingLine(int start, int finish, SolidColorBrush brush, double opacity, int zLevel)
        {
            // First, find out whether the routeing table contains the next hop, or the whole route:
            List<int> storedRoute = Globals.myNodes[start].NetworkLayer.LookUpRoute(finish);
            int firstHop = Globals.myNodes[start].NetworkLayer.LookupNextHop(finish);
            if (storedRoute == null && firstHop == Globals.NOWHERE)
            {
                // There is no route in the routeing table at all.
                // Just draw a dotted line to the destination and return.
                GUIBits.DrawDisplayLine(start, finish, brush, true, opacity, zLevel);
                return;
            }

            // If there is a route, then go through that route putting in lines:
            if (storedRoute != null)
            {
                int currentlyAt = start;
                for (int loop = 0; loop < storedRoute.Count; loop++)
                {
                    int nextHop = storedRoute[loop];
                    GUIBits.DrawDisplayLine(currentlyAt, nextHop, brush, false, opacity, zLevel);
                    currentlyAt = nextHop;
                }
                if (currentlyAt != finish)
                {
                    GUIBits.DrawDisplayLine(currentlyAt, finish, brush, true, opacity, zLevel);
                }
            }

            else // otherwise, it's a series of next hops.
            {
                // If it's a series of next hops, then there could be a loop, so I need to detect this:
                List<int> route = new List<int>();
                Boolean loopDetected = false;
                int currentlyAt = start;
                route.Add(start);
                // Then plotting the route from start to finish (note this routine gives up after plotting
                // Globals.MaximumHopsToPlot hops, just in case anything silly has happened. 
                int hopsPlotted = 0;
                while (currentlyAt != finish && hopsPlotted < Globals.MaximumHopsToPlot && loopDetected == false)
                {
                    // Get the next hop.
                    int nextHop = Globals.myNodes[currentlyAt].NetworkLayer.LookupNextHop(finish);

                    // If this is already in the route, there's a routeing loop here.
                    // Stop, and draw a dotted red line to the destination.
                    for (int loop = 0; loop < route.Count; loop++)
                    {
                        if (route[loop] == nextHop)
                        {
                            GUIBits.DrawDisplayLine(currentlyAt, finish, Globals.LineRouteLoopBrush, true, opacity, zLevel);
                            loopDetected = true;
                            continue;
                        }
                    }
                    if (loopDetected == true) continue;
                    // If there's a sensible next hop from here, draw the line then move to next hop:
                    if (nextHop != Globals.NOWHERE && nextHop != Globals.BROADCAST)
                    {
                        route.Add(nextHop);
                        GUIBits.DrawDisplayLine(currentlyAt, nextHop, brush, false, opacity, zLevel);
                        currentlyAt = nextHop;
                        hopsPlotted++;
                    }
                    else
                    {
                        // No route in routeing table, go straight to destination with a dotted line:
                        route.Add(finish);
                        GUIBits.DrawDisplayLine(currentlyAt, finish, brush, true, opacity, zLevel);
                        currentlyAt = finish; // Break out of loop
                        continue;
                    }
                }
            }
        }
        internal void ShowParentLine(double opacity, Boolean isMACLayer)
        {
            if (isMACLayer && (myMACParent == Globals.NOWHERE || myMACParent >= Globals.NumberOfNodes)) return;
            if (!isMACLayer && (myLLCParent == Globals.NOWHERE || myLLCParent >= Globals.NumberOfNodes)) return;

            int myParent = isMACLayer ? myMACParent : myLLCParent;
            Line thisLine = isMACLayer ? lineMACParent : lineLLCParent;
            thisLine.X1 = Canvas.GetLeft(this.ellNode) + this.ellNode.Width / 2;
            thisLine.Y1 = Canvas.GetTop(this.ellNode) + this.ellNode.Height / 2;
            thisLine.X2 = Canvas.GetLeft(Globals.myNodes[myParent].ellNode)
                + Globals.myNodes[myParent].ellNode.Width / 2;
            thisLine.Y2 = Canvas.GetTop(Globals.myNodes[myParent].ellNode)
                + Globals.myNodes[myParent].ellNode.Height / 2;
            thisLine.Opacity = opacity;
            thisLine.Visibility = Visibility.Visible;
        }
        internal void ClearParentLine(Boolean isMACLayer)
        {
            if (isMACLayer) lineMACParent.Visibility = Visibility.Hidden;
            else lineLLCParent.Visibility = Visibility.Hidden;
        }
        internal string NodeInfo()
        {
            StringBuilder text = new StringBuilder(1024);
            text.Append("Node " + nodeNumber.ToString() + " at ");
            text.Append("(" + (Position.X * 100).ToString("0.00") + ", "
                            + (Position.Y * 100).ToString("0.00") + ")\n");
            if (TransmitState == Globals.TransmitterState.Off) text.Append("Tx Off : ");
            if (TransmitState == Globals.TransmitterState.Transmitting) text.Append("Tx Transmitting : ");
            if (ReceiveState == Globals.ReceiverState.Asleep) text.Append("Rx Asleep\n");
            if (ReceiveState == Globals.ReceiverState.Detecting) text.Append("Rx Detecting\n");
            if (ReceiveState == Globals.ReceiverState.Colliding) text.Append("Rx Colliding\n");
            if (ReceiveState == Globals.ReceiverState.Listening) text.Append("Rx Listening\n");
            if (ReceiveState == Globals.ReceiverState.Receiving) text.Append("Rx Receiving\n");
            switch (Globals.EnergyMode)
            {
                case Globals.EnergyType.Countdown:
                    text.Append("Energy left " + GetEnergyLeft().ToString("0.00") + "\n");
                    break;
                case Globals.EnergyType.Addup:
                    text.Append("Energy used " + GetEnergyUsed().ToString("0.00") + "\n");
                    break;
                case Globals.EnergyType.Down_Not_Zero:
                    if (nodeNumber == 0)
                        text.Append("Energy used " + GetEnergyUsed().ToString("0.00") + "\n");
                    else
                        text.Append("Energy left " + GetEnergyLeft().ToString("0.00") + "\n");
                    break;
                default:
                    MessageBox.Show("Odd - unknown energy mode", "Serious error");
                    break;
            }
            text.Append("Tx channel " + transmitChannel.ToString() + "; Rx channel " + receiveChannel.ToString() + "\n");
            text.Append("Packets: sent " + nodePacketsSent.ToString() + " received " + nodePacketsReceived.ToString() + "\n");
            text.Append("Queued: " + TransportLayer.GetQueueLength().ToString() + " : "
                                    + NetworkLayer.GetQueueLength().ToString() + " : "
                                    + LogicalLinkLayer.GetQueueLength().ToString() + " : "
                                    + MACLayer.GetQueueLength().ToString());
            return text.ToString();
        }

        private void ellRange_MouseLeave(object sender, MouseEventArgs e)
        {
            polylinePath.Visibility = Visibility.Hidden;
            // And set the nodes back to a sensible colour:
            if (PacketBeingTransmitted == null) return; // Something's gone wrong if this happens.
            int source = PacketBeingTransmitted.MetaInformation().GetOriginalSource();
            int destination = PacketBeingTransmitted.MetaInformation().GetFinalDestination();
            if (source != Globals.NOWHERE) Globals.myNodes[source].SetNodeColour(false);
            if (destination != Globals.NOWHERE && destination != Globals.BROADCAST)
              Globals.myNodes[destination].SetNodeColour(false);
            ((MainWindow)Globals.MainWindow).txtInfoBox.Text = "";
        }
        private void ellRange_MouseEnter(object sender, System.Windows.Input.MouseEventArgs e)
        {
            if (PacketBeingTransmitted == null) return; // Something's gone wrong if this happens.

            // What to do is the mouse is put over the packet on the screen: print the
            // details about the packet in the txtInfoBox (not the floating one).
            StringBuilder text = new StringBuilder(1024);
            // Now fill up the text and turn it on:
            text.Append("Packet " + PacketBeingTransmitted.MetaInformation().GetTag().ToString() + "\n");
            int source = PacketBeingTransmitted.MetaInformation().GetOriginalSource();
            int destination = PacketBeingTransmitted.MetaInformation().GetFinalDestination();
            if (destination == Globals.BROADCAST)
                text.Append("Source " + source.ToString() + ", Destination BROADCAST\n");
            else if (destination == Globals.NOWHERE && PacketBeingTransmitted.MetaInformation().GetNextHop() == Globals.BROADCAST)
                text.Append("Source " + source.ToString() + ", Packet Broadcast.\n");
            else if (destination == Globals.NOWHERE)
                text.Append("Source " + source.ToString() + ", Destination unknown.\n");
            else
                text.Append("Source " + source.ToString() + ", Destination " + destination.ToString() + "\n");
            double TransmitPower = PacketBeingTransmitted.MetaInformation().GetTransmitPower();
            TransmitPower = Math.Round((30 + 10 * Math.Log10(TransmitPower)) * 100) / 100;
            text.Append("Transmit Power " + TransmitPower + " dBm\n");
            text.Append("Channel " + PacketBeingTransmitted.MetaInformation().GetChannel() + "\n");
            List<int> Route = PacketBeingTransmitted.MetaInformation().GetRoute();
            text.Append("Route: ");
            for (int loop = 0; loop < Route.Count; loop++) text.Append(Route[loop].ToString() + "-");
            text.Remove(text.Length - 1, 1);  // Remove the last "-" from the Route
            
            ((MainWindow)Globals.MainWindow).txtInfoBox.Text = text.ToString();

            // Also, colour in the source and destination nodes of packet:
            if (source != Globals.NOWHERE) Globals.myNodes[source].ColourNode(Globals.NodeAsSourceBrush);
            if (destination != Globals.NOWHERE && destination != Globals.BROADCAST) // it might be broadcast...
                Globals.myNodes[destination].ColourNode(Globals.NodeAsDestinationBrush);
            // And set-up the polylinePath to go around the path the packet has taken,
            // so far (including the next hop), then turn it on:
            polylinePath.Points.Clear();
            foreach (int NodeNumber in PacketBeingTransmitted.MetaInformation().GetRoute())
            {
                if (NodeNumber >= 0 && NodeNumber < 100) // i.e. it's not NOWHERE or BROADCAST
                {
                    Point thisPoint = Globals.myNodes[NodeNumber].GetLocationOnScreen();
                    polylinePath.Points.Add(thisPoint);
                }
            }
            polylinePath.Visibility = Visibility.Visible;
        }

        internal void Replace()
        {
            // Move the node:
            Canvas.SetLeft(ellNode, Globals.GridCentre.X + Position.X * Globals.GridSize.Width / 2.0 - ellNode.Width / 2.0);
            Canvas.SetTop(ellNode, Globals.GridCentre.Y - Position.Y * Globals.GridSize.Height / 2.0 - ellNode.Height / 2.0);
            Canvas.SetLeft(tbNumberName, Globals.GridCentre.X + Position.X * Globals.GridSize.Width / 2.0 + 2);
            Canvas.SetTop(tbNumberName, Globals.GridCentre.Y - Position.Y * Globals.GridSize.Height / 2.0 + 2);
        }
        internal Point GetLocationOnScreen()
        {
            return new Point(Canvas.GetLeft(ellNode) + ellNode.Width/2.0, Canvas.GetTop(ellNode) + ellNode.Height/2.0);
        }
        private void AddRangeCircles(double receiveRange, double detectRange, Visibility show)
        {
            // Add the large receive range circle around the node, with specified diameter
            ellRxRange.Width = receiveRange * Globals.GridSize.Width;
            ellRxRange.Height = receiveRange * Globals.GridSize.Height;
            Canvas.SetLeft(ellRxRange, Globals.GridCentre.X + (Position.X - receiveRange) * Globals.GridSize.Width / 2.0);
            Canvas.SetTop(ellRxRange, Globals.GridCentre.Y - (Position.Y + receiveRange) * Globals.GridSize.Height / 2.0);
            ellRxRange.Visibility = show;
            // Add the even larger detection range circle around the node, with specified diameter
            ellDetectRange.Width = detectRange * Globals.GridSize.Width;
            ellDetectRange.Height = detectRange * Globals.GridSize.Height;
            Canvas.SetLeft(ellDetectRange, Globals.GridCentre.X + (Position.X - detectRange) * Globals.GridSize.Width / 2.0);
            Canvas.SetTop(ellDetectRange, Globals.GridCentre.Y - (Position.Y + detectRange) * Globals.GridSize.Height / 2.0);
            ellDetectRange.Visibility = show;
        }
        private void MoveRangeCircles()
        {
            // This is purely a GUI thing, so is only done if animations are on,
            // which means this is not done in batch mode.
            if (Globals.Animate == false) return;

            double receiveRange = ellRxRange.Width / Globals.GridSize.Width;
            Canvas.SetLeft(ellRxRange, Globals.GridCentre.X + (Position.X - receiveRange) * Globals.GridSize.Width / 2.0);
            Canvas.SetTop(ellRxRange, Globals.GridCentre.Y - (Position.Y + receiveRange) * Globals.GridSize.Height / 2.0);
            double detectRange = ellDetectRange.Width / Globals.GridSize.Width;
            Canvas.SetLeft(ellDetectRange, Globals.GridCentre.X + (Position.X - detectRange) * Globals.GridSize.Width / 2.0);
            Canvas.SetTop(ellDetectRange, Globals.GridCentre.Y - (Position.Y + detectRange) * Globals.GridSize.Height / 2.0);
        }
        internal void UpdateIfMoved()
        {
            // This is purely a GUI thing, so is only done if animations are on,
            // which means this is not done in batch mode.
            if (Globals.Animate == false) return;

            if (TransmitState == Globals.TransmitterState.Transmitting) MoveRangeCircles();
            if (MouseOnThisNode == true)
            {
                ellNode_MouseLeave(null, null);
                ellNode_MouseEnter(null, null);
            }
        }
        private void ColourNode(SolidColorBrush NewColour)
        {
            ellNode.Fill = NewColour;
        }
        internal void ResetNode()
        {
            if (TransportLayer != null) TransportFunctions.CallWhenShutdown();
            if (NetworkLayer != null) NetworkFunctions.CallWhenShutdown();
            if (LogicalLinkLayer != null) LogicalLinkFunctions.CallWhenShutdown();
            if (MACLayer != null) MACFunctions.CallWhenShutdown();
            SetTransmitState(Globals.TransmitterState.Off, 0.0, null, 0);
            SetReceiveState(Globals.ReceiverState.Listening, null, 0.0, 0.0, false);
        }

        public override string ToString()
        {
            string thing = "Node " + nodeNumber.ToString();
            thing += " at (" + Position.X.ToString("0.00") + "," + Position.Y.ToString("0.00") + ")";
            thing += " energy used " + GetEnergyUsed().ToString();
            return thing;
        }
        internal string GetStatusString()
        {
            // There must be a better way to do this, surely:
            string nodeString = String.Format("{0, 4:0}", this.nodeNumber);
            string XlocString = String.Format("{0, 6:0.00}", (this.Position.X * 100));
            string YlocString = String.Format("{0, 6:0.00}", (this.Position.Y * 100));
            string sentString = String.Format("{0, 6:0}", this.GetPacketsSent());
            string receivedString = String.Format("{0, 6:0}", this.GetPacketsReceived());
            string energyString = String.Format("{0, 6:0.000}", this.GetEnergyLeft());
            if (Globals.EnergyMode == Globals.EnergyType.Addup
                || (Globals.EnergyMode == Globals.EnergyType.Down_Not_Zero && nodeNumber == 0))
                energyString = String.Format("{0, 6:0.000}", this.GetEnergyUsed());

            return(nodeString + "\t" + XlocString + "\t" + YlocString + "\t"
                + sentString + "\t" + receivedString + "\t" + energyString);
        }

        // Updating the state of the node, and calculating the energy:
        internal void SetTransmitState(Globals.TransmitterState Tx, double TxPower, cPacket packet, long whenFinished)
        {
            UpdateEnergy();
            this.TransmitState = Tx;
            Globals.TxActivity txActivity = new Globals.TxActivity(Tx);
            if (packet != null)
            {
                txActivity.packetTag = packet.MetaInformation().GetTag();
                txActivity.txPower = packet.MetaInformation().GetTransmitPower();
            }
            TxHistory.Add(txActivity);

            CurrentTransmitPower = TxPower;
            this.PacketBeingTransmitted = packet;
            this.WhenCurrentTxFinishes = whenFinished;

            // I store the time when the transmitter last became idle in case user wants to
            // wait for the transmitter to be idle for a fixed period:
            if (Tx == Globals.TransmitterState.Off)
                this.MACCallbackTimeWhenChannelLastBecameClear = GetTime();

            if (MACCallbackWhenTransmitterIdle == true && Tx == Globals.TransmitterState.Off)
            {
                // Callback requested when channel becomes clear, and that's just happened.
                if (MACCallbackWhenTransmitterIdleForPeriod == 0)
                {
                    Globals.theQueue.AddEvent(new cEvent(this, null, (long)(this.GetTime()),
                        EventType.MAC_Callback, MACCallbackWhenTransmitterIdleIndex));
                }
                else
                {
                    Globals.theQueue.AddEvent(new cEvent(this, null, (long)(this.GetTime()
                    + MACCallbackWhenTransmitterIdleForPeriod), EventType.Node_WaitForTxIdle,
                    MACCallbackWhenTransmitterIdleIndex));
                }
                // Reset flag so it doesn't happen again (unless set to happen again)
                MACCallbackWhenTransmitterIdle = false;
            }

            // Also, if animating, calculate size of big range circle, and draw it on the screen.
            if (Globals.Animate == false) return;
            if (Tx == Globals.TransmitterState.Off)
            {
                this.AddRangeCircles(0, 0, Visibility.Hidden);
                SetNodeColour(false); // Set colour based on rx state
            }
            else
            {
                // First thing to do is work out the size of the "can be received in" circle,
                // based on the modulation and coding scheme being used:
                double bitRate = packet.MetaInformation().GetBitRate();
                double SINRrequired = Globals.GetRequiredSINR(packet);

                double receiveRange = Globals.GetReceiveRangeFromTransmitPower(TxPower, SINRrequired);
                double detectRange = Globals.GetDetectRangeFromTransmitPower(TxPower);
                this.AddRangeCircles(receiveRange / 100, detectRange / 100, Visibility.Visible);
                this.ColourNode(Globals.NodeTransmittingBrush);
            }
        }
        internal void SetReceiveState(Globals.ReceiverState Rx, cPacket packet, double SINR, double packetPower, Boolean success)
        {
            UpdateEnergy();
            // If this is a new receive starting, start a new list of SINRs and set the
            // packet being received store.  If it's not receiving or colliding, then
            // the channel must have gone too quiet, so set packet being received to null.
            if (Rx == Globals.ReceiverState.Receiving
                    && packet != this.PacketBeingReceived)
            {
                this.PacketBeingReceived = packet;
                this.PacketBeingReceivedPower = packetPower;
                SINRHistory.Clear();
                SINRHistory.Add(new Globals.ReceiveSINRHistoryItem(SINR));
            }
            else if (Rx == Globals.ReceiverState.Receiving || Rx == Globals.ReceiverState.Colliding)
            {
                if (packet == this.PacketBeingReceived)
                    SINRHistory.Add(new Globals.ReceiveSINRHistoryItem(SINR));
            }
            else
            {
                this.PacketBeingReceived = null;
            }
            // OK, go ahead and set the new receive state:
            this.ReceiveState = Rx;
            Globals.RxActivity rxActivity = new Globals.RxActivity(Rx);
            rxActivity.success = success;
            // Do string copy in case receiver modifies the tag before resending
            // the packet, rather than generating a new packet: this happens for 
            // example in on-demand routeing.
            if (packet != null)
            {
                rxActivity.packetTag = string.Copy(packet.MetaInformation().GetTag());
                rxActivity.excessSINR = SINR / Globals.GetRequiredSINR(packet);
            }
            RxHistory.Add(rxActivity);
            
            // I store the time when the channel last became clear in case user wants to
            // wait for the channel to become clear for a fixed period:
            if (Rx == Globals.ReceiverState.Listening)
                this.MACCallbackTimeWhenChannelLastBecameClear = GetTime();

            if (MACCallbackWhenChannelClear == true && Rx == Globals.ReceiverState.Listening)
            {
                // Callback requested when channel becomes clear, and that's just happened:
                if (MACCallbackWhenChannelClearForPeriod == 0)
                {
                    Globals.theQueue.AddEvent(new cEvent(this, null, (long)(this.GetTime()),
                        EventType.MAC_Callback, MACCallbackWhenChannelClearIndex));
                }
                else
                {
                    Globals.theQueue.AddEvent(new cEvent(this, null, (long)(this.GetTime()
                        + MACCallbackWhenChannelClearForPeriod), EventType.Node_WaitForRxIdle,
                        MACCallbackWhenChannelClearIndex));
                }

                // Reset flag so it doesn't happen again (unless set to happen again)
                MACCallbackWhenChannelClear = false;
            }
            if (Globals.Animate == true) SetNodeColour(false);
        }

        // This next one works out whether the current packet being received
        // was received correctly or not.  It uses the history of the SINR
        // during the reception of the packet to determine an approximate
        // bit error rate during the reception of the packet.  It's all a
        // bit of a bodge, I must replace this with something more accurate
        // when I get the time.
        internal Boolean PacketReceivedCorrectly()
        {
            // If nothing being received, it can't have worked:
            if (this.PacketBeingReceived == null) return false;
            if (this.SINRHistory.Count == 0) return false;

            // Then look through the history:
            long endTime = Globals.SimTime;
            double bitRate = this.PacketBeingReceived.MetaInformation().GetBitRate();
            double SINRrequired = Globals.GetRequiredSINR(this.PacketBeingReceived);
            double probSuccess = 1;
            for (int loop = this.SINRHistory.Count - 1; loop >= 0; loop--)
            {
                // If channel model is Cliff_Edge, then just prevent receiving
                // if at any time the SINR goes below the threshold.  Otherwise,
                // work out in terms of BER.

                // For this bit, how many bits were received?
                double bits = (endTime - SINRHistory[loop].time) / 1e9 * bitRate;
                // And what is the excess SINR?
                double excessSINR = SINRHistory[loop].SINR / SINRrequired;
                double prob = 1;
                if (Globals.ChannelStyle == Globals.ChannelType.Default)
                {
                    // What bit error rate does this excess SINR correspond to?
                    // (This uses an approximation to the Q-function)
                    double x = Math.Sqrt(2 * excessSINR * 4.725);
                    double ber = (1 - Math.Exp(-1.98 * x / Math.Sqrt(2)))
                        * Math.Exp(-0.5 * (x * x))
                        / (1.135 * Math.Sqrt(2 * 3.1415926) * x);
                    // So what's the probability that this part of the frame succeeded?
                    prob = Math.Pow((1 - ber), bits);
                }
                else if (Globals.ChannelStyle == Globals.ChannelType.Cliff_Edge)
                {
                    if (excessSINR < 1) prob = 0;
                }
                else
                {
                    Globals.ShowMessageBox("Unrecognised channel model", "Internal error");
                }
                // Get ready for the next bit:
                probSuccess *= prob;
                endTime = SINRHistory[loop].time;
            }
            // Got final probability now, I can work out if frame succeeded:
            return (Globals.rands.NextDouble() < probSuccess);
        }

        // The event handler that sorts out calling the MAC layer if the channel has
        // been clear for a certain time, or the transmitter has been idle for a
        // certain time.  (This is not easy to do at the MAC layer.)
        internal void EventHandler(cEvent thing)
        {
            if (thing.type == EventType.Node_WaitForTxIdle)
            {
                // Is transmitter still idle, and has it been idle for
                // the required time?  If so, callback the MAC layer.
                if (TransmitState == Globals.TransmitterState.Off
                    && (GetTime() - MACCallbackTimeWhenTransmitterLastBecameIdle
                    >= MACCallbackWhenTransmitterIdleForPeriod - 1))
                {
                    Globals.theQueue.AddEvent(new cEvent(this, null, (long)(this.GetTime()),
                        EventType.MAC_Callback, MACCallbackWhenTransmitterIdleIndex));
                }
                // If not, it must have become busy since the last time
                // it was found to be idle.  If it's still busy, start waiting again.
                else if (TransmitState != Globals.TransmitterState.Off)
                {
                    MACCallbackWhenTransmitterIdle = true;
                }
                // Otherwise it must have been busy for a short time and then 
                // become quiet again.  Try again and the earliest possible time:
                else
                {
                    long NextTimeToTry = MACCallbackTimeWhenTransmitterLastBecameIdle
                                            + MACCallbackWhenTransmitterIdleForPeriod;
                    if (NextTimeToTry < GetTime()) NextTimeToTry = GetTime();
                    Globals.theQueue.AddEvent(new cEvent(this, null, NextTimeToTry,
                        EventType.Node_WaitForTxIdle, MACCallbackWhenTransmitterIdleIndex));
                }
            }
            else if (thing.type == EventType.Node_WaitForRxIdle)
            {
                // Is transmitter still idle, and has it been idle for
                // the required time?  If so, callback the MAC layer.
                if (ReceiveState == Globals.ReceiverState.Listening
                    && (GetTime() - MACCallbackTimeWhenChannelLastBecameClear
                    >= MACCallbackWhenChannelClearForPeriod - 1))
                {
                    Globals.theQueue.AddEvent(new cEvent(this, null, (long)(this.GetTime()),
                        EventType.MAC_Callback, MACCallbackWhenChannelClearIndex));
                }
                // If not, it must have become busy since the last time
                // it was found to be idle.  If it's still busy, start waiting again:
                else if (ReceiveState != Globals.ReceiverState.Listening)
                {
                    MACCallbackWhenChannelClear = true;
                }
                // Otherwise it must have been busy for a very short time; try
                // waiting until the first possible time:
                else 
                {
                    long NextTimeToTry = MACCallbackTimeWhenChannelLastBecameClear
                                            + MACCallbackWhenChannelClearForPeriod;
                    if (NextTimeToTry < GetTime()) NextTimeToTry = GetTime();
                    Globals.theQueue.AddEvent(new cEvent(this, null, NextTimeToTry,
                        EventType.Node_WaitForRxIdle, MACCallbackWhenChannelClearIndex));
                }
            }
        }

        internal void SetNodeColour(Boolean Highlight)
        {
            // Sets the colour of the node.  Highlight takes priority,
            // then transmitting, then the receive state:
            switch (ReceiveState)
            {
                case Globals.ReceiverState.Asleep:
                    ColourNode(Globals.NodeAsleepBrush);
                    break;
                case Globals.ReceiverState.Listening:
                    ColourNode(Globals.NodeListeningBrush);
                    break;
                case Globals.ReceiverState.Detecting:
                    ColourNode(Globals.NodeDetectingBrush);
                    break;
                case Globals.ReceiverState.Receiving:
                    ColourNode(Globals.NodeReceivingBrush);
                    break;
                case Globals.ReceiverState.Colliding:
                    ColourNode(Globals.NodeCollisionBrush);
                    break;
            }
            if (TransmitState == Globals.TransmitterState.Transmitting)
                this.ColourNode(Globals.NodeTransmittingBrush);
            if (Highlight == true)
                this.ColourNode(Globals.NodeHighlightBrush);
        }
        internal void UpdateEnergy()
        {
            long TimeSinceLastEnergyUpdate = Globals.SimTime - WhenEnergyLastUpdated;
            WhenEnergyLastUpdated = Globals.SimTime;
            switch (ReceiveState)
            {
                case Globals.ReceiverState.Asleep:
                    EnergyUsedAsleep += TimeSinceLastEnergyUpdate / 1.0e9 * Globals.PowerWhenRxAsleep;
                    break;
                case Globals.ReceiverState.Off:
                    EnergyUsedRxOff += TimeSinceLastEnergyUpdate / 1.0e9 * Globals.PowerWhenRxOff;
                    break;
                case Globals.ReceiverState.Listening:
                case Globals.ReceiverState.Detecting:
                case Globals.ReceiverState.Colliding:
                    EnergyUsedListening += TimeSinceLastEnergyUpdate / 1.0e9 * Globals.PowerWhenRxListening;
                    break;
                case Globals.ReceiverState.Receiving:
                    EnergyUsedReceiving += TimeSinceLastEnergyUpdate / 1.0e9 * Globals.PowerWhenRxReceiving;
                    break;
                default:
                    MessageBox.Show("Unknown state for receiver in energy calculation.", "Serious Error");
                    break;
            }
            switch (TransmitState)
            {
                case Globals.TransmitterState.Off:
                    EnergyUsedTxOff += TimeSinceLastEnergyUpdate / 1.0e9 * Globals.PowerWhenTxOff;
                    break;
                case Globals.TransmitterState.Transmitting:
                    EnergyUsedTransmitting += TimeSinceLastEnergyUpdate / 1.0e9 
                        * (Globals.PowerWhenTransmittingOffset 
                            + Globals.PowerWhenTransmittingMultiplier * CurrentTransmitPower);
                    break;
                default:
                    MessageBox.Show("Unknown state for transmitter in energy calculation.", "Serious Error");
                    break;
            }
        }

        // If any event handler called at the nodes wants the local time, they can get
        // it from here:
        internal long GetTime()
        {
            return (long)(this.ClockOffset + Math.Round(Globals.SimTime * this.ClockSpeedFactor));
        }
        internal void SetTime(long desiredTime)
        {
            // This allows the user to set (or reset) the local clock.  It's a case of working
            // out what the ClockOffset must be...
            long currentTime = GetTime();
            long difference = desiredTime - currentTime;
            this.ClockOffset += difference;
        }
        // and if the system wants to convert a local time to the exact simulation time, it can be done:
        internal long ConvertLocalToGlobalTime(long nodetime)
        {
            return (long)((nodetime - this.ClockOffset) / this.ClockSpeedFactor);
        }
        internal long ConvertGlobalToLocalTime(long nodetime)
        {
            return (long)(this.ClockOffset + Math.Round(nodetime * this.ClockSpeedFactor));
        }

        internal void Initialise()
        {
            // You can only initialise a node at the start of the simulation.
            // Attempts to do otherwise will result in "event queued before the
            // current time" errors.  I'll just return: this is likely to only
            // happen if the number of nodes is changed at the end of a simulation
            // and it doesn't really matter in this case.
            if (Globals.SimTime > 0) return;

            // Initialise all the protocol layers at the node.  The application
            // and physical layers are easy, since there's only one option (for now):
            ApplicationLayerOne = new cApplication(this);
            PhysicalLayer = new cPhysical(this);

            // Now the four user-controllable layers.  This depends on what is
            // currently chosen as the layer.  I'll start with the transport layer:
            switch (Globals.TransportStyle)
            {
                case Globals.TransportType.Best_Effort:
                    TransportLayer = (cTransport)(new cBestEffortTransport(this, ref TransportFunctions));
                    break;
                case Globals.TransportType.Reliable:
                    TransportLayer = (cTransport)(new cReliableTransport(this, ref TransportFunctions));
                    break;
                case Globals.TransportType.User:
                    TransportLayer = (cTransport)(new cUserTransport(this, ref TransportFunctions));
                    break;
                default:
                    MessageBox.Show("Unknown Transport Protocol", "Serious Error");
                    break;
            }

            switch (Globals.NetworkStyle)
            {
                case Globals.NetworkType.Direct:
                    NetworkLayer = (cNetwork)(new cDirectRouteing(this, ref NetworkFunctions));
                    break;
                case Globals.NetworkType.Flooding:
                    NetworkLayer = (cNetwork)(new cFloodingRouteing(this, ref NetworkFunctions));
                    break;
                case Globals.NetworkType.Bellman_Ford:
                    NetworkLayer = (cNetwork)(new cSimpleBellmanFordRouteing(this, ref NetworkFunctions));
                    break;
                case Globals.NetworkType.On_Demand:
                    NetworkLayer = (cNetwork)(new cOnDemandRouteing(this, ref NetworkFunctions));
                    break;
                case Globals.NetworkType.User:
                    NetworkLayer = (cNetwork)(new cUserNetwork(this, ref NetworkFunctions));
                    break;
                default:
                    MessageBox.Show("Unknown Network Protocol", "Serious Error");
                    break;
            }

            switch (Globals.LogicalLinkStyle)
            {
                case Globals.LogicalLinkType.Best_Effort:
                    LogicalLinkLayer = (cLogicalLink)(new cBestEffortLLC(this, ref LogicalLinkFunctions));
                    break;
                case Globals.LogicalLinkType.Reliable:
                    LogicalLinkLayer = (cLogicalLink)(new cReliableLLC(this, ref LogicalLinkFunctions));
                    break;
                case Globals.LogicalLinkType.User:
                    LogicalLinkLayer = (cLogicalLink)(new cUserLLC(this, ref LogicalLinkFunctions));
                    break;
                default:
                    MessageBox.Show("Unknown Logical Link Protocol", "Serious Error");
                    break;
            }

            switch (Globals.MACStyle)
            {
                case Globals.MultipleAccessType.ALOHA:
                    MACLayer = (cMAC)(new cALOHA(this, ref MACFunctions));
                    break;
                case Globals.MultipleAccessType.CSMA:
                    MACLayer = (cMAC)(new cCSMA(this, ref MACFunctions));
                    break;
                case Globals.MultipleAccessType.Polling:
                    MACLayer = (cMAC)(new cPolling(this, ref MACFunctions));
                    break;
                case Globals.MultipleAccessType.User:
                    MACLayer = (cMAC)(new cUserMAC(this, ref MACFunctions));
                    break;
                default:
                    MessageBox.Show("Unknown MAC Protocol", "Serious Error");
                    break;
            }

            // If using individual clocks, calculate the starting offset and speed,
            // otherwise set to the global simulation clock.
            if (Globals.ClockSync == Globals.ClockSyncType.Global)
            {
                this.ClockSpeedFactor = 1.0;
                this.ClockOffset = 0;
            }
            else
            {
                this.ClockSpeedFactor = 1.0 + Globals.ClockAccuracy * (Globals.rands.NextDouble() - 0.5) * 2.0;
                this.ClockOffset = 1000 * (Globals.rands.Next((int)1e9));  // Sometime between zero and 1000 s
            }

            // Work out when this node is going to be woken up for the first time:
            long whenToSwitchOn = 0; // Global time when simulation starts
            switch (Globals.SwitchingOn)
            {
                case Globals.SwitchingOnType.Instant:
                    // This is the default, everyone wakes-up at the start.
                    break;
                case Globals.SwitchingOnType.Sequence:
                    // Wake up in sequence, taking the whole pre-roll time:
                    whenToSwitchOn = (long)(Globals.PrerollLength * 1e9 / Globals.NumberOfNodes 
                                                * this.nodeNumber);
                    break;
                case Globals.SwitchingOnType.Random:
                    // Wake up in a random order, but always wake node zero up
                    // at time zero:
                    if (this.nodeNumber != 0)
                    {
                        whenToSwitchOn = (long)(Globals.rands.NextDouble() 
                            * Globals.PrerollLength * 1e9);
                    }
                    break;
                default:
                    MessageBox.Show("Unknown switching-on scheme", "Serious Error");
                    break;
            }

            // Initialise all of these layers:
            localTimeWhenSwitchedOn = ConvertGlobalToLocalTime(whenToSwitchOn);
            Globals.theQueue.AddEvent(new cEvent(this, null, localTimeWhenSwitchedOn, EventType.Transport_Initialise));
            Globals.theQueue.AddEvent(new cEvent(this, null, localTimeWhenSwitchedOn, EventType.Network_Initialise));
            Globals.theQueue.AddEvent(new cEvent(this, null, localTimeWhenSwitchedOn, EventType.LogicalLink_Initialise));
            Globals.theQueue.AddEvent(new cEvent(this, null, localTimeWhenSwitchedOn, EventType.MAC_Initialise));

            // Set packets received to zero, and clear the histories:
            nodePacketsReceived = 0;
            TxHistory.Clear(); RxHistory.Clear(); SINRHistory.Clear();
            TxHistory.Add(new Globals.TxActivity(Globals.TransmitterState.Off));    
            RxHistory.Add(new Globals.RxActivity(Globals.ReceiverState.Listening));
        }
    }
}
