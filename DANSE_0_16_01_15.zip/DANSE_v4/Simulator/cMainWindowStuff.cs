﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Collections.Generic;
using System.IO;
using System.Windows.Documents;
using System.Text;
using Microsoft.Win32;
using System.Windows.Threading;
using System.Threading;
using System.Windows.Media.Imaging;

namespace DANSE_v4
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>

    public partial class MainWindow : Window
    {
        #region Region: Setting things up and initialising

        // Setup the Combo box that selects which nodes to store information for:
        private void SetUpLogWhichNodesCombo()
        {
            cmbLogNodes.Items.Clear();
            cmbLogNodes.Items.Add("All Nodes");
            cmbLogNodes.Items.Add("Node 0");
            cmbLogNodes.Items.Add("Node 0 and 1");
            cmbLogNodes.Items.Add("Packet 0");
            cmbLogNodes.Items.Add("Packet 0 and 1");
            cmbLogNodes.Items.Add("Packet Non-Zero");
            cmbLogNodes.Text = "All Nodes";
            cmbLogNodes.SelectedItem = 0;
        }

        // Setup all the controls on the "Setup Simulation" panel.
        List<GroupBox> mySetupGroups = new List<GroupBox>();
        private void SetUpControlsOnSimulationPanel()
        {
            double systemBoxWidth = (canvasSetup.Width - 80) / 3.0;
            double firstDown = 5.0;
            double gapBetween = 10.0;
            double firstLeft = 15.0;
            double secondLeft = 15 + systemBoxWidth + 25;
            double thirdLeft = 15 + 2 * (systemBoxWidth + 25);
            mySetupGroups.Clear();

            Point wherenext = new Point(firstLeft, firstDown);
            wherenext.Y += gbConfigs.Height + gapBetween;
            GroupBox SystemBox = SetupGroupBox("System", GetSystemControls(), wherenext, systemBoxWidth, 9);
            canvasSetup.Children.Add(SystemBox);
            mySetupGroups.Add(SystemBox);

            wherenext.X = secondLeft; wherenext.Y = firstDown;
            GroupBox ApplicationBox = SetupGroupBox("Application", GetApplicationControls(), wherenext, systemBoxWidth, 6);
            canvasSetup.Children.Add(ApplicationBox);
            mySetupGroups.Add(ApplicationBox);

            wherenext.X = thirdLeft; wherenext.Y = firstDown;
            GroupBox MovementBox = SetupGroupBox("Movement", GetMovementControls(), wherenext, systemBoxWidth, 3);
            canvasSetup.Children.Add(MovementBox);
            mySetupGroups.Add(MovementBox);

            wherenext.Y += MovementBox.Height + gapBetween;
            GroupBox ChannelBox = SetupGroupBox("Channel", GetChannelControls(), wherenext, systemBoxWidth, 1);
            canvasSetup.Children.Add(ChannelBox);
            mySetupGroups.Add(ChannelBox);

            wherenext = new Point(firstLeft, firstDown);
            GroupBox TransportBox = SetupGroupBox("Transport", GetTransportControls(), wherenext, systemBoxWidth, 7);
            canvasProtocols.Children.Add(TransportBox);
            mySetupGroups.Add(TransportBox);
            InitSelectedControls(Globals.ctsTransportStyle.theComboBox);

            wherenext.Y += TransportBox.Height + gapBetween;
            GroupBox LogicalLinkBox = SetupGroupBox("Logical Link", GetLogicalLinkControls(), wherenext, systemBoxWidth, 7);
            canvasProtocols.Children.Add(LogicalLinkBox);
            mySetupGroups.Add(LogicalLinkBox);
            InitSelectedControls(Globals.ctsLogicalLinkType.theComboBox);

            wherenext.X = secondLeft; wherenext.Y = firstDown;
            GroupBox NetworkBox = SetupGroupBox("Network", GetNetworkControls(), wherenext, systemBoxWidth, 9);
            canvasProtocols.Children.Add(NetworkBox);
            mySetupGroups.Add(NetworkBox);
            InitSelectedControls(Globals.ctsNetworkStyle.theComboBox);

            wherenext.X = thirdLeft; wherenext.Y = firstDown;
            GroupBox MACBox = SetupGroupBox("Multiple Access", GetMACControls(), wherenext, systemBoxWidth, 9);
            canvasProtocols.Children.Add(MACBox);
            mySetupGroups.Add(MACBox);
            InitSelectedControls(Globals.ctsMACStyle.theComboBox);

            wherenext.Y += MACBox.Height + gapBetween;
            GroupBox PhysicalBox = SetupGroupBox("Physical", GetPhysicalControls(), wherenext, systemBoxWidth, 5);
            canvasProtocols.Children.Add(PhysicalBox);
            mySetupGroups.Add(PhysicalBox);
        }

        private GroupBox SetupGroupBox(string name, List<UIElement> stuff, Point where, double width, double rows)
        {
            // Sets up the controls in a group box, and returns a pointer to the
            // GroupBox it creates.  The calling function can then look at the size of
            // this box, and decide whether it needs to be moved somewhere else.
            // Currently, boxes are one-third of the big grid across, and have a 
            // height that is 6 + 28 * the number of controls.
            double height = (rows + 1) * (Globals.CONTROLVOFFSETDELTA);
            GroupBox box = new GroupBox();
            box.Header = name;
            box.Width = width;
            box.Height = height;
            box.HorizontalAlignment = HorizontalAlignment.Left;
            box.VerticalAlignment = VerticalAlignment.Top;
            Canvas.SetLeft(box, where.X); Canvas.SetTop(box, where.Y);
            Canvas newCanvas = new Canvas();
            newCanvas.Width = box.Width; newCanvas.Height = box.Height;
            box.Content = newCanvas;
            foreach (UIElement uie in stuff) newCanvas.Children.Add(uie);
            return box;
        }
        private void InitSelectedControls(ComboBox thing)
        {
            if (thing.Items.Count > 1) thing.SelectedIndex = 2;
            thing.SelectedIndex = 1;
        }

        // Setup the shadow controls on the front page:
        private void SetUpShadowControls()
        {
            // First set up some default content for the strings:
            lblNodes.Content = Globals.stsSimulationLength.GetActualValue().ToString() + " nodes";
            lblSimLength.Content = Globals.stsSimulationLength.GetActualValue().ToString() + " s";
            // The nodes slider is mirrored on the front page:
            if (Globals.stsNumberOfNodes == null) return;
            sldNodes.Maximum = Globals.stsNumberOfNodes.theSlider.Maximum;
            sldNodes.Minimum = Globals.stsNumberOfNodes.theSlider.Minimum;
            sldNodes.Value = Globals.stsNumberOfNodes.theSlider.Value;
            // The simulation time is also mirrored on the front page:
            if (Globals.stsSimulationLength == null) return;
            sldSimLength.Maximum = Globals.stsSimulationLength.theSlider.Maximum;
            sldSimLength.Minimum = Globals.stsSimulationLength.theSlider.Minimum;
            sldSimLength.Value = Globals.stsSimulationLength.theSlider.Value;
        }

        // Setup the main animation grid and its border
        private void SetCanvasToRightSize(Canvas setCanvas, Canvas onCanvas)
        {
            setCanvas.HorizontalAlignment = HorizontalAlignment.Left;
            setCanvas.VerticalAlignment = VerticalAlignment.Top;
            Canvas.SetLeft(setCanvas, Middle(elliCanvasTop).X);
            Canvas.SetTop(setCanvas, Middle(elliCanvasTop).Y);
            setCanvas.Width = Canvas.GetLeft(elliCanvasBottom) - Canvas.GetLeft(elliCanvasTop);
            setCanvas.Height = Canvas.GetTop(elliCanvasBottom) - Canvas.GetTop(elliCanvasTop);
            setCanvas.ClipToBounds = true; // So all nodes and lines stay inside this Grid (even when outside)

            elliCanvasTop.Visibility = System.Windows.Visibility.Hidden;
            elliCanvasBottom.Visibility = System.Windows.Visibility.Hidden;

            setCanvas.Children.Clear();
            Rectangle BorderRect = new Rectangle();
            BorderRect.HorizontalAlignment = HorizontalAlignment.Left;
            BorderRect.VerticalAlignment = VerticalAlignment.Top;
            BorderRect.Stroke = new SolidColorBrush(Colors.Gray);
            BorderRect.StrokeThickness = 2;
            Canvas.SetLeft(BorderRect, Canvas.GetLeft(setCanvas) - 1.0);
            Canvas.SetTop(BorderRect, Canvas.GetTop(setCanvas) - 1.0);
            BorderRect.Width = setCanvas.Width + 2;
            BorderRect.Height = setCanvas.Height + 2;
            onCanvas.Children.Add(BorderRect);

            Globals.GridCentre = new Point(setCanvas.Width / 2.0, setCanvas.Height / 2.0);
            Globals.GridSize.Width = setCanvas.Width;
            Globals.GridSize.Height = setCanvas.Height;
            Globals.GridScale = 1.0;
        }

        private void SetupNodes(Canvas where)
        {
            // First get rid of all the nodes that are there at the moment, and the path loss array
            foreach (cNode node in Globals.myNodes) node.DestroyNode();
            Globals.myNodes.Clear();
            Globals.PathLosses = null; // Ditch the current path losses array
            where.Children.Clear(); // Gets rid of anything else hanging around too.

            // Setting up the nodes.  First, the nodes themselves.  The idea is that
            // they are somewhere in a square, of side length two units.  In order to 
            // prevent nodes forming isolated islands, no node is allowed to be placed
            // further than the current range from an existing node, and no node is 
            // allowed within a distance of 0.1 from an existing node.  So it's not
            // entirely random.

            // First: if preload selected but there are no pre-loaded nodes,
            // automatically switch to something more sensible
            if (Globals.HowToPlaceNodes == Globals.eNodePlacement.Preloaded
                && Globals.myPreloadedNodes.Count == 0)
            {
                // XXX Add a warning in here, but note this (as written)
                // doesn't work, since when loading XML file, the nodes
                // are cleared, then the eNodePlacement set to Preloaded,
                // then this is called, which sets eNodePlacement back to
                // linear, before more nodes are added.
                // Globals.HowToPlaceNodes = Globals.eNodePlacement.Linear;
                // Globals.NumberOfNodes = 3;
            }

            switch (Globals.HowToPlaceNodes)
            {
                case Globals.eNodePlacement.Preloaded:
                    {
                        // Load in the preloaded nodes:
                        int howMany = Globals.myPreloadedNodes.Count;
                        if (Globals.NumberOfNodes < howMany) howMany = Globals.NumberOfNodes;
                        for (int loop = 0; loop < howMany; loop++)
                        {
                            cNode newNode = new cNode(where, Globals.myPreloadedNodes[loop].X, Globals.myPreloadedNodes[loop].Y);
                            Globals.myNodes.Add(newNode);
                        }
                    }
                    break;
                case Globals.eNodePlacement.Random:
                    // First, place the first node.  This is always close to the middle of the display
                    if (Globals.NumberOfNodes > 0)
                    {
                        double newXrange = (2.0 * Globals.rands.NextDouble() - 1.0) * Globals.FirstNodeMaxOffset;
                        double newYrange = (2.0 * Globals.rands.NextDouble() - 1.0) * Globals.FirstNodeMaxOffset;
                        cNode NewNode = new cNode(where, newXrange, newYrange);
                        Globals.myNodes.Add(NewNode);
                    }

                    // Then for all the others:
                    double MinSquareRange = Globals.MinimumNodeSeparation * Globals.MinimumNodeSeparation;
                    double MaxSquareHop = Globals.MaximumNodeSeparation * Globals.MaximumNodeSeparation;

                    while (Globals.myNodes.Count < Globals.NumberOfNodes)
                    {
                        double newXrange = (2.0 * Globals.rands.NextDouble() - 1.0) * 0.9;
                        double newYrange = (2.0 * Globals.rands.NextDouble() - 1.0) * 0.9;
                        double MinDistance = 1e10;
                        foreach (cNode node in Globals.myNodes)
                        {
                            double distance = Math.Pow(newXrange - node.GetPosition().X, 2) + Math.Pow(newYrange - node.GetPosition().Y, 2);
                            if (distance < MinDistance) MinDistance = distance;
                        }
                        if (MinDistance > MinSquareRange && MinDistance < MaxSquareHop)
                        {
                            cNode NewNode = new cNode(where, newXrange, newYrange);
                            Globals.myNodes.Add(NewNode);
                        }
                    }
                    break;
                case Globals.eNodePlacement.Linear:
                    double MeanX = (Globals.NumberOfNodes - 1) * Globals.DefaultNodeSeparation / 2.0;
                    double Scale = 1.0;
                    if (MeanX > 1.0) Scale = MeanX / 0.95;

                    // They're spaced the maximum apart, then scaled to fit:
                    for (int loop = 0; loop < Globals.NumberOfNodes; loop++)
                    {
                        double NewX = (loop * Globals.DefaultNodeSeparation - MeanX) / Scale;
                        double NewY = 0;
                        cNode OtherNode = new cNode(where, NewX, NewY);
                        Globals.myNodes.Add(OtherNode);
                    }
                    break;
                case Globals.eNodePlacement.Cross:
                    int numberOfRings = (Globals.NumberOfNodes / 4);
                    double offsetToFirstRing = Globals.DefaultNodeSeparation / (2 - Globals.NumberOfNodes % 4) / Math.Sqrt(2);
                    double offsetBetweenRings = Globals.DefaultNodeSeparation / Math.Sqrt(2);
                    double totalArmLength = offsetToFirstRing + numberOfRings * offsetBetweenRings;
                    Scale = 1.0; if (totalArmLength > 0.98) Scale = totalArmLength / 0.98;

                    // If there is a central node, put this in first:
                    if (Globals.NumberOfNodes % 4 == 1)
                    {
                        cNode OtherNode = new cNode(where, 0.0, 0.0);
                        Globals.myNodes.Add(OtherNode);
                    }
                    // Then the others:
                    for (int loop = 0; loop < numberOfRings; loop++)
                    {
                        double NewX = (offsetToFirstRing + loop * offsetBetweenRings) / Scale;
                        double NewY = (offsetToFirstRing + loop * offsetBetweenRings) / Scale;
                        cNode newNode = new cNode(where, NewX, NewY);
                        Globals.myNodes.Add(newNode);
                        NewX *= -1;
                        newNode = new cNode(where, NewX, NewY);
                        Globals.myNodes.Add(newNode);
                        NewY *= -1;
                        newNode = new cNode(where, NewX, NewY);
                        Globals.myNodes.Add(newNode);
                        NewX *= -1;
                        newNode = new cNode(where, NewX, NewY);
                        Globals.myNodes.Add(newNode);
                    }
                    break;
                case Globals.eNodePlacement.Circle:

                    // The first node is always in the middle:
                    cNode FirstNode = new cNode(where, 0, 0);
                    Globals.myNodes.Add(FirstNode);

                    double Radius = Globals.MaximumNodeSeparation;
                    for (int loop = 1; loop < Globals.NumberOfNodes; loop++)
                    {
                        double NewX = Math.Cos(loop * 2 * Math.PI / (Globals.NumberOfNodes - 1)) * Radius;
                        double NewY = Math.Sin(loop * 2 * Math.PI / (Globals.NumberOfNodes - 1)) * Radius;
                        cNode OtherNode = new cNode(where, NewX, NewY);
                        Globals.myNodes.Add(OtherNode);
                    }
                    break;
                case Globals.eNodePlacement.Ring:

                    // Same as circle, except there's no node in the middle:
                    double ringRadius = Globals.MaximumNodeSeparation;
                    for (int loop = 0; loop < Globals.NumberOfNodes; loop++)
                    {
                        double NewX = Math.Cos(loop * 2 * Math.PI / Globals.NumberOfNodes) * ringRadius;
                        double NewY = Math.Sin(loop * 2 * Math.PI / Globals.NumberOfNodes) * ringRadius;
                        cNode OtherNode = new cNode(where, NewX, NewY);
                        Globals.myNodes.Add(OtherNode);
                    }
                    break;
                case Globals.eNodePlacement.Square:
                    int SquareRowToUse = -1;
                    for (int loop = 0; loop < Globals.SquareGrids.Length; loop++)
                    {
                        int NumberInPattern = 0;
                        for (int lop = 0; lop < (Globals.SquareGrids[loop]).Length; lop++)
                        {
                            NumberInPattern += Globals.SquareGrids[loop][lop];
                        }
                        if (NumberInPattern == Globals.NumberOfNodes) SquareRowToUse = loop;
                    }
                    if (SquareRowToUse == -1)
                    {
                        MessageBox.Show("Can't find square pattern to use", "Internal error");
                        return;
                    }
                    List<Point> SquareLocs = GetPatternNodeCoordinates(Globals.SquareGrids[SquareRowToUse], false, true);
                    foreach (Point pnt in SquareLocs)
                    {
                        cNode Node = new cNode(where, pnt.X, pnt.Y);
                        Globals.myNodes.Add(Node);
                    }
                    break;
                case Globals.eNodePlacement.Hexagonal:
                    int HexRowToUse = -1;
                    for (int loop = 0; loop < Globals.HexGrids.Length; loop++)
                    {
                        int NumberInPattern = 0;
                        for (int lop = 0; lop < Globals.HexGrids[loop].Length; lop++)
                        {
                            NumberInPattern += Globals.HexGrids[loop][lop];
                        }
                        if (NumberInPattern == Globals.NumberOfNodes) HexRowToUse = loop;
                    }
                    if (HexRowToUse == -1)
                    {
                        MessageBox.Show("Can't find hexagonal pattern to use", "Internal error");
                        return;
                    }
                    List<Point> HexLocs = GetPatternNodeCoordinates(Globals.HexGrids[HexRowToUse], true, true);
                    foreach (Point pnt in HexLocs)
                    {
                        cNode Node = new cNode(where, pnt.X, pnt.Y);
                        Globals.myNodes.Add(Node);
                    }
                    break;
                default:
                    break;
            }

            // Now generate a new array to store all the path losses, which will be initialised to zero:
            Globals.PathLosses = new double[Globals.NumberOfNodes, Globals.NumberOfNodes];
            // and since we know where all the nodes are now, we can fill this up
            Globals.MoveClass.CalculatePathLosses();
            // Then I need to know the middle node in case I want to target it:
            double ClosestToCentre = 1e10;
            for (int loop = 0; loop < Globals.myNodes.Count; loop++)
            {
                double SqDistToCentre = Globals.myNodes[loop].GetPosition().X * Globals.myNodes[loop].GetPosition().X
                                        + Globals.myNodes[loop].GetPosition().Y * Globals.myNodes[loop].GetPosition().Y;
                if (SqDistToCentre < ClosestToCentre)
                {
                    Globals.CentreNode = loop;
                    ClosestToCentre = SqDistToCentre;
                }
            }
            // OK that's all done now.
        }
        private List<Point> GetPatternNodeCoordinates(int[] Elements, Boolean HexMode, Boolean Scale)
        {
            // Works out where to put the patterns of nodes, and marks with a spot.
            List<Double> XCoords = new List<Double>();
            List<Double> YCoords = new List<Double>();
            double VerticalSeparation = 1;
            if (HexMode == true) VerticalSeparation = Math.Sqrt(3) / 2.0;
            double Y = 0;
            for (int row = 0; row < Elements.Length; row++)
            {
                if (Elements[row] == 0) continue;
                double X = Elements[row] / -2.0 + 0.5;
                for (int loop = 0; loop < Elements[row]; loop++)
                {
                    XCoords.Add(X);
                    YCoords.Add(Y);
                    X = X + 1;
                }
                Y += VerticalSeparation;
            }
            // Now just scale so that the centre node is in the middle of the screen, and the
            // elements either fill up 90% of the area, or are the minimum distance apart.
            double MinX = 1e10; double MinY = 1e10; double MaxX = -1e10; double MaxY = -1e10;
            foreach (double Xx in XCoords)
            {
                if (Xx < MinX) MinX = Xx;
                if (Xx > MaxX) MaxX = Xx;
            }
            foreach (double Yy in YCoords)
            {
                if (Yy < MinY) MinY = Yy;
                if (Yy > MaxY) MaxY = Yy;
            }
            // Then adjust so that everything is relative to the midpoint:
            List<Point> Locations = new List<Point>();
            double MidX = (MinX + MaxX) / 2.0;
            double MidY = (MinY + MaxY) / 2.0;
            double ScaleToFitX = (MaxX - MinX) / 1.9; if (ScaleToFitX == 0) ScaleToFitX = 1;
            double ScaleToFitY = (MaxY - MinY) / 1.9; if (ScaleToFitY == 0) ScaleToFitY = 1;
            double ScaleForMinimumDistance = 1.0 / Globals.DefaultNodeSeparation;
            if (Scale == true && ScaleForMinimumDistance > ScaleToFitX)
            {
                ScaleToFitX = ScaleForMinimumDistance; 
                ScaleToFitY = ScaleForMinimumDistance;
            }
            for (int loop = 0; loop < XCoords.Count; loop++)
            {
                XCoords[loop] -= MidX;
                YCoords[loop] -= MidY;
                Locations.Add(new Point(XCoords[loop] / ScaleToFitX, YCoords[loop] / ScaleToFitY));
            }
            return Locations;
        }
        private void ShutdownNodes()
        {
            // Shutdown all protocol layers for all nodes:
            foreach (cNode node in Globals.myNodes) node.ResetNode();
            // Deselect any selected nodes:
            Globals.SelectedNode = Globals.NOWHERE;
        }
        #endregion

        #region Region: Running UI routines from background threads
        internal void UpdateSliderOnUI(GUIBits.SliderTagStruct sts, string valString, Boolean bWarnings)
        {
            sts.SetSliderValue(valString, bWarnings);
        }
        internal void UpdateSliderOnUI(GUIBits.SliderTagStruct sts, double val, Boolean bWarnings)
        {
            sts.SetSliderValue(val, bWarnings);
        }
        internal void UpdateComboBoxOnUI(GUIBits.ComboBoxTagStruct cbts, string newValue)
        {
            cbts.SetValue(newValue);
            // Perhaps fire off the selection changed event just in case the selection 
            // hasn't changed but there are some side-effects that require doing? XXX
        }
        internal void ResetSimBeforeBatchFileRun()
        {
            // Gets the simulator ready to run a new batch file, and sets the Global
            // variable Globals.SimStatus to Reset when it's finished (this is used as
            // a flag to let the background thread know that everything's done and it
            // can carry on with the batch file.
            ResetSimulation();
            StartNewLogFile();
            SimulateFullSpeed();
            Globals.SimStatus = Globals.status.Reset;
        }
        internal void ResetSimAfterBatchFileRun()
        {
            // Resets the simulator back into a known state after a batch file has run, 
            // and sets the Global variable Globals.SimStatus to Reset when it's finished
            // (this is used as a flag to let the background thread know that everything's 
            // done and it can carry on with the batch file.
            EndSimulation();
            ResetSimulation();
            // (However at present this doesn't do anything, since Globals.
            // ConsoleText is cleared in the ResetSimulation() routine.)
            txtConsole.Text = "Batch file completed.";
            Globals.BatchStatus = Globals.BatchRunStatus.Default;
        }
        internal void DisableTabs()
        {
            tabControl1.IsEnabled = false;
        }
        internal void EnableTabs()
        {
            tabControl1.IsEnabled = true;
        }
        #endregion

        #region Region: The test button
        private void btnTest_Click(object sender, RoutedEventArgs e)
        {
            // Here for testing when required.  Actual button is bottom-left
            // on the "Setup Simulation" tab, with visibility set to hidden.
        }
        #endregion

        #region Region: The timer routine

        private void SetUpTimer()
        {
            Globals.theTimer = new DispatcherTimer();
            Globals.theTimer.IsEnabled = false;
            Globals.theTimer.Interval = System.TimeSpan.FromMilliseconds(Globals.TimeStep);
            Globals.theTimer.Tick += new EventHandler(WhatToDoWhenTimerTimesOut);
        }

        static DateTime TimeStatusLastUpdated = DateTime.Now;
        static DateTime TimeRoutesLastUpdated = DateTime.Now;
        internal void WhatToDoWhenTimerTimesOut(object sender, EventArgs e)
        {
            // Grab the time so I can time how long this takes; I can then optimise speed of this 
            // simulator later:
            DateTime StartInterrupt = DateTime.Now;

            // Update the real time (providing the timer is going...)
            if (Globals.theTimer.IsEnabled == true)
            {
                Globals.RealTime += Globals.TimeStep * (int)1e6;
                if (chkFastTime.IsChecked == true) Globals.RealTime += Globals.TimeStep * (int)4e6;
            }

            // If not in real time and not stepping, do Globals.EventsPerInterrupt events
            if (Globals.TimingMode == Globals.TimeMode.NonReal && Globals.SimStatus == Globals.status.Running)
            {
                // If I'm currently running at full speed, then do the next series of events
                int loop = 0;
                while (Globals.SimStatus == Globals.status.Running && loop < Globals.EventsPerInterrupt)
                {
                    Globals.theQueue.DoNextEvent();
                    loop++;
                }
            }
            // If I'm running slow or stepping, then just do one event,
            else if (Globals.SimStatus == Globals.status.Stepping
                    || Globals.SimStatus == Globals.status.Stopped)
            {
                Globals.theQueue.DoNextEvent();
            }
            // Otherwise I'm running in real or fast time, so do however many events come before the current real/fast time.
            else if (Globals.SimStatus != Globals.status.Reset &&
                Globals.SimStatus != Globals.status.Resetting && Globals.SimStatus != Globals.status.Terminating)
            {
                long TimeToGetTo = Globals.RealTime;
                while (Globals.theQueue.EventCount() > 0 && Globals.theQueue.NextTime() <= TimeToGetTo
                    && (DateTime.Now - StartInterrupt).TotalMilliseconds < 60)
                {
                    Globals.theQueue.DoNextEvent();
                }
            }
            // Update the times and number of events indicators:
            if (chkRealTime != null && Globals.TimingMode == Globals.TimeMode.NonReal)
                lblTime.Content = "Time = " + (Globals.SimTime / 1e9).ToString("###,###,##0.000000000") + " s";
            else
                lblTime.Content = "Time = " + (Math.Max(Globals.SimTime, Globals.RealTime) / 1e9).ToString("###,###,##0.000000000") + " s";

            lblEvents.Content = "Queued Events = " + Globals.theQueue.EventCount().ToString() + " (" + Globals.EventsPerInterrupt.ToString() + ")";

            // Grab the time again, and work out how long all these events have taken:
            DateTime EndInterrupt = DateTime.Now;

            // If the energy indicators were last updated more than 250 ms ago,
            // update them again now (more often just wastes time):
            if ((DateTime.Now - TimeStatusLastUpdated).TotalMilliseconds > 250)
            {
                foreach (cNode node in Globals.myNodes) node.UpdateEnergy();
                if (chkAnimations.IsChecked == true) UpdateEnergyIndicators();
                if (chkAnimations.IsChecked == true) UpdatePacketIndicators();
                TimeStatusLastUpdated = DateTime.Now;
                if (Globals.SelectedNode != Globals.NOWHERE)
                {
                    txtInfoBox.Text = Globals.myNodes[Globals.SelectedNode].NodeInfo();
                }
            }

            // Also, while I'm at it, I'll check the queues for sense:
            int packetsWaitingAtTransport = 0;
            int packetsWaitingAtNetwork = 0;
            int packetsWaitingAtLogicalLink = 0;
            int packetsWaitingAtMediaAccess = 0;
            for (int loop = 0; loop < Globals.NumberOfNodes; loop++)
            {
                if (Globals.myNodes[loop].TransportLayer != null) packetsWaitingAtTransport += Globals.myNodes[loop].TransportLayer.GetQueueLength();
                if (Globals.myNodes[loop].NetworkLayer != null) packetsWaitingAtNetwork += Globals.myNodes[loop].NetworkLayer.GetQueueLength();
                if (Globals.myNodes[loop].LogicalLinkLayer != null) packetsWaitingAtLogicalLink += Globals.myNodes[loop].LogicalLinkLayer.GetQueueLength();
                if (Globals.myNodes[loop].MACLayer != null) packetsWaitingAtMediaAccess += Globals.myNodes[loop].MACLayer.GetQueueLength();
            }

            // If there are more than Globals.MaxPacketsInQueues packets waiting in queues, 
            // something has probably gone wrong...
            int packetsWaiting = packetsWaitingAtTransport + packetsWaitingAtNetwork
                                + packetsWaitingAtLogicalLink + packetsWaitingAtMediaAccess;
            if (packetsWaiting > Globals.MaxPacketsInQueues)
            {
                Boolean stillGoing = 
                    Globals.ShowMessageBox("There are " + packetsWaiting + " packets waiting in queues."
                    + "\nPerhaps something has gone wrong?", "Possible user error");
                if (stillGoing == true && Globals.MaxPacketsInQueues < int.MaxValue)
                    Globals.MaxPacketsInQueues *= 2; // User is happy, so increase limit...
            }

            // If there are more than Globals.MaxEventsInQueue events per node in the queue, 
            // something has probably gone wrong...
            if (Globals.NumberOfNodes > 0)
            {
                int eventsPerNode = Globals.theQueue.EventCount() / Globals.NumberOfNodes;
                if (eventsPerNode > Globals.MaxEventsPerNode)
                {
                    Boolean stillGoing =
                        Globals.ShowMessageBox("There are " + eventsPerNode + " events per node waiting in the queue."
                        + "\nPerhaps something has gone wrong?", "Possible user error");
                    if (stillGoing == true)
                        Globals.MaxEventsPerNode *= 2; // User is happy, so increase limit...
                }
            }

            // If the routes are actively being updated, and were updated more
            // than one second ago, then update them again now.  Note this is
            // only being done every second, and it doesn't count towards the
            // time measurements to make sure a sensible number of events take
            // place in each interrupt cycle, since this this can take a very 
            // long time.
            if ((DateTime.Now - TimeRoutesLastUpdated).TotalMilliseconds > 1000)
            {
                TimeRoutesLastUpdated = DateTime.Now;
                if (Globals.SelectedNode != Globals.NOWHERE)
                {
                    Globals.myNodes[Globals.SelectedNode].ClearRouteingLines();
                    if (chkRoutes.IsChecked == true)
                    {
                        Globals.myNodes[Globals.SelectedNode].ShowRouteingLines(1.0);
                    }
                }
            }

            // Right, the plan is to modify Globals.EventsPerInterrupt until I'm using about
            // 60% of the capacity of the machine... that should be enough for other things
            // and keep the user interface reasonably responsive.  Or that's the idea,
            // anyway.  I'll make the change gradual but safe: if you're using too much time
            // you jump back to the best guess for 60% immediately; if the interrupt routine
            // happened with lots of time to spare, you jump half-way to the 60% level.
            // Whatever happens, you do at least one event per interrupt cycle.
            if (Globals.SimStatus == Globals.status.Running 
                && chkRealTime.IsChecked == false
                && chkFastTime.IsChecked == false)
            {
                TimeSpan TimeTaken = EndInterrupt - StartInterrupt;
                int EventsPerInterruptNow = Globals.EventsPerInterrupt;
                int EventsPerInterruptFor60 = (int)((double)EventsPerInterruptNow / (TimeTaken.TotalMilliseconds + 1)
                                                * Globals.theTimer.Interval.TotalMilliseconds);
                if (EventsPerInterruptFor60 < EventsPerInterruptNow) EventsPerInterruptNow = EventsPerInterruptFor60;
                else EventsPerInterruptNow = (EventsPerInterruptNow + EventsPerInterruptFor60) / 2;
                Globals.EventsPerInterrupt = Math.Max(1, EventsPerInterruptNow);
            }
        }
        #endregion

        #region Region: Re-scaling stuff
        // These are the routines and variables required for automatic re-scaling the
        // entire form to be full-screen.
        double Rescale_DefaultWidth;
        double Rescale_DefaultHeight;
        void InitReScaling() // Initialises the stuff for changing window sizes
        {
            // Set the Canvas to fill the available window area
            topCanvas.Height = this.Height;
            topCanvas.Width = this.Width;
            Canvas.SetTop(topCanvas, 0); Canvas.SetLeft(topCanvas, 0);
            topCanvas.HorizontalAlignment = HorizontalAlignment.Left;
            topCanvas.VerticalAlignment = VerticalAlignment.Top;
            // Then I need to memorise the original (design) size and shape of the form
            Rescale_DefaultWidth = this.Width;
            Rescale_DefaultHeight = this.Height;
            // And register an event handler for form re-sizing:
            this.SizeChanged += new SizeChangedEventHandler(MainWindow_SizeChanged);
        }
        void MainWindow_SizeChanged(object sender, SizeChangedEventArgs e) // When window changes size
        {
            double NewHeight = this.ActualHeight / Rescale_DefaultHeight;
            double NewWidth = this.ActualWidth / Rescale_DefaultWidth;
            topCanvas.RenderTransform = new ScaleTransform(NewWidth, NewHeight);
        }
        #endregion

        #region Region: A few useful things that really should be here
        private Point Middle(Ellipse elli)
        {
            return new Point(Canvas.GetLeft(elli) + elli.Width / 2.0, Canvas.GetTop(elli) + elli.Height / 2.0);
        }
        #endregion

        #region Region: The shadowing stuff
        WriteableBitmap shadowingBitmap;
        Image shadowingImage;
        double[,] shadowingArray = new double[100, 100];

        private void SetUpShadowing(double stdDev, double corrLength)
        {
            // Shadowing in DANSE is based around a 100 x 100 square matrix of
            // double, which represent the amount of shadowing loss encountered
            // by a path travelling through that part of the map.  The first
            // thing to do is to set up this array.  This is done as a 200 x 200
            // array to make it easier to implement a 2-d filter on the points,
            // to provide a variety of correlation lengths.
            double[,] preFilter = new double[200, 200];
            for (int loop = 0; loop < 200; loop++)
            {
                for (int lop = 0; lop < 200; lop += 2)
                {
                    // Generate two normal-distributed random variables
                    // using the Box-Muller method (see Wikipedia)
                    double randA = Globals.rands.NextDouble();
                    double randB = Globals.rands.NextDouble();
                    double randC = Math.Sqrt(-2.0 * Math.Log(randA));
                    double randX = randC * Math.Cos(2 * Math.PI * randB);
                    double randY = randC * Math.Sin(2 * Math.PI * randB);

                    preFilter[loop, lop] = randX;
                    preFilter[loop, lop + 1] = randY;
                }
            }

            // Now need to filter this so that the result provides the required
            // correlation length, ensure that the array is scaled to have the
            // required standard deviation of shadowing, and then fill up the
            // actual shadowingArray for later use.

            // Note: when drawing ranges, try: http://blogs.msdn.com/b/sean_mcdirmid/archive/2008/10/06/curved-polygons-in-wpf.aspx?Redirected=true

            // First, take down any existing shadowing component:
            if (shadowingImage != null && Canvas2D != null)
            {
                if (Canvas2D.Children.Contains(shadowingImage) == true) Canvas2D.Children.Remove(shadowingImage);
            }

            if (stdDev > 0.0)
            {
                // This is a request to set up a new shadowing component (calling with stdDev of
                // zero is interpreted as a request not to use shadowing at all)
                shadowingBitmap = new WriteableBitmap(100 * Globals.shadowPixelSize, 100 * Globals.shadowPixelSize, 96, 96, PixelFormats.Bgr32, null);

                for (int loop = 0; loop < 100; loop++)
                {
                    for (int lop = 0; lop < 100; lop++)
                    {
                        if ((loop + lop) % 2 == 1) DrawPixelLocked(shadowingBitmap, lop, loop, Colors.Black);
                        else DrawPixelLocked(shadowingBitmap, lop, loop, Colors.White);
                    }
                }
                shadowingImage = new System.Windows.Controls.Image();
                Canvas.SetZIndex(shadowingImage, Globals.Z_Background);
                shadowingImage.Source = shadowingBitmap;
                shadowingImage.Stretch = Stretch.Fill;
                shadowingImage.HorizontalAlignment = System.Windows.HorizontalAlignment.Left;
                shadowingImage.VerticalAlignment = System.Windows.VerticalAlignment.Top;
                shadowingImage.Opacity = 1.0;
                shadowingImage.Visibility = System.Windows.Visibility.Visible;
                Canvas2D.Children.Add(shadowingImage);
            }
        }

        private void DrawPixelLocked(WriteableBitmap bitmap, int x, int y, System.Windows.Media.Color col)
        {
            // Mostly taken from: http://msdn.microsoft.com/en-us/library/system.windows.media.imaging.writeablebitmap.aspx
            // Reserve the back buffer for updates.
            bitmap.Lock();
            unsafe
            {
                // Get a pointer to the back buffer.
                int pBackBuffer = (int)bitmap.BackBuffer;

                // Compute the pixel's color.
                int color_data = col.R << 16; // R
                color_data |= col.G << 8;   // G
                color_data |= col.B << 0;   // B

                if (Globals.shadowPixelSize == 1)
                {
                    // Find the address of the pixel to draw.
                    pBackBuffer += y * bitmap.BackBufferStride;
                    pBackBuffer += x * 4;

                    // Assign the color data to the pixel.
                    *((int*)pBackBuffer) = color_data;
                }
                else if (Globals.shadowPixelSize > 1)
                {
                    y *= Globals.shadowPixelSize;
                    x *= Globals.shadowPixelSize;

                    for (int loop = 0; loop < Globals.shadowPixelSize; loop++)
                    {
                        for (int lop = 0; lop < Globals.shadowPixelSize; lop++)
                        {
                            pBackBuffer = (int)bitmap.BackBuffer;
                            int thisy = y + loop;
                            int thisx = x + lop;
                            pBackBuffer += thisy * bitmap.BackBufferStride;
                            pBackBuffer += thisx * 4;
                            *((int*)pBackBuffer) = color_data;
                        }
                    }
                }
            }

            // Specify the area of the bitmap that changed.
            bitmap.AddDirtyRect(new Int32Rect(x, y, Globals.shadowPixelSize, Globals.shadowPixelSize));
            // Release the back buffer and make it available for display.
            bitmap.Unlock();
        }
        #endregion

        #region Region: The energy and packet queue indicator methods
        static double BatteryLineLoc = 1.0; // Only for total energy mode
        static Line PacketTargetLine = new Line(); // The thin red line...
        static Line BatteryLine = new Line(); // The other thin red line...
        double _packetLineFactor = 0.9; // How much to fill with expected packets...
        private void ResetEnergyAndPacketIndicators()
        {
            // First get rid of all existing rectangles:
            foreach (Rectangle rect in Globals.PowerRects) canvasMain.Children.Remove(rect);
            Globals.PowerRects.Clear();  // These are the rectangles for power
            foreach (Rectangle rect in Globals.TotalPowerRects) canvasMain.Children.Remove(rect);
            Globals.TotalPowerRects.Clear();  // These are the rectangles for total power (for clicking)
            foreach (Rectangle rect in Globals.PacketRects) canvasMain.Children.Remove(rect);
            Globals.PacketRects.Clear();  // These are the rectangles for packets waiting at MAC
            // Then work out how big they should be, and where:
            BatteryLineLoc = 1.0;
            BatteryLine.Visibility = Visibility.Hidden;
            int NumberOfThings = 1 + 4 * Globals.NumberOfNodes;
            double EachSpace = 4 * rectPowers.Height / NumberOfThings;
            double StartWidth = 1.0 * rectPowers.Width - 2;
            double StartOffset = EachSpace / 4 + Canvas.GetTop(rectPowers);
            // Then put them all on the screen, and fill Globals.PowerRects again:
            for (int loop = 0; loop < Globals.NumberOfNodes; loop++)
            {
                // First for the power rectangles:
                Rectangle ThisRect = new Rectangle();
                ThisRect.HorizontalAlignment = HorizontalAlignment.Left;
                ThisRect.VerticalAlignment = VerticalAlignment.Top;
                Canvas.SetLeft(ThisRect, Canvas.GetLeft(rectPowers) + 1);
                Canvas.SetTop(ThisRect, StartOffset + EachSpace * loop);
                
                Rectangle ThisTotalRect = new Rectangle();
                ThisTotalRect.HorizontalAlignment = HorizontalAlignment.Left;
                ThisTotalRect.VerticalAlignment = VerticalAlignment.Top;
                Canvas.SetLeft(ThisTotalRect, Canvas.GetLeft(rectPowers) + 1);
                Canvas.SetTop(ThisTotalRect, StartOffset + EachSpace * loop);

                switch (Globals.EnergyMode)
                {
                    case Globals.EnergyType.Countdown:
                        ThisRect.Width = StartWidth;
                        break;
                    case Globals.EnergyType.Addup:
                        ThisRect.Width = 0;
                        break;
                    case Globals.EnergyType.Down_Not_Zero:
                        if (loop == 0) ThisRect.Width = 0;
                        else ThisRect.Width = StartWidth;
                        break;
                    default:
                        break;
                }
                ThisTotalRect.Width = StartWidth;

                ThisRect.Height = EachSpace * 0.8;
                ThisRect.Fill = Globals.PowerLevelOK;
                ThisRect.Tag = loop;
                ThisRect.StrokeThickness = 0;
                ThisRect.MouseEnter += new MouseEventHandler(ThisRect_MouseEnter);
                ThisRect.MouseLeave += new MouseEventHandler(ThisRect_MouseLeave);
                Globals.PowerRects.Add(ThisRect);
                canvasMain.Children.Add(ThisRect);

                ThisTotalRect.Height = EachSpace * 0.8;
                ThisTotalRect.Fill = Globals.PowerLevelBackground;
                ThisTotalRect.Tag = loop;
                ThisTotalRect.StrokeThickness = 0;
                ThisTotalRect.Opacity = 0.1;
                ThisTotalRect.MouseEnter += new MouseEventHandler(ThisRect_MouseEnter);
                ThisTotalRect.MouseLeave += new MouseEventHandler(ThisRect_MouseLeave);
                Globals.TotalPowerRects.Add(ThisTotalRect);
                canvasMain.Children.Add(ThisTotalRect);

                // Then for the packets rectangles:
                Rectangle ThisOtherRect = new Rectangle();
                ThisOtherRect.HorizontalAlignment = HorizontalAlignment.Left;
                ThisOtherRect.VerticalAlignment = VerticalAlignment.Top;
                Canvas.SetLeft(ThisOtherRect, Canvas.GetLeft(rectPackets) + 1);
                Canvas.SetTop(ThisOtherRect, StartOffset + EachSpace * loop);
                ThisOtherRect.Width = 0;  // Start with no packet there, unlike energy
                ThisOtherRect.Height = EachSpace * 0.8;
                ThisOtherRect.Fill = Globals.PacketLevelBrush;
                ThisOtherRect.Tag = loop;
                ThisOtherRect.StrokeThickness = 0;
                ThisOtherRect.MouseEnter += new MouseEventHandler(ThisRect_MouseEnter);
                ThisOtherRect.MouseLeave += new MouseEventHandler(ThisRect_MouseLeave);
                Globals.PacketRects.Add(ThisOtherRect);
                canvasMain.Children.Add(ThisOtherRect);
            }
            
            // Then work out the target number of packets, and hence the scaling
            // factor for plotting, and add the vertical guideline:
            Globals.PacketsTarget = (int)(Globals.TrafficGenerateRate 
                * (Globals.SimulationLength - Globals.PrerollLength - Globals.PostrollLength) 
                / (double)Globals.NumberOfNodes);
            Globals.PacketsTarget += Globals.myPacketsToGo.Count / (double)Globals.NumberOfNodes;
            double ThinRedLineOffset = StartWidth * _packetLineFactor;
            // Place the thin red "packets target" line:
            PacketTargetLine.HorizontalAlignment = HorizontalAlignment.Left;
            PacketTargetLine.VerticalAlignment = VerticalAlignment.Top;
            PacketTargetLine.Stroke = Globals.PacketLevelLine;
            PacketTargetLine.StrokeThickness = 2;
            PacketTargetLine.Opacity = 0.5;
            PacketTargetLine.X1 = Canvas.GetLeft(rectPackets) + ThinRedLineOffset;
            PacketTargetLine.X2 = Canvas.GetLeft(rectPackets) + ThinRedLineOffset;
            PacketTargetLine.Y1 = Canvas.GetTop(rectPackets);
            PacketTargetLine.Y2 = Canvas.GetTop(rectPackets) + rectPackets.Height;
            if (canvasMain.Children.Contains(PacketTargetLine) == false) canvasMain.Children.Add(PacketTargetLine);

            // The vertical guideline for battery capacity:
            double BatteryLineOffset = StartWidth * 1.0;
            // Place the thin red "battery capacity" line:
            BatteryLine.HorizontalAlignment = HorizontalAlignment.Left;
            BatteryLine.VerticalAlignment = VerticalAlignment.Top;
            BatteryLine.Stroke = Globals.PacketLevelLine;
            BatteryLine.StrokeThickness = 2;
            BatteryLine.Opacity = 0.5;
            BatteryLine.X1 = Canvas.GetLeft(rectPowers) + rectPowers.Width * BatteryLineLoc;
            BatteryLine.X2 = Canvas.GetLeft(rectPowers) + rectPowers.Width * BatteryLineLoc;
            BatteryLine.Y1 = Canvas.GetTop(rectPowers);
            BatteryLine.Y2 = Canvas.GetTop(rectPowers) + rectPackets.Height;
            BatteryLine.Visibility = Visibility.Hidden;
            if (canvasMain.Children.Contains(BatteryLine) == false) canvasMain.Children.Add(BatteryLine);

            // Finally sort out the title for the energy bars:
            switch (Globals.EnergyMode)
            {
                case Globals.EnergyType.Countdown:
                    lblEnergy.Content = "Energy Left";
                    break;
                case Globals.EnergyType.Addup:
                    lblEnergy.Content = "Energy Used";
                    break;
                case Globals.EnergyType.Down_Not_Zero:
                    lblEnergy.Content = "Energy";
                    break;
                default:
                    MessageBox.Show("Unknown energy mode.", "Serious error");
                    break;
            }
        }

        int _lastHighlighted = 0;
        internal void HighlightEnergyDisplay(int node, Boolean turnOn)
        {
            // Called when the mouse is put over the node to highlight the
            // corresponding energy bar.
            // First - if this is an attempt to turn on something different from
            // what's already on, then what's already on should be turned off:
            if (turnOn == true && node != _lastHighlighted) HighlightEnergyDisplay(_lastHighlighted, false);

            // Then store what what is to be turned on, so I know what to turn off
            // when the next call comes with turnOn = false
            if (turnOn == true) _lastHighlighted = node; else node = _lastHighlighted;

            // Now turn something on (or off):
            if (Globals.PowerRects.Count >= node && Globals.PacketRects.Count >= node)
            {
                if (turnOn == true)
                {
                    Globals.PowerRects[node].Stroke = Globals.NodeHighlightBrush;
                    Globals.TotalPowerRects[node].Stroke = Globals.NodeHighlightBrush;
                    Globals.PacketRects[node].Stroke = Globals.NodeHighlightBrush;
                    Globals.PowerRects[node].StrokeThickness = 2;
                    Globals.TotalPowerRects[node].StrokeThickness = 2;
                    Globals.PacketRects[node].StrokeThickness = 2;
                    Globals.TotalPowerRects[node].Opacity = 0.8;
                }
                else
                {
                    Globals.PowerRects[node].StrokeThickness = 0;
                    Globals.TotalPowerRects[node].StrokeThickness = 0;
                    Globals.PacketRects[node].StrokeThickness = 0;
                    Globals.TotalPowerRects[node].Opacity = 0.1;
                }
            }
        }
        void ThisRect_MouseLeave(object sender, MouseEventArgs e)
        {
            int node = (int)((Rectangle)sender).Tag;
            Globals.myNodes[node].SetNodeColour(false);
            SetDefaultNodeInfoBox(Globals.NOWHERE);
        }
        void ThisRect_MouseEnter(object sender, MouseEventArgs e)
        {
            // What to do is the mouse is put over the packets so far rectangle.
            int node = (int)((Rectangle)sender).Tag;
            Globals.myNodes[node].SetNodeColour(true);
            SetDefaultNodeInfoBox(node);
        }
        internal void SetDefaultNodeInfoBox(int node)
        {
            if (node != Globals.NOWHERE)
            {
                txtInfoBox.Text = Globals.myNodes[node].NodeInfo();
                txtInfoBox.Foreground = Globals.TextBlackBrush;
                if (chkRoutes.IsChecked == true) Globals.myNodes[node].ShowRouteingLines(1.0);
                HighlightEnergyDisplay(node, true);
            }
            else if (Globals.SelectedNode != Globals.NOWHERE)
            {
                txtInfoBox.Text = Globals.myNodes[Globals.SelectedNode].NodeInfo();
                txtInfoBox.Foreground = Globals.TextGrayBrush;
                if (chkRoutes.IsChecked == true) Globals.myNodes[Globals.SelectedNode].ShowRouteingLines(0.5);
                HighlightEnergyDisplay(Globals.SelectedNode, true);
            }
            else
            {
                txtInfoBox.Text = "";
                Globals.myNodes[0].ClearRouteingLines();
                HighlightEnergyDisplay(0, false);
            }
        }

        internal void UpdateEnergyIndicators()
        {
            for (int loop = 0; loop < Globals.NumberOfNodes; loop++)
                UpdateEnergyIndicator(loop);
        }
        private void UpdateEnergyIndicator(int loop)
        {
            if (Globals.myNodes.Count <= loop) return; // This node doesn't exist.
            double MaxWidth = rectPowers.Width - 2;
            if (Globals.EnergyMode == Globals.EnergyType.Countdown
                || (Globals.EnergyMode == Globals.EnergyType.Down_Not_Zero && loop != 0))
            {
                double EnergyLeft = Globals.myNodes[loop].GetEnergyLeft();
                if (EnergyLeft < 0) Globals.PowerRects[loop].Width = 0;
                else Globals.PowerRects[loop].Width = EnergyLeft / Globals.InitialEnergy * MaxWidth;
                if (EnergyLeft <= Globals.InitialEnergy / 2.0) Globals.PowerRects[loop].Fill = Globals.PowerLevelWeak;
                if (EnergyLeft <= Globals.InitialEnergy / 5.0) Globals.PowerRects[loop].Fill = Globals.PowerLevelCritical;
            }
            else
            {
                double EnergyUsed = Globals.myNodes[loop].GetEnergyUsed();
                Globals.PowerRects[loop].Width = EnergyUsed / Globals.InitialEnergy * MaxWidth * BatteryLineLoc;
                Globals.PowerRects[loop].Fill = Globals.PowerLevelOK;
                if (Globals.PowerRects[loop].Width > rectPowers.Width)
                {
                    // Battery line location needs updating...
                    BatteryLineLoc *= 0.8;
                    BatteryLine.X1 = Canvas.GetLeft(rectPowers) + rectPowers.Width * BatteryLineLoc;
                    BatteryLine.X2 = BatteryLine.X1;
                    BatteryLine.Visibility = Visibility.Visible;
                }
            }
        }
        internal void UpdatePacketIndicators()
        {
            int maxPackets = 0;
            for (int loop = 0; loop < Globals.NumberOfNodes; loop++)
            {
                // Check to see what the maximum is to see if this is going to need scaling:
                if (Globals.myNodes[loop].GetPacketsReceived() > maxPackets)
                    maxPackets = Globals.myNodes[loop].GetPacketsReceived();
            }
            // If this is won't fit, then I'll need a scaling factor for everything:
            double scaleFactor =  _packetLineFactor;
            if (maxPackets / Globals.PacketsTarget > 1 / _packetLineFactor) 
            {
                scaleFactor = Globals.PacketsTarget / maxPackets;
                double packetTargetLineX = Canvas.GetLeft(rectPackets) 
                    + (1.0 * rectPowers.Width - 2) * scaleFactor * _packetLineFactor;
                PacketTargetLine.X1 = packetTargetLineX;
                PacketTargetLine.X2 = packetTargetLineX;
            }
            for (int loop = 0; loop < Globals.NumberOfNodes; loop++)
                UpdatePacketIndicator(loop, scaleFactor);
            // Which is fine provided all of the indicators are less than the width of
            // the rectangular box.  
        }
        private void UpdatePacketIndicator(int loop, double scale)
        {
            double MaxWidth = rectPackets.Width - 2;
            if (Globals.PacketsTarget > 0)
                Globals.PacketRects[loop].Width = Globals.myNodes[loop].GetPacketsReceived() / Globals.PacketsTarget * MaxWidth * scale;
            else
                Globals.PacketRects[loop].Width = 0.0;
        }
        #endregion

        #region Region: The GUI object event handlers
        private void sldNodes_Value(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            // If this is being moved, then we must be on the Main tab.  This is a shadow of the
            // real control slider on the Setup tab, so all I need to do here is move the
            // real control slider to the same value, and update the text:
            Globals.stsNumberOfNodes.theSlider.Value = ((Slider)sender).Value;
            if (Globals.NumberOfNodes == 1) lblNodes.Content = "1 Node";
            else lblNodes.Content = Globals.NumberOfNodes.ToString() + " Nodes";
        }

        private void btnNextTransmit_Click(object sender, RoutedEventArgs e)
        {
            // If initial, then need to reset first:
            if (Globals.SimStatus == Globals.status.Initial) ResetSimulation();
            // If a log file is required, and there isn't one, then set one up:
            if (Globals.SimStatus != Globals.status.Stepping && Globals.LogStreamWriter == null)
                StartNewLogFile();
            // Then go into stepping mode:
            Globals.SimStatus = Globals.status.Stepping;
            Globals.theTimer.IsEnabled = false;
            MakeChangesPossibleOrNot(false);
            // Then a loop, doing 1000 events or until the next frame gets transmitted, whichever
            // is the sooner:
            int EventsUntilFrameTransmit = 0;
            long FramesSentUntilNow = Globals.TotalFramesSent;
            while (EventsUntilFrameTransmit < 1000 && FramesSentUntilNow == Globals.TotalFramesSent)
            {
                EventsUntilFrameTransmit++;
                WhatToDoWhenTimerTimesOut(null, null);
                // And since we're in stepping mode, print out what this step just did:
                if (Globals.NewLogEvent != null)
                    txtStatus.Text = JustifyText(Globals.NewLogEvent.ToString(), Globals.STATUSTEXTLENGTH);
                // If no logged event found after 1000 attempts, pause to prevent the
                // programme appearing to lock up before trying again:
                if (EventsUntilFrameTransmit == 1000)
                {
                    Dispatcher.CurrentDispatcher.Invoke(DispatcherPriority.Background, new ThreadStart(delegate { }));
                    Thread.Sleep(100);
                    EventsUntilFrameTransmit = 0;
                }
            }
        }
        private string JustifyText(string s, int length)
        {
            // Takes a string, and inserts new-line characters where appropriate so that
            // it prints out nicely on a screen.  Used with the txtStatus box mostly.
            char[] delimiterChars = { ' ', '\t' };
            string[] words = s.Split(delimiterChars);
            StringBuilder output = new StringBuilder(256);
            int lengthSoFar = 0;
            foreach (string word in words)
            {
                lengthSoFar += word.Length;
                if (lengthSoFar > length)
                {
                    output.Append("\n    ");
                    lengthSoFar = 0;
                }
                if (word.Contains("\n") == true) lengthSoFar = 0;
                output.Append(word);
                output.Append(" ");
            }
            return output.ToString();
        }

        private void btnNextLogEvent_Click(object sender, RoutedEventArgs e)
        {
            // This one does nothing if the log file is not on (it's not enabled).
            // Otherwise, it moves forward to the next event that causes an output 
            // to the log file, or 1000 events, whichever is the sooner.

            // If there are no events left in the queue, just return:
            if (Globals.theQueue.EventCount() == 0) return;
            // If initial, then need to reset first:
            if (Globals.SimStatus == Globals.status.Initial) ResetSimulation();
            // If a log file is required, and there isn't one, then set one up:
            if (Globals.SimStatus != Globals.status.Stepping && Globals.LogStreamWriter == null)
                StartNewLogFile();
            // Then go into stepping mode:
            Globals.SimStatus = Globals.status.Stepping;
            btnRun.Content = "Continue";
            Globals.theTimer.IsEnabled = false;
            MakeChangesPossibleOrNot(false);
            // Then a loop, doing 1000 events or until the next log event, whichever
            // is the sooner:
            int EventsUntilLog = 0;
            long LoggedEventsUntilNow = Globals.LogEventCount;
            while (EventsUntilLog < 1000 && LoggedEventsUntilNow == Globals.LogEventCount)
            {
                EventsUntilLog++;
                WhatToDoWhenTimerTimesOut(null, null);
                // And since we're in stepping mode, print out what this step just did:
                if (Globals.NewLogEvent != null)
                    txtStatus.Text = JustifyText(Globals.NewLogEvent.ToString(), Globals.STATUSTEXTLENGTH);
                // If no logged event found after 1000 attempts, pause to prevent the
                // programme appearing to lock up before trying again:
                if (EventsUntilLog == 1000)
                {
                    Dispatcher.CurrentDispatcher.Invoke(DispatcherPriority.Background, new ThreadStart(delegate { }));
                    Thread.Sleep(100);
                    EventsUntilLog = 0;
                }
            }
        }

        private void btnReset_Click(object sender, RoutedEventArgs e)
        {
            ResetSimulation();
            // If simulator status is Reset then the nodes won't be re-initialised,
            // so I'll do it here (required to move random node placements around)
            SetupNodes(Canvas2D);
            Globals.SimStatus = Globals.status.Reset;
        }

        private void btnStep_Click(object sender, RoutedEventArgs e)
        {
            // If initial, then need to reset first:
            if (Globals.SimStatus == Globals.status.Initial) ResetSimulation();
            // If a log file is required, and there isn't one, then set one up:
            if (Globals.LogStreamWriter == null) StartNewLogFile();
            // Then go into stepping mode:
            Globals.SimStatus = Globals.status.Stepping;
            Globals.theTimer.IsEnabled = false;
            // And since we're in stepping mode, print out what this step does:
            txtStatus.Text = JustifyText(Globals.theQueue.GetNextEventString(), Globals.STATUSTEXTLENGTH);
            WhatToDoWhenTimerTimesOut(null, null);
            MakeChangesPossibleOrNot(false);
            // If the event queue is currently displayed, then it will need updating:
            if (tbOutputEventQueue.Visibility == System.Windows.Visibility.Visible)
            {
                rbOutputs_Checked(null, null);
            }
        }

        internal void btnRun_Click(object sender, RoutedEventArgs e)
        {
            // Operation of this button depends on the simulator status:
            switch (Globals.SimStatus)
            {
                // If initialised, stopped or stepping, then start going full speed:
                case Globals.status.Stepping:
                case Globals.status.Stopped:
                    SimulateFullSpeed();
                    break;
                // If running, then stop and disable timer, and allow step control:
                case Globals.status.Running:
                    CloseLogFile();
                    Globals.SimStatus = Globals.status.Stopped;
                    Globals.theTimer.IsEnabled = false;
                    btnRun.Content = "Continue";
                    btnStep.IsEnabled = true;
                    break;
                // If reset, then initialise, then go full speed:
                case Globals.status.Terminating:
                case Globals.status.Resetting:
                case Globals.status.Reset:
                    ResetSimulation();  // added to get packet bars right size
                    StartNewLogFile();
                    SimulateFullSpeed();
                    break;
                // If initial, then reset with new log file, then go full speed:
                case Globals.status.Initial:
                    ResetSimulation();
                    if (Globals.LogStreamWriter == null) StartNewLogFile();
                    SimulateFullSpeed();
                    break;
                default:
                    break;
            }
        }
        internal void SimulateFullSpeed()
        {
            btnRun.Content = "Pause";
            btnStep.IsEnabled = false;
            MakeChangesPossibleOrNot(false);
            Globals.SimStatus = Globals.status.Running;
            Globals.theTimer.IsEnabled = true;
            // Inform the user I'm done:
            if (txtStatus != null) txtStatus.Text = "Running...";
        }

        // This one is called when a simulation "Stop" event occurs.  It finalises
        // saving all the output files and updates the results, then shuts down the
        // queue and resets the simulation.
        internal void EndSimulation()
        {
            // If I'm running from a batch file, I shouldn't access the GUI parameters:
            Boolean batchMode = (Globals.BatchStatus != Globals.BatchRunStatus.Default) ? true : false;
            // Stop the clock, reset the nodes, empty the queue, set mode to Stopped and allow changes:
            Globals.theTimer.IsEnabled = false;
            Globals.SimStatus = Globals.status.Stopped;
            foreach (cNode node in Globals.myNodes) node.ResetNode();
            Globals.theQueue.Reset();
            // Close the output file
            CloseLogFile();
            // If I'm running from the main GUI thread, I can update the various
            // GUI parameters as well (remember to do this when returning to
            // the main GUI thread after running a simulation in a different
            // thread)
            if (batchMode == false)
            {
                btnRun.Content = "Start";
                btnRun.IsEnabled = false;
                UpdateEnergyIndicators();
                UpdatePacketIndicators();
                MakeChangesPossibleOrNot(true);
                // Inform the user I'm done:
                if (txtStatus != null) txtStatus.Text = "All done.";
            }
        }
        private void CloseLogFile()
        {
            if (Globals.LogStreamWriter != null)
            {
                Globals.LogStreamWriter.Flush();
                Globals.LogStreamWriter.Close();
                Globals.LogFileStream.Close();
                Globals.LogStreamWriter = null;
                Globals.LogFileStream = null;
            }
        }

        internal void ResetSimulation()
        {
            // If still setting up the simulation, return immediately:
            if (Globals.SettingUp == true) return;
            // Otherwise start to reset:
            Globals.SimStatus = Globals.status.Resetting;
            // Stop then clock and set back to zero time:
            Globals.theTimer.IsEnabled = false;
            Globals.SimTime = 0;
            Globals.RealTime = 0;
            Globals.WhenPacketsLastViewed = -1; // So that things are updated at time = 0
            Globals.WhenLogFileLastViewed = -1; // So that things are updated at time = 0
            Globals.WhenConsoleLastViewed = -1; // So that things are updated at time = 0
            // Empty the event queue, and reset the time and packet counts:
            Globals.theQueue.Reset();
            Globals.ClearStatistics();
            Globals.myPackets.Clear();
            Globals.MaxPacketsInQueues = Globals.DefaultMaxPacketsInQueues;
            Globals.MaxEventsPerNode = Globals.DefaultMaxEventsPerNode;
            // The indicators of packet numbers and energy:
            ResetEnergyAndPacketIndicators();
            // If not already reset, set up the nodes again to make sure they are reset,
            // and initialise the protocol layers:
            if (Globals.SimStatus != Globals.status.Reset) SetupNodes(Canvas2D);
            // Don't initialise the nodes: this is already done in SetupNodes,
            // and doing it again will put in a new Application Callback which
            // results in a doubling of the packet generation rate.
            // ** foreach (cNode node in Globals.myNodes) node.Initialise(); **
            // Stop the clock and set back to zero time:
            Globals.theTimer.IsEnabled = false;
            btnRun.Content = "Start";
            btnRun.IsEnabled = true;
            // Allow stepping, or the number of nodes to be changed:
            btnStep.IsEnabled = true;
            MakeChangesPossibleOrNot(true);
            // Then initialise the nodes:
            // InitialiseNodes(); // Not required, already done in SetupNodes ???
            // Add an "end simulation" event to the queue:
            Globals.theQueue.AddEvent(new cEvent(null, null, (long)(Globals.SimulationLength * 1e9), EventType.System_Stop));
            // Add an "get stored packet to play out" event to the queue:
            Globals.InitialisePacketsToGo();
            // Then if the nodes are moving, add a movement event to the queue:
            if (Globals.MoveMode != Globals.MovementType.None)
                Globals.theQueue.AddEvent(new cEvent(null, null, 0, EventType.System_Movement));
            // Status should be Resetting (so no events will be called), then
            // can use WhatToDoWhenTimerTimesOut() to update the screen strings:
            WhatToDoWhenTimerTimesOut(null, null);
            // Set this back to a default value, in case number of nodes has changed:
            Globals.EventsPerInterrupt = 100;
            // Close any already open log file and zero counts:
            CloseLogFile();
            Globals.LogEventCount = 0;
            Globals.LogFileEntryCount = 0;
            if (Globals.ConsoleText != null)
                Globals.ConsoleText.Length = 0;
            // And empty the infobox (if it exists yet) and the other information boxes:
            if (txtInfoBox != null) txtInfoBox.Text = "";
            Globals.SelectedNode = Globals.NOWHERE;
            if (Globals.myNodes.Count > 0) Globals.myNodes[0].ClearRouteingLines();
            if (txtStatus != null) txtStatus.Text = "Version 0.16.01.15 (beta) ready to go.";
            if (txtConsole != null) txtConsole.Text = Globals.ConsoleText.ToString();
            if (txtQuery != null) txtQuery.Text = "";
            if (txtResponse != null) txtResponse.Text = "";
            // OK that's it... just set status to reset and all is ready to go:
            Globals.SimStatus = Globals.status.Reset;
            int thing = Globals.theQueue.EventCount();
        }
        // If a new log file is required, then one is started here.
        internal void StartNewLogFile()
        {
            // Whether a log file is required or not, clear the stringbuilder from the last run:
            Globals.LogFileCurrentContents.Remove(0, Globals.LogFileCurrentContents.Length);

            if (Globals.LogStreamWriter != null) return; // There's already a log file
            if (Globals.LogFileOn == false) return; // A log file is not required
            string now = DateTime.Now.Year.ToString() + "_" + DateTime.Now.Month.ToString() + "_" + DateTime.Now.Day.ToString() + "_"
                + DateTime.Now.Hour.ToString() + "_" + DateTime.Now.Minute.ToString() + "_" + DateTime.Now.Second.ToString() + "_"
                + DateTime.Now.Millisecond.ToString();
            Globals.LogFileName = "LogFile_" + now + ".txt";
            Globals.LogFileStream = new FileStream(Globals.LogFileName, FileMode.OpenOrCreate, FileAccess.ReadWrite);
            Globals.LogStreamWriter = new StreamWriter(Globals.LogFileStream);
        }

        private void MakeChangesPossibleOrNot(Boolean OK)
        {
            sldNodes.IsEnabled = OK;
            sldSimLength.IsEnabled = OK;
            foreach (GroupBox box in mySetupGroups) box.IsEnabled = OK;
            btnLoadXML.IsEnabled = OK;
            btnLoadXMLNodes.IsEnabled = OK;
            btnLoadXMLPackets.IsEnabled = OK;
            btnSaveXMLPackets.IsEnabled = OK;
            btnSaveXML.IsEnabled = OK;
            btnLoadBatch.IsEnabled = OK;
            btnSaveNodes.IsEnabled = OK;
        }

        private void chkAnimations_Change(object sender, RoutedEventArgs e)
        {
            if (chkAnimations.IsChecked == true) Globals.Animate = true;
            if (chkAnimations.IsChecked == false) Globals.Animate = false;
        }
        private void chkRealTime_Change(object sender, RoutedEventArgs e)
        {
            if (chkRealTime.IsChecked == true && chkFastTime.IsChecked == false)
            {
                Globals.RealTime = Globals.SimTime;
                Globals.TimingMode = Globals.TimeMode.Real;
            }
            else if (chkRealTime.IsChecked == false && chkFastTime.IsChecked == true)
            {
                Globals.RealTime = Globals.SimTime;
                Globals.TimingMode = Globals.TimeMode.Fast;
            }
            else if (chkRealTime.IsChecked == false && chkFastTime.IsChecked == false)
            {
                Globals.SimTime = Globals.RealTime;
                Globals.TimingMode = Globals.TimeMode.NonReal;
            }
            else if (chkRealTime.IsChecked == true && chkFastTime.IsChecked == true)
            {
                if (sender == (object)chkRealTime) chkFastTime.IsChecked = false;
                else chkRealTime.IsChecked = false;
            }
        }

        private void UpdateLogStuff(object sender, RoutedEventArgs e)
        {
            if (chkLogFile.IsChecked == true) Globals.LogFileOn = true;
            else Globals.LogFileOn = false;
            if (chkLogApplication.IsChecked == true) Globals.LogApplication = true;
            else Globals.LogApplication = false;
            if (chkLogTransport.IsChecked == true) Globals.LogTransport = true;
            else Globals.LogTransport = false;
            if (chkLogNetwork.IsChecked == true) Globals.LogNetwork = true;
            else Globals.LogNetwork = false;
            if (chkLogLogicalLink.IsChecked == true) Globals.LogLogicalLink = true;
            else Globals.LogLogicalLink = false;
            if (chkLogMultipleAccess.IsChecked == true) Globals.LogMultipleAccess = true;
            else Globals.LogMultipleAccess = false;
            if (chkLogPhysical.IsChecked == true) Globals.LogPhysical = true;
            else Globals.LogPhysical = false;
            if (chkLogMovement.IsChecked == true) Globals.LogMovement = true;
            else Globals.LogMovement = false;
            if (chkLogSystem.IsChecked == true) Globals.LogSystem = true;
            else Globals.LogSystem = false;
            // Then only enable the "step to log event" button, if there is a log event clicked
            btnStepToLog.IsEnabled = false;
            if (Globals.LogApplication || Globals.LogTransport || Globals.LogNetwork
                || Globals.LogLogicalLink || Globals.LogMultipleAccess || Globals.LogPhysical
                || Globals.LogMovement || Globals.LogSystem) btnStepToLog.IsEnabled = true;
        }

        private void sldSimTime_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            if (Globals.SettingUp == true) return;
            // If this is being moved, then we must be on the Main tab.  This is a shadow of the
            // real control slider on the Setup tab, so all I need to do here is:
            Globals.stsSimulationLength.theSlider.Value = ((Slider)sender).Value;
            if (lblSimLength != null)
                lblSimLength.Content = ((int)(Globals.SimulationLength)).ToString() + " s";
            // Then reset the simulation:
            ResetSimulation();
        }

        private void BigTab_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (tabControl1.SelectedItem == tabOutput)
            {
                rbOutputs_Checked(null, null);
            }
            if (tabControl1.SelectedItem == tabMain)
            {
                // Copy the correct values into the two shadowed sliders:
                sldNodes.Value = Globals.stsNumberOfNodes.GetSliderValue();
                sldSimLength.Value = Globals.stsSimulationLength.GetSliderValue();
                // and set the labels to the current values:
                lblSimLength.Content = ((int)(Globals.SimulationLength)).ToString() + " s";
                if (Globals.NumberOfNodes == 1) lblNodes.Content = "1 Node";
                else lblNodes.Content = Globals.NumberOfNodes.ToString() + " Nodes";
            }
            if (tabControl1.SelectedItem == tabSetupSimulation)
            {
                // Set the values of the shared sliders:
                Globals.stsNumberOfNodes.SetSliderValue(Globals.NumberOfNodes, false);
                Globals.stsSimulationLength.SetSliderValue(Globals.SimulationLength, false);
            }
            if (tabControl1.SelectedItem == tabPhysicalActivity)
            {
                WorkOutNewPHYActivityTimes(false);
                WorkOutNewPHYActivityNodes();
                ReDrawPHYActivityStuff();
            }
        }

        private void cmbLogNodes_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int Selection = cmbLogNodes.SelectedIndex;
            if (Selection == 0) Globals.WhatToLog = Globals.eWhatToLog.All;
            else if (Selection == 1) Globals.WhatToLog = Globals.eWhatToLog.Zero;
            else if (Selection == 2) Globals.WhatToLog = Globals.eWhatToLog.ZeroAndOne;
            else if (Selection == 3) Globals.WhatToLog = Globals.eWhatToLog.PacketZero;
            else if (Selection == 4) Globals.WhatToLog = Globals.eWhatToLog.PacketZeroAndOne;
            else if (Selection == 5) Globals.WhatToLog = Globals.eWhatToLog.PacketNonZero;
        }


        private void btnSaveNodes_Click(object sender, RoutedEventArgs e)
        {
            cXMLStuff.XMLSaveNodes();
        }
        private void btnLoadXML_Click(object sender, RoutedEventArgs e)
        {
            cXMLStuff.XMLLoadConfiguration(false, false, false);
        }
        private void btnSaveXML_Click(object sender, RoutedEventArgs e)
        {
            cXMLStuff.XMLSaveConfiguration();
        }
        private void btnLoadXMLPackets_Click(object sender, RoutedEventArgs e)
        {
            cXMLStuff.XMLLoadConfiguration(false, true, false);
        }
        private void btnSaveXMLPackets_Click(object sender, RoutedEventArgs e)
        {
            cXMLStuff.XMLSavePackets();
        }
        private void btnLoadXMLNodes_Click(object sender, RoutedEventArgs e)
        {
            cXMLStuff.XMLLoadConfiguration(false, false, true);
        }

        private void btnLoadBatch_Click(object sender, RoutedEventArgs e)
        {
            cXMLStuff.XMLLoadConfiguration(true, false, false);
        }

        private void chkNumbers_Checked(object sender, RoutedEventArgs e)
        {
            if (((CheckBox)sender).IsChecked == true) Globals.ShowNumbers = true;
            else Globals.ShowNumbers = false;
            foreach (cNode node in Globals.myNodes)
            {
                node.SetNumberVisibility(Globals.ShowNumbers);
            }
        }
        private void chkRoutes_Checked(object sender, RoutedEventArgs e)
        {
            if (((CheckBox)sender).IsChecked == true) Globals.ShowRoutes = true;
            else Globals.ShowRoutes = false;
            // If there is a selected node, then print them up immediately:
            if (chkRoutes.IsChecked == true && Globals.SelectedNode != Globals.NOWHERE)
            {
                Globals.myNodes[Globals.SelectedNode].ShowRouteingLines(0.5);
            }
            else if (chkRoutes.IsChecked == false && Globals.myNodes.Count > 0)
            {
                Globals.myNodes[0].ClearRouteingLines();
            }
        }
        private void chkParent_Checked(object sender, RoutedEventArgs e)
        {
            if (((CheckBox)sender).IsChecked == true)
            {
                Globals.ShowParents = true;
                for (int loop = 0; loop < Globals.NumberOfNodes; loop++)
                {
                    Globals.myNodes[loop].ShowParentLine(0.5, true);
                    Globals.myNodes[loop].ShowParentLine(0.5, false);
                }
            }
            else
            {
                Globals.ShowParents = false;
                for (int loop = 0; loop < Globals.NumberOfNodes; loop++)
                {
                    Globals.myNodes[loop].ClearParentLine(true);
                    Globals.myNodes[loop].ClearParentLine(false);
                }
            }
        }
        private void rbShowEvents_Checked(object sender, RoutedEventArgs e)
        {
            txtConsole.Visibility = Visibility.Hidden;
            txtStatus.Visibility = Visibility.Visible;
        }
        private void rbShowConsole_Checked(object sender, RoutedEventArgs e)
        {
            txtConsole.Visibility = Visibility.Visible;
            txtStatus.Visibility = Visibility.Hidden;
        }

        // When the query text is selected and user is typing a query
        private void txtQuery_KeyDown(object sender, System.Windows.Input.KeyEventArgs e)
        {
            if (e.Key != Key.Enter) return;

            // The default node to use is the currently selected node:
            int currentSelectedNode = Globals.SelectedNode;

            // However it is possible to specify a different node in the query as the second field:
            char[] delimiterChars = { ' ', ',', '.', ':', '\t' };
            string[] words = txtQuery.Text.Split(delimiterChars);
            int tryThis; if (words.Length > 1)
            {
                if (int.TryParse(words[1], out tryThis)) currentSelectedNode = tryThis;
            }

            if (currentSelectedNode < 0 || currentSelectedNode >= Globals.NumberOfNodes)
            {
                txtResponse.Text = "Selected node not valid.  Choose another one.";
                return;
            }
            // Now got selected node, see which network layer is being addressed:
            if (txtQuery.Text.Length == 0)
            {
                txtResponse.Text = "Invalid query, please ask something.";
                return;
            }
            // Next, find out which layer to send the query to:
            char layerIdentifier = txtQuery.Text[0];
            string outputString = "";
            switch (layerIdentifier)
            {
                case 'N':
                case 'n':
                    // Send this one to the network layer:
                    outputString = Globals.myNodes[currentSelectedNode].NetworkLayer.AskQuery(txtQuery.Text);
                    break;
                case 'T':
                case 't':
                    // Send this one to the transport layer:
                    outputString = Globals.myNodes[currentSelectedNode].TransportLayer.AskQuery(txtQuery.Text);
                    break;
                case 'L':
                case 'l':
                    // Send this one to the logical-link layer:
                    outputString = Globals.myNodes[currentSelectedNode].LogicalLinkLayer.AskQuery(txtQuery.Text);
                    break;
                case 'M':
                case 'm':
                    // Send this one to the MAC layer:
                    outputString = Globals.myNodes[currentSelectedNode].MACLayer.AskQuery(txtQuery.Text);
                    break;
                case 'S':
                case 's':
                    // Special case, this means "select this node"
                    if (currentSelectedNode < Globals.NumberOfNodes) 
                    {
                        Globals.myNodes[currentSelectedNode].ellNode_MouseDown(null, null);
                    }
                    break;
                default:
                    break;
            }
            txtResponse.Text = outputString;
        }

        #endregion

        #region Region: Output grid, and output routines
        private void rbOutputs_Checked(object sender, RoutedEventArgs e)
        {
            if (tbOutputStatistics == null) return;  // Sort out initialisation

            // Maintain all textboxes as separate and only updating when
            // required speeds up rendering when user returns to the same
            // output at the same point in the simulation.
            tbOutputLogFile.Visibility = System.Windows.Visibility.Hidden;
            tbOutputStatistics.Visibility = System.Windows.Visibility.Hidden;
            tbOutputRawPackets.Visibility = System.Windows.Visibility.Hidden;
            tbOutputRawNodes.Visibility = System.Windows.Visibility.Hidden;
            tbOutputConsole.Visibility = System.Windows.Visibility.Hidden;
            tbOutputEventQueue.Visibility = System.Windows.Visibility.Hidden;
            tbRawHeader.Visibility = System.Windows.Visibility.Hidden;
            btnOutput.Visibility = System.Windows.Visibility.Hidden;
            ChangeVisibilityOfSearchStuff(Visibility.Hidden);
            btnSearch.Visibility = System.Windows.Visibility.Hidden;
            btnSearchLast.Visibility = System.Windows.Visibility.Hidden;
            btnSearchNext.Visibility = System.Windows.Visibility.Hidden;
            tbSearcher.Visibility = System.Windows.Visibility.Hidden;

            Boolean refillLogFile = true;
            Boolean refillConsole = true;
            Boolean refillPackets = true;
            if (Globals.WhenLogFileLastViewed == Globals.SimTime) refillLogFile = false;
            if (Globals.WhenConsoleLastViewed == Globals.SimTime) refillConsole = false;
            if (Globals.WhenPacketsLastViewed == Globals.SimTime) refillPackets = false;

            if (rbLogFile.IsChecked == true)
            {
                if (refillLogFile == true)
                {
                    // What to print up is held in the big stringbuilder:
                    tbOutputLogFile.Clear();
                    string Whatever = Globals.LogFileCurrentContents.ToString();
                    tbOutputLogFile.Text = Whatever;
                    // And holding message if nothing there:
                    if (tbOutputLogFile.Text.Length == 0) tbOutputLogFile.Text = "No logged events.";
                    Globals.WhenLogFileLastViewed = Globals.SimTime;
                }
                tbOutputLogFile.Visibility = System.Windows.Visibility.Visible;
                btnSearch.Visibility = System.Windows.Visibility.Hidden;
                ChangeVisibilityOfSearchStuff(Visibility.Visible);
            }
            else if (rbStatistics.IsChecked == true)
            {
                tbOutputStatistics.Clear();
                tbOutputStatistics.Text = MakeStatisticsUpAtEnd();
                tbOutputStatistics.Visibility = System.Windows.Visibility.Visible;
            }
            else if (rbPackets.IsChecked == true)
            {
                if (refillPackets == true)
                {
                    tbOutputRawPackets.Clear();
                    StringBuilder Raw = new StringBuilder();
                    foreach (Globals.RawPacketData data in Globals.myPackets)
                        Raw.AppendLine(data.ToString());
                    tbOutputRawPackets.Text = Raw.ToString();
                    // And holding message if nothing there:
                    if (tbOutputRawPackets.Text.Length == 0) tbOutputRawPackets.Text = "No packets sent.";
                    Globals.WhenPacketsLastViewed = Globals.SimTime;
                }
                tbOutputRawPackets.Visibility = System.Windows.Visibility.Visible;
                tbRawHeader.Text = "Packet\tPriority\tLength\tSource\tDest\tHops\tTime Created\tTime Delivered";
                tbRawHeader.Visibility = System.Windows.Visibility.Visible;
                ChangeVisibilityOfSearchStuff(Visibility.Visible);
            }
            else if (rbSummary.IsChecked == true)
            {
                tbOutputRawNodes.Clear();
                StringBuilder Raw = new StringBuilder();
                foreach (cNode node in Globals.myNodes)
                    Raw.AppendLine(node.GetStatusString());
                tbOutputRawNodes.Text = Raw.ToString();
                tbOutputRawNodes.Visibility = System.Windows.Visibility.Visible;
                tbRawHeader.Text = "Node\t    X\t    Y\t  Sent\tReceived\t  Energy";
                tbRawHeader.Visibility = System.Windows.Visibility.Visible;
            }
            else if (rbConsole.IsChecked == true)
            {
                if (refillConsole == true)
                {
                    tbOutputConsole.Clear();
                    tbOutputConsole.Text = Globals.ConsoleText.ToString();
                    Globals.WhenConsoleLastViewed = Globals.SimTime;
                }
                tbOutputConsole.Visibility = System.Windows.Visibility.Visible;
                ChangeVisibilityOfSearchStuff(Visibility.Visible);
            }
            else if (rbEventQueue.IsChecked == true)
            {
                tbOutputEventQueue.Clear();
                StringBuilder Raw = new StringBuilder();
                // Count through backwards, so next item to do is at the top:
                for (int loop = Globals.theQueue.EventCount() - 1; loop >= 0;  loop--)
                    Raw.AppendLine(Globals.theQueue.ScryEvent(loop).ToString());
                tbOutputEventQueue.Text = Raw.ToString();
                // Holding message if nothing is there, or next event button if something is:
                if (tbOutputEventQueue.Text.Length == 0)
                {
                    tbOutputEventQueue.Text = "No events in queue.";
                    btnOutput.Visibility = System.Windows.Visibility.Hidden;
                }
                else
                {
                    btnOutput.Visibility = System.Windows.Visibility.Visible;
                }
                tbOutputEventQueue.Visibility = System.Windows.Visibility.Visible;
            }
        }
        private void ChangeVisibilityOfSearchStuff(Visibility vis)
        {
            btnSearch.Visibility = vis;
            btnSearchLast.Visibility = vis;
            btnSearchNext.Visibility = vis;
            tbSearcher.Visibility = vis;
        }

        #region Region: Sorting
        enum whatToSort { PacketNumber, Priority, Length, Source, Destination, Hops, CreationTime, DeliveryTime };
        private void tbRawHeader_SortAscending(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            // Have to work out what I'm sorting, as a function of mouse position:
            double xLoc = e.GetPosition(tbRawHeader).X;
            SortPacketsInTextBox(xLoc, true);
        }
        private void tbRawHeader_SortDescending(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            // Have to work out what I'm sorting, as a function of mouse position:
            double xLoc = e.GetPosition(tbRawHeader).X;
            SortPacketsInTextBox(xLoc, false);
        }
        private void SortPacketsInTextBox(double xLoc, Boolean ascending)
        {
            // MessageBox.Show("Ascending sort at " + xLoc);
            whatToSort sortCategory = whatToSort.PacketNumber;
            if (xLoc < 42) sortCategory = whatToSort.PacketNumber;
            else if (xLoc < 92) sortCategory = whatToSort.Priority;
            else if (xLoc < 139) sortCategory = whatToSort.Length;
            else if (xLoc < 186) sortCategory = whatToSort.Source;
            else if (xLoc < 230) sortCategory = whatToSort.Destination;
            else if (xLoc < 280) sortCategory = whatToSort.Hops;
            else if (xLoc < 373) sortCategory = whatToSort.CreationTime;
            else if (xLoc < 477) sortCategory = whatToSort.DeliveryTime;

            int dir = ascending ? 1 : -1;

            List<Globals.RawPacketData> sorting = new List<Globals.RawPacketData>();
            foreach (Globals.RawPacketData p in Globals.myPackets) sorting.Add(p);
            switch (sortCategory)
            {
                case whatToSort.Priority:
                    sorting.Sort(delegate(Globals.RawPacketData A, Globals.RawPacketData B) 
                    {
                        int one = A.GetPriority();
                        int two = B.GetPriority();
                        if (one != two) return dir * one.CompareTo(two);
                        else return A.GetPacketNumber().CompareTo(B.GetPacketNumber());
                    });
                    break;
                case whatToSort.Length:
                    sorting.Sort(delegate(Globals.RawPacketData A, Globals.RawPacketData B) 
                    {
                        int one = A.GetLength();
                        int two = B.GetLength();
                        if (one != two) return dir * one.CompareTo(two);
                        else return A.GetPacketNumber().CompareTo(B.GetPacketNumber());
                    });
                    break;
                case whatToSort.Source:
                    sorting.Sort(delegate(Globals.RawPacketData A, Globals.RawPacketData B) 
                    {
                        int one = A.GetOriginalSource();
                        int two = B.GetOriginalSource();
                        if (one != two) return dir * one.CompareTo(two);
                        else return A.GetPacketNumber().CompareTo(B.GetPacketNumber());
                    });
                    break;
                case whatToSort.Destination:
                    sorting.Sort(delegate(Globals.RawPacketData A, Globals.RawPacketData B) 
                    {
                        int one = A.GetFinalDestination();
                        int two = B.GetFinalDestination();
                        if (one != two) return dir * one.CompareTo(two);
                        else return A.GetPacketNumber().CompareTo(B.GetPacketNumber());
                    });
                    break;
                case whatToSort.Hops:
                    sorting.Sort(delegate(Globals.RawPacketData A, Globals.RawPacketData B) 
                    {
                        int one = A.GetNumberOfHops();
                        int two = B.GetNumberOfHops();
                        if (one != two) return dir * one.CompareTo(two);
                        else return A.GetPacketNumber().CompareTo(B.GetPacketNumber());
                    });
                    break;
                case whatToSort.CreationTime:
                    sorting.Sort(delegate(Globals.RawPacketData A, Globals.RawPacketData B) 
                    {
                        long one = A.GetStartTime();
                        long two = B.GetStartTime();
                        if (one != two) return dir * one.CompareTo(two);
                        else return A.GetPacketNumber().CompareTo(B.GetPacketNumber());
                    });
                    break;
                case whatToSort.DeliveryTime:
                    sorting.Sort(delegate(Globals.RawPacketData A, Globals.RawPacketData B) 
                    {
                        long one = A.GetEndTime();
                        long two = B.GetEndTime();
                        if (one != two) return dir * one.CompareTo(two);
                        else return A.GetPacketNumber().CompareTo(B.GetPacketNumber());
                    });
                    break;
                case whatToSort.PacketNumber:
                default:
                    sorting.Sort(delegate(Globals.RawPacketData A, Globals.RawPacketData B) 
                    {
                        int one = A.GetPacketNumber();
                        int two = B.GetPacketNumber();
                        return dir * one.CompareTo(two);
                    });
                    break;
            }

            tbOutputRawPackets.Clear();
            StringBuilder Raw = new StringBuilder();
            foreach (Globals.RawPacketData data in sorting)
                Raw.AppendLine(data.ToString());
            tbOutputRawPackets.Text = Raw.ToString();
            // And holding message if nothing there:
            if (tbOutputRawPackets.Text.Length == 0) tbOutputRawPackets.Text = "No packets sent.";
        }
        #endregion

        #region Region: Searching
        static int _SearchFromHere = 0;
        List<int> _SearchLocations = new List<int>();
        int _SearchIndex = 0;
        int _SearchHowManyLines = 0;
        TextBox _SearchInHere = null;
        private void btnSearch_Click(object sender, RoutedEventArgs e)
        {
            // First work out which textbox to search through:
            _SearchInHere = null;
            if (tbOutputRawPackets.Visibility == System.Windows.Visibility.Visible)
                _SearchInHere = tbOutputRawPackets;
            else if (tbOutputRawNodes.Visibility == System.Windows.Visibility.Visible)
                _SearchInHere = tbOutputRawNodes;
            else if (tbOutputConsole.Visibility == System.Windows.Visibility.Visible)
                _SearchInHere = tbOutputConsole;
            else if (tbOutputLogFile.Visibility == System.Windows.Visibility.Visible)
                _SearchInHere = tbOutputLogFile;
            if (_SearchInHere == null) return;
            if (_SearchInHere.Text.Length < 2) return;

            // Then find the first instance:
            _SearchFromHere = 0;
            int startLoc = _SearchInHere.Text.IndexOf(tbSearcher.Text, 0);
            if (startLoc < 0)
            {
                _SearchLocations.Clear();
                _SearchIndex = -1;
                return;
            }
            
            // Count how many lines are in this textbox:
            _SearchHowManyLines = 0;
            for (int loop = 0; loop < _SearchInHere.Text.Length; loop++)
                if (_SearchInHere.Text[loop] == '\n') _SearchHowManyLines++;

             // There's at least one...
             _SearchLocations.Clear();
            _SearchLocations.Add(startLoc);
            _SearchIndex = 0;
            _SearchFromHere = startLoc;

            SearchAndHighlight(startLoc);
        }

        private void btnSearchLast_Click(object sender, RoutedEventArgs e)
        {
            if (_SearchLocations.Count == 0) return; // Nothing here.

            if (_SearchIndex > 0)
            {
                _SearchIndex--;
                SearchAndHighlight(_SearchLocations[_SearchIndex]);
            }
            else
            {
                SearchAndHighlight(_SearchLocations[0]);
            }
        }

        private void btnSearchNext_Click(object sender, RoutedEventArgs e)
        {
            if (_SearchLocations.Count == 0) return; // Nothing here.

            // If at the end need to do a new search, otherwise can jump
            // straight there:
            if (_SearchIndex == _SearchLocations.Count - 1)
            {
                // Find the next instance:
                int startLoc = _SearchInHere.Text.IndexOf(tbSearcher.Text, _SearchFromHere + 1);
                if (startLoc > 0)
                {
                    _SearchLocations.Add(startLoc);
                    _SearchFromHere = startLoc;
                    _SearchIndex++;
                }
            }
            else
            {
                _SearchIndex++;
            }
            
            SearchAndHighlight(_SearchLocations[_SearchIndex]);
        }

        private void SearchAndHighlight(int startLoc)
        {
            _SearchInHere.SelectionStart = startLoc;
            _SearchInHere.SelectionLength = tbSearcher.Text.Length;
            _SearchInHere.SelectionBrush = Globals.TextHighlightBrush;
            _SearchInHere.SelectionOpacity = 0.4;
            _SearchInHere.Focus();

            // Now there's the case where the highlighted text is not currently on the screen...
            // I'll need to know which line it is on...
            int whichLine = 0;
            for (int loop = 0; loop < startLoc; loop++)
            {
                if (_SearchInHere.Text[loop] == '\n') whichLine++;
            }
            _SearchInHere.ScrollToLine(whichLine);
        }

        private void tbSearcher_KeyDown(object sender, System.Windows.Input.KeyEventArgs e)
        {
            // If return is pressed, do a search (same as pressing the Find button).
            if (e.Key == Key.Return) btnSearch_Click(null, null);
        }
        #endregion

        private string MakeStatisticsUpAtEnd()
        {
            StringBuilder Stats = new StringBuilder();
            Stats.AppendLine("Number of Nodes: " + Globals.myNodes.Count.ToString());
            long currentTime = Math.Max(Globals.RealTime, Globals.SimTime);
            Stats.AppendLine("Simulation Time: " + currentTime / 1.0e9 + " s");
            Stats.AppendLine("(Total Simulation Length: " + Globals.SimulationLength + " s)");
            Stats.AppendLine();
            Stats.AppendLine("Number of Packets Sent: " + Globals.TotalPacketsSent.ToString());
            Stats.AppendLine("Number of Packets Arrived: " + Globals.TotalPacketsReceived.ToString());
            Stats.AppendLine("Number of Packets Delivered to Wrong Node: " + Globals.TotalPacketsReceivedAtWrongNode.ToString());
            Stats.AppendLine("Number of Packets Delivered to Wrong Port: " + Globals.TotalPacketsReceivedAtWrongPort.ToString());
            double SuccessRatio = Globals.TotalPacketsReceived / (double)Globals.TotalPacketsSent;
            Stats.AppendLine();
            Stats.AppendLine("Proportion of Packets Delivered: " + (100 * SuccessRatio).ToString("0.##") + " %");
            Stats.AppendLine("Throughput: " + (Globals.TotalPacketsReceived / (currentTime / 1.0e9)).ToString("0.########") + " packets/sec");
            Stats.AppendLine();
            Stats.AppendLine("Number of Frames Transmitted: " + Globals.TotalFramesSent.ToString());
            Stats.AppendLine("Number of Frames Received: " + Globals.TotalFramesReceived.ToString());
            double MeanFramesPerPacket = Globals.TotalFramesSent / (double)Globals.TotalPacketsSent;
            Stats.AppendLine("Mean Frames Sent Per Packet: " + (MeanFramesPerPacket).ToString("0.###"));
            Stats.AppendLine();
            Stats.AppendLine("Mean Delay: " + (Globals.TotalDelay / (double)Globals.TotalPacketsReceived / 1e9).ToString("0.#########") + " s");
            Stats.AppendLine("Minimum Delay: " + (Globals.MinDelay / (double)1e9).ToString("0.#########") + " s"); ;
            Stats.AppendLine("Maximum Delay: " + (Globals.MaxDelay / (double)1e9).ToString("0.#########") + " s"); ;
            Stats.AppendLine();
            double TotalEnergyUsed = 0.0;
            double TotalEnergyUsedTransmitting = 0.0;
            double TotalEnergyUsedReceiving = 0.0;
            double TotalEnergyUsedListening = 0.0;
            double MaxEnergyUsed = 0.0; int MaxEnergyNode = 0;
            double MinEnergyUsed = 1e12; int MinEnergyNode = 0;
            for (int loop = 0; loop < Globals.myNodes.Count; loop++)
            {
                double EnergyUsedByThisNode = Globals.myNodes[loop].GetEnergyUsed();
                if (EnergyUsedByThisNode > MaxEnergyUsed)
                {
                    MaxEnergyUsed = EnergyUsedByThisNode;
                    MaxEnergyNode = loop;
                }
                if (EnergyUsedByThisNode < MinEnergyUsed)
                {
                    MinEnergyUsed = EnergyUsedByThisNode;
                    MinEnergyNode = loop;
                }
                TotalEnergyUsed += EnergyUsedByThisNode;
                TotalEnergyUsedTransmitting += Globals.myNodes[loop].GetEnergyUsedTransmitting();
                TotalEnergyUsedReceiving += Globals.myNodes[loop].GetEnergyUsedReceiving();
                TotalEnergyUsedListening += Globals.myNodes[loop].GetEnergyUsedListening();
            }
            Stats.AppendLine("Total Energy Used: " + TotalEnergyUsed.ToString("0.###") + " J");
            // Stats.AppendLine("Total Energy Used Listening: " + TotalEnergyUsedListening.ToString("0.###"));
            Stats.AppendLine("Total Energy Used Receiving: " + TotalEnergyUsedReceiving.ToString("0.###") + " J");
            Stats.AppendLine("Total Energy Used Transmitting: " + TotalEnergyUsedTransmitting.ToString("0.###") + " J");
            Stats.AppendLine("Maximum Energy Used by a Node: " + MaxEnergyUsed.ToString("0.###") + " J by node " + MaxEnergyNode.ToString());
            Stats.AppendLine("Minimum Energy Used by a Node: " + MinEnergyUsed.ToString("0.###") + " J by node " + MinEnergyNode.ToString());
            return Stats.ToString();
        }

        // The mouse double-click things to get to the PHY activity window
        DateTime _lastClick = DateTime.Now;
        private void tbOutputTextBox_MouseLeftButtonUp(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            // Check that not clicking on the scroll bars.  Without this check, you
            // can select some text with a time, then double click on the scroll bar 
            // which triggers this function but does not change the selected text,
            // and that causes an undesired jump to the PHY output display.
            if (e.OriginalSource is TextBox == false) return;

            // Now check for double-clicks:
            double howLong = (DateTime.Now - _lastClick).TotalMilliseconds;
            if (howLong < 500)
            {
                string strWhen = (sender as TextBox).SelectedText;
                TextBox tb = sender as TextBox;

                // The only problem with this is that sometimes the time is
                // specified in seconds, and sometimes with commas separating
                // the thousands for easier reading.  In both cases the default
                // behaviour of the double-click to stop the select text at
                // a non alphanumeric character is not what is required.
                // I'll try and extend the range of selected text to the next
                // white space character:
                int selectStart = tb.SelectionStart;
                int selectLength = tb.SelectionLength;
                int totalLength = tb.Text.Length;

                // This can go wrong if the selection is right at the end, or right
                // at the start of the text file, so I need to check that the
                // starting points are sensible, and if not, adjust them.
                if (selectStart < 0) selectStart = 0;
                if (selectStart > tb.Text.Length - 2) selectStart = tb.Text.Length - 2;
                if (selectLength > tb.Text.Length - selectStart - 1) selectLength = tb.Text.Length - selectStart - 1;

                Boolean lookingBack = true;
                while (lookingBack)
                {
                    char cfs = tb.Text[selectStart];
                    if (cfs == ',' || cfs == '.' || Char.IsDigit(cfs))
                    {
                        selectStart -= 1;
                        selectLength += 1;
                        if (selectStart == 0) lookingBack = false;
                    }
                    else
                    {
                        lookingBack = false;
                    }
                }

                Boolean lookingForward = true;
                while (lookingForward)
                {
                    char cfs = tb.Text[selectStart + selectLength];
                    if (cfs == ',' || cfs == '.' || Char.IsDigit(cfs))
                    {
                        selectLength += 1;
                        if (selectStart + selectLength >= totalLength)
                            lookingForward = false;
                    }
                    else
                    {
                        lookingForward = false;
                    }
                }
                strWhen = tb.Text.Substring(selectStart, selectLength);

                long when = GetTimeFromString(strWhen);

                // There's another issue.  Some of the times in the log reports are
                // local times, but the times on the PHY output trace are always
                // global (exact) times.  I'll need to spot if this is a local
                // time, and if so, convert it to a global time.  This isn't too
                // hard, since every local time has the word "local" just before 
                // it on the same line, and the number of the node just before that.
                string beforeNumber = "";
                if (selectStart > 60)
                {
                    for (int loop = -60; loop < 0; loop++)
                    {
                        if (tb.Text[selectStart + loop] == '\n') beforeNumber = "";
                        else beforeNumber += tb.Text[selectStart + loop];
                    }
                    if (beforeNumber.ToUpper().Contains("LOCAL") == true)
                    {
                        // This is a local time.  I'll need to work out which node it comes from:
                        int whereIs = beforeNumber.ToUpper().IndexOf("NODE");
                        string nodeNum = beforeNumber.Substring(whereIs + 4, 4);
                        int whichNode = GetIntegerFromString(nodeNum);
                        if (whichNode >= 0 && whichNode < Globals.NumberOfNodes)
                        {
                            when = Globals.myNodes[whichNode].ConvertLocalToGlobalTime(when);
                        }
                    }
                }

                if (when > 100000 && when < Globals.SimTime)
                {
                    setCentreTimeToGivenTime(when);
                    tabControl1.SelectedIndex = 4;  // Makes PHY tab active
                }
            }
            _lastClick = DateTime.Now;
        }
        private int GetIntegerFromString(string strWhen)
        {
            int outputInt = -1;

            // Some strings have decimal points (they are in seconds),
            // others have commas.  I'll sort these into longs.
            string numString = "";
            foreach (char c in strWhen)
            {
                if (c == '0' || c == '1' || c == '2' || c == '3'
                    || c == '4' || c == '5' || c == '6' || c == '7'
                    || c == '8' || c == '9') numString += c;
            }

            Int32.TryParse(numString, out outputInt);
            return outputInt;
        }

        // Saving the outputs in the file requested:
        static private string btnSave_CurrentDirectory = @"C:\";
        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                SaveFileDialog NewSFD = new SaveFileDialog();
                NewSFD.Title = "Select Filename";
                NewSFD.InitialDirectory = btnSave_CurrentDirectory;
                NewSFD.Filter = "All files (*.*)|*.*|Text files (*.txt)|*.txt|Log files (*.log)|*.log";
                NewSFD.FilterIndex = 2;
                NewSFD.RestoreDirectory = true;
                Nullable<bool> result = NewSFD.ShowDialog();
                btnSave_CurrentDirectory = System.IO.Path.GetDirectoryName(NewSFD.FileName);
                if (result == true)
                {
                    // Save the file code in here (note this overwrites any file with same name)
                    FileStream newFileStream = new FileStream(NewSFD.FileName, FileMode.Create);
                    using (StreamWriter OutputFile = new StreamWriter(newFileStream))
                    {
                        if (tbOutputConsole.Visibility == System.Windows.Visibility.Visible)
                            OutputFile.Write(tbOutputConsole.Text);
                        if (tbOutputRawPackets.Visibility == System.Windows.Visibility.Visible)
                            OutputFile.Write(tbOutputRawPackets.Text);
                        if (tbOutputRawNodes.Visibility == System.Windows.Visibility.Visible)
                            OutputFile.Write(tbOutputRawNodes.Text);
                        if (tbOutputStatistics.Visibility == System.Windows.Visibility.Visible)
                            OutputFile.Write(tbOutputStatistics.Text);
                        if (tbOutputLogFile.Visibility == System.Windows.Visibility.Visible)
                            OutputFile.Write(tbOutputLogFile.Text);
                        if (tbOutputEventQueue.Visibility == System.Windows.Visibility.Visible)
                            OutputFile.Write(tbOutputEventQueue.Text);
                    }
                    newFileStream.Close();
                }
            }
            catch (Exception problem)
            {
                string Description = problem.ToString();
                // MessageBox.Show(Description + "\nSorry, file write failed.", "Annoying Error");
            }
        }
        #endregion

        #region Region: The PHY activity graph

        // Some main window variables required:
        long PHYActivityStartTime, PHYActivityEndTime;
        int PHYActivityStartNode, PHYActivityEndNode;
        List<Polyline> theTraces = new List<Polyline>();
        Rectangle rectForZoom = new Rectangle();
        Line VertCursor = new Line();
        long PHYActivityCursorTime = -1; // -1 means not used
        Label lblPHYActivityCursor = new Label();
        List<Label> yLabels = new List<Label>();
        double whereLeftButtonWasPressedDown = 0;
        long whenLeftButtonWasPressedDown = 0;
        Boolean doPHYActivitySliderStuff = true;

        const double HOWCLOSETOCLICKCURSOR = 8.0;
        const double HOWCLOSETOTIMETOCURSOR = 2.0;

        private void SetUpPHYActivityGraph()
        {
            // Set up the cursor line.  For now, set hidden.
            VertCursor.HorizontalAlignment = System.Windows.HorizontalAlignment.Left;
            VertCursor.VerticalAlignment = System.Windows.VerticalAlignment.Top;
            VertCursor.Visibility = System.Windows.Visibility.Hidden;
            VertCursor.Opacity = 0.4;
            VertCursor.Stroke = Globals.PHYActivityCursorBrush;
            VertCursor.StrokeThickness = 1;
            VertCursor.X1 = 0; VertCursor.X2 = 0; VertCursor.Y1 = 0; VertCursor.Y2 = cvsPHYActivity.Height;
            cvsPHYActivity.Children.Add(VertCursor);

            // Set up the label for giving information about the things:
            lblPHYActivityCursor.HorizontalAlignment = HorizontalAlignment.Left;
            lblPHYActivityCursor.VerticalAlignment = VerticalAlignment.Top;
            lblPHYActivityCursor.Visibility = Visibility.Hidden;
            lblPHYActivityCursor.FontSize = 12;
            lblPHYActivityCursor.Background = new SolidColorBrush(Colors.White);
            lblPHYActivityCursor.Opacity = 0.6;
            Canvas.SetZIndex(lblPHYActivityCursor, 2);
            cvsPHYActivity.Children.Add(lblPHYActivityCursor);

            // The mouse needs something to click on:
            Rectangle rectForMouseToClickOn = new Rectangle();
            rectForMouseToClickOn.HorizontalAlignment = System.Windows.HorizontalAlignment.Left;
            rectForMouseToClickOn.VerticalAlignment = System.Windows.VerticalAlignment.Top;
            rectForMouseToClickOn.Visibility = System.Windows.Visibility.Visible;
            rectForMouseToClickOn.Opacity = 0.01;
            rectForMouseToClickOn.Stroke = Globals.PHYActivityWhite;
            rectForMouseToClickOn.Fill = Globals.PHYActivityWhite;
            rectForMouseToClickOn.StrokeThickness = 1;
            rectForMouseToClickOn.Tag = (long)0;
            rectForMouseToClickOn.Width = cvsPHYActivity.Width;
            rectForMouseToClickOn.Height = cvsPHYActivity.Height;
            Canvas.SetLeft(rectForMouseToClickOn, 0.0);
            Canvas.SetTop(rectForMouseToClickOn, 0.0);
            cvsPHYActivity.Children.Add(rectForMouseToClickOn);
            Canvas.SetZIndex(rectForMouseToClickOn, 10);

            // When zooming in, this rectangle shows what's happening:
            rectForZoom.HorizontalAlignment = System.Windows.HorizontalAlignment.Left;
            rectForZoom.VerticalAlignment = System.Windows.VerticalAlignment.Top;
            rectForZoom.Visibility = System.Windows.Visibility.Hidden;
            rectForZoom.Opacity = 0.2;
            rectForZoom.Stroke = Globals.PHYActivityWhite;
            rectForZoom.Fill = Globals.PHYActivityCursorBrush;
            rectForZoom.StrokeThickness = 1;
            rectForZoom.Tag = (long)0;
            rectForZoom.Width = 0;
            rectForZoom.Height = cvsPHYActivity.Height;
            Canvas.SetLeft(rectForZoom, 0.0);
            Canvas.SetTop(rectForZoom, 0.0);
            cvsPHYActivity.Children.Add(rectForZoom);

            // Add some mouse handlers:
            rectForMouseToClickOn.MouseEnter += new MouseEventHandler(rectMouseForPHY_MouseEnter);
            rectForMouseToClickOn.MouseLeave += new MouseEventHandler(rectMouseForPHY_MouseLeave);
            rectForMouseToClickOn.MouseMove += new MouseEventHandler(rectMouseForPHY_MouseMove);
            rectForMouseToClickOn.MouseLeftButtonDown += new MouseButtonEventHandler(rectForMouseToClickOn_MouseLeftButtonDown);
            rectForMouseToClickOn.MouseRightButtonDown += new MouseButtonEventHandler(rectForMouseToClickOn_MouseRightButtonDown);
            rectForMouseToClickOn.MouseLeftButtonUp += new MouseButtonEventHandler(rectForMouseToClickOn_MouseLeftButtonUp);
            rectForMouseToClickOn.MouseWheel += new MouseWheelEventHandler(rectForMouseToClickOn_MouseWheel);

            // Setup the y-axis labels for the node numbers:
            for (int loop = 0; loop < 10; loop++)
            {
                Label lblNew = new Label();
                lblNew.HorizontalAlignment = HorizontalAlignment.Left;
                lblNew.VerticalAlignment = VerticalAlignment.Top;
                lblNew.Visibility = Visibility.Hidden;
                lblNew.FontSize = 14;
                lblNew.Height = 40;
                lblNew.Width = Canvas.GetLeft(cvsPHYActivity) - 2;
                lblNew.HorizontalContentAlignment = System.Windows.HorizontalAlignment.Right;
                lblNew.VerticalContentAlignment = System.Windows.VerticalAlignment.Center;
                lblNew.Opacity = 1.0;
                Canvas.SetLeft(lblNew, 0.0);
                Canvas.SetTop(lblNew, 0.0);
                canvasPHYActivity.Children.Add(lblNew);
                yLabels.Add(lblNew);
            }
        }

        void rectForMouseToClickOn_MouseWheel(object sender, MouseWheelEventArgs e)
        {
            // This cycles through the time... it has the same effect as clicking on 
            // the slider above or below the slider thingy.
            double what = e.Delta;
            double newValue = scrPHYTimeOffset.Value + Math.Sign(e.Delta) * scrPHYTimeOffset.SmallChange;
            if (newValue < 0.0) newValue = 0.0;
            if (newValue > 1.0) newValue = 1.0;
            scrPHYTimeOffset.Value = newValue;
        }

        void rectForMouseToClickOn_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            // Set the cursor:
            Point mouseLoc = Mouse.GetPosition(cvsPHYActivity);
            long whatTime = DisplayTimeFromLoc(mouseLoc);
            whenLeftButtonWasPressedDown = whatTime;
            whereLeftButtonWasPressedDown = mouseLoc.X;

            // Turn on the rectForZoom in case this is a zoom:
            rectForZoom.Visibility = System.Windows.Visibility.Visible;
            Canvas.SetLeft(rectForZoom, mouseLoc.X);
            Canvas.SetTop(rectForZoom, 0.0);
            rectForZoom.Width = 0;
            rectForZoom.Tag = mouseLoc.X; // Stores where the cursor was put down:
        }
        void rectForMouseToClickOn_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            Point mouseLoc = Mouse.GetPosition(cvsPHYActivity);
            long whatTime = DisplayTimeFromLoc(mouseLoc);

            if (Math.Abs(whereLeftButtonWasPressedDown - mouseLoc.X) < 10)
            {
                // If I'm where the cursor is and the cursor is on, turn it off:
                if (whatTime == PHYActivityCursorTime)
                {
                    PHYActivityCursorTime = -1;
                }
                // else if the mouse hasn't moved very far, just put the cursor line down:
                else
                {
                    // Is this near an interesting point?  If so, clip the cursor to the point:
                    Point cursorLoc = mouseLoc;
                    Point interestingLoc = NearestInterestingPoint(mouseLoc);
                    if (Math.Abs(interestingLoc.X - mouseLoc.X) < HOWCLOSETOCLICKCURSOR) cursorLoc = interestingLoc;
                    whatTime = DisplayTimeFromLoc(cursorLoc);
                    PHYActivityCursorTime = whatTime;
                }
                DoCursorStuff();
                // Update time from cursor:
                UpdateCursorText();
                // And turn the zoom rectangle off:
                rectForZoom.Visibility = System.Windows.Visibility.Hidden;
            }
            else if (PHYActivityEndTime - PHYActivityStartTime < 100)
            {
                // Do nothing, user is just being silly, you can't zoom past
                // this level, there's no point.  Just turn the zoom rectangle off:
                rectForZoom.Visibility = System.Windows.Visibility.Hidden;
            }
            else
            {
                // otherwise, consider this a drag-to-zoom.
                PHYActivityStartTime = Math.Min(whenLeftButtonWasPressedDown, whatTime);
                PHYActivityEndTime = Math.Max(whenLeftButtonWasPressedDown, whatTime);
                doStuffForMouseRangeChange();
            }
        }
        void rectForMouseToClickOn_MouseRightButtonDown(object sender, MouseButtonEventArgs e)
        {
            // Zoom out by a factor of two where possible:
            long currentRange = PHYActivityEndTime - PHYActivityStartTime;
            PHYActivityStartTime = Math.Max(0, PHYActivityStartTime - currentRange);
            PHYActivityEndTime = Math.Min((long)(Globals.SimulationLength * 1e9), PHYActivityEndTime + currentRange);
            doStuffForMouseRangeChange();
        }
        void setCentreTimeToGivenTime(long givenTime)
        {
            // Attempts to set the centre of the PHY display to the specified time
            long currentRange = PHYActivityEndTime - PHYActivityStartTime;
            PHYActivityStartTime = Math.Max(0, givenTime - currentRange / 2);
            PHYActivityEndTime = Math.Min((long)(Globals.SimulationLength * 1e9), givenTime + currentRange / 2);
            doStuffForMouseRangeChange();
        }
        void setStartTimeToGivenTime(long givenTime)
        {
            // Attempts to set the centre of the PHY display to the specified time
            long currentRange = PHYActivityEndTime - PHYActivityStartTime;
            PHYActivityStartTime = Math.Max(0, givenTime);
            PHYActivityEndTime = Math.Min((long)(Globals.SimulationLength * 1e9), givenTime + currentRange);
            doStuffForMouseRangeChange();
        }
        void setEndTimeToGivenTime(long givenTime)
        {
            // Attempts to set the centre of the PHY display to the specified time
            long currentRange = PHYActivityEndTime - PHYActivityStartTime;
            PHYActivityStartTime = Math.Max(0, givenTime - currentRange);
            PHYActivityEndTime = Math.Min((long)(Globals.SimulationLength * 1e9), givenTime);
            doStuffForMouseRangeChange();
        }
        void doStuffForMouseRangeChange()
        {
            // Quick sanity check...
            if (PHYActivityStartTime < 0 || PHYActivityEndTime < 0) return;

            // The equations below fail if the start time is equal to the end time,
            // so I'll trap this one as well, and ensure a minimum 100 ns across:
            if (PHYActivityEndTime - PHYActivityStartTime < 100)
            {
                long meanTime = (PHYActivityEndTime + PHYActivityStartTime) / 2;
                if (meanTime < 50) meanTime = 50;
                if (meanTime > Globals.SimulationLength * 1e9 - 50) meanTime = Globals.SimulationLength - 50;
                PHYActivityStartTime = meanTime - 50;
                PHYActivityEndTime = meanTime + 50;
            }

            // Turn the slider events off so I don't get into a confusing loop:
            doPHYActivitySliderStuff = false;

            // Work out some intermediate results:
            long newRange = PHYActivityEndTime - PHYActivityStartTime;

            // Round the range and start/end times to something as sensible as possible.
            // This means range is done to three significant figures, and then start and
            // end time to within one-tenth of this accuracy.
            double scale = Math.Pow(10, Math.Floor(Math.Log10(newRange)) + 1);
            newRange = (long)(scale * Math.Round(newRange / scale, 2));
            PHYActivityStartTime = (long)(scale * Math.Round(PHYActivityStartTime / scale, 2));
            PHYActivityEndTime = (long)(scale * Math.Round(PHYActivityEndTime / scale, 2));

            // Might be some rounding errors in the maths, so I'll just tidy these up a bit:
            PHYActivityStartTime = ((PHYActivityStartTime + 50) / 100) * 100;
            PHYActivityEndTime = ((PHYActivityEndTime + 50) / 100) * 100;
            newRange = PHYActivityEndTime - PHYActivityStartTime;

            // Set the sliders to the current value:
            double newRangeValue = rangeToScrValue((long)newRange);
            scrPHYTimeScale.Value = Math.Min(1.0, newRangeValue);
            double newMidTime = (PHYActivityEndTime + PHYActivityStartTime) / 2.0;
            if (Globals.SimulationLength * 1e9 == newRange)
            {
                scrPHYTimeOffset.Value = (scrPHYTimeOffset.Minimum + scrPHYTimeOffset.Maximum) / 2.0;
            }
            else
            {
                if (Globals.SimulationLength * 1e9 == newRange)
                    scrPHYTimeOffset.Value = 0.5;
                else
                    scrPHYTimeOffset.Value = (newMidTime - newRange / 2.0) / (Globals.SimulationLength * 1e9 - newRange);
            }

            // Adapt the small-scale movement of the time offset scroll bar:
            scrPHYTimeOffset.SmallChange = newRange / (Globals.SimulationLength * 1e9) / 10;

            // Adjust the position and width of the thumbs on the sliders:
            double range = (PHYActivityEndTime - PHYActivityStartTime) / (1e9 * Globals.SimulationLength);
            GUIBits.ScrollBarThumbStuff.SetThumbLength(scrPHYTimeOffset, range);

            // And re-draw the screen:
            ReDrawPHYActivityStuff();

            // finally, turn the zoom rectangle off and the sliders back on:
            rectForZoom.Visibility = System.Windows.Visibility.Hidden;
            doPHYActivitySliderStuff = true;
        }

        void rectMouseForPHY_MouseMove(object sender, MouseEventArgs e)
        {
            Point mouseLoc = Mouse.GetPosition(cvsPHYActivity);            
            UpdateCursorText();
            // If button is down, and Tag underway, expand the rectForZoom:
            double newLocation = 0.0;
            if (rectForZoom.Tag is double) newLocation = (double)rectForZoom.Tag;
            if (newLocation != 0.0 && e.LeftButton == MouseButtonState.Pressed)
            {
                double distanceMoved = mouseLoc.X - whereLeftButtonWasPressedDown;
                if (distanceMoved > 0)
                {
                    Canvas.SetLeft(rectForZoom, newLocation);
                    Canvas.SetTop(rectForZoom, 0.0);
                    rectForZoom.Width = distanceMoved;
                }
                else if (distanceMoved < 0)
                {
                    Canvas.SetLeft(rectForZoom, mouseLoc.X);
                    Canvas.SetTop(rectForZoom, 0.0);
                    rectForZoom.Width = -1.0 * distanceMoved;
                }
                else rectForZoom.Width = 0;
            }
        }
        private long DisplayTimeFromLoc(Point loc)
        {
            long thisTime = (long)(PHYActivityStartTime + loc.X / cvsPHYActivity.Width * (PHYActivityEndTime - PHYActivityStartTime));
            return thisTime;
        }
        private Point DisplayLocFromTimeAndNode(long time, int node)
        {
            double locX = (time - PHYActivityStartTime) * cvsPHYActivity.Width / (PHYActivityEndTime - PHYActivityStartTime);
            double locY = (node - PHYActivityStartNode) * cvsPHYActivity.Height / (PHYActivityEndNode - PHYActivityStartNode + 1);
            return new Point(locX, locY);
        }
        private int DisplayNodeFromLoc(Point loc)
        {
            int thisNode = (int)(PHYActivityStartNode + loc.Y / cvsPHYActivity.Height * (PHYActivityEndNode - PHYActivityStartNode + 1));
            return thisNode;
        }
        private Point NearestInterestingPoint(Point loc)
        {
            // Returns the nearest point where something interesting happens to either
            // the transmitter or receiver.
            int node = DisplayNodeFromLoc(loc);
            long time = DisplayTimeFromLoc(loc);

            // A bit of safety checking:
            if (node >= Globals.NumberOfNodes) node = Globals.NumberOfNodes - 1;
            if (time > Globals.SimTime) time = Globals.SimTime;

            int txEventBeforeIndex = 0;
            int rxEventBeforeIndex = 0;
            for (int loop = 0; loop < Globals.myNodes[node].TxHistory.Count; loop++)
            {
                if (Globals.myNodes[node].TxHistory[loop].time < time)
                {
                    txEventBeforeIndex = loop;
                }
                else break;
            }
            for (int loop = 0; loop < Globals.myNodes[node].RxHistory.Count; loop++)
            {
                if (Globals.myNodes[node].RxHistory[loop].time < time)
                    rxEventBeforeIndex = loop;
                else break;
            }

            long timeOfPreviousTxEvent = 0;
            long timeOfNextTxEvent = 0;
            long timeOfPreviousRxEvent = 0;
            long timeOfNextRxEvent = 0;

            if (Globals.myNodes[node].TxHistory.Count > txEventBeforeIndex)
                timeOfPreviousTxEvent = Globals.myNodes[node].TxHistory[txEventBeforeIndex].time;
            if (Globals.myNodes[node].TxHistory.Count > txEventBeforeIndex + 1)
                timeOfNextTxEvent = Globals.myNodes[node].TxHistory[txEventBeforeIndex + 1].time;
            if (Globals.myNodes[node].RxHistory.Count > rxEventBeforeIndex)
                timeOfPreviousRxEvent = Globals.myNodes[node].RxHistory[rxEventBeforeIndex].time;
            if (Globals.myNodes[node].RxHistory.Count > rxEventBeforeIndex + 1)
                timeOfNextRxEvent = Globals.myNodes[node].RxHistory[rxEventBeforeIndex + 1].time;

            // Now four alternatives... which one is closest?
            long closestTime = timeOfPreviousTxEvent;
            long howClose = Math.Abs(time - timeOfPreviousTxEvent);
            if (howClose > Math.Abs(time - timeOfNextTxEvent)) { howClose = Math.Abs(time - timeOfNextTxEvent); closestTime = timeOfNextTxEvent; }
            if (howClose > Math.Abs(time - timeOfPreviousRxEvent)) { howClose = Math.Abs(time - timeOfPreviousRxEvent); closestTime = timeOfPreviousRxEvent; }
            if (howClose > Math.Abs(time - timeOfNextRxEvent)) { howClose = Math.Abs(time - timeOfNextRxEvent); closestTime = timeOfNextRxEvent; }

            return DisplayLocFromTimeAndNode(closestTime, node);
        }
        void UpdateCursorText()
        {
            // Put the label where the mouse is, and fill with relevant information:
            Point mouseLoc = Mouse.GetPosition(cvsPHYActivity);
            double xOffset = 0, yOffset = 0;
            if (mouseLoc.X > cvsPHYActivity.Width / 2) xOffset = -120; else xOffset = 20;
            if (mouseLoc.Y > cvsPHYActivity.Height / 2) yOffset = -80; else yOffset = 10;
            // Get the time and the node:
            long thisTime = DisplayTimeFromLoc(mouseLoc);
            int thisNode = DisplayNodeFromLoc(mouseLoc);
            // I might have run off the ends of the scale - it might be possible:
            if (thisNode >= Globals.NumberOfNodes) thisNode = Globals.NumberOfNodes - 1;
            if (thisNode < 0) thisNode = 0;
            // Work out what the receiver and transmitter were doing at this time:
            Globals.TxActivity txEventBefore = Globals.myNodes[thisNode].TxHistory[0];
            for (int loop = 0; loop < Globals.myNodes[thisNode].TxHistory.Count; loop++)
            {
                if (Globals.myNodes[thisNode].TxHistory[loop].time < thisTime)
                    txEventBefore = Globals.myNodes[thisNode].TxHistory[loop];
                else break;
            }
            Globals.RxActivity rxEventBefore = Globals.myNodes[thisNode].RxHistory[0];
            Globals.RxActivity rxEventAfter = Globals.myNodes[thisNode].RxHistory[0];
            int rxEventAfterIndex = 0;
            for (int loop = 0; loop < Globals.myNodes[thisNode].RxHistory.Count; loop++)
            {
                if (Globals.myNodes[thisNode].RxHistory[loop].time < thisTime)
                {
                    rxEventBefore = Globals.myNodes[thisNode].RxHistory[loop];
                    if (loop + 1 < Globals.myNodes[thisNode].RxHistory.Count)
                    {
                        rxEventAfter = Globals.myNodes[thisNode].RxHistory[loop + 1];
                        rxEventAfterIndex = loop;
                    }
                    else
                    {
                        rxEventAfter = rxEventBefore;
                        rxEventAfterIndex = loop;
                    }
                }
                else break;
            }

            // Is this near an interesting point?  If so, clip the cursor to the point:
            Point interestingLoc = NearestInterestingPoint(mouseLoc);
            if (Math.Abs(interestingLoc.X - mouseLoc.X) < HOWCLOSETOTIMETOCURSOR) thisTime = DisplayTimeFromLoc(interestingLoc);

            string txString = "\nTransmitter: " + txEventBefore.state.ToString() + " " + txEventBefore.packetTag;
            string rxString = "\nReceiver: " + rxEventBefore.state.ToString();
            if (rxEventBefore.state == Globals.ReceiverState.Receiving)
            {
                rxString += " " + rxEventBefore.packetTag + " (" + Math.Round(10 * Math.Log10(rxEventBefore.excessSINR), 1) + ")";
                if (rxEventAfter.time != rxEventBefore.time && rxEventAfter.success == false)
                {
                    // This might be a packet reception failure, however that is not certain, there is one case
                    // in which it might not be.  This occurs when a packet starts to be received correctly, but
                    // then an interference source starts up and causes a small amount of interference.  This
                    // results in a new rxEvent in the history, so that the rxEventAfter will not in this case
                    // be the end of packet reception, so the success will be set to false by default (as the
                    // receiver doesn't know at this point whether the entire packet has arrived or not).
                    // To trap this case, look forward to the next event in the history which is not a
                    // packet being received event; this should be the end of this packet being actively 
                    // received.  Then take the success or failure from that event.
                    if (rxEventAfter.state != Globals.ReceiverState.Receiving)
                    {
                        rxString += "\nBit error: reception failed";
                    }
                    else
                    {
                        int packetEndEvent = rxEventAfterIndex;
                        int howManyEventsInHistory = Globals.myNodes[thisNode].RxHistory.Count;
                        while (packetEndEvent < howManyEventsInHistory - 1
                            && Globals.myNodes[thisNode].RxHistory[packetEndEvent].state == Globals.ReceiverState.Receiving)
                            packetEndEvent++;
                        if (Globals.myNodes[thisNode].RxHistory[packetEndEvent].success == false)
                            rxString += "\nBit error: reception failed";
                    }
                }
            }
            Canvas.SetLeft(lblPHYActivityCursor, mouseLoc.X + xOffset);
            Canvas.SetTop(lblPHYActivityCursor, mouseLoc.Y + yOffset);
            lblPHYActivityCursor.Visibility = System.Windows.Visibility.Visible;
            lblPHYActivityCursor.Content = "Time = " + timeToString(thisTime)
                + "\nNode = " + thisNode.ToString()
                + txString + rxString;
            if (PHYActivityCursorTime > -1)
            {
                lblPHYActivityCursor.Content +=
                    "\nTime to Cursor = " + timeToString(thisTime - PHYActivityCursorTime);
            }
        }
        string timeToString(long time)
        {
            // Formats a system long into a suitable string format, as efficiently as possible.
            long absTime = Math.Abs(time);
            if (absTime > 1e9) return (time / 1.0e9).ToString() + " s";
            if (absTime > 1e6) return (time / 1.0e6).ToString() + " ms";
            if (absTime > 1e3) return (time / 1.0e3).ToString() + " us";
            else return time.ToString() + " ns";
        }
        void rectMouseForPHY_MouseEnter(object sender, MouseEventArgs e)
        {
            if (Mouse.LeftButton == MouseButtonState.Pressed) rectForMouseToClickOn_MouseLeftButtonDown(null, null);
            rectMouseForPHY_MouseMove(sender, e);
        }
        void rectMouseForPHY_MouseLeave(object sender, MouseEventArgs e)
        {
            lblPHYActivityCursor.Visibility = System.Windows.Visibility.Hidden;
            rectForZoom.Visibility = System.Windows.Visibility.Hidden;
        }
        private void scrPHYTimeOffset_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            if (doPHYActivitySliderStuff == false) return;
            WorkOutNewPHYActivityTimes(false);
            ReDrawPHYActivityStuff();
        }
        private void scrPHYTimeScale_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            if (doPHYActivitySliderStuff == false) return;
            long timeToDisplay = scrValueToRange(scrPHYTimeScale.Value);
            WorkOutNewPHYActivityTimes(true);
            ReDrawPHYActivityStuff();
        }
        private void scrPHYAVertScale_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            WorkOutNewPHYActivityNodes();
            ReDrawPHYActivityStuff();
        }
        private void scrPHYAVertOffset_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            WorkOutNewPHYActivityNodes();
            ReDrawPHYActivityStuff();
        }
        private long scrValueToRange(double scrValue)
        {
            // Converts a scroll-bar value to the range.  The slider goes from
            // zero to one, this corresponds to 1 ms to 1000 seconds.
            long totalRange;
            totalRange = (long)(Math.Floor(Math.Pow(10, scrValue * 6)) * 1e6);

            // This is then quantised to "sensible" values:
            int mult = 1; long fact = totalRange;
            while (fact > 100) { mult++; fact = fact / 10; }
            while (mult > 1) { mult--; fact = fact * 10; }
            totalRange = fact;

            // And just check this is not greater than the total length:
            if (totalRange > (long)(Globals.SimulationLength * 1e9)) 
                totalRange = (long)(Globals.SimulationLength * 1e9);
            return totalRange;
        }
        private double rangeToScrValue(long range)
        {
            // Converts a range to the scroll-bar value:
            double pos = 1 / 6.0 * Math.Log10((double)range / 1e6);
            if (pos < 0) pos = 0.0;
            if (pos > 1) pos = 1.0;
            return pos;
        }
        private void WorkOutNewPHYActivityTimes(Boolean rangeChanged)
        {
            // Called when either of the sliders is moved, or at the start.
            long totalSimulationTime = (long)(Globals.SimulationLength * 1e9);
            long timeToDisplay = scrValueToRange(scrPHYTimeScale.Value);
            if (timeToDisplay > totalSimulationTime) timeToDisplay = totalSimulationTime;
            if (rangeChanged == true)
            {
                // If the range has changed, then leave the mid-point where it is:
                long midTime = (PHYActivityStartTime + PHYActivityEndTime) / 2;
                PHYActivityStartTime = midTime - timeToDisplay / 2;
                PHYActivityEndTime = midTime + timeToDisplay / 2;
                // and change the value of the time offset slider for the new range:
                double sliderMidPoint = 0.5;
                if (timeToDisplay < totalSimulationTime)
                    sliderMidPoint = (midTime - timeToDisplay / 2.0) / (totalSimulationTime - timeToDisplay);
                if (sliderMidPoint < 0.0) sliderMidPoint = 0.0;
                if (sliderMidPoint > 1.0) sliderMidPoint = 1.0;
                scrPHYTimeOffset.Value = sliderMidPoint;
            }
            else
            {
                // If the offset has changed, then the midTime changes:
                double sliderMidPoint = scrPHYTimeOffset.Value;
                long midTime = (long)(timeToDisplay / 2.0 + sliderMidPoint * totalSimulationTime - sliderMidPoint * timeToDisplay);
                PHYActivityStartTime = midTime - timeToDisplay / 2;
                PHYActivityEndTime = midTime + timeToDisplay / 2;
            }

            // Finally, if the start time or end time is off the scale, move everything:
            if (PHYActivityStartTime < 0 && PHYActivityEndTime > totalSimulationTime)
            {
                PHYActivityStartTime = 0;
                PHYActivityEndTime = totalSimulationTime;
            }
            else if (PHYActivityStartTime < 0)
            {
                PHYActivityStartTime = 0;
                PHYActivityEndTime = (timeToDisplay < totalSimulationTime) ? timeToDisplay : totalSimulationTime;
            }
            else if (PHYActivityEndTime > totalSimulationTime)
            {
                PHYActivityEndTime = totalSimulationTime;
                PHYActivityStartTime = (timeToDisplay < totalSimulationTime) ? (totalSimulationTime - timeToDisplay) : 0;
            }
            // Adapt the small-scale movement of the time offset scroll bar:
            scrPHYTimeOffset.SmallChange = timeToDisplay / (Globals.SimulationLength * 1e9) / 10;

            // Really finally, adjust the position and width of the thumbs on the sliders:
            double range = (PHYActivityEndTime - PHYActivityStartTime) / (1e9 * Globals.SimulationLength);
            GUIBits.ScrollBarThumbStuff.SetThumbLength(scrPHYTimeOffset, range);
        }
        private void WorkOutNewPHYActivityNodes()
        {
            // Works out which nodes to put at the top and bottom of the display
            int numberOfNodes = Globals.NumberOfNodes;
            int numberOfNodesToDisplay = (int)((1 - scrPHYAVertScale.Value) * numberOfNodes);
            if (numberOfNodesToDisplay < 2) numberOfNodesToDisplay = 2;
            PHYActivityStartNode = (int)(scrPHYAVertOffset.Value * (numberOfNodes - numberOfNodesToDisplay));
            PHYActivityEndNode = PHYActivityStartNode + numberOfNodesToDisplay - 1;
            // Adjust size of scroll bar slider for the scrPHYAVertOffset slider:
            GUIBits.ScrollBarThumbStuff.SetThumbLength(scrPHYAVertOffset, numberOfNodesToDisplay / (double)numberOfNodes);
        }
        private void DoCursorStuff()
        {
            // Add in the cursor if possible:
            if (PHYActivityCursorTime > PHYActivityStartTime && PHYActivityCursorTime < PHYActivityEndTime)
            {
                double whereCursor = (double)(PHYActivityCursorTime - PHYActivityStartTime)
                    / (double)(PHYActivityEndTime - PHYActivityStartTime) * cvsPHYActivity.Width;
                VertCursor.X1 = whereCursor;
                VertCursor.X2 = whereCursor;
                VertCursor.Visibility = System.Windows.Visibility.Visible;
            }
            else
            {
                VertCursor.Visibility = System.Windows.Visibility.Hidden;
            }
        }
        private void ReDrawPHYActivityStuff()
        {
            if (lblStartTime == null) return;
            lblStartTime.Content = (PHYActivityStartTime/1.0e9).ToString("0.0####");
            lblEndTime.Content = (PHYActivityEndTime / 1.0e9).ToString("0.0####");
            lblMidTime.Content = (PHYActivityStartTime / 2.0e9 + PHYActivityEndTime / 2.0e9).ToString("0.0####");

            int nodeGapForLabels = (PHYActivityEndNode - PHYActivityStartNode) / 10 + 1;

            // Clear all the polylines on the screen at the moment:
            foreach (Polyline trace in theTraces) cvsPHYActivity.Children.Remove(trace);
            theTraces.Clear();

            // Now test to see if the vertical cursor should be displayed, and if so, show it:
            DoCursorStuff();

            // Note how many labels have been added so far (maximum is ten), and set them
            // all to invisible for now:
            int yLabelsAdded = 0;
            for (int loop = 0; loop < 10; loop++) yLabels[loop].Visibility = System.Windows.Visibility.Hidden;

            for (int node = PHYActivityStartNode; node <= PHYActivityEndNode; node++)
            {
                if (node >= Globals.NumberOfNodes) continue; // Node doesn't exist
                
                // Find the top and bottom of where these lines should go:
                double unitHeight = cvsPHYActivity.Height / (1 + 4 * (PHYActivityEndNode - PHYActivityStartNode + 1));
                double minY = unitHeight * (1 + 4 * (node - PHYActivityStartNode));
                double maxY = unitHeight * (1 + 4 * (node - PHYActivityStartNode) + 3);

                // Find the horizontal scaling factor for times:
                double unitTime = cvsPHYActivity.Width / (PHYActivityEndTime - PHYActivityStartTime);

                // Put a label on the grid if required:
                if (node % nodeGapForLabels == 0 && yLabelsAdded < 9)
                {
                    double heightForLabel = (maxY + minY) / 2 
                        - yLabels[yLabelsAdded].Height / 2 + Canvas.GetTop(cvsPHYActivity);
                    Canvas.SetLeft(yLabels[yLabelsAdded], 0);
                    Canvas.SetTop(yLabels[yLabelsAdded], heightForLabel);
                    yLabels[yLabelsAdded].Content = node.ToString();
                    yLabels[yLabelsAdded].Visibility = System.Windows.Visibility.Visible;
                    yLabelsAdded++;
                }

                // Now look through the list of this node's receive and transmit events to find the 
                // ones just before the start of the displayed time.  This is a bit tricky, as there 
                // may only be one, and all the points could be before the start of the display.
                int startRxIndex = 0, endRxIndex = Globals.myNodes[node].RxHistory.Count - 1;
                for (int loop = 0; loop < Globals.myNodes[node].RxHistory.Count; loop++)
                {
                    Globals.RxActivity thisOne = Globals.myNodes[node].RxHistory[loop];
                    if (thisOne.time < PHYActivityStartTime) startRxIndex = loop;
                    if (thisOne.time > PHYActivityEndTime) 
                    { 
                        endRxIndex = loop;
                        break;
                    }
                }

                int startTxIndex = 0, endTxIndex = Globals.myNodes[node].TxHistory.Count - 1;
                for (int loop = 0; loop < Globals.myNodes[node].TxHistory.Count; loop++)
                {
                    Globals.TxActivity thisOne = Globals.myNodes[node].TxHistory[loop];
                    if (thisOne.time < PHYActivityStartTime) startTxIndex = loop;
                    if (thisOne.time > PHYActivityEndTime) 
                    { 
                        endTxIndex = loop;
                        break;
                    }
                }

                // I can then start a new polyline for the transmitter:
                Polyline newline = new Polyline();
                newline.HorizontalAlignment = System.Windows.HorizontalAlignment.Left;
                newline.VerticalAlignment = System.Windows.VerticalAlignment.Top;
                Canvas.SetLeft(newline, 0.0);
                Canvas.SetTop(newline, 0.0);
                newline.Opacity = 0.6;
                newline.Stroke = Globals.TransmitterActivityBrush;
                newline.StrokeThickness = Globals.PHYActivityStrokeThickness;
                newline.Visibility = System.Windows.Visibility.Visible;

                double lastY = maxY; 
                // The first point is at max height, and occurs when the node
                // was switched on, or zero, whichever is greater.
                long whenSwitchedOn = Globals.myNodes[node].ConvertLocalToGlobalTime(
                                        Globals.myNodes[node].GetLocalTimeWhenSwitchedOn());
                double whereToStart = Math.Max(0, (whenSwitchedOn - PHYActivityStartTime) * unitTime);
                Point firstPointTx = new Point(whereToStart, lastY);
                newline.Points.Add(firstPointTx);
                Point currentPoint = firstPointTx;
                for (int loop = startTxIndex; loop <= endTxIndex; loop++)
                {
                    Globals.TxActivity thing = Globals.myNodes[node].TxHistory[loop];
                    double x = Math.Max(0, (thing.time - PHYActivityStartTime) * unitTime);
                    double y = thing.state == Globals.TransmitterState.Off ? maxY : minY;

                    // Add in a horizontal line from where I was to here:
                    if (x < cvsPHYActivity.Width && x > currentPoint.X)
                    {
                        Point nextPoint = new Point(x, lastY);
                        newline.Points.Add(nextPoint);
                        currentPoint = nextPoint;
                    }
                    // Add in a vertical line from last state to this state:
                    if (x < cvsPHYActivity.Width && x >= currentPoint.X && lastY != y)
                    {
                        // I need a vertical line: the y-axis has changed:
                        Point nextPoint = new Point(x, y);
                        newline.Points.Add(nextPoint);
                        currentPoint = nextPoint;
                        lastY = y;
                    }
                }
                // and remember to finish the line off to either the right-hand side 
                // of the plot or the current simulation time, if smaller
                double simEndx = (Globals.SimTime - PHYActivityStartTime) * unitTime;
                newline.Points.Add(new Point(Math.Min(simEndx, cvsPHYActivity.Width), lastY));
                // and add to the canvas children for display:
                theTraces.Add(newline);
                cvsPHYActivity.Children.Add(newline);
                
                // And one for the receiver:
                newline = new Polyline();
                newline.HorizontalAlignment = System.Windows.HorizontalAlignment.Left;
                newline.VerticalAlignment = System.Windows.VerticalAlignment.Top;
                Canvas.SetLeft(newline, 0.0);
                Canvas.SetTop(newline, 0.0);
                newline.Opacity = 0.6;
                newline.Stroke = Globals.ReceiverActivityBrush;
                newline.StrokeThickness = Globals.PHYActivityStrokeThickness;
                newline.Visibility = System.Windows.Visibility.Visible;

                lastY = minY + 0.8 * (maxY - minY);
                Point firstPointRx = new Point(whereToStart, lastY);
                newline.Points.Add(firstPointRx);
                currentPoint = firstPointRx;
                for (int loop = startRxIndex; loop <= endRxIndex; loop++)
                {
                    Globals.RxActivity thing = Globals.myNodes[node].RxHistory[loop];
                    double x = Math.Max(0, (thing.time - PHYActivityStartTime) * unitTime);
                    double y = maxY;
                    switch (thing.state)
                    {
                        case Globals.ReceiverState.Asleep:
                            y = maxY; break;
                        case Globals.ReceiverState.Off:
                            y = maxY; break;
                        case Globals.ReceiverState.Listening:
                            y = minY + 0.8 * (maxY - minY); break;
                        case Globals.ReceiverState.Detecting:
                            y = minY + 0.6 * (maxY - minY); break;
                        case Globals.ReceiverState.Receiving:
                            y = minY; break;
                        case Globals.ReceiverState.Colliding:
                            y = minY + 0.3 * (maxY - minY); break;
                        default:
                            break;
                    }

                    // Add in a horizontal line from where I was to here:
                    if (x < cvsPHYActivity.Width && x > currentPoint.X)
                    {
                        Point nextPoint = new Point(x, lastY);
                        newline.Points.Add(nextPoint);
                        currentPoint = nextPoint;
                    }
                    // Add in a vertical line from last state to this state:
                    if (x < cvsPHYActivity.Width && x >= currentPoint.X && lastY != y)
                    {
                        // I need a vertical line: the y-axis has changed:
                        Point nextPoint = new Point(x, y);
                        newline.Points.Add(nextPoint);
                        currentPoint = nextPoint;
                        lastY = y;
                    }
                }
                // and remember to finish the line off to either the right-hand side 
                // of the plot or the current simulation time, if smaller
                simEndx = (Globals.SimTime - PHYActivityStartTime) * unitTime;
                newline.Points.Add(new Point(Math.Min(simEndx, cvsPHYActivity.Width), lastY));
                // and add to the canvas children for display:
                theTraces.Add(newline);
                cvsPHYActivity.Children.Add(newline);
            }
        }

        private void lblTime_MouseLeftButtonDown(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            // Moves to a specified place, taken from the clipboard...
            if (Clipboard.ContainsText() == true)
            {
                long when = GetTimeFromString(Clipboard.GetText());

                if (when > 100000 && when < Globals.SimTime)
                {
                    if (sender == lblMidTime) setCentreTimeToGivenTime(when);
                    else if (sender == lblStartTime) setStartTimeToGivenTime(when);
                    else if (sender == lblEndTime) setEndTimeToGivenTime(when);
                }
                else if (when >= 0)
                {
                    setStartTimeToGivenTime(0);
                }
            }
        }
        private long GetTimeFromString(string strWhen)
        {
            long when = -1;

            // Some strings have decimal points (they are in seconds),
            // others have commas.  I'll sort these into longs.
            string numString = "";
            foreach (char c in strWhen)
            {
                if (c == '0' || c == '1' || c == '2' || c == '3'
                    || c == '4' || c == '5' || c == '6' || c == '7'
                    || c == '8' || c == '9') numString += c;
            }

            long.TryParse(numString, out when);
            return when;
        }
        #endregion
    }
}
