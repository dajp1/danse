﻿using System.Runtime.InteropServices;
using System;
using System.Windows;
namespace DANSE_v4
{
    public partial class MainWindow : Window
    {
        private void LogicalLinkSetupBestEffortControls()
        {
        }
    }

    unsafe partial class cBestEffortLLC : cLogicalLink
    {
        ///////////////////////////////////
        // Best-effort logical-link layer.
        //

        internal cBestEffortLLC(cNode Here, ref cNode.LogicalLinkDelegates Delegates)
            : base(Here)
        {
            Delegates.CallWhenCallback = new cNode.LogicalLinkCallbackDelegate(this.Callback);
            Delegates.CallWhenInitialise = new cNode.LogicalLinkInitialiseDelegate(this.Initialise);
            Delegates.CallWhenPacketArrivesFromNetworkLayer = new cNode.LogicalLinkPacketFromAboveDelegate(this.PacketArrivesFromNetworkLayer);
            Delegates.CallWhenPacketArrivesFromMACLayer = new cNode.LogicalLinkPacketFromBelowDelegate(this.PacketArrivesFromMACLayer);
            Delegates.CallWhenShutdown = new cNode.LogicalLinkShutdownDelegate(this.Shutdown);
        }

        void PacketArrivesFromMACLayer(cPacket packet, int sourceNode)
        {
            // Best-effort LLC does nothing: there is no header to remove.
            // Just pass up to the Network layer.
            Globals.theQueue.AddEvent(new cEvent(node, packet, node.GetTime(),
                EventType.Network_PacketArrivesFromLogicalLinkLayer, sourceNode));
            // Update log file:
            if (Globals.LogEventsOn == true)
                OutToLog("  Logical Link: Packet sent up to network layer, arrived from node " + sourceNode);
        }

        void PacketArrivesFromNetworkLayer(cPacket packet, int destinationNode)
        {
            // Pass straight down...
            Globals.theQueue.AddEvent(new cEvent(node, packet, node.GetTime(),
                EventType.MAC_PacketArrivesFromLogicalLinkLayer, destinationNode));
            // Update log file and counters:
            if (Globals.LogEventsOn == true)
                OutToLog("  Logical Link: Packet sent down to multiple access layer, going to node " + destinationNode);
            LogicalLinkPacketsSentSoFar++;
        }

        void Callback(int A, cPacket packet = null)
        {
            // No callbacks ever requested, so nothing to do.
        }

        void Initialise(double A, double B, double C, double D)
        {
            // Nothing to initialise.
        }

        void Shutdown()
        {
            // No dynamically assigned memory to free up.
        }
    }
}
