﻿using System.Windows;
namespace DANSE_v4
{
    public partial class MainWindow : Window
    {
        private void LogicalLinkSetupUserControls()
        {
            Globals.stsLogicalLinkParameterOne.Enable(true);
            Globals.stsLogicalLinkParameterTwo.Enable(true);
            Globals.stsLogicalLinkParameterThree.Enable(true);
            Globals.stsLogicalLinkParameterFour.Enable(true);
            Globals.stsLogicalLinkParameterOne.NameOnSetup.Content = "Parameter A";
            Globals.stsLogicalLinkParameterTwo.NameOnSetup.Content = "Parameter B";
            Globals.stsLogicalLinkParameterThree.NameOnSetup.Content = "Parameter C";
            Globals.stsLogicalLinkParameterFour.NameOnSetup.Content = "Parameter D";
        }
    }

    unsafe partial class cUserLLC : cLogicalLink
    {
        ///////////////////////////////////////////
        // User logical-link layer routine wrapper.
        //

        internal cUserLLC(cNode Here, ref cNode.LogicalLinkDelegates Delegates)
            : base(Here)
        {
            Delegates.CallWhenCallback = new cNode.LogicalLinkCallbackDelegate(this.Callback);
            Delegates.CallWhenInitialise = new cNode.LogicalLinkInitialiseDelegate(this.Initialise);
            Delegates.CallWhenPacketArrivesFromMACLayer = new cNode.LogicalLinkPacketFromBelowDelegate(this.PacketArrivesFromMACLayer);
            Delegates.CallWhenPacketArrivesFromNetworkLayer = new cNode.LogicalLinkPacketFromAboveDelegate(this.PacketArrivesFromNetworkLayer);
            Delegates.CallWhenShutdown = new cNode.LogicalLinkShutdownDelegate(this.Shutdown);
        }

        /////////////////////////////////////////////
        // Do not modify anything below this line. //
        /////////////////////////////////////////////
    }
}
