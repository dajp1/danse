﻿using System.Runtime.InteropServices;
using System;
using System.Windows;

// This is a simple reliable logical-link layer, that re-transmits up
// to Globals.LogicalLinkRetries times before giving up.  The backoff
// time is set to Globals.LogicalLinkTimeOut, modified by the backoff
// factor according to:
//
//   Timeout = Globals.LogicalLinkTimeOut * BackoffFactor ^ (attempts - 1)
//
// so setting this factor to one uses the same backoff time, and
// setting to two implements exponential backoff.
//
// There is a maximum number of outstanding packets to each destination, 
// and the layer will keep stored any more packets it is given until the 
// outstanding packets are either acknowledged or the number of 
// attempts is exceeded.
//
// Broadcast packets are sent on a best-effort basis, and are not
// acknowledged.

namespace DANSE_v4
{
    public partial class MainWindow : Window
    {
        private void LogicalLinkSetupReliableControls()
        {
            Globals.stsLogicalLinkAttempts.Enable(true);
            Globals.stsLogicalLinkTimeOut.Enable(true);

            Globals.stsLogicalLinkParameterOne.NameOnSetup.Content = "Window Size";
            Globals.stsLogicalLinkParameterOne.SetNewRange(1, 10, 10, GUIBits.SliderType.integer);
            Globals.stsLogicalLinkParameterOne.Enable(true);

            Globals.stsLogicalLinkParameterTwo.NameOnSetup.Content = "Backoff Factor";
            Globals.stsLogicalLinkParameterTwo.SetNewRange(1, 2, 1, GUIBits.SliderType.linear);
            Globals.stsLogicalLinkParameterTwo.Enable(true);
        }
    }

    unsafe partial class cReliableLLC : cLogicalLink
    {
        /////////////////////////////////////////////////
        // Reliable logical-link layer routine wrapper.

        internal cReliableLLC(cNode Here, ref cNode.LogicalLinkDelegates Delegates)
            : base(Here)
        {
            Delegates.CallWhenCallback = new cNode.LogicalLinkCallbackDelegate(this.Callback);
            Delegates.CallWhenInitialise = new cNode.LogicalLinkInitialiseDelegate(this.Initialise);
            Delegates.CallWhenPacketArrivesFromNetworkLayer = new cNode.LogicalLinkPacketFromAboveDelegate(this.PacketArrivesFromNetworkLayer);
            Delegates.CallWhenPacketArrivesFromMACLayer = new cNode.LogicalLinkPacketFromBelowDelegate(this.PacketArrivesFromMACLayer);
            Delegates.CallWhenShutdown = new cNode.LogicalLinkShutdownDelegate(this.Shutdown);
        }

        [Serializable] internal struct LogicalLinkHeader
        {
            internal byte sequenceNumber;
            internal enum ACKthing { data, ack, broadcast };
            internal ACKthing type;

            internal LogicalLinkHeader(int sequenceNumber, ACKthing what)
            {
                this.sequenceNumber = (byte)(sequenceNumber % 256);
                this.type = what;
            }
            internal int GetSize() { return 2; }
        }
        internal class ReliableLLCMetadata
        {
            internal int destinationNode;
            internal int attemptsSoFar;
            internal long whenTimeOut;
            internal long whenPutIn;
            internal int sequenceNumber;
            internal ReliableLLCMetadata(int destination, int attempts, long whenTimesOut, 
                long whenAddedIn, int seqNumber)
            {
                this.destinationNode = destination;
                this.attemptsSoFar = attempts;
                this.whenTimeOut = whenTimesOut;
                this.whenPutIn = whenAddedIn;
                this.sequenceNumber = seqNumber;
            }
        }

        void PacketArrivesFromNetworkLayer(cPacket packet, int destinationNode)
        {
            // Broadcast packets are sent on a best-effort basis only, so I'll
            // deal with these first:
            if (destinationNode == BROADCAST)
            {
                // Just add a header with no sequence number and send:
                LogicalLinkPacketsSentSoFar++;
                LogicalLinkHeader broadhead = new LogicalLinkHeader(0, LogicalLinkHeader.ACKthing.broadcast);
                packet.AddHeader((Object)broadhead, broadhead.GetSize());
                Globals.theQueue.AddEvent(new cEvent(node, packet, node.GetTime(),
                    EventType.MAC_PacketArrivesFromLogicalLinkLayer, destinationNode));
                if (Globals.LogEventsOn == true)
                    OutToLog("  Logical-Link: Packet " + packet.MetaInformation().GetSystemNumber().ToString()
                        + " broadcast on a best-effort basis");
                return;
            }

            // It's not broadcast, so add a header to the packet with the new 
            // sequence number, and with acknowledgement set to false:
            int sequenceNumber = LogicalLinkPacketsSentSoFar % 256;
            LogicalLinkPacketsSentSoFar++;
            LogicalLinkHeader newhead = new LogicalLinkHeader(sequenceNumber, LogicalLinkHeader.ACKthing.data);
            packet.AddHeader((Object)newhead, newhead.GetSize());

            // Has the window size reached a maximum to this destination?
            if (HowManyOutstanding(destinationNode) < this.WindowSize)
            {
                // Sort out some metadata for this packet:
                long timeOut = node.GetTime() + (long)node.LogicalLinkLayer.MaxTimeOut;
                ReliableLLCMetadata metaData
                    = new ReliableLLCMetadata(destinationNode, 1, timeOut, node.GetTime(), sequenceNumber);

                // And put the packet in the queue if required:
                if (node.LogicalLinkLayer.Retries > 0)
                {
                    cPacket copyForQueue = cPacket.DeepCopy(packet);
                    PutPacketInQueue(copyForQueue, metaData);

                    // Also set a callback event when the packet times out:
                    Globals.theQueue.AddEvent(new cEvent(node, null, timeOut,
                        EventType.LogicalLink_Callback, sequenceNumber));

                    // A bit of debugging help:
                    if (Globals.LogEventsOn == true)
                        OutToLog("  Logical-Link: Packet " + packet.MetaInformation().GetSystemNumber().ToString()
                            + " stored, with time-out set for " + timeOut + " ns, with " + copyForQueue.HowManyHeaders() + " headers");
                }

                // Then pass this packet on down to the MAC layer:
                Globals.theQueue.AddEvent(new cEvent(node, packet, node.GetTime(),
                    EventType.MAC_PacketArrivesFromLogicalLinkLayer, destinationNode));
                if (Globals.LogEventsOn == true)
                    OutToLog("  Logical-Link: Packet " + packet.MetaInformation().GetSystemNumber().ToString()
                        + " with sequence number " + newhead.sequenceNumber.ToString()
                        + " sent down to MAC layer, going to node " + destinationNode
                        + " for the first attempt");
            }
            else
            {
                // If the number of outstanding packets is greater than or
                // equal to the window size, then just store the packet for now:
                ReliableLLCMetadata metaData
                    = new ReliableLLCMetadata(destinationNode, 0, 0, node.GetTime(), sequenceNumber);
                PutPacketInQueue(packet, metaData);

                // A bit of debugging help:
                if (Globals.LogEventsOn == true)
                    OutToLog("  Logical-Link: Packet " + packet.MetaInformation().GetSystemNumber().ToString()
                        + " stored, no time-out since too many packets in queue already");
            }
        }

        void PacketArrivesFromMACLayer(cPacket packet, int sourceNode)
        {
            // Some idiot checking:
            if (!(packet.ViewHeader() is LogicalLinkHeader))
            {
                Globals.ShowMessageBox("Packet arrived at reliable logical-link layer\n"
                    + "without a suitable header. \n"
                    + "Packet will be deleted.", "User Protocol Error?");
                return;
            }

            // First, take the outermost header off for examination:
            LogicalLinkHeader myHeader
                = (LogicalLinkHeader)(packet.RemoveHeader());

            switch (myHeader.type)
            {
                case LogicalLinkHeader.ACKthing.data:
                    // Send the source node info up to the network layer:
                    Globals.theQueue.AddEvent(new cEvent(node, packet, node.GetTime(),
                        EventType.Network_PacketArrivesFromLogicalLinkLayer, sourceNode));
                    OutToLog("  Packet " + myHeader.sequenceNumber.ToString()
                        + " sent up to network layer, arrived from node "
                        + packet.MetaInformation().GetOriginalSource().ToString());

                    LogicalLinkHeader newHeader = new LogicalLinkHeader(myHeader.sequenceNumber, LogicalLinkHeader.ACKthing.ack);
                    int headersize = newHeader.GetSize();
                    // Make up the acknowledgement (note packet system number is copied from incoming packet)
                    cPacket newAck = new cPacket(0, node.GetNumber(), packet.MetaInformation().GetSystemNumber());
                    newAck.MetaInformation().SetFinalDestination(packet.MetaInformation().GetOriginalSource());
                    newAck.MetaInformation().SetOriginalSource(packet.MetaInformation().GetFinalDestination());
                    newAck.MetaInformation().SetSystemNumber(packet.MetaInformation().GetSystemNumber());
                    newAck.MetaInformation().SetTag("Ack for " + packet.MetaInformation().GetSystemNumber().ToString());
                    newAck.AddHeader((Object)newHeader, headersize);
                    // ACK should be sent back to the source node here:
                    Globals.theQueue.AddEvent(new cEvent(node, newAck, node.GetTime(),
                        EventType.MAC_PacketArrivesFromLogicalLinkLayer, sourceNode));
                    // Update log file:
                    if (Globals.LogEventsOn == true)
                    {
                        OutToLog("  Logical-Link layer acknowledgement for sequence number "
                            + myHeader.sequenceNumber.ToString() + " sent to node "
                            + sourceNode);
                    }
                    break;

                case LogicalLinkHeader.ACKthing.ack:
                    // If it's an acknowledgement, try and find the relevant packet
                    // in the list of stored packets waiting for possible retransmit.
                    // Note: this is not a cumulative ACK - individual ACKs are required
                    // (it can't be cumulative, different packets might be sent to different
                    // destinations).

                    int SeqNumberInAck = myHeader.sequenceNumber;
                    cPacketStoreElement FoundMatch = null;
                    foreach (cPacketStoreElement searcher in PacketStore)
                    {
                        int SequenceNumberFromQueue
                            = ((ReliableLLCMetadata)searcher.GetMetadata()).sequenceNumber;
                        if (SeqNumberInAck == SequenceNumberFromQueue) FoundMatch = searcher;
                    }
                    if (FoundMatch != null)
                    {
                        PacketStore.Remove(FoundMatch);
                    }
                    // Update log file:
                    if (Globals.LogEventsOn == true)
                    {
                        if (FoundMatch == null) OutToLog("  ACK received (seq. no " + SeqNumberInAck + "), but no matching packet found in store");
                        else OutToLog("  Sequence number " + myHeader.sequenceNumber.ToString() + " acknowledged successfully");
                    }
                    // It's possible that this has reduced the number of
                    // outstanding packets to below the window size, in 
                    // which case it's safe to send another packet now:
                    if (HowManyOutstanding(sourceNode) < this.WindowSize)
                    {
                        // A bit of debugging help:
                        if (Globals.LogEventsOn == true)
                            OutToLog("  Logical-Link: ACK received with seq. no " + SeqNumberInAck + ") now "
                                + HowManyOutstanding(sourceNode) + " packets outstanding to node " + sourceNode);

                        // Find the oldest packet in the queue to this destination 
                        // that has not yet been sent:
                        int oldestUnsent = -1; long OldTimeSoFar = (long)(Globals.SimulationLength * 1e9);
                        for (int loop = 0; loop < PacketStore.Count; loop++)
                        {
                            ReliableLLCMetadata thisMeta = (ReliableLLCMetadata)GetMetadataInQueue(loop);
                            long whenThisIn = thisMeta.whenPutIn;
                            int attempts = thisMeta.attemptsSoFar;
                            int whereTo = thisMeta.destinationNode;
                            if (whenThisIn < OldTimeSoFar && attempts == 0 && whereTo == sourceNode)
                            {
                                OldTimeSoFar = whenThisIn;
                                oldestUnsent = loop;
                            }
                        }
                        // and if a suitable packet exists, send it...
                        if (oldestUnsent != -1)
                        {
                            cPacket newPacket = GetPacketInQueue(oldestUnsent);
                            int seqNumber = ((LogicalLinkHeader)newPacket.ViewHeader()).sequenceNumber;
                            // Then pass a copy of this packet on down to the MAC layer, keeping
                            // the original packet in the queue.
                            cPacket copyToSend = cPacket.DeepCopy(newPacket);
                            Globals.theQueue.AddEvent(new cEvent(node, copyToSend, node.GetTime(),
                                EventType.MAC_PacketArrivesFromLogicalLinkLayer, sourceNode));
                            if (Globals.LogEventsOn == true)
                                OutToLog("  Logical-Link: Packet " + packet.MetaInformation().GetSystemNumber().ToString()
                                    + " with sequence number " + seqNumber.ToString()
                                    + " sent down to MAC layer, going to node " + sourceNode
                                    + " for the first attempt now window size allows");
                            // Set a callback for when this packet times out:
                            long timeOut = node.GetTime() + (long)node.LogicalLinkLayer.MaxTimeOut;
                            Globals.theQueue.AddEvent(new cEvent(node, null, timeOut,
                                EventType.LogicalLink_Callback, seqNumber));
                            // Adjust metadata to note packet has now been sent:
                            ReliableLLCMetadata metaData
                                = new ReliableLLCMetadata(sourceNode, 1, timeOut, node.GetTime(), seqNumber);
                            ReplaceMetadataInQueue(oldestUnsent, metaData);
                        }
                    }
                    break;

                case LogicalLinkHeader.ACKthing.broadcast:
                    // Send the source node info up to the network layer:
                    Globals.theQueue.AddEvent(new cEvent(node, packet, node.GetTime(),
                        EventType.Network_PacketArrivesFromLogicalLinkLayer, sourceNode));
                    OutToLog("  Broadcast packet " + myHeader.sequenceNumber.ToString()
                        + " sent up to network layer, arrived from node "
                        + packet.MetaInformation().GetOriginalSource().ToString());
                    break;
                default:
                    break;
            }
        }

        // Returns how many packets already sent but not acknowledged to this destination:
        int HowManyOutstanding(int whereTo)
        {
            int howMany = 0;
            foreach (cPacketStoreElement x in PacketStore)
            {
                ReliableLLCMetadata thisMeta = (ReliableLLCMetadata)x.GetMetadata();
                if (whereTo == thisMeta.destinationNode && thisMeta.attemptsSoFar > 0)
                    howMany++;
            }
            return howMany;
        }

        void Callback(int A, cPacket packet = null)
        {
            // A timeout has occured.  If the packet has not already been
            // acknowledged, it needs to be re-transmitted.  First, see if
            // a packet with the right sequence number has timed out:
            int sequenceNumberInQueue = A;
            long whenDue = 0;
            cPacketStoreElement x = PacketStore.Find(o =>
                ((ReliableLLCMetadata)(o.GetMetadata())).sequenceNumber == A);
            if (x != null)
            {
                ReliableLLCMetadata thisMeta = (ReliableLLCMetadata)x.GetMetadata();
                whenDue = thisMeta.whenTimeOut;
            }
            if (x == null || Math.Abs(whenDue - node.GetTime()) > 1000)
            {
                // There is nothing suitable in the queue.  Must have already
                // been acknowledged.
                if (Globals.LogEventsOn == true)
                    OutToLog("  Logical-Link: Timeout event for packet sequence number "
                        + sequenceNumberInQueue.ToString()
                        + " but packet already acknowledged");
                return;
            }

            // OK, I have a callback for a real packet in the queue, so if I can, I
            // should re-transmit it.  First check I can retransmit:
            ReliableLLCMetadata theMeta = (ReliableLLCMetadata)x.GetMetadata();
            int attemptsSoFar = theMeta.attemptsSoFar;
            if (attemptsSoFar > node.LogicalLinkLayer.Retries)
            {
                // Can't try again, maximum number of retries reached:
                PacketStore.Remove(x);
                if (Globals.LogEventsOn == true)
                    OutToLog("  Logical-Link: Timeout event for packet sequence number "
                        + theMeta.sequenceNumber.ToString()
                        + " but maximum number of retries exceeded");
                return;
            }

            // OK, so I can re-transmit.  I need to update the metadata and work
            // out a new timeout time:
            theMeta.attemptsSoFar++;
            theMeta.whenTimeOut = node.GetTime() 
                + (long)(node.LogicalLinkLayer.MaxTimeOut 
                    * Math.Pow(this.BackoffFactor, theMeta.attemptsSoFar - 1));
            int destNode = theMeta.destinationNode;

            // And then make a copy of the packet to send to the MAC layer:
            cPacket copyToSend = cPacket.DeepCopy(x.GetPacket());

            Globals.theQueue.AddEvent(new cEvent(node, copyToSend, node.GetTime(),
                EventType.MAC_PacketArrivesFromLogicalLinkLayer, destNode));
            if (Globals.LogEventsOn == true)
                OutToLog("  Logical-Link: Packet " + x.GetPacket().MetaInformation().GetSystemNumber().ToString()
                    + " with sequence number " + theMeta.sequenceNumber.ToString()
                    + " sent down to MAC layer, going to node " + destNode
                    + " for attempt number " + theMeta.attemptsSoFar);

            // Update count of packets sent:
            LogicalLinkPacketsSentSoFar++;

            // If I can try yet again, then put in another callback request.
            // If I can't, take the packet out of the queue.
            if (node.LogicalLinkLayer.Retries + 1 > theMeta.attemptsSoFar)
            {
                Globals.theQueue.AddEvent(new cEvent(node, null, theMeta.whenTimeOut,
                    EventType.LogicalLink_Callback, sequenceNumberInQueue));
            }
            else
            {
                PacketStore.Remove(x);
            }
        }

        int WindowSize;
        double BackoffFactor;
        void Initialise(double A, double B, double C, double D)
        {
            // A is the maximum number of outstanding packets allowed
            // to any destination, B is the backoff factor
            this.WindowSize = (int)A;
            this.BackoffFactor = B;
        }

        void Shutdown()
        {
            // No dynamically assigned memory to free up.
        }
    }
}
