﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;

namespace DANSE_v4
{
    #region Region: The user interface controls
    // The user interface controls for the physical and channel layers
    public partial class MainWindow : Window
    {
        internal List<UIElement> GetPhysicalControls()
        {
            List<UIElement> controls = new List<UIElement>();
            int VOffset = Globals.CONTROLVOFFSETSTART;
            int VOffsetDifference = Globals.CONTROLVOFFSETDELTA;

            // A label and ComboBox for the physical style:
            Globals.ctsPhysicalType = GUIBits.SetupNewComboBox<Globals.PhysicalType>(controls, VOffset, "physical type", "Preempt");
            Globals.ctsPhysicalType.theComboBox.SelectionChanged += new SelectionChangedEventHandler(PhysicalTypeCombo_SelectionChanged);
            VOffset += VOffsetDifference;

            // Then a slider for the default transmit power:
            Globals.stsDefaultTxPower = GUIBits.SetupNewLinearSlider(controls, VOffset, "default transmit power", "Power (dBm)",
                Globals._DefaultTxPowerDefault, Globals._DefaultTxPowerMinimum, Globals._DefaultTxPowerMaximum);
            Globals.stsDefaultTxPower.theSlider.ValueChanged += new RoutedPropertyChangedEventHandler<double>(DefaultTxPowerSlider_ValueChanged);
            DefaultTxPowerSlider_ValueChanged(Globals.stsDefaultTxPower.theSlider, null);
            VOffset += VOffsetDifference;

            // Then a slider for the default SINR for detection:
            Globals.stsDetectSINR = GUIBits.SetupNewLinearSlider(controls, VOffset, "SINR for detection", "Detect (dB)",
                Globals._DetectSINRDefault, Globals._DetectSINRMinimum, Globals._DetectSINRMaximum);
            Globals.stsDetectSINR.theSlider.ValueChanged += new RoutedPropertyChangedEventHandler<double>(DetectSINRSlider_ValueChanged);
            DetectSINRSlider_ValueChanged(Globals.stsDetectSINR.theSlider, null);
            VOffset += VOffsetDifference;

            // Then a slider for the default bit rate:
            Globals.stsDefaultBitRate = GUIBits.SetupNewLogIntegerSlider(controls, VOffset, "default bit rate", "Bit Rate (bit/s)",
                Globals._DefaultBitRateDefault, Globals._DefaultBitRateMinimum, Globals._DefaultBitRateMaximum);
            Globals.stsDefaultBitRate.theSlider.ValueChanged += new RoutedPropertyChangedEventHandler<double>(DefaultBitRateSlider_ValueChanged);
            DefaultBitRateSlider_ValueChanged(Globals.stsDefaultBitRate.theSlider, null);
            VOffset += VOffsetDifference;

            // Then a slider for the physical layer header (the preamble):
            Globals.stsPhysicalHeaderSize = GUIBits.SetupNewIntegerSlider(controls, VOffset, "physical header size", "Preamble (byte)",
                Globals._PhysicalHeaderSizeDefault, Globals._PhysicalHeaderSizeMinimum, Globals._PhysicalHeaderSizeMaximum);
            Globals.stsPhysicalHeaderSize.theSlider.ValueChanged += new RoutedPropertyChangedEventHandler<double>(PhysicalHeaderSizeSlider_ValueChanged);
            PhysicalHeaderSizeSlider_ValueChanged(Globals.stsPhysicalHeaderSize.theSlider, null);
            VOffset += VOffsetDifference;

            // Then send back the list
            return controls;
        }

        internal List<UIElement> GetChannelControls()
        {
            List<UIElement> controls = new List<UIElement>();
            int VOffset = Globals.CONTROLVOFFSETSTART;
            // int VOffsetDifference = Globals.CONTROLVOFFSETDELTA;

            // A label and ComboBox for the physical style:
            Globals.ctsChannelType = GUIBits.SetupNewComboBox<Globals.ChannelType>(controls, VOffset, "channel type", "Channel Model");
            Globals.ctsChannelType.theComboBox.SelectionChanged += new SelectionChangedEventHandler(ChannelTypeCombo_SelectionChanged);

            // Then send back the list
            return controls;
        }

        void DefaultTxPowerSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            Globals.DefaultTxPowerdBm = ((GUIBits.SliderTagStruct)(((Slider)sender).Tag)).GetActualValue();
            Globals.DefaultTxPowerdBm = Math.Round(Globals.DefaultTxPowerdBm, 3);
        }

        void DefaultBitRateSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            double newValue = ((GUIBits.SliderTagStruct)(((Slider)sender).Tag)).GetActualValue();
            // Set to the nearest of the permitted values:
            newValue = Globals.GetNearestLegalBitRate(newValue);
            Globals.stsDefaultBitRate.SetSliderValue(newValue, false);
            Globals.DefaultBitRate = newValue;
        }

        void PhysicalHeaderSizeSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            double newValue = ((GUIBits.SliderTagStruct)(((Slider)sender).Tag)).GetActualValue();
            Globals.PhysicalHeaderSize = Math.Round(newValue, 0);
        }

        void DetectSINRSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            double newValue = ((GUIBits.SliderTagStruct)(((Slider)sender).Tag)).GetActualValue();
            newValue = Math.Round(newValue, 3);
            Globals.DetectSINRdB = newValue;
        }

        void PhysicalTypeCombo_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ComboBox thing = (ComboBox)sender;
            String chosen = thing.Items[thing.SelectedIndex].ToString();
            try { Globals.PhysicalStyle = (Globals.PhysicalType)Enum.Parse(typeof(Globals.PhysicalType), chosen); }
            catch { MessageBox.Show("Physical Type " + chosen + " not recognised", "Serious Error"); }
        }

        void ChannelTypeCombo_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ComboBox thing = (ComboBox)sender;
            if (thing.SelectedIndex != -1)
            {
                String chosen = thing.Items[thing.SelectedIndex].ToString();

                GUIBits.ComboBoxTagStruct tagstruct = (GUIBits.ComboBoxTagStruct)thing.Tag;
                tagstruct.SetValue<Globals.ChannelType>(chosen, ref Globals.ChannelStyle);
            }
        }
    }
    #endregion
    #region Region: The physical layer stuff
    class cPhysical
    {
        // First of all, this physical layer needs to know which node it is 
        // associated with and this is setup when the class is instantiated:
        cNode node;
        int myNumber;
        internal cPhysical(cNode node)
        {
            this.node = node;
            this.myNumber = node.GetNumber();
        }

        // A bit of help when outputting to the log file:
        private void OutToLog(string whatever, Boolean addStatus)
        {
            if (Globals.LogEventsOn == true)
            {
                Globals.NewLogEvent.AppendLine(whatever);
                if (addStatus)
                    Globals.NewLogEvent.AppendLine("  Physical: Tx State: " + node.GetTransmitState().ToString()
                    + ";  Rx State: " + node.GetReceiveState().ToString()
                    + ";  Tx/Rx Channels: " + node.GetTransmitChannel().ToString() + "/" + node.GetReceiveChannel().ToString()
                    + ";  Receiving Power: " + (10 * Math.Log10(node.CurrentTotalReceivedPower) + 30).ToString("0.000") + " dBm");
            }
        }

        // When the nodes are moving, it's possible that a node might move out of 
        // range during reception, and this needs to be detected and handled.  Note 
        // that this doesn't change the MetaInformation ReceivedPower field, that 
        // is defined as the received power when the transmission started.
        // This function is also called when a node changes channel, so that
        // it is up-to-date with the received power on the new channel.
        internal void NodeMovedStuff()
        {
            // What channel am I on?
            int channel = this.node.GetReceiveChannel();

            // Recalculate the received power, and SINR:
            double newRxPower = 0.0, newNoiseAndInterference = Globals.NoiseFloor;
            int listeningTo = Globals.NOWHERE, numberTransmitting = 0;
            double requiredSINR = 0.0;
            if (node.GetPacketBeingReceived() != null 
                && node.GetReceiveState() == Globals.ReceiverState.Receiving)
            {
                listeningTo = node.GetPacketBeingReceived().MetaInformation().GetLastHop();
                requiredSINR = Globals.GetRequiredSINR(node.GetPacketBeingReceived());
            }
            foreach (cNode thing in Globals.myNodes)
            {
                if (thing.GetTransmitState() == Globals.TransmitterState.Transmitting
                    && thing.GetTransmitChannel() == channel)
                {
                    numberTransmitting++;
                    node.UpdateIfMoved();
                    
                    // If I'm currently listening to this node, then it's the signal,
                    // otherwise it's interference:
                    double signalStrength = thing.GetCurrentTransmitPower() / Globals.PathLosses[thing.GetNumber(), node.GetNumber()];
                    if (thing.GetNumber() == listeningTo)
                        newRxPower = signalStrength;
                    else
                        newNoiseAndInterference += signalStrength;
                }
            }

            // If no-one is transmitting, there's nothing more to do except
            // possibly set the node to listening if it is awake:
            if (numberTransmitting == 0)
            {
                if (node.GetReceiveState() != Globals.ReceiverState.Asleep)
                    node.SetReceiveState(Globals.ReceiverState.Listening, null, 0.0, 0.0, false);
                return;
            }

            // I'll need the detection value not in dB several times, so to save time
            // I'll calculate it once here:
            double DetectSINR = Math.Pow(10.0, Globals.DetectSINRdB / 10.0);

            // OK, now possibly change receiver's state, depending on what's going on:
            switch (node.GetReceiveState())
            {
                case Globals.ReceiverState.Asleep:
                case Globals.ReceiverState.Off:
                    // Nothing to do, just leave as it is
                    break;
                case Globals.ReceiverState.Listening:
                    if (newNoiseAndInterference > (DetectSINR + 1) * Globals.NoiseFloor)
                        node.SetReceiveState(Globals.ReceiverState.Detecting, null, 0.0, 0.0, false);
                    break;
                case Globals.ReceiverState.Detecting:
                    if (newNoiseAndInterference < (DetectSINR + 1) * Globals.NoiseFloor)
                        node.SetReceiveState(Globals.ReceiverState.Listening, null, 0.0, 0.0, false);
                    break;
                case Globals.ReceiverState.Receiving:
                    double newSINR = newRxPower / newNoiseAndInterference;
                    if (newSINR < requiredSINR)
                        node.SetReceiveState(Globals.ReceiverState.Detecting, null, newSINR, 0.0, false);
                    break;
                case Globals.ReceiverState.Colliding:
                    if (newNoiseAndInterference < (DetectSINR + 1) * Globals.NoiseFloor)
                        node.SetReceiveState(Globals.ReceiverState.Listening, null, 0.0, 0.0, false);
                    break;
                default:
                    MessageBox.Show("That's odd, I don't know about receiver state: " 
                        + node.GetReceiveState().ToString(), "Serious Error");
                    break;
            }
        }

        // Now the event handlers.  I'll start with something simple:
        internal void EventHandler(cEvent thing)
        {
            // I'll need the detection value not in dB several times, so to save time
            // I'll calculate it once here:
            double DetectSINR = Math.Pow(10.0, Globals.DetectSINRdB / 10.0);

            if (thing.type == EventType.Physical_FinishArriving)
            {
                // In the event, A is the bit rate, B the channel, C the transmitter 
                // and D the receive power.
                int theBitRate = thing.A;
                int theChannel = thing.B;
                double ReceivedPower = thing.D;
                Boolean didItSucceed = false;

                // First, don't do anything if the node is not listening on this channel:
                if (node.GetReceiveChannel() != thing.B) return;

                // Then, no matter what happens, reduce the received power by the power
                // associated with this packet:
                node.CurrentTotalReceivedPower -= ReceivedPower;

                // Then packet finished arriving, so check to see if still 
                // listening to this packet (it might not be if moved out 
                // of range at some point, or the node changed the receive 
                // channel, or there was a collision), and if so, pass the 
                // packet up to the MAC layer:

                if (node.GetReceiveState() == Globals.ReceiverState.Receiving && thing.packet == node.GetPacketBeingReceived())
                    {
                    // There's a really ugly first attempt at making the frame error rate
                    // a function of the SINR in here.  This needs a bit more work and 
                    // justification, but it'll have to do for now... see the cNode class 
                    // for more details on how it works.
                    if (node.PacketReceivedCorrectly() == true)
                    {
                        didItSucceed = true;

                        // Copy the packet so the packet arriving at this node is unique:
                        cPacket copy = cPacket.DeepCopy(thing.packet);
                        copy.MetaInformation().SetCrossLayer(0.0);
                        copy.MetaInformation().AddHopToRoute(node.GetNumber());

                        // Can now fill in the receive power metainformation on this new packet
                        copy.MetaInformation().SetReceivedPower(ReceivedPower);
                        copy.MetaInformation().SetIfRxSucceeded(true);

                        // If the next hop was set to NOWHERE or BROADCAST, then replace this with where 
                        // the packet has actually arrived in the Route list:
                        List<int> Route = copy.MetaInformation().GetRoute();
                        int LastHopInRoute = Route[Route.Count - 1];
                        if (LastHopInRoute == Globals.NOWHERE || LastHopInRoute == Globals.BROADCAST)
                        {
                            Route.RemoveAt(Route.Count - 1);
                            Route.Add(this.node.GetNumber());
                        }

                        // Send up to the MAC layer for processing:
                        Globals.theQueue.AddEvent(new cEvent(node, copy, node.GetTime(),
                            EventType.MAC_PacketArrivesFromPhysicalLayer, theBitRate, 0, 0, ReceivedPower));
                        Globals.TotalFramesReceived++;

                        // Then sort out the log stuff:
                        if (Globals.LogEventsOn == true)
                            OutToLog("  Physical: Packet finished arriving, passing up to Multiple Access layer", false);
                    }
                    else
                    {
                        // Just sort out the log stuff:
                        if (Globals.LogEventsOn == true)
                            OutToLog("  Physical: Packet finished arriving, but arrived with errors", false);
                    }
                }
                // The node might be listening to a different packet, possibly due to pre-emption:
                else if (node.GetReceiveState() == Globals.ReceiverState.Receiving)
                {
                    if (Globals.LogEventsOn == true)
                        OutToLog("  Physical: Packet finished arriving, but not the packet being received", false);
                }
                // if not, then let the user know the packet has finished, but was not received.
                else
                {
                    if (Globals.LogEventsOn == true)
                        OutToLog("  Physical: Packet finished arriving, but was not received", false);
                }

                // Then select new receiver state depending on the level of the received
                // signal:
                double SINRNow = node.CurrentTotalReceivedPower / Globals.NoiseFloor;
                if (node.GetReceiveState() == Globals.ReceiverState.Asleep
                    || node.GetReceiveState() == Globals.ReceiverState.Off)
                {
                    // Do nothing, I'm asleep or off (transmitter is going)
                }
                else if (node.GetReceiveState() == Globals.ReceiverState.Receiving && thing.packet != node.GetPacketBeingReceived())
                {
                    // I'm still receiving a different packet, but SINR will have changed, so update
                    // the SINR for this node:
                    node.SetReceiveState(Globals.ReceiverState.Receiving, 
                        node.GetPacketBeingReceived(), SINRNow, node.GetPacketBeingReceivedPower(), didItSucceed);
                }
                else if (SINRNow < DetectSINR)
                {
                    node.SetReceiveState(Globals.ReceiverState.Listening, null, 0.0, 0.0, didItSucceed);
                    if (Globals.LogEventsOn == true)
                        OutToLog("  Physical: Packet over, back to listening for new packet", true);
                }
                else 
                {
                    node.SetReceiveState(Globals.ReceiverState.Detecting, null, 0.0, 0.0, didItSucceed);
                    if (Globals.LogEventsOn == true)
                        OutToLog("  Physical: Packet over, but still detecting a transmission", true);
                }

                // Prevent any build-up of errors in the calculation of current receive power due to 
                // adding things and subtracting things all the time:
                if (node.CurrentTotalReceivedPower < Globals.NoiseFloor / 1000) 
                    node.CurrentTotalReceivedPower = 0.0;
            }
            else if (thing.type == EventType.Physical_PacketArrivesFromMACLayer)
            {
                // If the transmitter is already transmitting, then just throw it away...
                if (node.GetTransmitState() == Globals.TransmitterState.Transmitting)
                {
                    if (Globals.LogEventsOn == true)
                        OutToLog("  Physical: Attempt to transmit a packet while already transmitting", true);
                    return;
                }

                // If I'm asleep, don't transmit the packet either:
                if (node.GetReceiveState() == Globals.ReceiverState.Asleep)
                {
                    if (Globals.LogEventsOn == true)
                        OutToLog("  Physical: Attempt to transmit a packet while asleep", true);
                    return;
                }

                // If I'm currently receiving a packet, then mark as colliding, I can't do both,
                // but carry on and do the transmission anyway:
                if (node.GetReceiveState() == Globals.ReceiverState.Receiving)
                {
                    if (Globals.LogEventsOn == true)
                        OutToLog("  Physical: Transmit started while receiving " + node.GetPacketBeingReceived().ToString(), true);
                    node.SetReceiveState(Globals.ReceiverState.Colliding, null, 0.0, node.GetPacketBeingReceivedPower(), false);
                }

                // Then update the counters of frames sent:
                Globals.TotalFramesSent++;

                // If necessary, add a jiffy to the next bit, since things can go badly wrong if 
                // any strange zero-length packets start to arrive at the same time as they leave.
                int packetSize = thing.packet.GetPacketSize() + (int)Globals.PhysicalHeaderSize;  // in bytes
                long LocalTimeWhenFinished = node.GetTime() + (long)(packetSize * 8 * 1.0e9 / thing.packet.MetaInformation().GetBitRate());
                if (packetSize == 0) LocalTimeWhenFinished += Globals.OneJiffy;
                long GlobalTimeWhenFinished = node.ConvertLocalToGlobalTime(LocalTimeWhenFinished);

                // Check the channel to transmit on, and set the packet accordingly:
                int channelToSendPacketOn = node.GetTransmitChannel();
                thing.packet.MetaInformation().SetChannel(channelToSendPacketOn);

                foreach (cNode receiver in Globals.myNodes)
                {
                    if (receiver != node && receiver.GetReceiveChannel() == channelToSendPacketOn)
                    {
                        // Packets are now only copied on successful reception to save time,
                        // this means that the receivedPower in thing.D cannot be set yet.
                        cPacket copy = thing.packet;

                        // And the receive power will depend on where the destination node is, as well
                        // as the transmit power handed down from the MAC layer.
                        double transmitPower = thing.D; // Contains transmit power from MAC layer
                        double receivedPower = transmitPower / Globals.PathLosses[node.GetNumber(), receiver.GetNumber()];

                        int bitRate = thing.A;
                        // Work out the distance, and hence time of flight:
                        double sqdist = (receiver.GetPosition().X - node.GetPosition().X) * (receiver.GetPosition().X - node.GetPosition().X)
                            + (receiver.GetPosition().Y - node.GetPosition().Y) * (receiver.GetPosition().Y - node.GetPosition().Y);
                        long propDelay = (long)(Math.Sqrt(sqdist) * 100 / 3e8 * 1e9);

                        // Queue the start to arrive and finish arriving events at the receiver.  This is a little
                        // tricky, since the receiver's clock might be different from the transmitter's clock, and
                        // both times have to be local to the node registering the event.
                        // In events, A = bit rate, B = channel, C = transmitter, D = received power
                        Globals.theQueue.AddEvent(new cEvent(receiver, copy, 
                            receiver.ConvertGlobalToLocalTime(Globals.SimTime) + propDelay,
                            EventType.Physical_StartToArriveFromBelow, bitRate, channelToSendPacketOn, myNumber, receivedPower));
                        Globals.theQueue.AddEvent(new cEvent(receiver, copy, 
                            receiver.ConvertGlobalToLocalTime(GlobalTimeWhenFinished) + propDelay,
                            EventType.Physical_FinishArriving, bitRate, channelToSendPacketOn, myNumber, receivedPower));
                        if (Globals.LogEventsOn == true)
                            OutToLog("  Physical: Packet copied and sent to node " + receiver.GetNumber().ToString() 
                                + " to arrive from local time " 
                                + (receiver.ConvertGlobalToLocalTime(Globals.SimTime) + propDelay).ToString()
                                + " to "
                                + (receiver.ConvertGlobalToLocalTime(GlobalTimeWhenFinished) + propDelay).ToString(),
                                false);
                    }
                }
                node.SetTransmitState(Globals.TransmitterState.Transmitting, 
                    thing.packet.MetaInformation().GetTransmitPower(), thing.packet, LocalTimeWhenFinished);

                // If the receiver is on the same channel, then switch it off:
                if (node.GetReceiveChannel() == node.GetTransmitChannel())
                    node.SetReceiveState(Globals.ReceiverState.Off, thing.packet, 0.0, 0.0, false);

                // And queue an event for the end of the packet transmission:
                Globals.theQueue.AddEvent(new cEvent(node, thing.packet, LocalTimeWhenFinished, 
                    EventType.Physical_PacketTransmissionFinished));
            }
            else if (thing.type == EventType.Physical_PacketTransmissionFinished)
            {
                // At the moment, just stop transmitting, and go back to transmit state idle:
                node.SetTransmitState(Globals.TransmitterState.Off, 0.0, null, 0);
                if (Globals.LogEventsOn == true)
                    OutToLog("  Physical: Node " + node.GetNumber().ToString() + " finishes transmission", true);

                // What about the receiver?  It depends on what the current receive
                // power is, it could be detecting or listening:
                if (node.CurrentTotalReceivedPower > DetectSINR * Globals.NoiseFloor)
                    node.SetReceiveState(Globals.ReceiverState.Detecting, null, 0.0, 0.0, false);
                else
                    node.SetReceiveState(Globals.ReceiverState.Listening, null, 0.0, 0.0, false);
            }
            else if (thing.type == EventType.Physical_StartToArriveFromBelow)
            {
                // In the event, A is the bit rate, B the channel, and D the receive power.
                // If packet is on a different channel, ignore it:
                if (thing.B != node.GetReceiveChannel()) return;

                // If not, then the total received power will increase due to this new packet:
                double newPacketReceivedPower = thing.D;
                node.CurrentTotalReceivedPower += newPacketReceivedPower;

                // If the node is currently transmitting on the same channel, then just ignore 
                // this.  I can't do both.
                if (node.GetTransmitState() == Globals.TransmitterState.Transmitting
                    && node.GetTransmitChannel() == node.GetReceiveChannel())
                {
                    if (Globals.LogEventsOn == true)
                        OutToLog("  Physical: Packet ignored, since it starts to arrive while transmitting in progress", true);
                    return;
                }
                // Similarly, if the node is currently asleep, then ignore this.
                if (node.GetReceiveState() == Globals.ReceiverState.Asleep)
                {
                    if (Globals.LogEventsOn == true)
                        OutToLog("  Physical: Arriving packet ignored, since node is currently asleep", true);
                    return;
                }
                // Otherwise, calculate the SINR for this new packet, and the new SINR for continuing
                // to receive the current packet (if a packet is currently being received):
                double SINRNew = newPacketReceivedPower
                        / (node.CurrentTotalReceivedPower - newPacketReceivedPower + Globals.NoiseFloor);
                double SINRExisting = 0.0;
                if (node.GetPacketBeingReceived() != null)
                {
                    // Packet being received is not the one that's just arrived:
                    double signalPower = node.GetPacketBeingReceivedPower();
                    SINRExisting = signalPower
                        / (node.CurrentTotalReceivedPower - signalPower + Globals.NoiseFloor);
                }
                // I also need to know what SINR is required to receive this packet, based on the bit 
                // rate being used to send it.  I'll then allow node to attempt to receive up to three
                // dB below this: it is possible that a small frame might get through at this level.
                double SINRRequiredToStart = Globals.GetRequiredSINR(thing.packet) / 2;
                // And to pre-empt, you need at least 6 dB more than the existing SINR
                double SINRRequiredToPreempt = SINRExisting * 4;
                // And when this packet is due to end:
                double bitRate = thing.A; // was packet.MetaInformation().GetBitRate();
                long LocalTimeWhenFinished = node.GetTime() 
                    + (long)(thing.packet.GetPacketSize() * 8 * 1.0e9 / bitRate + Globals.OneJiffy);

                // I've now got eight possibilities:
                // a) The node was in a listening or detecting state and the new SINR is enough to start receiving
                // b) The node was in a listening state and the new SINR is not enough to start detecting
                // c) The node was in a listening state and the new SINR is enough to start detecting
                // d) The node was in a detecting state and the new SINR is not enough to start receiving
                // e) The node was in a receiving state and the new SINR is enough to cause preemption
                // f) The node was in a receiving state and the new SINR is enough to cause collision
                // g) The node was in a receiving state and the new SINR is not enough to allow collision
                // h) The node was in a colliding state and the new SINR is enough to start new preemptive reception
                // i) The node was in a colliding state and the new SINR is not enough to start new preemptive reception
                //
                // I'll go through these cases in turn:
                if ((node.GetReceiveState() == Globals.ReceiverState.Listening
                    || node.GetReceiveState() == Globals.ReceiverState.Detecting)
                    && SINRNew >= SINRRequiredToStart)
                {
                    // a) listening or detecting, and able to start receiving:
                    node.SetReceiveState(Globals.ReceiverState.Receiving, thing.packet, SINRNew, thing.D, false);
                    if (Globals.LogEventsOn == true)
                        OutToLog("  Physical: Attempting to receive " + thing.packet.ToString() + " with SINR " + (10 * Math.Log10(SINRNew)).ToString("0.000") + " dB", true);
                }
                else if (node.GetReceiveState() == Globals.ReceiverState.Listening 
                    && SINRNew < DetectSINR)
                {
                    // b) listening, and not able to start detecting:
                    if (Globals.LogEventsOn == true)
                        OutToLog("  Physical: Unable to start to receive packet with SINR " + (10 * Math.Log10(SINRNew)).ToString("0.000") + " dB", true);
                }
                else if (node.GetReceiveState() == Globals.ReceiverState.Listening 
                    && SINRNew >= DetectSINR)
                {
                    // c) listening, and enough to start detecting:
                    node.SetReceiveState(Globals.ReceiverState.Detecting, thing.packet, SINRNew, thing.D, false);
                    if (Globals.LogEventsOn == true)
                        OutToLog("  Physical: Detecting a packet, but unable to receive with SINR " + (10 * Math.Log10(SINRNew)).ToString("0.000") + " dB", true);
                }
                else if (node.GetReceiveState() == Globals.ReceiverState.Detecting
                    && SINRNew < SINRRequiredToStart)
                {
                    // d) detecting, and not enough to start receiving:
                    if (Globals.LogEventsOn == true)
                        OutToLog("  Physical: Detecting another packet, but still unable to receive with SINR " + (10 * Math.Log10(SINRNew)).ToString("0.000") + " dB", true);
                    // No need to change state, I'm still detecting...
                }
                else if (node.GetReceiveState() == Globals.ReceiverState.Receiving && SINRNew >= SINRRequiredToPreempt)
                {
                    // e) receiving, and enough to cause preemption:
                    if (Globals.LogEventsOn == true)
                        OutToLog("  Physical: New packet arriving with SINR " + (10 * Math.Log10(SINRNew)).ToString("0.000") + " dB", true);
                    // If pre-emption is on, I can start receiving this new packet; if not
                    // this will cause a collision.
                    if (Globals.PhysicalStyle == Globals.PhysicalType.Preemptive)
                    {
                        node.SetReceiveState(Globals.ReceiverState.Receiving, thing.packet, SINRNew, thing.D, false);
                        if (Globals.LogEventsOn == true)
                            OutToLog("  Physical: Preemption by " + thing.packet.ToString(), true);
                    }
                    else
                    {
                        node.SetReceiveState(Globals.ReceiverState.Colliding, null, SINRExisting, 0.0, false);
                        if (Globals.LogEventsOn == true)
                            OutToLog("  Physical: Collision caused by " + thing.packet.ToString(), true);
                    }
                }
                else if (node.GetReceiveState() == Globals.ReceiverState.Receiving
                            && SINRNew < SINRRequiredToPreempt && SINRExisting < SINRRequiredToStart)
                {
                    // f) receiving, and not enough to cause preemption, but enough to cause collision:
                    node.SetReceiveState(Globals.ReceiverState.Colliding, null, SINRExisting, 0.0, false);
                    if (Globals.LogEventsOn == true)
                        OutToLog("  Physical: Collision caused by " + thing.packet.ToString() + " SINR is now " + (10 * Math.Log10(SINRNew)).ToString("0.000") + " dB", true);
                }
                else if (node.GetReceiveState() == Globals.ReceiverState.Receiving && SINRExisting >= SINRRequiredToStart)
                {
                    // g) receiving, and not enough to cause collision, but SINR changes, so:
                    // reset state so that the PHY output tab updates its excess SINR field:
                    node.SetReceiveState(Globals.ReceiverState.Receiving, node.GetPacketBeingReceived(), 
                        SINRExisting, node.GetPacketBeingReceivedPower(), false);
                    if (Globals.LogEventsOn == true)
                        OutToLog("  Physical: New packet arrived but not strong enough to disturb reception, SINR is now " + (10 * Math.Log10(SINRExisting)).ToString("0.000") + " dB", true);
                    // No need to change state, I'm still receiving...
                }
                else if (node.GetReceiveState() == Globals.ReceiverState.Colliding && SINRNew >= SINRRequiredToStart)
                {
                    // h) colliding, and enough to start a preemptive reception.  The idea here 
                    // is that a node once in colliding state will stop receiving, and effectively 
                    // go back to listening state, waiting for a strong enough signal to start 
                    // receiving.  There's a slight problem here: the original frame could still be
                    // received, but it's so unlikely in this situation that I won't worry about it.
                    node.SetReceiveState(Globals.ReceiverState.Receiving, thing.packet, SINRNew, thing.D, false);
                    if (Globals.LogEventsOn == true)
                    {
                        OutToLog("  Physical: New packet arriving with SINR " + (10 * Math.Log10(SINRNew)).ToString("0.000") + " dB", true);
                        OutToLog("  Physical: Starting to receive " + thing.packet.ToString(), true);
                    }
                }
                else if (node.GetReceiveState() == Globals.ReceiverState.Colliding && SINRNew < SINRRequiredToStart)
                {
                    // i) colliding, and not enough to start a preemption reception
                    // but reset state so that PHY output tab excess SINR field is updated:
                    node.SetReceiveState(Globals.ReceiverState.Colliding, node.GetPacketBeingReceived(), 
                        SINRExisting, node.GetPacketBeingReceivedPower(), false);
                    if (Globals.LogEventsOn == true)
                        OutToLog("  Physical: New packet arrived but not enough to preempt collision state", true);
                    // No need to change state, I'm still receiving...
                }
                else
                {
                    // Error: something very odd must have happened.
                    Globals.ShowMessageBox("Unexpected event at physical layer receiver.\n" + 
                        "Have you got two nodes in the same place?", "Unexpected Error");
                }
            }
            else 
            {
                MessageBox.Show("Problem: Physical layer called with event " + thing.ToString(), "Serious Error");
            }
        }
    }
    #endregion
}
