﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;

namespace DANSE_v4
{
    [Serializable] class cPacket
    {
        //   Note that headers are classes containing structures (as Objects) and the 
        // size as a separate integer.  This is because MemoryStreams have lots of 
        // metadata and are much bigger than the structures they represent.  The size 
        // parameter is the size the header would be if composed of the data, and 
        // nothing else.
        //   Packets can have defined content, in which case they should be created
        // with a pointer to a byte array containing the content in the form of a 
        // lot of 8-bit characters.  (It's not a char array since in C# a char is 
        // a 16-bit field.  A bit confusing this for C programmers.)

        //   In terms of stored fields, a packet is a bodySize; a byte array of
        // (at least) this size (which might be null if no content is defined);
        // a list of headers (each of which know their own size); and some metadata
        // in a cMetaPacket:
        private int bodySize;
        private object content = null;
        private List<cHeader> headers = new List<cHeader>();
        private cMetaPacket metaInformation;

        // A class for headers, and the list of headers that every packet
        // has.
        [Serializable] internal class cHeader
        {
            private Object header;       // Whatever struct type the header is
            private int size;            // Size in bytes (with no metadata)

            // There are two constructors: one for new headers, and one to
            // copy headers, used as part of the copy packet routines at 
            // the physical and reliable layers.

            internal cHeader(Object newheader, int newsize)
            {
                this.header = newheader;
                this.size = newsize;
            }
            /* Following function deleted in favour of the DeepCopy method
            internal cHeader(cHeader OrigHeader)
            {
                this.header = OrigHeader.header;
                this.size = OrigHeader.size;
            } */
            internal Object GetHeader () { return header; }
            internal int GetSize() { return size; }
        }

        // A .ToString override function for printing and toolbox help:
        public override string ToString()
        {
            StringBuilder Description = new StringBuilder(256);
            Description.Append("Packet number " + metaInformation.GetSystemNumber().ToString());
            Description.Append(" (priority " + metaInformation.GetPriority().ToString() + ")");
            Description.Append(" size " + GetPacketSize().ToString());
            if (headers.Count == 1) Description.Append(" with 1 header");
            else Description.Append(" with " + headers.Count.ToString() + " headers");
            Description.Append(" sent from " + metaInformation.GetOriginalSource().ToString());
            int FinalDest = metaInformation.GetFinalDestination();
            if (FinalDest != Globals.BROADCAST && FinalDest != Globals.NOWHERE)
                Description.Append(" to " + FinalDest.ToString());
            int LastHop = metaInformation.GetLastHop();
            if (LastHop != Globals.BROADCAST && LastHop != Globals.NOWHERE) 
                Description.Append(" last hop " + LastHop.ToString());
            int NextHop = metaInformation.GetNextHop();
            if (NextHop != Globals.BROADCAST && NextHop != Globals.NOWHERE)
                Description.Append(" next hop " + metaInformation.GetNextHop().ToString());
            else if (NextHop == Globals.BROADCAST)
                Description.Append(" broadcast");

            return Description.ToString();
        }

        // There's also some metadata that accompanies every packet that can be used
        // for cross-layer information, or diagnosis / performance analysis.  In the
        // built-in routines, it should only be used for debugging or error detection.
        [Serializable] internal class cMetaPacket
        {
            int Channel;            // Set by physical layer when transmitted
            int OriginalSource;     // Added by cApplication when packet generated
            int FinalDestination;   // Added by cApplication when packet generated
            long WhenGenerated;     // Added by cApplication when packet generated
            int SourcePort;         // Source port number, added by cApplication
            int DestinationPort;    // Destination port number, added by cApplication
            int SystemNumber;       // Unique number identifying packet, added by cApplication when generated
            int TransportRetries;   // Updated by transport layer (at least internal reliable option)
            int LogicalLinkRetries; // Updated by logical-link layer when packet transmitted
            int NextHop;            // Updated by MAC layer when packet addressed
            int LastHop;            // Updated by MAC layer when packet addressed
            int Priority;           // Set by whichever layer creates the packet
            Boolean RxSuccess;      // Updated by physical layer when packet received
            double RxPower;         // Updated by physical layer when packet received
            double TxPower;         // Updated by physical layer when packet transmitted
            double BitRate;         // Updated by physical layer when packet transmitted
            Object CrossLayer;      // Used to send cross-layer information between layers
            string Tag;             // Short info to print when packet is displayed
            List<int> Route = new List<int>();  // Keeps a note of the route, initialised by application
                                                // layer and updated by physical layer, so users 
                                                // don't have to worry about it.

            // Constructor clears everything or sets to defaults:
            internal cMetaPacket(int sourceNode)
            {
                Channel = Globals.myNodes[sourceNode].GetTransmitChannel();
                OriginalSource = sourceNode;
                FinalDestination = Globals.NOWHERE;
                SourcePort = 0;
                DestinationPort = 0;
                WhenGenerated = Globals.SimTime;
                TransportRetries = 0;
                NextHop = Globals.NOWHERE;
                LastHop = sourceNode;
                LogicalLinkRetries = 0;
                Priority = 0;
                RxSuccess = false;
                RxPower = 0.0;
                TxPower = Math.Pow(10,(Globals.DefaultTxPowerdBm - 30.0)/10.0);
                CrossLayer = 0.0;
                BitRate = Globals.DefaultBitRate;
                Route.Clear();
                Route.Add(sourceNode);
                SystemNumber = 0;
                Tag = "";
            }

            // And some routines for interrogating the contents by user routines:
            internal int GetChannel() { return this.Channel; }
            internal int GetSystemNumber() { return this.SystemNumber; }
            internal int GetFinalDestination() {return this.FinalDestination; }
            internal int GetOriginalSource() { return this.OriginalSource; }
            internal long GetWhenGenerated() { return this.WhenGenerated; }
            internal int GetSourcePort() { return this.SourcePort; }
            internal int GetDestinationPort() { return this.DestinationPort; }
            internal int GetLastHop() { return this.LastHop; }
            internal int GetNextHop() { return this.NextHop; }
            internal int GetTransportRetries() { return this.TransportRetries; }
            internal int GetLogicalLinkRetries() { return this.LogicalLinkRetries; }
            internal int GetPriority() { return this.Priority; }
            internal double GetReceivedPower() { return this.RxPower; }
            internal Boolean DidReceiveSucceed() { return this.RxSuccess; }
            internal double GetTransmitPower() { return this.TxPower; }
            internal Object GetCrossLayer() { return this.CrossLayer; }
            internal double GetBitRate() { return this.BitRate; }
            internal string GetTag() { return this.Tag; }
            internal void SetChannel(int x) { this.Channel = x; }
            internal void SetSystemNumber(int x) { this.SystemNumber = x; }
            internal void SetFinalDestination(int x) { this.FinalDestination = x; }
            internal void SetOriginalSource(int x) { this.OriginalSource = x; }
            internal void SetDestinationPort(int x) { this.DestinationPort = x; }
            internal void SetWhenGenerated(long x) { this.WhenGenerated = x; }
            internal void SetSourcePort(int x) { this.SourcePort = x; }
            internal void SetLastHop(int x) { this.LastHop = x; }
            internal void SetNextHop(int x) { this.NextHop = x; }
            internal void SetTransportRetries(int x) { this.TransportRetries = x; }
            internal void SetLogicalLinkRetries(int x) { this.LogicalLinkRetries = x; }
            internal void SetPriority(int x) { this.Priority = x; }
            internal void SetIfRxSucceeded(Boolean success) { this.RxSuccess = success; }
            internal void SetReceivedPower(double x) { this.RxPower = x; }
            internal void SetTransmitPower(double x) { this.TxPower = x; }
            internal void SetCrossLayer(Object x) { this.CrossLayer = x; }
            internal void SetBitRate(double x) { this.BitRate = x; }
            internal void SetTag(string x) { this.Tag = x; }
            internal void AddHopToRoute(int x) { Route.Add(x); }
            internal List<int> GetRoute() { return Route; }
        }
        internal cMetaPacket MetaInformation() { return this.metaInformation; }
        
        // The constructor starts from just the data (of known size) and the source node:
        internal cPacket(int size, int sourceNode, int ThisSystemNumber)
        {
            this.headers.Clear();
            this.bodySize = size;
            this.content = null;
            this.metaInformation = new cMetaPacket(sourceNode);
        }
        internal cPacket(int size, int sourceNode, object content, int ThisSystemNumber)
        {
            this.headers.Clear();
            this.bodySize = size;
            this.content = content;
            this.metaInformation = new cMetaPacket(sourceNode);
        }

        /* XXX The following function removed in favour of the DeepCopy method
        internal cPacket(cPacket existing)
        {
            // Copy the packet size and content (if any exists, sometimes packets
            // are defined without any content to save time).
            this.bodySize = existing.bodySize;
            if (existing.content != null)
            {
                this.content = new byte[bodySize];
                if (existing.content != null)
                    Array.Copy(existing.content, this.content, this.bodySize);
            }

            // Copy all the headers:
            this.headers.Clear();
            foreach (cHeader header in existing.headers)
            {
                cHeader NewHeader = new cHeader(header);
                this.AddHeader(NewHeader);
            }

            // And copy the metadata:
            this.metaInformation = new cMetaPacket(existing.metaInformation);
        }*/

        // I can add, view and remove headers, and retrieve a pointer to 
        // the content.  (If something does not exist, then null is returned.)
        internal void AddHeader(cHeader newheader)
        {
            headers.Add(newheader);
        }
        internal void AddHeader(Object contents, int SizeInBytes)
        {
            cHeader newheader = new cHeader(contents, SizeInBytes);
            headers.Add(newheader);
        }
        internal Object ViewHeader()
        {
            if (this.headers.Count == 0) return null;
            int LastHeaderNumber = this.headers.Count - 1;
            return this.headers[LastHeaderNumber].GetHeader();
        }
        internal Object ViewHeader(int whichHeader)
        {
            if (this.headers.Count <= whichHeader) return null;
            return this.headers[whichHeader].GetHeader();
        }
        internal Object RemoveHeader()
        {
            if (this.headers.Count == 0) return null;
            int LastHeaderNumber = this.headers.Count - 1;
            Object LastHeader = this.headers[LastHeaderNumber].GetHeader();
            this.headers.Remove(this.headers[LastHeaderNumber]);
            return LastHeader;
        }
        internal int HowManyHeaders() { return this.headers.Count; }
        internal Type GetHeaderType() { return this.headers[headers.Count - 1].GetHeader().GetType(); }
        internal object ViewContents()
        {
            //   This is a bit of a funny one, it's not quite as obvious as it might
            // appear, since anyone wanting to look at the contents can't just see
            // the application layer contents, they should get the contents of the
            // packet at the corresponding layer: for example Viewcontents if called
            // by a Network layer function should return the transport layer header
            // and the application contents.
            //   If they want to see the actual contents, they need to remove all 
            // headers, then look, then put the headers back again.  This should
            // discourage people from trying to do this.
            //   For now, I'll throw an error if someone is asking to see the contents
            // of a packet with more than one header.
            if (this.headers.Count > 1)
            {
                MessageBox.Show("This layer can't see inside this packet.", "User error");
            }
            return this.content;
        }

        // I can also return the size of the entire packet, including all 
        // the headers added so far (required so I can work out how long
        // it takes to transmit the thing, and at what energy cost).
        internal int GetPacketSize()
        {
            int TotalSize = bodySize;
            foreach (cHeader header in headers) TotalSize += header.GetSize();
            return TotalSize;
        }

        // For fragmentation: need to be able to get and set the payload size
        internal int GetPayloadSize() { return this.bodySize; }
        internal void SetPayloadSize(int x) { this.bodySize = x; }

        /* Fragmentation: this just fragments packets assuming that all headers
        // fit in the first fragment.  If this is not true, then this simple
        // scheme does not work, and the function will return null.
        internal List<cPacket> FragmentPacket(int fragmentSize)
        {
            // First, check that all headers fit in one fragment
            int headersSize = 0;
            for (int loop = 0; loop < HowManyHeaders(); loop++)
                headersSize += headers[loop].GetSize();
            if (headersSize > fragmentSize)
            {
                Globals.ShowMessageBox("All headers do not fit in first fragment."
                    + "\nThis means the fragmentation algorithm will fail", 
                    "Fragmentation problem");
                return null;
            }
            // Set up a list of packets to reply, and get data required:
            List<cPacket> fragments = new List<cPacket>();
            int sourceNode = this.metaInformation.GetOriginalSource();
            int systemNumber = this.metaInformation.GetSystemNumber();

            // OK, now divide up the packet, first generate the first fragment:
            cPacket first = DeepCopy(this);
            first.bodySize = (this.GetPacketSize() > fragmentSize) ? fragmentSize - headersSize : this.bodySize;

            int bytesLeft = this.bodySize - first.bodySize;
            fragments.Add(first);

            // If there is only one fragment:
            if (bytesLeft <= 0) return fragments;

            // otherwise we need some more fragments:
            while (bytesLeft > 0)
            {
                cPacket next;
                if (bytesLeft > fragmentSize) next = new cPacket(fragmentSize, sourceNode, systemNumber);
                else next = new cPacket(bytesLeft, sourceNode, systemNumber);
                fragments.Add(next);
                bytesLeft -= fragmentSize;
            }
            return fragments;
        } */

        // When transmitting a packet, a different copy is required for
        // all the nodes that receive the packet.  This requires a deep
        // copy.  This is difficult since the packet structure doesn't 
        // know the types of the headers.
        // For now, I'll use a serializer: slow, but does the job.  I'll
        // try and find a faster way to do this later.
        // (Thanks to Kilhoffer for the code he posted.)
        internal static cPacket DeepCopy(cPacket obj)
        {
            try // This doesn't always work, perhaps a memory problem?
            {
                using (var ms = new System.IO.MemoryStream())
                {
                    var formatter = new System.Runtime.Serialization.Formatters.Binary.BinaryFormatter();
                    formatter.Serialize(ms, obj);
                    ms.Position = 0;
                    return (cPacket)formatter.Deserialize(ms);
                }
            }
            catch
            {
                MessageBox.Show("Packet copy failure."
                    + "\nDid you forget to put a [Serializable] tag on a header structure or class?"
                    + "\nOtherwise this is usually the first symptom of an out-of-memory problem.");
                // Always remember to test result for null, and if so,
                // give a warning and end the simulation.
                return null; 
            }
        }
    }
}
